'use client';
import VeloRow from './VeloRow';
import VeloCard from './VeloCard';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import DragTh from '@/components/ui/DragTh';
import { useInventaire } from '@/hooks/useInventaire';
import { useColOrder } from '@/hooks/useColOrder';

const COLS = [
  { id: 'id',     header: 'bons de travail', hCls: 'px-3 py-2' },
  { id: 'velo',   header: 'vélos',           hCls: 'px-3 py-2' },
  { id: 'client', header: 'clients',         hCls: 'px-3 py-2' },
  { id: 'eval',   header: 'évaluation',      hCls: 'px-3 py-2' },
  { id: 'meca',   header: 'mécanique',       hCls: 'px-3 py-2' },
  { id: 'ctrl',   header: 'contrôle',        hCls: 'px-3 py-2' },
  { id: 'recu',   header: 'date IN',         hCls: 'px-3 py-2' },
] as const;

export type VeloColId = typeof COLS[number]['id'];

export default function VeloTable() {
  const { velos, isLoading, error } = useInventaire();
  const { orderedCols, dragProps, dragOverId } = useColOrder('inventaire', COLS as any);

  if (isLoading) return <LoadingSpinner className="py-20" />;
  if (error)     return <p className="p-6 text-red-600">Erreur : {error.message}</p>;
  if (!velos.length) return <p className="p-6 text-gray-400 text-sm">Aucun vélo en inventaire.</p>;

  // Clients considérés "staff" — leurs vélos sont grisés et relégués en fin
  // de liste avec un séparateur. Le BDT de ces vélos passe en mode cost par
  // défaut (cf. BDCPanel).
  const STAFF_CLIENTS = ['Jean-Christophe Yacono'];
  const isStaffVelo = (client: string) => STAFF_CLIENTS.includes(client.trim());

  const sortByDate = (a: typeof velos[0], b: typeof velos[0]) => {
    const da = a.date1 ?? '';
    const db = b.date1 ?? '';
    return da.localeCompare(db);
  };
  const clientVelos = velos.filter(v => !isStaffVelo(v.client)).sort(sortByDate);
  const staffVelos  = velos.filter(v =>  isStaffVelo(v.client)).sort(sortByDate);

  // Groupement partagé desktop + mobile : NOUVEAU (RV + REÇU + ÉVAL.) / WIP / Facturé / Staff
  // ÉVAL. déplacé dans NOUVEAU le 2026-05-16 (jaune, cohérent avec RV/REÇU).
  const NOUVEAU_SET = new Set(['RV', 'REÇU', 'ÉVAL.']);
  const WIP_SET   = new Set(['APPROUVÉ', 'ON BENCH', 'CTRL QLTÉ', 'FINI']);
  const FACT_SET  = new Set(['FACTURER', 'FACTURÉ', 'LIVRÉ']);
  const nouveau = clientVelos.filter(v => NOUVEAU_SET.has(v.status));
  const wip    = clientVelos.filter(v => WIP_SET.has(v.status));
  const fact   = clientVelos.filter(v => FACT_SET.has(v.status));
  // Fallback : vélos sans statut connu — on les met dans WIP pour ne pas les perdre
  const autres = clientVelos.filter(v =>
    !NOUVEAU_SET.has(v.status) && !WIP_SET.has(v.status) && !FACT_SET.has(v.status)
  );

  const nCols = orderedCols.length;
  const separatorRow = (key: string, label: string) => (
    <tr key={`sep-${key}`}>
      <td
        colSpan={nCols}
        style={{
          padding: '2px 8px 2px',
          fontSize: '11px',
          fontWeight: 700,
          letterSpacing: '0.08em',
          textTransform: 'uppercase',
          color: 'rgba(255,255,255,0.6)',
          textAlign: 'left',
        }}
      >
        {label} ───
      </td>
    </tr>
  );

  return (
    <>
      {/* ── DESKTOP : table groupée par statut ── */}
      <div className="hidden md:block overflow-x-auto" style={{ borderCollapse: 'separate', borderSpacing: '0 4px' }}>
        <table className="w-full text-left" style={{ borderCollapse: 'separate', borderSpacing: '0 10px' }}>
          <thead>
            {/* Cluster 10 : retire le fond blanc/50 de .list-header sur
                l'inventaire seulement (le main panel passe en noir 20% donc
                la légende doit être transparente). On force backgroundColor
                'transparent' inline pour override le CSS global. */}
            <tr className="list-header" style={{ backgroundColor: 'transparent', color: 'rgba(255,255,255,0.7)' }}>
              {orderedCols.map(col => (
                <DragTh key={col.id} className={col.hCls} isDragOver={dragOverId === col.id} {...dragProps(col.id)}>
                  <div className="flex items-center justify-between gap-2">
                    <span>{col.header}</span>
                    <span style={{ color: '#ffffff', fontSize: '16px', flexShrink: 0 }}>→</span>
                  </div>
                </DragTh>
              ))}
            </tr>
          </thead>
          <tbody>
            {nouveau.length > 0 && separatorRow('nouveau', 'Nouveau')}
            {nouveau.map(v => (
              <VeloRow key={v.id} velo={v} colOrder={orderedCols.map(c => c.id) as VeloColId[]} />
            ))}

            {(wip.length > 0 || autres.length > 0) && separatorRow('wip', 'WIP')}
            {wip.map(v => (
              <VeloRow key={v.id} velo={v} colOrder={orderedCols.map(c => c.id) as VeloColId[]} />
            ))}
            {autres.map(v => (
              <VeloRow key={v.id} velo={v} colOrder={orderedCols.map(c => c.id) as VeloColId[]} />
            ))}

            {fact.length > 0 && separatorRow('fact', 'Facturé')}
            {fact.map(v => (
              <VeloRow key={v.id} velo={v} colOrder={orderedCols.map(c => c.id) as VeloColId[]} />
            ))}

            {staffVelos.length > 0 && separatorRow('staff', 'Staff')}
            {staffVelos.map(v => (
              <VeloRow key={v.id} velo={v} colOrder={orderedCols.map(c => c.id) as VeloColId[]} isStaff />
            ))}
          </tbody>
        </table>
      </div>

      {/* ── MOBILE : cards groupées par statut (NOUVEAU / WIP / Facturé / Staff) ── */}
      {(() => {
        // Groupement par statut — ÉVAL. dans NOUVEAU (cohérent avec desktop)
        const NOUVEAU_SET  = new Set(['RV', 'REÇU', 'ÉVAL.']);
        const WIP_SET      = new Set(['APPROUVÉ', 'ON BENCH', 'CTRL QLTÉ', 'FINI']);
        const FACT_SET     = new Set(['FACTURER', 'FACTURÉ', 'LIVRÉ']);

        const nouveau = clientVelos.filter(v => NOUVEAU_SET.has(v.status));
        const wip   = clientVelos.filter(v => WIP_SET.has(v.status));
        const fact  = clientVelos.filter(v => FACT_SET.has(v.status));
        // Fallback : vélos sans statut connu (jamais vu en prod) — on les
        // place dans WIP pour ne pas les perdre.
        const autres = clientVelos.filter(v =>
          !NOUVEAU_SET.has(v.status) && !WIP_SET.has(v.status) && !FACT_SET.has(v.status)
        );

        const separator = (label: string) => (
          <div style={{
            padding: '2px 8px 2px',
            fontSize: '11px',
            fontWeight: 700,
            letterSpacing: '0.08em',
            textTransform: 'uppercase',
            color: 'rgba(255,255,255,0.6)',
            textAlign: 'left',
          }}>
            {label} ───
          </div>
        );

        return (
          <div className="md:hidden flex flex-col" style={{ gap: '20px' }}>
            {nouveau.length > 0 && (
              <>
                {separator('Nouveau')}
                {nouveau.map(v => <VeloCard key={v.id} velo={v} />)}
              </>
            )}
            {(wip.length > 0 || autres.length > 0) && (
              <>
                {separator('WIP')}
                {wip.map(v => <VeloCard key={v.id} velo={v} />)}
                {autres.map(v => <VeloCard key={v.id} velo={v} />)}
              </>
            )}
            {fact.length > 0 && (
              <>
                {separator('Facturé')}
                {fact.map(v => <VeloCard key={v.id} velo={v} />)}
              </>
            )}
            {staffVelos.length > 0 && (
              <>
                {separator('Staff')}
                {staffVelos.map(v => <VeloCard key={v.id} velo={v} isStaff />)}
              </>
            )}
          </div>
        );
      })()}
    </>
  );
}
