'use client';
import { useState, useMemo } from 'react';
import BarcodeScanner from '@/components/ui/BarcodeScanner';
import QuickReceiveModal from './QuickReceiveModal';
import PieceForm from '@/components/catalogue/PieceForm';
import { usePieces } from '@/hooks/useCatalogue';
import type { Piece } from '@/types/catalogue';

/**
 * Flow complet de scan rapide ad-hoc :
 *
 *   [BarcodeScanner ouvert]
 *           ↓ scan d'un code-barres
 *   match catalogue (sku ou codeBarre) ?
 *           ├─ OUI → [QuickReceiveModal] : qte/fournisseur/prix → POST adhoc-receive
 *           └─ NON → [PieceForm pré-rempli avec codeBarre] : crée la pièce
 *                       → puis QuickReceiveModal sur la pièce nouvellement créée
 *
 * Ouvert depuis le big menu (`/menu`). Ferme le BarcodeScanner pendant
 * la modale de réception, le réouvre quand l'utilisateur ferme la modal
 * (continuer à scanner).
 */

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function QuickScanFlow({ open, onClose }: Props) {
  const { pieces, mutate, patchPiece } = usePieces();

  // État du flow (4 phases) :
  //   - scanning : BarcodeScanner ouvert
  //   - receiving : QuickReceiveModal ouvert (pièce trouvée)
  //   - creating : PieceForm ouvert (pièce inconnue, création)
  const [phase, setPhase]               = useState<'scanning' | 'receiving' | 'creating'>('scanning');
  const [scannedCode, setScannedCode]   = useState('');
  const [matchedPiece, setMatchedPiece] = useState<Piece | null>(null);
  const [scanMessage, setScanMessage]   = useState('');

  // Liste des fournisseurs et catégories pour les modals
  const fournisseurs = useMemo(
    () => [...new Set(pieces.map(p => p.fournisseur).filter(Boolean))].sort(),
    [pieces],
  );
  const categories = useMemo(
    () => [...new Set(pieces.map(p => p.categorie).filter(Boolean))].sort(),
    [pieces],
  );

  function handleScan(code: string) {
    const normalized = code.trim();
    if (!normalized) return;

    setScannedCode(normalized);

    // Match catalogue par sku OU codeBarre (un scan EAN ↔ codeBarre,
    // un scan Code128 ↔ sku). Match exact d'abord, puis casse-insensible.
    const exact = pieces.find(p =>
      (p.sku && p.sku === normalized) ||
      (p.codeBarre && p.codeBarre === normalized)
    );
    const fuzzy = exact ?? pieces.find(p =>
      (p.sku && p.sku.toLowerCase() === normalized.toLowerCase()) ||
      (p.codeBarre && p.codeBarre.toLowerCase() === normalized.toLowerCase())
    );

    if (fuzzy) {
      setMatchedPiece(fuzzy);
      setPhase('receiving');
      setScanMessage(`✓ ${fuzzy.nom}`);
    } else {
      setMatchedPiece(null);
      setPhase('creating');
      setScanMessage(`Inconnu : ${normalized}`);
    }
  }

  function handleReceiveSuccess() {
    // Retour à scanning pour permettre des scans en chaîne
    setMatchedPiece(null);
    setScannedCode('');
    setPhase('scanning');
    mutate(); // refresh catalogue (stock mis à jour)
  }

  function handlePieceCreated(info?: { nom: string; fournisseur: string }) {
    // Après création, on relance le scan pour que la pièce nouvellement
    // créée soit matchée et ouvre QuickReceiveModal pour la qte.
    setPhase('scanning');
    mutate(); // refresh pour avoir la nouvelle pièce dans `pieces`
    // On laisse l'utilisateur re-scanner son code pour ouvrir la modal
    // de réception (plus simple que d'orchestrer la transition automatique).
    setScanMessage(`Pièce créée : ${info?.nom ?? ''} — re-scanne pour réception`);
  }

  function handleClose() {
    setPhase('scanning');
    setScannedCode('');
    setMatchedPiece(null);
    setScanMessage('');
    onClose();
  }

  return (
    <>
      <BarcodeScanner
        open={open && phase === 'scanning'}
        onClose={handleClose}
        onScan={handleScan}
        lastMessage={scanMessage}
      />

      <QuickReceiveModal
        open={open && phase === 'receiving'}
        onClose={() => setPhase('scanning')}
        piece={matchedPiece}
        scannedSku={scannedCode}
        fournisseurs={fournisseurs}
        onSuccess={handleReceiveSuccess}
      />

      <PieceForm
        open={open && phase === 'creating'}
        onClose={() => setPhase('scanning')}
        categories={categories}
        fournisseurs={fournisseurs}
        initialCodeBarre={scannedCode}
        onCreated={handlePieceCreated}
        /* v1.3.1+ (cluster suite item p) : si la pièce scannée existe
           déjà au catalogue sous un autre nom/SKU, permettre d'associer
           le code-barre à cette pièce existante (au lieu de dupliquer). */
        onSelectExisting={async (piece) => {
          try {
            await patchPiece(piece._row, { codeBarre: scannedCode });
            await mutate();  // refresh catalogue
            setMatchedPiece({ ...piece, codeBarre: scannedCode });
            setPhase('receiving');
          } catch (err: any) {
            // toast géré dans PieceForm via try/catch — on remonte juste
            throw err;
          }
        }}
      />
    </>
  );
}
