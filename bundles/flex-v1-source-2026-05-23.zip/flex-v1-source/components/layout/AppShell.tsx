'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { signOut, useSession } from 'next-auth/react';
import {
  TagIcon,
  ArrowRightOnRectangleIcon,
  Bars3Icon,
} from '@heroicons/react/24/outline';
import PriceLookupModal from '@/components/catalogue/PriceLookupModal';
import ToastContainer from '@/components/ui/Toast';
import GoogleAuthBanner from './GoogleAuthBanner';
import { NAV, LOGO_MENU, type NavItem } from '@/lib/nav';
import { usePieces } from '@/hooks/useCatalogue';
import { useInventaire } from '@/hooks/useInventaire';
import { useEquipe } from '@/hooks/useEquipe';
import { useVentes } from '@/hooks/useVentes';
import { useIsAdmin } from '@/hooks/useIsAdmin';

/** Statuts BDT qui comptent comme « actifs » (non archivés). */
const BDT_ACTIVE_STATUSES = new Set(['REÇU', 'ÉVAL.', 'APPROUVÉ', 'ON BENCH', 'CTRL QLTÉ', 'FINI', 'FACTURER']);

const APP_VERSION = 'v1.3.1';


// Dimensions constantes pour que la hauteur du bloc icône ne change pas
// entre le mode étendu et le mode réduit. Deux tailles d'items :
//   - "large" (Inventaire, Services, Pièces) : cellule 64, icône 50
//   - "small" (clients, vélos, archives)     : cellule 50, icône 30
// Pour que les icônes restent sur la MÊME ligne horizontale lors de la
// transition étendu↔réduit, chaque item a une hauteur TOTALE fixe qui
// inclut l'espace du label même en mode réduit (label caché mais place
// réservée).
const LG_CELL    = 60;
const LG_ICON    = 46;
const SM_CELL    = 40;
const SM_ICON    = 26;
const LOGOUT_CELL= 60;     // = LG_CELL (cohérence avec highlights icônes + logo)
const LABEL_H    = 24;     // hauteur réservée pour le label (même caché)
const ITEM_GAP   = 2;      // gap vertical entre items — resserré
const LOGO_LG    = 130;    // largeur du logo en mode étendu
const LOGO_SM    = 60;     // largeur du logo en mode réduit (= LG_CELL highlights)

// Hauteurs FIXES des blocs top (logo) et bottom (compte+déconnexion) pour
// que la zone de navigation au centre ait toujours la même hauteur dispo,
// peu importe que le menu soit étendu ou réduit. Sans ça, le `flex-1
// justify-center` de la nav positionne les icônes différemment selon la
// présence du texte de version et du courriel.
const TOP_BLOCK_H    = 230;  // logo + version (avec place réservée)
const BOTTOM_BLOCK_H = 110;  // email (place réservée) + bouton déconnexion

export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname           = usePathname();
  const { data: session }  = useSession();
  // Lookup du membre équipe correspondant au courriel connecté → affiche
  // son surnom (col J _EQUIPE_) au lieu de l'email/name Google. Fallback :
  // session.user.name puis email.split('@')[0].
  const { members, isLoading: equipeLoading } = useEquipe();
  // v1.0.26+ : filter LOGO_MENU pour items adminOnly (ex. /depenses)
  const { isAdmin } = useIsAdmin();
  // Tant que l'équipe charge, on n'affiche RIEN (évite le flash "Jean-Christophe
  // Yacono" → "yako" sur chaque page load). Une fois chargée :
  //   1. Match par courriel → surnom
  //   2. Fallback : prenom + nom du membre
  //   3. Fallback ultime : email.split('@')[0]
  const userDisplay = (() => {
    if (equipeLoading || members.length === 0) return '';
    const email = session?.user?.email?.toLowerCase().trim() ?? '';
    const member = email ? members.find(m => m.courriel?.toLowerCase().trim() === email) : null;
    if (member?.surnom)             return member.surnom;
    if (member?.prenom || member?.nom) return `${member.prenom ?? ''} ${member.nom ?? ''}`.trim();
    return email.split('@')[0] ?? '';
  })();
  const { pieces }         = usePieces();
  const { velos }          = useInventaire();
  const { ventes }         = useVentes();

  // Badges numériques sur les icônes du menu
  const stockBasCount = React.useMemo(
    () => pieces.filter(p =>
      (p.qteACommander || 0) > 0
      && p.nom && p.nom !== 'Nom ITEM'
      && !p.nom.startsWith('FIN DE')
    ).length,
    [pieces],
  );
  const bdtActifsCount = React.useMemo(
    () => velos.filter(v => BDT_ACTIVE_STATUSES.has(v.status)).length,
    [velos],
  );
  const venteNonFactCount = React.useMemo(
    () => ventes.filter(v => !v.factureDate).length,
    [ventes],
  );

  /** Map href → { count, color } pour afficher le badge. */
  const BADGES: Record<string, { count: number; color: string }> = {
    '/inventaire':        { count: bdtActifsCount,    color: '#88fa4e' }, // vert
    '/catalogue/ventes':  { count: venteNonFactCount, color: '#e53935' }, // rouge
    '/catalogue/pieces':  { count: stockBasCount,     color: '#e53935' }, // rouge
  };

  // Mode collapsed : ouvert par défaut sur /dashboard, fermé ailleurs
  const isHomePage = pathname === '/dashboard';
  const [collapsed, setCollapsed] = useState(!isHomePage);
  const [hoverExpand, setHoverExpand] = useState(false);
  const [logoMenuOpen, setLogoMenuOpen] = useState(false);
  const logoMenuRef = React.useRef<HTMLDivElement>(null);

  // Lookup prix (scan rapide depuis le top menu)
  const [priceLookupOpen, setPriceLookupOpen] = useState(false);

  // Long-press (600 ms) sur la version mobile → déconnexion
  const pressTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  function startLongPress() {
    if (pressTimerRef.current) clearTimeout(pressTimerRef.current);
    pressTimerRef.current = setTimeout(() => {
      if (window.confirm('Se déconnecter ?')) {
        signOut({ callbackUrl: '/login' });
      }
    }, 600);
  }
  function cancelLongPress() {
    if (pressTimerRef.current) {
      clearTimeout(pressTimerRef.current);
      pressTimerRef.current = null;
    }
  }

  // Fermer le dropdown logo au clic extérieur
  useEffect(() => {
    if (!logoMenuOpen) return;
    function onClick(e: MouseEvent) {
      if (!logoMenuRef.current?.contains(e.target as Node)) setLogoMenuOpen(false);
    }
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, [logoMenuOpen]);

  // Reset à chaque changement de page
  useEffect(() => {
    setCollapsed(!isHomePage);
    setHoverExpand(false);
  }, [pathname, isHomePage]);

  // Fermer le dropdown logo dès que le menu passe en mode fermé (collapsed + pas en hover)
  useEffect(() => {
    if (collapsed && !hoverExpand) setLogoMenuOpen(false);
  }, [collapsed, hoverExpand]);

  // Auto-logout à 23:59 chaque jour (token frais au login du lendemain)
  useEffect(() => {
    function scheduleLogout() {
      const now = new Date();
      const target = new Date(now);
      target.setHours(23, 59, 0, 0);
      if (target.getTime() <= now.getTime()) {
        // Déjà passé 23:59 aujourd'hui → programmer pour demain
        target.setDate(target.getDate() + 1);
      }
      const ms = target.getTime() - now.getTime();
      return setTimeout(() => { signOut({ callbackUrl: '/login' }); }, ms);
    }
    const timer = scheduleLogout();
    return () => clearTimeout(timer);
  }, []);

  // État effectif (étendu si pas collapsed OU si hover)
  const expanded = !collapsed || hoverExpand;

  return (
    <div className="flex flex-col md:flex-row h-screen overflow-hidden p-5" style={{ backgroundColor: '#929292', gap: '20px' }}>
      {/* ── Top bar mobile (md:hidden) ────────────────────── */}
      {(() => {
        const ICON_CELL      = 56;
        const LOGO_MOBILE    = 56;
        return (
      <div
        className="md:hidden flex items-center justify-between shrink-0"
        style={{
          backgroundColor: '#fff056',
          borderRadius: '50px',
          padding: '8px 14px',
          boxShadow: '0 6px 12px rgba(0,0,0,0.23)',
          gap: '12px',
        }}
      >
        {/* v1.0.5+ : logo mobile → /menu (big menu), au lieu d'un reload
            de la page courante. Le user veut que le logo soit le retour
            home quand sur iPhone (cohérent avec le pattern app native). */}
        <div className="flex items-center shrink-0" style={{ gap: '8px' }}>
          <Link
            href="/menu"
            title="Menu"
            className="flex items-center transition-opacity hover:opacity-90"
            style={{ background: 'transparent', cursor: 'pointer', padding: 0 }}
          >
            <span style={{ display: 'inline-flex', pointerEvents: 'none' }}>
              <Image
                src="/logo-flex-rev-trans-brun-small.svg"
                alt="FLEX-REV"
                width={LOGO_MOBILE}
                height={LOGO_MOBILE}
                priority
              />
            </span>
          </Link>
          <div
            onTouchStart={startLongPress}
            onTouchEnd={cancelLongPress}
            onTouchCancel={cancelLongPress}
            onTouchMove={cancelLongPress}
            onMouseDown={startLongPress}
            onMouseUp={cancelLongPress}
            onMouseLeave={cancelLongPress}
            onContextMenu={e => e.preventDefault()}
            title="Appui long pour se déconnecter"
            className="flex flex-col"
            style={{
              color: '#9a7b4f',
              fontSize: '11px',
              fontWeight: 400,
              lineHeight: 1.15,
              userSelect: 'none',
              WebkitUserSelect: 'none',
              WebkitTouchCallout: 'none',
              cursor: 'default',
            }}
          >
            {userDisplay && (<span>{userDisplay}</span>)}
            <span>{APP_VERSION}</span>
          </div>
        </div>

        {/* v1.0.2+ : burger unique → /menu. Badge rouge UNIQUEMENT si ventes
            non facturées (vraie urgence — manque à encaisser). Les BDT
            actifs ne sont pas une urgence, c'est l'activité normale de
            l'atelier — leur compteur s'affiche sur la card "Inventaire"
            du desktop / sur la sidebar, pas dans la pastille du burger. */}
        <Link
          href="/menu"
          title="Menu"
          className="flex items-center justify-center transition-colors hover:bg-black/10"
          style={{
            width: `${ICON_CELL}px`,
            height: `${ICON_CELL}px`,
            borderRadius: '50%',
            backgroundColor: 'transparent',
            color: '#9a7b4f',
            textDecoration: 'none',
            position: 'relative',
          }}
        >
          <Bars3Icon style={{ width: '32px', height: '32px' }} />
          {venteNonFactCount > 0 && (
            <span
              title={`${venteNonFactCount} vente(s) non facturée(s)`}
              style={{
                position: 'absolute',
                top: 0, right: 0,
                minWidth: '20px', height: '20px',
                padding: '0 5px',
                borderRadius: '10px',
                backgroundColor: '#e53935',
                color: '#fff',
                fontSize: '10px', fontWeight: 700,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                boxShadow: '0 2px 6px rgba(0,0,0,0.30)',
                border: '2px solid #fff',
                lineHeight: 1,
              }}
            >
              {venteNonFactCount > 99 ? '99+' : venteNonFactCount}
            </span>
          )}
        </Link>
      </div>
        );
      })()}

      {/* ── Sidebar desktop (hidden md+) ─────────────────── */}
      <div
        className="hidden md:block shrink-0"
        style={{
          width: collapsed ? '90px' : '200px',
          transition: 'width 300ms cubic-bezier(0.4, 0, 0.2, 1)',
          position: 'relative',
        }}
        onMouseEnter={() => collapsed && setHoverExpand(true)}
        onMouseLeave={() => setHoverExpand(false)}
      >
        <aside
          className="flex flex-col h-full"
          style={{
            width: expanded ? '200px' : '90px',
            backgroundColor: '#fff056',
            borderRadius: '50px',
            boxShadow: collapsed && hoverExpand ? '0 12px 32px rgba(0,0,0,0.40)' : '0 6px 12px rgba(0,0,0,0.23)',
            transition: 'width 300ms cubic-bezier(0.4, 0, 0.2, 1), box-shadow 300ms ease',
            overflow: 'hidden',
            position: collapsed && hoverExpand ? 'absolute' : 'relative',
            top: 0,
            left: 0,
            zIndex: collapsed && hoverExpand ? 50 : 'auto',
          }}
        >
          {/* ── Logo + version (centrés, hauteur FIXE entre modes) ── */}
          <div
            className="flex flex-col items-center shrink-0"
            style={{
              height: `${TOP_BLOCK_H}px`,
              paddingTop: '18px',
              justifyContent: 'flex-start',
            }}
          >
            <div
              ref={logoMenuRef}
              style={{ position: 'relative' }}
              className="flex flex-col items-center"
              onMouseEnter={() => setLogoMenuOpen(true)}
              onMouseLeave={() => setLogoMenuOpen(false)}
            >
              {/* Click = va au Dashboard. Mouseover = ouvre le sous-menu. */}
              <Link
                href="/dashboard"
                title="Dashboard"
                className="flex flex-col items-center"
                style={{ textDecoration: 'none', color: 'inherit' }}
              >
                <Image
                  src={expanded ? '/logo-flex-rev-trans-brun.svg' : '/logo-flex-rev-trans-brun-small.svg'}
                  alt="FLEX-REV"
                  width={expanded ? LOGO_LG : LOGO_SM}
                  height={expanded ? LOGO_LG : LOGO_SM}
                  priority
                />
                <span
                  className="mt-2"
                  style={{
                    color: '#9a7b4f',
                    fontSize: expanded ? '13px' : '10px',
                    fontWeight: 400,
                  }}
                >
                  {APP_VERSION}
                </span>
                {userDisplay && (
                  <span
                    className="mt-0.5 truncate"
                    style={{
                      color: '#9a7b4f',
                      fontSize: expanded ? '11px' : '9px',
                      fontWeight: 400,
                      maxWidth: expanded ? '180px' : '80px',
                      textAlign: 'center',
                    }}
                    title={session?.user?.email ?? ''}
                  >
                    {userDisplay}
                  </span>
                )}
              </Link>

              {logoMenuOpen && (
                <div
                  className="absolute flex flex-col"
                  style={{
                    top: expanded ? `${LOGO_LG + 40}px` : `${LOGO_SM + 40}px`,
                    left: '50%',
                    transform: 'translateX(-50%)',
                    minWidth: '180px',
                    backgroundColor: '#fff',
                    borderRadius: '20px',
                    boxShadow: '0 6px 24px rgba(0,0,0,0.25)',
                    zIndex: 100,
                    padding: '8px 0',
                  }}
                >
                  {LOGO_MENU
                    .filter(item => !item.adminOnly || isAdmin)
                    .map(({ href, label, icon: Icon }) => (
                    <Link
                      key={href}
                      href={href}
                      onClick={() => setLogoMenuOpen(false)}
                      className="flex items-center transition-colors hover:bg-yellow-100"
                      style={{
                        gap: '10px',
                        padding: '10px 16px',
                        textDecoration: 'none',
                        color: 'rgba(0,0,0,0.8)',
                        fontSize: '14px',
                        fontWeight: 600,
                      }}
                    >
                      <Icon style={{ width: '20px', height: '20px', color: 'rgba(0,0,0,0.5)', flexShrink: 0 }} />
                      {label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* ── Navigation (centrée verticalement dans l'espace dispo) ──
              Le highlight actif est calculé en prenant la route la plus
              spécifique qui matche le pathname. Évite le double-highlight
              quand un item englobe les routes d'un autre. */}
          <nav
            className="flex-1 flex flex-col items-center justify-center"
            style={{ overflow: 'hidden', gap: `${ITEM_GAP}px`, padding: '0 12px' }}
          >
            {NAV.map(({ href, label, icon: Icon, small, matches }, idx) => {
              // Calcule le href actif en prenant le match LE PLUS LONG
              // parmi tous les candidats NAV + leurs `matches`. Évite le
              // double-highlight quand un item englobe les routes d'un autre.
              let bestHref = '';
              let bestLen  = 0;
              for (const item of NAV) {
                const candidates = [item.href, ...(item.matches ?? [])];
                for (const c of candidates) {
                  const m = pathname === c || pathname.startsWith(c + '/');
                  if (m && c.length > bestLen) {
                    bestLen  = c.length;
                    bestHref = item.href;
                  }
                }
              }
              const isActive = bestHref === href;

              const cellSize  = small ? SM_CELL : LG_CELL;
              const iconSize  = small ? SM_ICON : LG_ICON;
              const labelSize = small ? 13 : 18;
              // Hauteur totale du conteneur = cellule + label réservé, MÊME
              // en mode réduit (label invisible mais place gardée), pour
              // que l'icône ne change jamais de position verticale lors
              // de la transition open/close.
              const itemHeight = cellSize + LABEL_H;

              // Séparateurs : avant SERVICES (idx 2) pour isoler Inventaire+Ventes,
              // et avant clients (idx 4) pour isoler les items opérationnels.
              const showSeparator = idx === 2 || idx === 4;

              return (
                <React.Fragment key={href}>
                  {showSeparator && (
                    <div
                      style={{
                        width: expanded ? `${LOGO_LG}px` : `${LOGO_SM}px`,
                        height: '1px',
                        backgroundColor: 'rgba(154,123,79,0.35)',
                        marginTop: '20px',
                        marginBottom: '20px',
                        transition: 'width 300ms cubic-bezier(0.4, 0, 0.2, 1)',
                      }}
                    />
                  )}
                <Link
                  href={href}
                  className="flex flex-col items-center group"
                  style={{
                    textDecoration: 'none',
                    height: `${itemHeight}px`,
                    justifyContent: 'flex-start',
                  }}
                >
                  {/* Cellule icône — taille fixe. Hover noir 10% uniquement
                      quand l'item n'est pas actif. On évite de mettre
                      backgroundColor en inline sur l'état inactif sinon
                      l'inline écrase le group-hover de Tailwind. */}
                  <span
                    className={`flex items-center justify-center transition-colors ${isActive ? '' : 'group-hover:bg-black/10'}`}
                    style={{
                      width: `${cellSize}px`,
                      height: `${cellSize}px`,
                      borderRadius: '50%',
                      position: 'relative',
                      ...(isActive ? { backgroundColor: '#9a7b4f' } : {}),
                      color: isActive ? '#fff056' : '#9a7b4f',
                      flexShrink: 0,
                    }}
                  >
                    <Icon style={{ width: `${iconSize}px`, height: `${iconSize}px` }} />
                    {/* Badge numérique (BDT actifs, ventes à facturer, stock bas…) */}
                    {BADGES[href] && BADGES[href].count > 0 && (
                      <span
                        title={
                          href === '/inventaire'       ? `${BADGES[href].count} BDT actif${BADGES[href].count > 1 ? 's' : ''}` :
                          href === '/catalogue/ventes' ? `${BADGES[href].count} vente${BADGES[href].count > 1 ? 's' : ''} à facturer` :
                          `${BADGES[href].count} pièce${BADGES[href].count > 1 ? 's' : ''} à commander`
                        }
                        style={{
                          position: 'absolute',
                          top: 0,
                          right: 0,
                          minWidth: '22px',
                          height: '22px',
                          padding: '0 6px',
                          borderRadius: '11px',
                          backgroundColor: BADGES[href].color,
                          color: BADGES[href].color === '#88fa4e' ? 'rgba(0,0,0,0.6)' : '#fff',
                          fontSize: '11px',
                          fontWeight: 700,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          boxShadow: '0 2px 6px rgba(0,0,0,0.30)',
                          border: '2px solid #fff',
                          lineHeight: 1,
                        }}
                      >
                        {BADGES[href].count > 99 ? '99+' : BADGES[href].count}
                      </span>
                    )}
                  </span>

                  {/* Label — toujours rendu pour réserver la place, mais
                      invisible quand le menu est réduit. */}
                  <span
                    style={{
                      fontSize     : `${labelSize}px`,
                      fontWeight   : small ? 400 : 700,
                      color        : '#9a7b4f',
                      letterSpacing: small ? '0.02em' : '0.05em',
                      textTransform: small ? 'none' as const : 'uppercase' as const,
                      whiteSpace   : 'nowrap',
                      lineHeight   : 1.2,
                      marginTop    : '4px',
                      visibility   : expanded ? 'visible' : 'hidden',
                      height       : `${LABEL_H - 4}px`,
                      display      : 'flex',
                      alignItems   : 'center',
                    }}
                  >
                    {label}
                  </span>
                </Link>
                </React.Fragment>
              );
            })}
          </nav>

          {/* ── Compte + déconnexion (hauteur FIXE entre modes) ─── */}
          <div
            className="flex flex-col items-center shrink-0"
            style={{
              height: `${BOTTOM_BLOCK_H}px`,
              paddingBottom: '18px',
              gap: '8px',
              justifyContent: 'flex-end',
            }}
          >
            {/* v1.0.10+ : avatar Google + hover icône déconnexion.
                Récupère session.user.image (fourni par NextAuth Google
                provider). Au survol : l'image se floute légèrement et
                l'icône signOut apparaît en overlay. Click → signOut. */}
            <button
              onClick={() => signOut({ callbackUrl: '/login' })}
              title={`Connecté : ${session?.user?.email ?? '—'} (cliquer pour se déconnecter)`}
              className="group flex items-center justify-center transition-colors relative overflow-hidden"
              style={{
                width: `${LOGOUT_CELL}px`,
                height: `${LOGOUT_CELL}px`,
                borderRadius: '50%',
                backgroundColor: 'rgba(154,123,79,0.15)',
                border: 'none',
                cursor: 'pointer',
                color: '#9a7b4f',
                padding: 0,
              }}
            >
              {session?.user?.image ? (
                <>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={session.user.image}
                    alt="Profil"
                    className="transition-all"
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      borderRadius: '50%',
                    }}
                    referrerPolicy="no-referrer"
                  />
                  {/* Overlay icône signOut au hover */}
                  <span
                    className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{
                      backgroundColor: 'rgba(0,0,0,0.55)',
                      borderRadius: '50%',
                      color: '#fff',
                    }}
                  >
                    <ArrowRightOnRectangleIcon style={{ width: `${SM_ICON}px`, height: `${SM_ICON}px` }} />
                  </span>
                </>
              ) : (
                <ArrowRightOnRectangleIcon style={{ width: `${SM_ICON}px`, height: `${SM_ICON}px` }} />
              )}
            </button>
          </div>
        </aside>
      </div>

      {/* ── Main ──────────────────────────────────────────── */}
      <main
        className="flex-1 min-w-0 overflow-y-auto md:bg-black/20 md:rounded-[50px]"
      >
        {children}
      </main>

      <ToastContainer />
      <GoogleAuthBanner />
      <PriceLookupModal open={priceLookupOpen} onClose={() => setPriceLookupOpen(false)} />
    </div>
  );
}
