'use client';
import { useState, useEffect, useMemo, useRef } from 'react';
import { useBDC } from '@/hooks/useBDC';
import { usePieces, useServices } from '@/hooks/useCatalogue';
import BDCHeader from './BDCHeader';
import BDCTotaux from './BDCTotaux';
import ServicesPopup from './ServicesPopup';
import Modal from '@/components/ui/Modal';
import PiecesPopup from './PiecesPopup';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import DragTh from '@/components/ui/DragTh';
import HelpHint from '@/components/ui/HelpHint';
import { useColOrder } from '@/hooks/useColOrder';
import { frPrix } from '@/lib/utils/format';
import { pceNomClean, stripIconPrefix } from '@/lib/utils/pieces';
import { toast } from '@/components/ui/Toast';
import { STATUTS } from '@/lib/utils/statuts';
import { ChevronDownIcon, ChevronRightIcon, TrashIcon, PlusIcon, ClockIcon, Cog6ToothIcon, CheckIcon, ArrowPathIcon } from '@heroicons/react/24/outline';
// v1.1.9 — Item 5 audit : helpers purs extraits dans lib/bdc-helpers.ts
import {
  parseSvcTemps,
  normSvcKey,
  svcTailKey,
  svcLabel,
  pceLabel,
  computeMontant,
  parseDureeToMinutes,
  computeTotalDuree,
} from '@/lib/bdc-helpers';
import type { BDCItem } from '@/types/bdc';
import type { Remise } from './BDCHeader';

interface BDCPanelProps {
  bdcId: string;
  onArchived?: () => void;
  hideHeader?: boolean;
  status?: string;
  noteClient?: string;
  onNoteClientChange?: (v: string) => void;
  onNoteClientBlur?: () => void;
  noteClientFacture?: string;
  onNoteClientFactureChange?: (v: string) => void;
  onNoteClientFactureBlur?: () => void;
  remiseSvc?: Remise;
  onRemiseSvcChange?: (r: Remise) => void;
  remisePce?: Remise;
  onRemisePceChange?: (r: Remise) => void;
  /** v1.0.15+ : avance versée par le client (acompte). Réduit le « reste
   *  à payer » sans toucher aux taxes. v1.0.17+ : objet {montant,mode,note}. */
  avance?: { montant: number; mode?: 'comptant' | 'interac' | 'cartes'; note?: string };
  onAvanceChange?: (v: { montant: number; mode?: 'comptant' | 'interac' | 'cartes'; note?: string }) => void;
}

import { CMD_STYLE, CMD_TOOLTIP } from '@/lib/utils/statuts';
const FLAG_COLORS: Record<string, { backgroundColor: string; color: string }> = Object.fromEntries(
  Object.entries(CMD_STYLE).map(([k, v]) => [k, { backgroundColor: v.bg, color: v.fg }])
);

// Colonnes du tableau Services (sans delete)
const SVC_COLS = [
  { id: 'service', header: 'service', hCls: 'px-3 py-2',                  cCls: 'px-3 py-1.5 text-gray-800' },
  { id: 'duree',   header: 'durée',   hCls: 'px-2 py-2 text-center w-20', cCls: 'px-2 py-1.5 text-center text-gray-400 text-xs italic' },
  { id: 'fait',    header: 'fait',    hCls: 'px-3 py-2 text-center w-20', cCls: 'px-3 py-1.5 text-center' },
  { id: 'prix',    header: 'prix',    hCls: 'px-3 py-2 text-right w-20',  cCls: 'px-3 py-1.5 text-right text-gray-700 font-medium' },
] as const;

// Colonnes du tableau Pièces (sans delete)
const PCE_COLS = [
  { id: 'item',     header: 'items',   hCls: 'px-1 py-2 pl-3',            cCls: 'px-1 py-1.5 pl-3 text-gray-800' },
  { id: 'prix',     header: 'prix',    hCls: 'px-1 py-2 text-right w-20', cCls: 'px-1 py-1.5 text-right' },
  { id: 'qte',      header: 'qté',     hCls: 'px-1 py-2 text-center w-12', cCls: 'px-1 py-1.5 text-center' },
  { id: 'sousTotal',header: 's/total', hCls: 'px-1 py-2 text-right w-20 pr-3', cCls: 'px-1 py-1.5 pr-3 text-right text-gray-700 font-medium' },
  { id: 'cmd',      header: 'cmd',     hCls: 'px-1 py-2 text-center w-16', cCls: 'px-1 py-1.5 text-center' },
] as const;

type SvcColId = typeof SVC_COLS[number]['id'];
type PceColId = typeof PCE_COLS[number]['id'];

// v1.1.9 — Item 5 : 8 helpers purs (parseSvcTemps, normSvcKey, svcTailKey,
// svcLabel, pceLabel, computeMontant, parseDureeToMinutes, computeTotalDuree)
// déplacés dans lib/bdc-helpers.ts pour réduire la taille de ce composant
// (1555 → ~1480 LOC) et permettre du test unitaire isolé.

// ── Champ numérique éditable ────────────────────────────────────
function EditableNumber({
  value, onSave, min = 0, step = 0.01, className = '',
}: { value: number; onSave: (v: number) => void; min?: number; step?: number; className?: string }) {
  const [local, setLocal] = useState(String(value));
  useEffect(() => { setLocal(String(value)); }, [value]);
  return (
    <input
      type="number" min={min} step={step} value={local}
      onChange={e => setLocal(e.target.value)}
      onBlur={() => { const parsed = parseFloat(local) || 0; if (parsed !== value) onSave(parsed); }}
      className={`border rounded px-1 py-0.5 text-right text-sm focus:outline-none focus:ring-1 focus:ring-yellow-400 bg-white
        [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none
        ${className}`}
    />
  );
}

// ── Widget remise ──────────────────────────────────────────────
function RemiseInput({
  label, total, remise, onChange, wrapperClassName,
}: { label: string; total: number; remise: Remise; onChange: (r: Remise) => void; wrapperClassName?: string }) {
  const montant = computeMontant(total, remise);
  return (
    <div className={wrapperClassName ?? 'flex items-center gap-2'}>
      <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '14px', fontStyle: 'italic', flex: 1, textAlign: 'right' }}>{label}</span>
      <input
        type="number" min={0} max={remise.type === 'pct' ? 100 : undefined}
        value={remise.value || ''}
        onChange={e => onChange({ ...remise, value: parseFloat(e.target.value) || 0 })}
        className="w-14 text-sm text-center focus:outline-none focus:ring-2 focus:ring-yellow-400"
        style={{ height: '28px', backgroundColor: 'rgba(255,255,255,0.5)', color: 'rgba(0,0,0,0.7)', border: 'none', borderRadius: '0' }}
        placeholder="0"
      />
      <button
        onClick={() => onChange({ ...remise, type: remise.type === 'pct' ? 'fixed' : 'pct' })}
        className="text-xs font-bold w-8"
        style={{ height: '28px', backgroundColor: 'rgba(255,255,255,0.5)', color: 'rgba(0,0,0,0.7)', border: 'none', borderRadius: '0' }}
      >
        {remise.type === 'pct' ? '%' : '$'}
      </button>
      {montant > 0 && (
        <span className="text-xs font-medium" style={{ color: '#fca5a5' }}>− {frPrix(montant)}</span>
      )}
    </div>
  );
}

export default function BDCPanel({
  bdcId, onArchived, hideHeader = false, status = '',
  noteClient = '', onNoteClientChange, onNoteClientBlur,
  noteClientFacture = '', onNoteClientFactureChange, onNoteClientFactureBlur,
  remiseSvc  = { type: 'pct', value: 0 }, onRemiseSvcChange,
  remisePce  = { type: 'pct', value: 0 }, onRemisePceChange,
  avance, onAvanceChange,
}: BDCPanelProps) {
  const { bdc, isLoading, error, patchItem, patchItemFields, deleteItem, patchForfaitSubs } = useBDC(bdcId);
  const { pieces: catalogue, patchPiece } = usePieces();
  const { services: svcCatalogue } = useServices();
  const [showSvc,  setShowSvc]  = useState(false);
  const [showPce,  setShowPce]  = useState(false);
  // v1.1.13+ : état de re-génération du PDF facture (BDT facturé seulement)
  const [regenerating, setRegenerating] = useState(false);

  // Toggle note client (éval ↔ facture). Init selon cycle :
  //  - APPROUVÉ ou +  → mode 'facture' (la note facture est saisie après approbation)
  //  - sinon          → mode 'eval'    (note d'évaluation par défaut)
  // Le user peut basculer manuellement avec les pills.
  const initialNoteMode: 'eval' | 'facture' = (() => {
    const st = bdc?.evalStatus;
    if (st === 'APPROUVE' || bdc?.checkBds || bdc?.checkOut) return 'facture';
    return 'eval';
  })();
  const [noteMode, setNoteMode] = useState<'eval' | 'facture'>(initialNoteMode);
  const noteModeInitRef = useRef(false);
  useEffect(() => {
    // Sync l'init quand bdc arrive (premier load) — mais ne pas écraser
    // après que le user a basculé manuellement.
    if (!noteModeInitRef.current && bdc) {
      setNoteMode(initialNoteMode);
      noteModeInitRef.current = true;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bdc?.id]);
  // Clients staff : BDT par défaut en mode COST.
  const STAFF_CLIENTS = ['Jean-Christophe Yacono'];
  const [showCost, setShowCost] = useState(false);
  // Auto-apply le mode Cost selon que le client du BDT est staff ou pas.
  // Change automatiquement quand le client change → évite que le toggle
  // reste bloqué sur ON après un passage par un staff (bug G).
  // Pas de localStorage : le mode Cost est une décision per-BDT, pas
  // globale, sinon il fuit entre les BDTs.
  useEffect(() => {
    const clientNom = bdc?.clientNom?.trim() ?? '';
    const isStaff   = !!clientNom && STAFF_CLIENTS.includes(clientNom);
    setShowCost(isStaff);
  }, [bdc?.clientNom]);
  function toggleCost() {
    setShowCost(prev => !prev);
  }
  const [openForfaits, setOpenForfaits] = useState<Record<string, boolean>>({});

  // État local (localStorage) des cases à cocher des sous-items de forfaits.
  // Clé = numéro de ligne BDC du forfait ; valeur = tableau booléen aligné
  // sur l'ordre des sous-items catalogue.
  const subsStoreKey = `bdc-${bdcId}-forfaitSubs`;
  const [forfaitSubs, setForfaitSubs] = useState<Record<number, boolean[]>>(() => {
    if (typeof window === 'undefined') return {};
    try {
      const raw = localStorage.getItem(`bdc-${bdcId}-forfaitSubs`);
      return raw ? JSON.parse(raw) : {};
    } catch { return {}; }
  });
  useEffect(() => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(subsStoreKey, JSON.stringify(forfaitSubs));
  }, [forfaitSubs, subsStoreKey]);

  function toggleForfaitSub(
    forfaitRow: number,
    idx: number,
    subItemsCount: number,
    checked: boolean,
    filledIndexes: number[],
    currentForfaitFait: boolean,
    currentSubStates: boolean[] | undefined,
  ) {
    // v1.0.7+ : persiste dans Sheets (col J + col L) pour cross-device.
    // localStorage gardé en miroir local pour compat optimistic UI rapide.
    const arr = (currentSubStates ?? Array(subItemsCount).fill(currentForfaitFait)).slice();
    while (arr.length < subItemsCount) arr.push(currentForfaitFait);
    arr[idx] = checked;
    const allChecked = filledIndexes.every(i => !!arr[i]);

    // Update local cache (optimistic + offline tolerance)
    setForfaitSubs(prev => ({ ...prev, [forfaitRow]: arr }));

    // Persiste côté Sheets — best effort (le hook gère rollback si fail)
    patchForfaitSubs(forfaitRow, arr, allChecked).catch(err => {
      console.warn('[forfait-subs] sync échec :', err?.message);
    });
  }

  // Sous-items des forfaits depuis le catalogue (lignes "— ..." ou "- ..." qui suivent un forfait)
  const forfaitSubItems = useMemo(() => {
    const m = new Map<string, { label: string; isSeparator: boolean }[]>();
    let currentForfait = '';
    for (const s of svcCatalogue) {
      const t = (s.label ?? '').trim();
      if (!t) continue;
      if (t.toLowerCase().includes('forfait') && !t.startsWith('—') && !t.startsWith('- ')) {
        currentForfait = t;
        if (!m.has(currentForfait)) m.set(currentForfait, []);
      } else if (currentForfait && (t.startsWith('—') || t.startsWith('- ') || t.startsWith('-'))) {
        const cleaned = t.replace(/^[—\-]\s*/, '').trim();
        const isSep = t.startsWith('—');
        m.get(currentForfait)!.push({ label: cleaned || t, isSeparator: isSep });
      } else {
        currentForfait = '';
      }
    }
    return m;
  }, [svcCatalogue]);

  // v1.0.6+ : auto-initialise forfaitSubs[forfaitRow] dès que le BDC charge
  // pour chaque forfait. Sans ça, le 1er toggle d'un sous-item utilisait
  // un fallback `Array.fill(false)` qui RESET tous les autres sous-items
  // déjà visuellement cochés (cf v7.0.32 default `Array.fill(forfaitFait)`
  // qui était purement visuel, jamais persisté). Bug observé : user coche
  // 7 sous-items, en décoche 1 → les 6 autres tombent à false sans raison.
  // Maintenant : à chaque changement du BDC, on s'assure que chaque forfait
  // a une entrée concrète en state (initialisée à fill(forfaitFait)). Le
  // toggle peut ensuite muter idx sans toucher aux autres positions.
  useEffect(() => {
    if (!bdc?.items?.length) return;
    setForfaitSubs(prev => {
      let mutated = false;
      const next: Record<number, boolean[]> = { ...prev };
      for (const item of bdc.items) {
        if (!item.service) continue;
        const nom = item.service.nom?.trim() ?? '';
        if (!nom.toLowerCase().includes('forfait')) continue;
        if (next[item._row] !== undefined) continue;  // déjà initialisé
        // Trouve les sous-items du catalogue (match exact ou partiel)
        let subItems = forfaitSubItems.get(nom);
        if (!subItems) {
          for (const [k, v] of forfaitSubItems) {
            if (nom.includes(k) || k.includes(nom)) { subItems = v; break; }
          }
        }
        if (!subItems || subItems.length === 0) continue;
        next[item._row] = Array(subItems.length).fill(!!item.service.fait);
        mutated = true;
      }
      return mutated ? next : prev;
    });
  }, [bdc?.items, forfaitSubItems]);

  const svcCols = useColOrder('bdc-services', SVC_COLS as any);
  const pceCols = useColOrder('bdc-pieces',   PCE_COLS as any);

  // Map prix COST (col Q = prixCost) — utilisé quand le bouton Cost est activé.
  // Avant v5.1.2, on utilisait p.prixBase (col O) qui était le prix d'achat ;
  // depuis l'introduction de la col Q "COST" dans le sheet, on lit cette
  // colonne dédiée.
  const costMap = useMemo(() => {
    const m = new Map<string, number>();
    catalogue.forEach(p => {
      m.set(p.nom, p.prixCost);
      const key = p.nom.toLowerCase().replace(/\s+/g, ' ').trim();
      if (!m.has(key)) m.set(key, p.prixCost);
    });
    return m;
  }, [catalogue]);

  // Map prix BDC (col Q = prixBDC) — affiché par défaut
  const bdcPriceMap = useMemo(() => {
    const m = new Map<string, number>();
    catalogue.forEach(p => {
      m.set(p.nom, p.prixBDC);
      const key = p.nom.toLowerCase().replace(/\s+/g, ' ').trim();
      if (!m.has(key)) m.set(key, p.prixBDC);
    });
    return m;
  }, [catalogue]);

  const svcDureeMap = useMemo(() => {
    const m = new Map<string, string>();
    svcCatalogue.forEach(s => {
      if (!s.duree) return;
      m.set(s.label, s.duree);
      const nk = normSvcKey(s.label);
      if (nk && !m.has(nk)) m.set(nk, s.duree);
      const tk = svcTailKey(s.label);
      if (tk && !m.has(tk)) m.set(tk, s.duree);
    });
    return m;
  }, [svcCatalogue]);

  // Catégorie principale de chaque service (col C du sheet SERVICES -
  // À LA CARTE). Utilisé pour détecter les services Réhab dont la durée
  // est éditable (+/-) sur le BDT.
  const svcCategorieMap = useMemo(() => {
    const m = new Map<string, string>();
    svcCatalogue.forEach(s => {
      const cat = (s.categorie ?? '').trim();
      if (!cat) return;
      m.set(s.label, cat);
      const nk = normSvcKey(s.label);
      if (nk && !m.has(nk)) m.set(nk, cat);
      const tk = svcTailKey(s.label);
      if (tk && !m.has(tk)) m.set(tk, cat);
    });
    return m;
  }, [svcCatalogue]);

  function getSvcCategorie(nom: string): string {
    return svcCategorieMap.get(nom)
      || svcCategorieMap.get(normSvcKey(nom))
      || svcCategorieMap.get(svcTailKey(nom))
      || '';
  }

  // Prix catalogue par service (pour recomputer le prix au pro rata
  // de la durée quand on édite un Service - Réhab).
  const svcPrixMap = useMemo(() => {
    const m = new Map<string, number>();
    svcCatalogue.forEach(s => {
      if (!s.prix) return;
      m.set(s.label, s.prix);
      const nk = normSvcKey(s.label);
      if (nk && !m.has(nk)) m.set(nk, s.prix);
      const tk = svcTailKey(s.label);
      if (tk && !m.has(tk)) m.set(tk, s.prix);
    });
    return m;
  }, [svcCatalogue]);

  function getCatalogPrix(nom: string): number {
    return svcPrixMap.get(nom)
      ?? svcPrixMap.get(normSvcKey(nom))
      ?? svcPrixMap.get(svcTailKey(nom))
      ?? 0;
  }

  /** Formate des minutes totales en chaîne "h:mm". */
  function minutesToHMM(totalMin: number): string {
    const h = Math.floor(Math.max(0, totalMin) / 60);
    const m = Math.max(0, totalMin) % 60;
    return `${h}:${m.toString().padStart(2, '0')}`;
  }

  const stockMap = useMemo(() => {
    const m = new Map<string, number>();
    catalogue.forEach(p => {
      m.set(p.nom, p.stock);
      // Clé normalisée pour matching souple (minuscules, sans espaces multiples)
      const key = p.nom.toLowerCase().replace(/\s+/g, ' ').trim();
      if (!m.has(key)) m.set(key, p.stock);
      // v1.1.5+ : clé stable pieceId — survit aux renames de pièces.
      if (p.pieceId) m.set(`id:${p.pieceId}`, p.stock);
    });
    return m;
  }, [catalogue]);

  // v1.1.5+ (cluster 2) — Map du stock RÉSERVÉ (col AC) pour distinguer
  // "stock physique 0" vs "stock physique présent mais commité par un BDT".
  // Quand stockReserve >= stockPhysique, l'item EST en atelier mais n'est
  // pas disponible pour un nouveau BDT → on affiche "(réservé)" plutôt
  // que "(stock 0)".
  const stockReserveMap = useMemo(() => {
    const m = new Map<string, number>();
    catalogue.forEach(p => {
      m.set(p.nom, p.stockReserve);
      const key = p.nom.toLowerCase().replace(/\s+/g, ' ').trim();
      if (!m.has(key)) m.set(key, p.stockReserve);
    });
    return m;
  }, [catalogue]);

  // Lookup _row + fournisseur de la pièce catalogue par nom
  const catalogRowMap = useMemo(() => {
    const m = new Map<string, number>();
    catalogue.forEach(p => {
      m.set(p.nom, p._row);
      const key = p.nom.toLowerCase().replace(/\s+/g, ' ').trim();
      if (!m.has(key)) m.set(key, p._row);
      if (p.pieceId) m.set(`id:${p.pieceId}`, p._row);
    });
    return m;
  }, [catalogue]);

  const fournisseurMap = useMemo(() => {
    const m = new Map<string, string>();
    catalogue.forEach(p => {
      if (!p.fournisseur) return;
      m.set(p.nom, p.fournisseur);
      const key = p.nom.toLowerCase().replace(/\s+/g, ' ').trim();
      if (!m.has(key)) m.set(key, p.fournisseur);
      if (p.pieceId) m.set(`id:${p.pieceId}`, p.fournisseur);
    });
    return m;
  }, [catalogue]);

  // Map catalogue services, indexée par serviceId + nom exact + normSvcKey + svcTailKey
  const svcByKey = useMemo(() => {
    const m = new Map<string, any>();
    svcCatalogue.forEach(s => {
      const label = (s.label ?? '').trim();
      if (!label) return;
      const rec = { serviceId: s.serviceId, label, prix: s.prix ?? 0, duree: s.duree ?? '', categorie: s.categorie ?? '' };
      // Priorité : serviceId (match exact le plus fiable)
      if (s.serviceId) m.set(s.serviceId, rec);
      if (!m.has(label)) m.set(label, rec);
      const nk = normSvcKey(label); if (nk && !m.has(nk)) m.set(nk, rec);
      const tk = svcTailKey(label); if (tk && !m.has(tk)) m.set(tk, rec);
    });
    return m;
  }, [svcCatalogue]);

  /** Retourne le service catalogue qui match (par serviceId d'abord, puis nom). */
  function findSvcInCatalog(nom: string, serviceId?: string): { serviceId: string; label: string; prix: number; duree: string; categorie: string } | null {
    // 1. Match par serviceId (le plus fiable — survit aux renommages)
    if (serviceId && svcByKey.has(serviceId)) return svcByKey.get(serviceId);
    // 2. Fallback par nom (exact → normalisé → tail)
    if (!nom) return null;
    return svcByKey.get(nom)
        ?? svcByKey.get(normSvcKey(nom))
        ?? svcByKey.get(svcTailKey(nom))
        ?? null;
  }

  const oosMap = useMemo(() => {
    const m = new Map<string, boolean>();
    catalogue.forEach(p => {
      const v = !!p.oos;
      m.set(p.nom, v);
      const key = p.nom.toLowerCase().replace(/\s+/g, ' ').trim();
      if (!m.has(key)) m.set(key, v);
    });
    return m;
  }, [catalogue]);

  // État : cible du modal "Relier ce service à un item du catalogue"
  const [relinkTarget, setRelinkTarget] = useState<{ row: number; nom: string } | null>(null);
  const [relinkSearch, setRelinkSearch] = useState('');

  // Auto-sync : quand le catalogue et le BDC sont chargés, pour chaque service
  // dont un match existe (exact / norm / tail) dans le catalogue et dont le
  // nom OU le prix diffèrent, pousse une mise à jour vers la ligne BDC.
  // Idempotent : si nom/prix déjà à jour, ne fait rien.
  useEffect(() => {
    if (!bdc || !svcCatalogue.length) return;
    const services = (bdc.items ?? []).filter(it => it.service);
    for (const it of services) {
      const cur = it.service!;
      const nom = String(cur.nom ?? '').trim();
      if (!nom) continue;
      const cat = findSvcInCatalog(nom, cur.serviceId);
      if (!cat) continue;               // pas de match → on laisse tel quel

      const sameNom   = cat.label === nom;
      const hasOverride = String(cur.status ?? '').trim() && String(cur.status ?? '').trim() !== '...';
      const samePrix  = hasOverride || Math.abs((cat.prix ?? 0) - (cur.prix ?? 0)) < 0.005;
      // Migration progressive : si le BDC n'a pas de serviceId mais qu'on
      // a trouvé un match, on écrit le serviceId dans col I.
      const needsId   = !cur.serviceId && !!cat.serviceId;

      if (sameNom && samePrix && !needsId) continue;

      patchItemFields(it._row, 'service', {
        ...(sameNom  ? {} : { nom : cat.label }),
        ...(samePrix ? {} : { prix: cat.prix }),
        ...(needsId  ? { serviceId: cat.serviceId } : {}),
      }).catch(() => { /* rollback auto côté hook */ });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bdc?.id, svcCatalogue.length]);

  if (isLoading) return <LoadingSpinner className="py-20" />;
  if (error)     return <p className="p-4 text-red-600 text-sm">Erreur BDC : {error.message}</p>;
  if (!bdc || !bdc.id) return <p className="p-4 text-gray-400 text-sm">BDC introuvable.</p>;

  // Tri des services : Rencontres → Forfaits → À la carte
  const SVC_ORDER: Record<string, number> = {
    'rencontre': 0, 'rencontres': 0,
    'forfait': 1, 'forfaits': 1,
  };
  const svcSortKey = (nom: string): number => {
    const n = nom.toLowerCase();
    // v7.0.16 : forfait TOUJOURS en haut (au-dessus de Rencontre).
    if (n.includes('forfait'))  return 0;
    if (n.includes('rencontre')) return 1;
    return 2; // à la carte
  };
  const services = (bdc.items ?? [])
    .filter((it: BDCItem) => it.service)
    .sort((a, b) => svcSortKey(a.service!.nom) - svcSortKey(b.service!.nom));
  const pieces   = (bdc.items ?? []).filter((it: BDCItem) => it.piece);

  const s        = STATUTS[status];
  const headerBg = s?.bg ?? '#f5f5f5';
  const headerFg = s?.fg ?? '#333333';

  // Helper local : retourne le prix catalogue pour un item BDC, en tolérant
  // le suffixe « (Stock N) » que les anciennes lignes BDC peuvent contenir
  // dans le nom de la pièce. Lookup en 3 passes : exact → cleaned → cleaned+lowercased.
  function pieceCatalogPrice(map: Map<string, number>, nom: string, fallback: number): number {
    if (map.has(nom)) return map.get(nom)!;
    const cleaned = pceNomClean(nom);
    if (cleaned !== nom && map.has(cleaned)) return map.get(cleaned)!;
    const k = cleaned.toLowerCase().replace(/\s+/g, ' ').trim();
    if (map.has(k)) return map.get(k)!;
    return fallback;
  }

  // Prix effectif d'une pièce : toujours lu depuis le catalogue PIÈCES
  // (synchro temps réel avec le sheet). Fallback sur le prix stocké dans
  // le BDC uniquement si la pièce n'est plus au catalogue.
  function prixEffectif(item: BDCItem): number {
    const nom = item.piece!.nom;
    if (showCost) return pieceCatalogPrice(costMap, nom, item.piece!.prix);
    return pieceCatalogPrice(bdcPriceMap, nom, item.piece!.prix);
  }

  // Total pièces affiché — toujours calculé côté client pour cohérence
  // immédiate avec les qté/prix affichés (évite le glitch quand qte=0 ou
  // quand showCost change avant que le serveur ait répondu).
  const totalPiecesAffiche = pieces.reduce((sum, it) => {
    return sum + (it.piece!.qte * prixEffectif(it));
  }, 0);

  // Total services — calculé côté client pour cohérence immédiate après ajout/retrait
  const totalServicesAffiche = services.reduce((sum, it) => sum + (it.service!.prix || 0), 0);
  const montantSvc = computeMontant(totalServicesAffiche, remiseSvc);
  const montantPce = computeMontant(totalPiecesAffiche, remisePce);

  function openSvc() { setShowPce(false); setShowSvc(true); }
  function openPce() { setShowSvc(false); setShowPce(true); }

  // v1.1.13+ : bouton « Re-générer PDF » qui remplace le « + » Services
  // dès qu'un BDT a été facturé. Détection à 3 sources pour être robuste :
  //   1. `bdc.checkBds` (col F BDC sheet — coché à la facturation)
  //   2. `status === 'FACTURÉ'` (col C inventaire — set par la route /facturer)
  //   3. `status === 'LIVRÉ'`   (workflow complet, vélo récupéré — toujours
  //                              facturé en amont)
  // bdcId vient des props (toujours défini ici) — pas besoin de bdc.id.
  const statusNorm = (status ?? '').trim().toUpperCase();
  const isFacture  = !!bdc.checkBds
                  || statusNorm === 'FACTURÉ' || statusNorm === 'FACTURE'
                  || statusNorm === 'LIVRÉ'   || statusNorm === 'LIVRE';
  async function regenererFacture() {
    if (regenerating) return;
    if (!window.confirm(`Re-générer le PDF facture de ${bdcId} ?\n\n• Nouveau PDF dans Drive (l'ancien reste)\n• Nouveau brouillon Gmail (l'ancien reste)\n• Pas de double-ligne dans le journal comptable`)) return;
    setRegenerating(true);
    toast('Re-génération du PDF…', 'info');
    try {
      const res = await fetch(`/api/bdc/${bdcId}/regenerer-facture`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({
          noteClient: noteClientFacture || noteClient || '',
          remiseSvc, remisePce,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? `HTTP ${res.status}`);
      toast(`PDF re-généré — ${data.message ?? 'OK'}`, 'success');
      if (data.draftUrl) window.open(data.draftUrl, '_blank', 'noopener,noreferrer');
    } catch (err: any) {
      toast(err.message ?? 'Erreur re-génération', 'error');
    } finally {
      setRegenerating(false);
    }
  }

  function renderSvcCell(id: SvcColId, item: BDCItem) {
    switch (id) {
      case 'service': {
        const { display, temps } = svcLabel(item.service!.nom);
        return (
          <>
            {display}
            {temps && <span className="ml-1 text-xs text-gray-400 italic">{temps}</span>}
          </>
        );
      }
      case 'duree': {
        // Priorité : durée du catalogue (col D) → exact → normalisé → queue
        // (dernier segment après ':' / ' - ') → label inline → vide.
        const nom = item.service!.nom;
        const d = svcDureeMap.get(nom)
          || svcDureeMap.get(normSvcKey(nom))
          || svcDureeMap.get(svcTailKey(nom))
          || parseSvcTemps(nom).temps;
        return d || '—';
      }
      case 'fait':
        return (
          <select
            value={item.service!.fait ? 'FAIT' : '—'}
            onChange={e => patchItem(item._row, { fait: e.target.value === 'FAIT' })}
            className={`text-xs border rounded px-1 py-0.5 focus:outline-none focus:ring-1 focus:ring-yellow-400 ${item.service!.fait ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}
          >
            <option value="—">—</option>
            <option value="FAIT">FAIT</option>
          </select>
        );
      case 'prix':
        return frPrix(item.service!.prix);
    }
  }

  function renderPceCell(id: PceColId, item: BDCItem) {
    const nom = item.piece!.nom;
    const prixAffiche = prixEffectif(item);
    // Lookup : pieceId stable d'abord (v1.1.5+, survit aux renames), puis
    // fallbacks par nom : exact → cleaned (sans "(Stock N)") → cleaned+lowercased
    // → cleaned sans préfixe emoji (ex. "⚙️ : Babac, ..." → "Babac, ...").
    const idKey     = item.piece!.pieceId ? `id:${item.piece!.pieceId}` : null;
    const cleaned   = pceNomClean(nom);
    const k         = cleaned.toLowerCase().replace(/\s+/g, ' ').trim();
    const noPrefix  = stripIconPrefix(cleaned);
    const noPrefixK = noPrefix.toLowerCase().replace(/\s+/g, ' ').trim();
    const stock     = (idKey ? stockMap.get(idKey) : undefined)
      ?? stockMap.get(nom)
      ?? stockMap.get(cleaned)
      ?? stockMap.get(k)
      ?? stockMap.get(noPrefix)
      ?? stockMap.get(noPrefixK);
    // v1.1.5+ (cluster 2) — stockReserve pour distinguer "stock 0 vraiment vide"
    // de "stock 0 mais des unités sont réservées par des BDT actifs".
    const reserve   = stockReserveMap.get(nom)
      ?? stockReserveMap.get(cleaned)
      ?? stockReserveMap.get(k)
      ?? stockReserveMap.get(noPrefix)
      ?? stockReserveMap.get(noPrefixK)
      ?? 0;

    switch (id) {
      case 'item':
        return (
          <>
            {pceLabel(item.piece!.nom)}
            {stock !== undefined && stock > 0 && (
              <span className="ml-1.5 text-xs text-gray-400 italic font-normal">(stock {stock})</span>
            )}
            {/* v1.1.5+ (cluster 2) : stock physique 0 mais des unités sont
                réservées (par ce BDT ou un autre) → afficher "(réservé)" pour
                ne pas laisser croire que l'item est en rupture. */}
            {(stock === undefined || stock === 0) && reserve > 0 && (
              <span className="ml-1.5 text-xs italic font-normal" style={{ color: '#0d6efd' }}>(réservé)</span>
            )}
          </>
        );
      case 'prix':
        return (
          <div className="flex items-center justify-end gap-0.5">
            <EditableNumber
              value={prixAffiche}
              onSave={v => patchItemFields(item._row, 'piece', { prix: v, sousTotal: v * item.piece!.qte })}
              className="w-16"
            />
            <span className="text-xs text-gray-400">$</span>
          </div>
        );
      case 'qte':
        return (
          <EditableNumber
            value={item.piece!.qte}
            onSave={v => patchItemFields(item._row, 'piece', { qte: v, sousTotal: item.piece!.prix * v })}
            min={0} step={1}
            className="w-9 text-center"
          />
        );
      case 'cmd':
        return (
          <select
            value={item.piece!.cmd || '...'}
            onChange={e => patchItem(item._row, { cmd: e.target.value })}
            title={CMD_TOOLTIP}
            className="text-xs border rounded px-1 py-0.5 font-bold focus:outline-none focus:ring-1 focus:ring-yellow-400"
            style={FLAG_COLORS[item.piece!.cmd] ?? FLAG_COLORS['...']}
          >
            <option value="...">...</option>
            <option value="—">—</option>
            <option value="√">√</option>
            <option value="$">$</option>
            <option value="@">@</option>
          </select>
        );
      case 'sousTotal':
        return frPrix(item.piece!.qte * item.piece!.prix);
    }
  }

  return (
    <div className="h-full flex flex-col">
      {!hideHeader && (
        <div className="shrink-0 p-4 pb-0">
          <BDCHeader
            bdc={bdc} status={status}
            noteClient={noteClient}
            remiseSvc={remiseSvc}
            remisePce={remisePce}
            onArchived={onArchived}
          />
        </div>
      )}

      {/* ── SERVICES + PIÈCES ── */}
      <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden">
        <div className="flex flex-col md:flex-row md:items-start" style={{ gap: '20px' }}>

          {/* ── Colonne SERVICES ── */}
          <div className="flex-1 flex flex-col" style={{ gap: '10px' }}>

          {/* ── SERVICES ── */}
          <div className="overflow-hidden"
               style={{ borderRadius: '30px', backgroundColor: 'transparent' }}>
            {/* Header (couleur statut) : icône simple + titre + bouton + rond jaune */}
            <div className="flex items-center justify-between px-5"
                 style={{ backgroundColor: headerBg, height: '64px' }}>
              <div className="flex items-center gap-3">
                <ClockIcon style={{ width: '30px', height: '30px', color: 'rgba(0,0,0,0.5)' }} />
                <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '30px', fontWeight: 400, lineHeight: 1, display: 'inline-flex', alignItems: 'baseline', gap: '6px' }}>
                  Services
                  <HelpHint
                    topic="07-services-pieces"
                    title="Services + pièces"
                    hint="Le bouton + ouvre la popup Services. Filtre par catégorie, ou choisis un forfait (1 ligne) ou des services à la carte. Hover sur un forfait montre les sous-tâches."
                    size={18}
                  />
                </span>
              </div>
              {/* v1.1.13+ : sur un BDT facturé, le « + » Services laisse la
                  place à un bouton « Re-générer PDF » (utile après refonte
                  du template ou changement d'infos client). Sinon : bouton +
                  classique pour ajouter des services. */}
              {isFacture ? (
                <button
                  aria-label="Re-générer le PDF facture"
                  onClick={regenererFacture}
                  disabled={regenerating}
                  className="btn-plus-round btn-plus-round--outline"
                  title="Re-générer le PDF facture (nouveau PDF + brouillon Gmail, pas de double-ligne dans le journal)"
                >
                  <ArrowPathIcon style={regenerating ? { animation: 'spin 1s linear infinite' } : undefined} />
                </button>
              ) : (
                <button
                  aria-label="ajouter des services"
                  onClick={openSvc}
                  className="btn-plus-round btn-plus-round--outline"
                  title="Ajouter des services"
                >
                  <PlusIcon />
                </button>
              )}
            </div>

            {/* Ligne légende */}
            <div
              className="flex items-center list-header" style={{ height: '35px', padding: '0 16px' }}
            >
              <div style={{ width: '32px' }}></div>
              <div className="flex-1">item</div>
              <div style={{ width: '70px', textAlign: 'right' }}>durée</div>
              <div style={{ width: '70px', textAlign: 'center' }}>statut</div>
              <div style={{ width: '70px', textAlign: 'right' }}>prix</div>
            </div>

            {/* Lignes services */}
            <div style={{ backgroundColor: 'rgba(255,255,255,0.7)' }}>
              {/* Ligne par défaut : Rencontre — toujours présente, non supprimable */}
              <div
                className="flex items-center"
                style={{ padding: '10px 16px', borderBottom: '1px solid rgba(0,0,0,0.06)' }}
              >
                <div style={{ width: '32px' }}></div>
                <div className="flex-1" style={{ color: 'rgba(0,0,0,0.7)', fontSize: '14px', fontWeight: 700 }}>
                  👋 Rencontre : dépôt et évaluation
                </div>
                <div style={{ width: '70px', textAlign: 'right', color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontWeight: 700 }}>
                  0:15
                </div>
                <div style={{ width: '70px' }} className="flex items-center justify-center">
                  <input type="checkbox" checked disabled className="custom-checkbox" />
                </div>
                <div style={{ width: '70px', textAlign: 'right', color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontStyle: 'italic' }}>
                  inclu
                </div>
              </div>

              {services.length === 0 ? null : (
                services.map(item => {
                  const nom = item.service!.nom;
                  const isRencontre = nom.includes('Rencontre');
                  const isForfait   = nom.toLowerCase().includes('forfait');
                  const isSeparator = nom.startsWith('—') || nom.startsWith('- ') || nom === '—' || nom === '-' || nom === '--';
                  const forfaitOpen = !!openForfaits[item._row];
                  const { display } = svcLabel(nom);
                  // Durée catalogue (fallback)
                  const catalogDuree = svcDureeMap.get(nom)
                    || svcDureeMap.get(normSvcKey(nom))
                    || svcDureeMap.get(svcTailKey(nom))
                    || parseSvcTemps(nom).temps
                    || '';
                  // Override stocké dans item.service.status (col SVC_TXT)
                  const overrideRaw = String(item.service!.status ?? '').trim();
                  const hasOverride = overrideRaw && overrideRaw !== '...';
                  const dureeAffichee = hasOverride ? overrideRaw : (catalogDuree || '—');
                  const currentMin = parseDureeToMinutes(hasOverride ? overrideRaw : catalogDuree);

                  // Rate (prix par minute) calculé sur le catalogue.
                  // Permet de recomputer le prix au pro rata de la durée
                  // quand on édite. Fallback : garde le prix courant.
                  const catalogMin   = parseDureeToMinutes(catalogDuree);
                  const catalogPrix  = getCatalogPrix(nom);
                  const ratePerMin   = catalogMin > 0 ? catalogPrix / catalogMin : 0;

                  const adjustDuree = (deltaMin: number) => {
                    const next = Math.max(0, currentMin + deltaMin);
                    const nextPrix = ratePerMin > 0
                      ? Math.round(next * ratePerMin * 100) / 100  // arrondi au ¢
                      : item.service!.prix;
                    patchItemFields(item._row, 'service', {
                      dureeOverride: minutesToHMM(next),
                      prix         : nextPrix,
                    });
                  };

                  return (
                    <div key={item._row}>
                      <div
                        className="flex items-center"
                        style={{ padding: '10px 16px', borderBottom: '1px solid rgba(0,0,0,0.06)' }}
                      >
                        {/* Col 1 : effacer */}
                        <button
                          onClick={() => deleteItem(item._row)}
                          className="flex items-center justify-center transition-opacity hover:opacity-70 shrink-0"
                          style={{ width: '32px', color: 'rgba(0,0,0,0.5)' }}
                          title="Supprimer ce service"
                        >
                          <TrashIcon style={{ width: '20px', height: '20px' }} />
                        </button>

                        {/* Col 2 : items 14pt bold + ⚠ si pas au catalogue */}
                        <div className="flex-1 flex items-center" style={{ gap: '8px', color: 'rgba(0,0,0,0.7)', fontSize: '14px', fontWeight: 700 }}>
                          <span className="flex-1">{display}</span>
                          {!isSeparator && !isRencontre && !isForfait && !findSvcInCatalog(nom, item.service!.serviceId) && (
                            <button
                              type="button"
                              onClick={() => { setRelinkTarget({ row: item._row, nom }); setRelinkSearch(''); }}
                              className="flex items-center justify-center transition-opacity hover:opacity-70"
                              style={{
                                width: '22px', height: '22px',
                                borderRadius: '50%',
                                backgroundColor: 'rgba(245,158,11,0.25)',
                                color: '#b45309',
                                border: 'none',
                                cursor: 'pointer',
                                fontSize: '12px', fontWeight: 700, lineHeight: 1,
                                padding: 0,
                              }}
                              title="Service non trouvé dans le catalogue — clique pour relier"
                            >
                              ⚠
                            </button>
                          )}
                        </div>

                        {/* Col 3 : durée — éditable pour TOUS les services
                            (sauf forfait / rencontre / séparateur). Format
                            HH:MM avec incrémentation ±15 min. Le prix est
                            recomputé au pro rata via ratePerMin (basé sur
                            le catalogue). Même UX que le champ qté pièces. */}
                        {!isForfait && !isRencontre && !isSeparator ? (
                          <div
                            className="shrink-0 flex items-center group"
                            style={{
                              width: '70px', height: '32px',
                              border: 'none',
                              borderRadius: '12px',
                              backgroundColor: 'transparent',
                              overflow: 'hidden',
                              transition: 'border-color 150ms ease, box-shadow 150ms ease',
                            }}
                          >
                            <span
                              className="flex-1 text-right"
                              style={{
                                padding: '0 8px',
                                fontSize: '14px',
                                fontWeight: 700,
                                color: 'rgba(0,0,0,0.7)',
                                fontVariantNumeric: 'tabular-nums',
                              }}
                            >
                              {minutesToHMM(currentMin)}
                            </span>
                            <div
                              className="flex flex-col shrink-0"
                              style={{
                                height: '100%',
                                borderLeft: '1px solid rgba(0,0,0,0.1)',
                                backgroundColor: 'rgba(0,0,0,0.04)',
                              }}
                            >
                              <button
                                type="button"
                                onClick={() => adjustDuree(+15)}
                                className="flex items-center justify-center flex-1 transition-colors hover:bg-yellow-200"
                                style={{ width: '18px', cursor: 'pointer', color: 'rgba(0,0,0,0.6)', border: 'none', background: 'transparent' }}
                                title="+15 min"
                              >
                                <span style={{ fontSize: '8px', lineHeight: 1 }}>▲</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => adjustDuree(-15)}
                                disabled={currentMin <= 0}
                                className="flex items-center justify-center flex-1 transition-colors hover:bg-yellow-200 disabled:opacity-30"
                                style={{ width: '18px', cursor: 'pointer', color: 'rgba(0,0,0,0.6)', border: 'none', borderTop: '1px solid rgba(0,0,0,0.1)', background: 'transparent' }}
                                title="−15 min"
                              >
                                <span style={{ fontSize: '8px', lineHeight: 1 }}>▼</span>
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div style={{ width: '70px', textAlign: 'right', color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontWeight: 700 }}>
                            {dureeAffichee}
                          </div>
                        )}

                        {/* Col 4 : statut */}
                        <div style={{ width: '70px' }} className="flex items-center justify-center">
                          {isForfait ? (
                            <button
                              onClick={() => setOpenForfaits(s => ({ ...s, [item._row]: !s[item._row] }))}
                              className="flex items-center justify-center transition-opacity hover:opacity-70"
                              style={{ color: 'rgba(0,0,0,0.5)' }}
                              title={forfaitOpen ? 'Refermer le forfait' : 'Ouvrir le forfait'}
                            >
                              {forfaitOpen
                                ? <ChevronDownIcon style={{ width: '20px', height: '20px' }} strokeWidth={3} />
                                : <ChevronRightIcon style={{ width: '20px', height: '20px' }} strokeWidth={3} />}
                            </button>
                          ) : isRencontre ? (
                            <CheckIcon style={{ width: '20px', height: '20px', color: 'rgba(0,0,0,0.7)' }} strokeWidth={3} />
                          ) : isSeparator ? null : (
                            <input
                              type="checkbox"
                              checked={item.service!.fait}
                              onChange={e => patchItem(item._row, { fait: e.target.checked })}
                              className="custom-checkbox"
                            />
                          )}
                        </div>

                        {/* Col 5 : prix (centré verticalement à 32px = hauteur widget durée).
                            v1.3.1+ : prix = 0 → affiche "gratuit" italique grisé. Permet
                            de baisser la durée à 0:00 pour rendre un service offert,
                            l'item reste dans le BDT (cluster suite item h). */}
                        <div
                          className="flex items-center justify-end"
                          style={{ width: '70px', height: '32px', color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontWeight: 700 }}
                        >
                          {item.service!.prix === 0 ? (
                            <span style={{ fontStyle: 'italic', color: 'rgba(0,0,0,0.4)', fontWeight: 400 }}>gratuit</span>
                          ) : (
                            frPrix(item.service!.prix)
                          )}
                        </div>
                      </div>

                      {/* Sous-tâches forfait (depuis le catalogue) */}
                      {isForfait && forfaitOpen && (() => {
                        // Trouver les sous-items du forfait par match exact ou partiel
                        let subItems = forfaitSubItems.get(nom);
                        if (!subItems) {
                          // Fallback : match partiel sur le nom
                          for (const [k, v] of forfaitSubItems) {
                            if (nom.includes(k) || k.includes(nom)) { subItems = v; break; }
                          }
                        }
                        if (!subItems || subItems.length === 0) return null;
                        // Index des sous-items "cochables" (hors séparateurs)
                        const filledIdx = subItems
                          .map((s, i) => (s.isSeparator ? -1 : i))
                          .filter(i => i >= 0);
                        // v1.0.7+ : priorité aux subStates persistés en Sheets
                        // (col J de la ligne ITEM service) — cross-device.
                        // Fallback localStorage (cache local rapide), puis
                        // Array.fill(forfaitFait) si aucune source. Avant v1.0.7 :
                        // localStorage seul → invisible cross-device.
                        const forfaitFait = !!item.service?.fait;
                        const states = item.service?.subStates
                          ?? forfaitSubs[item._row]
                          ?? Array(subItems.length).fill(forfaitFait);
                        return (
                          <div style={{ backgroundColor: 'rgba(0,0,0,0.03)' }}>
                            {subItems.map((sub, idx) => {
                              const checked = !!states[idx];
                              return (
                                <div
                                  key={idx}
                                  className="flex items-center"
                                  style={{
                                    padding: sub.isSeparator ? '12px 16px 4px 56px' : '8px 16px 8px 56px',
                                    borderBottom: sub.isSeparator ? 'none' : '1px solid rgba(0,0,0,0.05)',
                                  }}
                                >
                                  <div
                                    className="flex-1"
                                    style={{
                                      color: sub.isSeparator
                                        ? 'rgba(0,0,0,0.4)'
                                        : checked ? 'rgba(0,0,0,0.35)' : 'rgba(0,0,0,0.6)',
                                      fontSize: sub.isSeparator ? '12px' : '15px',
                                      fontWeight: sub.isSeparator ? 700 : 400,
                                      textTransform: sub.isSeparator ? 'uppercase' : 'none',
                                      letterSpacing: sub.isSeparator ? '0.05em' : 'normal',
                                      textDecoration: !sub.isSeparator && checked ? 'line-through' : 'none',
                                    }}
                                  >
                                    {sub.isSeparator ? sub.label : `- ${sub.label}`}
                                  </div>
                                  <div style={{ width: '70px' }}></div>
                                  <div style={{ width: '70px' }} className="flex items-center justify-center">
                                    {!sub.isSeparator && (
                                      <input
                                        type="checkbox"
                                        className="custom-checkbox"
                                        checked={checked}
                                        onChange={e => toggleForfaitSub(item._row, idx, subItems!.length, e.target.checked, filledIdx, forfaitFait, states)}
                                      />
                                    )}
                                  </div>
                                  <div style={{ width: '70px' }}></div>
                                </div>
                              );
                            })}
                          </div>
                        );
                      })()}
                    </div>
                  );
                })
              )}
            </div>

            {/* Total temps de services */}
            {services.length > 0 && (
              <div
                className="flex items-center"
                style={{ backgroundColor: 'rgba(255,255,255,0.5)', height: '35px', padding: '0 16px' }}
              >
                <div style={{ width: '32px' }}></div>
                <div className="flex-1" style={{ color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontWeight: 700, fontStyle: 'italic', textAlign: 'right' }}>
                  total temps de services
                </div>
                <div style={{ width: '70px', textAlign: 'right', color: 'rgba(0,0,0,0.7)', fontSize: '18px', fontWeight: 700, paddingLeft: '8px' }}>
                  {computeTotalDuree(services, svcDureeMap)}
                </div>
                <div style={{ width: '70px' }}></div>
                <div style={{ width: '70px', textAlign: 'right', color: 'rgba(0,0,0,0.7)', fontSize: '18px', fontWeight: 700 }}>
                  {frPrix(totalServicesAffiche)}
                </div>
              </div>
            )}
          </div>

          {/* ── Bloc Remise services (sous Services) ── */}
          <div
            className="flex items-center"
            style={{ padding: '0 24px' }}
          >
            <RemiseInput
              label="Remise services"
              total={totalServicesAffiche}
              remise={remiseSvc}
              onChange={r => onRemiseSvcChange?.(r)}
              wrapperClassName="flex flex-1 items-center gap-3"
            />
          </div>

          </div>{/* fin colonne SERVICES */}

          {/* ── Colonne PIÈCES ── */}
          <div className="flex-1 flex flex-col" style={{ gap: '10px' }}>

          {/* ── PIÈCES ── */}
          <div className="overflow-hidden"
               style={{ borderRadius: '30px', backgroundColor: 'transparent' }}>
            <div className="flex items-center justify-between px-5"
                 style={{ backgroundColor: headerBg, height: '64px' }}>
              <div className="flex items-center gap-3">
                <Cog6ToothIcon style={{ width: '30px', height: '30px', color: 'rgba(0,0,0,0.5)' }} />
                <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '30px', fontWeight: 400, lineHeight: 1, display: 'inline-flex', alignItems: 'baseline', gap: '6px' }}>
                  Pièces
                  <HelpHint
                    topic="07-services-pieces"
                    title="Services + pièces"
                    hint="Le bouton + ouvre la popup Pièces (avec stock + SKU + scan). Coche les pièces nécessaires, ajuste qté/prix. Tu peux scanner un EAN avec 📷 ou importer un xlsx."
                    size={18}
                  />
                </span>
              </div>
              {/* v1.1.14+ : sur un BDT facturé, le + Pièces disparaît
                  (les items ne devraient plus être modifiés). Le bouton
                  Re-générer (en haut, section Services) suffit pour
                  redémarrer un PDF facture. */}
              {!isFacture && (
                <button
                  onClick={openPce}
                  className="btn-plus-round btn-plus-round--outline"
                  title="Ajouter des pièces"
                >
                  <PlusIcon />
                </button>
              )}
            </div>

            {/* Ligne légende */}
            <div
              className="flex items-center list-header" style={{ height: '35px', padding: '0 16px' }}
            >
              <div style={{ width: '32px' }}></div>
              <div className="flex-1">item</div>
              <div style={{ width: '80px', textAlign: 'right' }}>prix</div>
              <div style={{ width: '90px', textAlign: 'right' }}>qté</div>
              <div style={{ width: '80px', textAlign: 'right', paddingRight: '8px' }}>s/total</div>
            </div>

            {/* Lignes pièces */}
            <div style={{ backgroundColor: 'rgba(255,255,255,0.7)' }}>
              {pieces.length === 0 ? null : (
                pieces.map(item => {
                  const nom = item.piece!.nom;
                  const prixAffiche = prixEffectif(item);
                  const sousTotal = item.piece!.qte * prixAffiche;

                  // Stock courant : pieceId stable d'abord (v1.1.5+), puis
                  // fallbacks par nom (exact → cleaned → cleaned+lowercased).
                  const idKey = item.piece!.pieceId ? `id:${item.piece!.pieceId}` : null;
                  const cleaned = pceNomClean(nom);
                  const k = cleaned.toLowerCase().replace(/\s+/g, ' ').trim();
                  const stock = (idKey ? stockMap.get(idKey) : undefined)
                    ?? stockMap.get(nom)
                    ?? stockMap.get(cleaned)
                    ?? stockMap.get(k)
                    ?? 0;
                  // v1.1.5+ (cluster 2) — stockReserve (col AC) pour afficher
                  // "(réservé)" quand l'item est commité par un BDT actif.
                  const reserve = stockReserveMap.get(nom)
                    ?? stockReserveMap.get(cleaned)
                    ?? stockReserveMap.get(k)
                    ?? 0;
                  const qte = item.piece!.qte;
                  const cmd = item.piece!.cmd;
                  const manque = qte > 0 && stock < qte;
                  // Déjà en commande / partiellement reçue / reçue → pas de bouton +
                  const dejaCmd = cmd === '$' || cmd === '#' || cmd === '@';
                  const isOos = oosMap.get(nom) ?? oosMap.get(cleaned) ?? oosMap.get(k) ?? false;

                  return (
                    <div
                      key={item._row}
                      className="flex items-center"
                      style={{ padding: '10px 16px', borderBottom: '1px solid rgba(0,0,0,0.06)' }}
                    >
                      {/* Col 1 : effacer */}
                      <button
                        onClick={() => deleteItem(item._row)}
                        className="flex items-center justify-center transition-opacity hover:opacity-70 shrink-0"
                        style={{ width: '32px', color: 'rgba(0,0,0,0.5)' }}
                        title="Supprimer cette pièce"
                      >
                        <TrashIcon style={{ width: '20px', height: '20px' }} />
                      </button>

                      {/* Col 2 : items 14pt bold + (stock x) + bouton + si manque */}
                      <div className="flex-1 flex items-center" style={{ gap: '8px', color: 'rgba(0,0,0,0.7)', fontSize: '14px', fontWeight: 700 }}>
                        {(() => {
                          const catP = catalogue.find(p => p.nom === nom)
                                     ?? catalogue.find(p => p.nom === cleaned)
                                     ?? catalogue.find(p => p.nom.toLowerCase().replace(/\s+/g,' ').trim() === k);
                          return catP?.skuUrl
                            ? <a href={catP.skuUrl} target="_blank" rel="noopener noreferrer"
                                 className="hover:underline" style={{ color: 'inherit' }} title={catP.skuUrl}>
                                {pceLabel(cleaned)}
                              </a>
                            : <span>{pceLabel(cleaned)}</span>;
                        })()}
                        <span
                          className="text-xs italic"
                          style={{
                            color: manque
                              ? (reserve > 0 ? '#0d6efd' : '#b10202')   // bleu si réservé, rouge si manque réel
                              : 'rgba(0,0,0,0.4)',
                            fontWeight: 400,
                          }}
                        >
                          {/* v1.1.5+ (cluster 2) : stock 0 mais reserve > 0 →
                              afficher "(réservé)" — l'item est en atelier mais
                              commité par un BDT actif. Évite le faux signal
                              "rupture" sur des pièces qui sont juste prises. */}
                          {stock === 0 && reserve > 0
                            ? `(réservé${isOos ? ', oos' : ''})`
                            : `(stock ${stock}${isOos ? ', oos' : ''})`}
                        </span>
                        {manque && !dejaCmd && (
                          <button
                            type="button"
                            disabled={isOos}
                            onClick={() => {
                              if (isOos) return;
                              patchItem(item._row, { cmd: '$' });
                              // Flag la pièce catalogue en '$' pour qu'elle
                              // apparaisse dans la page Commande.
                              const catRow = (idKey ? catalogRowMap.get(idKey) : undefined)
                                ?? catalogRowMap.get(nom)
                                ?? catalogRowMap.get(cleaned)
                                ?? catalogRowMap.get(k);
                              if (catRow) {
                                // qté à commander = déficit (qté BDT − stock), cumulée avec l'existant
                                const catPiece = catalogue.find(p => p._row === catRow);
                                const deficit = Math.max(0, qte - stock);
                                const nextQteCmd = Math.max(catPiece?.qteACommander ?? 0, deficit);
                                patchPiece(catRow, { flag: '$', qteACommander: nextQteCmd }).catch((e: any) => {
                                  toast(e?.message ?? 'Erreur flag catalogue', 'error');
                                });
                              }
                              const fourn = (idKey ? fournisseurMap.get(idKey) : undefined)
                                ?? fournisseurMap.get(nom)
                                ?? fournisseurMap.get(cleaned)
                                ?? fournisseurMap.get(k)
                                ?? '';
                              toast(
                                fourn
                                  ? `Ajoutée à la commande ${fourn}`
                                  : 'Ajoutée à la commande (fournisseur inconnu)'
                              );
                            }}
                            title={isOos ? 'Pièce out-of-stock (non commandable)' : 'Ajouter à la commande'}
                            className="flex items-center justify-center transition-colors"
                            style={{
                              width: '20px', height: '20px',
                              borderRadius: '50%',
                              border: isOos ? '1.5px solid rgba(0,0,0,0.25)' : '1.5px solid #11734b',
                              color: isOos ? 'rgba(0,0,0,0.3)' : '#11734b',
                              background: 'transparent',
                              cursor: isOos ? 'not-allowed' : 'pointer',
                              padding: 0,
                            }}
                            onMouseEnter={e => { if (!isOos) e.currentTarget.style.backgroundColor = 'rgba(255,240,86,0.4)'; }}
                            onMouseLeave={e => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                          >
                            <span
                              style={{
                                fontSize: '16px',
                                lineHeight: '16px',
                                fontWeight: 700,
                                display: 'block',
                                marginTop: '-1px',
                              }}
                            >+</span>
                          </button>
                        )}
                      </div>

                      {/* Col 3 : prix (centré verticalement à 32px = hauteur widget qté) */}
                      <div
                        className="flex items-center justify-end"
                        style={{ width: '80px', height: '32px', color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontWeight: 700 }}
                      >
                        {frPrix(prixAffiche)}
                      </div>

                      {/* Col 4 : qté éditable — même style que le widget
                          durée Réhab (border input-system + chevrons ▲▼
                          à droite, zone grise, focus-within jaune). */}
                      <div
                        className="shrink-0 flex items-center group"
                        style={{
                          width: '60px', height: '32px',
                          border: 'none',
                          borderRadius: '12px',
                          backgroundColor: 'transparent',
                          overflow: 'hidden',
                          transition: 'border-color 150ms ease, box-shadow 150ms ease',
                        }}
                      >
                        <span
                          className="flex-1 text-right"
                          style={{
                            padding: '0 8px',
                            fontSize: '14px',
                            fontWeight: 700,
                            color: 'rgba(0,0,0,0.7)',
                            fontVariantNumeric: 'tabular-nums',
                          }}
                        >
                          {item.piece!.qte}
                        </span>
                        <div
                          className="flex flex-col shrink-0"
                          style={{
                            height: '100%',
                            borderLeft: '1px solid rgba(0,0,0,0.1)',
                            backgroundColor: 'rgba(0,0,0,0.04)',
                          }}
                        >
                          <button
                            type="button"
                            onClick={() => {
                              const next = item.piece!.qte + 1;
                              patchItemFields(item._row, 'piece', { qte: next, sousTotal: item.piece!.prix * next });
                            }}
                            className="flex items-center justify-center flex-1 transition-colors hover:bg-yellow-200"
                            style={{ width: '18px', cursor: 'pointer', color: 'rgba(0,0,0,0.6)', border: 'none', background: 'transparent' }}
                            title="Augmenter"
                          >
                            <span style={{ fontSize: '8px', lineHeight: 1 }}>▲</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const next = Math.max(0, item.piece!.qte - 1);
                              if (next !== item.piece!.qte) {
                                patchItemFields(item._row, 'piece', { qte: next, sousTotal: item.piece!.prix * next });
                              }
                            }}
                            disabled={item.piece!.qte <= 0}
                            className="flex items-center justify-center flex-1 transition-colors hover:bg-yellow-200 disabled:opacity-30"
                            style={{ width: '18px', cursor: 'pointer', color: 'rgba(0,0,0,0.6)', border: 'none', borderTop: '1px solid rgba(0,0,0,0.1)', background: 'transparent' }}
                            title="Diminuer"
                          >
                            <span style={{ fontSize: '8px', lineHeight: 1 }}>▼</span>
                          </button>
                        </div>
                      </div>

                      {/* Col 5 : sous-total (centré verticalement à 32px) */}
                      <div
                        className="flex items-center justify-end"
                        style={{ width: '80px', height: '32px', paddingRight: '8px', color: 'rgba(0,0,0,0.7)', fontSize: '14px', fontWeight: 700 }}
                      >
                        {frPrix(sousTotal)}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Total pièces */}
            {pieces.length > 0 && (
              <div
                className="flex items-center"
                style={{ backgroundColor: 'rgba(255,255,255,0.5)', height: '35px', padding: '0 16px' }}
              >
                <div style={{ width: '32px' }}></div>
                <div className="flex-1" style={{ color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontWeight: 700, fontStyle: 'italic', textAlign: 'right' }}>
                  total pièces
                </div>
                <div style={{ width: '80px' }}></div>
                <div style={{ width: '90px' }}></div>
                <div style={{ width: '80px', textAlign: 'right', paddingRight: '8px', color: 'rgba(0,0,0,0.7)', fontSize: '18px', fontWeight: 700 }}>
                  {frPrix(totalPiecesAffiche)}
                </div>
              </div>
            )}
          </div>

          {/* ── Bloc Remise pièces (sous Pièces) ── */}
          <div
            className="flex items-center"
            style={{ padding: '0 24px', gap: '10px' }}
          >
            <RemiseInput
              label="Remise pièces"
              total={totalPiecesAffiche}
              remise={remisePce}
              onChange={r => onRemisePceChange?.(r)}
              wrapperClassName="flex flex-1 items-center gap-3"
            />
            <label
              className="flex items-center gap-2 text-xs font-bold cursor-pointer"
              style={{ color: 'rgba(0,0,0,0.7)' }}
              title="Afficher les prix coûtants"
            >
              <input
                type="checkbox"
                checked={showCost}
                onChange={toggleCost}
                className="custom-checkbox"
              />
              Cost
            </label>
          </div>

          </div>{/* fin colonne PIÈCES */}
        </div>
      </div>

      {/* ── NOTE POUR LE CLIENT + TOTAL (côte à côte desktop, empilé mobile) ── */}
      <div className="shrink-0 flex flex-col md:flex-row md:items-end" style={{ gap: '20px', paddingTop: '20px' }}>
        {/* Note pour le client — toggle Éval ↔ Facture (2 champs distincts) */}
        <div className="w-full md:flex-1" style={{ backgroundColor: 'rgba(255,255,255,0.5)', borderRadius: '30px', padding: '20px' }}>
          <div className="flex items-center" style={{ gap: '10px', marginBottom: '8px' }}>
            <h4 style={{ color: 'rgba(0,0,0,0.5)', letterSpacing: '0.1em', margin: 0 }}>
              Note pour le client
            </h4>
            {/* Pills toggle Éval / Facture */}
            <div className="flex items-center" style={{ gap: '4px' }}>
              {(['eval', 'facture'] as const).map(m => {
                const active = noteMode === m;
                return (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setNoteMode(m)}
                    style={{
                      padding: '2px 10px',
                      height: '22px',
                      borderRadius: '11px',
                      backgroundColor: active ? '#fff056' : 'rgba(255,255,255,0.5)',
                      color: 'rgba(0,0,0,0.7)',
                      border: 'none',
                      cursor: 'pointer',
                      fontSize: '11px',
                      fontWeight: 700,
                      letterSpacing: '0.04em',
                      textTransform: 'uppercase',
                    }}
                  >
                    {m === 'eval' ? 'Éval' : 'Facture'}
                  </button>
                );
              })}
            </div>
          </div>
          {noteMode === 'eval' ? (
            <textarea
              key="note-eval"
              rows={5}
              value={noteClient}
              onChange={e => onNoteClientChange?.(e.target.value)}
              onBlur={onNoteClientBlur}
              placeholder="Message visible par le client sur l'évaluation…"
              className="w-full px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-yellow-400 block"
              style={{
                borderRadius: '0px',
                border: 'none',
                backgroundColor: 'rgba(255,255,255,0.7)',
                color: 'rgba(0,0,0,0.8)',
                resize: 'none',
                lineHeight: '1.5',
                height: 'calc(1.5em * 5 + 16px)',
              }}
            />
          ) : (
            <textarea
              key="note-facture"
              rows={5}
              value={noteClientFacture}
              onChange={e => onNoteClientFactureChange?.(e.target.value)}
              onBlur={onNoteClientFactureBlur}
              placeholder="Message visible par le client sur la facture…"
              className="w-full px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-yellow-400 block"
              style={{
                borderRadius: '0px',
                border: 'none',
                backgroundColor: 'rgba(255,255,255,0.7)',
                color: 'rgba(0,0,0,0.8)',
                resize: 'none',
                lineHeight: '1.5',
                height: 'calc(1.5em * 5 + 16px)',
              }}
            />
          )}
        </div>

        {/* Total — 2/3 de largeur, ligne unique */}
        <div style={{ flex: '2 1 0%' }}>
          <BDCTotaux
            bdc={bdc}
            remiseSvc={montantSvc}
            remisePce={montantPce}
            avance={avance}
            onAvanceChange={onAvanceChange}
            totalPiecesAffiche={totalPiecesAffiche}
            totalServicesAffiche={totalServicesAffiche}
          />
        </div>
      </div>

      <ServicesPopup bdcId={bdcId} open={showSvc} onClose={() => setShowSvc(false)} onOpenPieces={openPce} />
      <PiecesPopup   bdcId={bdcId} open={showPce} onClose={() => setShowPce(false)} onOpenServices={openSvc} />

      {/* Modal : relier un service orphelin (nom ≠ catalogue) à un service du catalogue */}
      <Modal
        open={relinkTarget !== null}
        onClose={() => { setRelinkTarget(null); setRelinkSearch(''); }}
        title="Relier ce service au catalogue"
        size="md"
      >
        {relinkTarget && (
          <div className="flex flex-col" style={{ gap: '14px' }}>
            <div style={{
              backgroundColor: 'rgba(245,158,11,0.12)',
              borderRadius: '12px',
              padding: '10px 14px',
              fontSize: '13px',
              color: '#7c2d12',
            }}>
              <div style={{ fontWeight: 700 }}>Nom stocké sur le BDC :</div>
              <div style={{ marginTop: '4px', fontStyle: 'italic' }}>{relinkTarget.nom}</div>
            </div>
            <input
              type="search"
              autoFocus
              placeholder="Rechercher un service du catalogue…"
              value={relinkSearch}
              onChange={e => setRelinkSearch(e.target.value)}
              className="input-system"
            />
            <div className="overflow-y-auto" style={{
              maxHeight: '320px',
              border: '1.5px solid rgba(0,0,0,0.15)',
              borderRadius: '12px',
            }}>
              {(() => {
                const q = normSvcKey(relinkSearch);
                const list = (svcCatalogue ?? [])
                  .filter(s => {
                    if (!s.label) return false;
                    if (!q) return true;
                    return normSvcKey(s.label).includes(q);
                  })
                  .slice(0, 100);
                if (!list.length) {
                  return <p className="text-center text-sm py-6" style={{ color: 'rgba(0,0,0,0.4)' }}>Aucun service.</p>;
                }
                return list.map(s => (
                  <button
                    key={s._row}
                    type="button"
                    onClick={async () => {
                      const tgt = relinkTarget;
                      setRelinkTarget(null); setRelinkSearch('');
                      try {
                        await patchItemFields(tgt.row, 'service', {
                          nom : s.label,
                          prix: s.prix ?? 0,
                          dureeOverride: '...',   // reset override — la durée catalogue prend le relais
                        });
                      } catch (err: any) {
                        console.error(err);
                      }
                    }}
                    className="w-full text-left transition-colors hover:bg-yellow-50"
                    style={{
                      padding: '10px 14px',
                      borderBottom: '1px solid rgba(0,0,0,0.06)',
                      background: 'transparent',
                      border: 'none',
                      cursor: 'pointer',
                      fontSize: '13px',
                      color: 'rgba(0,0,0,0.75)',
                    }}
                  >
                    <div style={{ fontWeight: 700 }}>{s.label}</div>
                    <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.45)', marginTop: '2px' }}>
                      {s.categorie || '—'} · {s.duree || '—'} · {frPrix(s.prix ?? 0)}
                    </div>
                  </button>
                ));
              })()}
            </div>
            <div className="flex items-center" style={{ paddingTop: '4px' }}>
              <button
                type="button"
                onClick={() => { setRelinkTarget(null); setRelinkSearch(''); }}
                className="btn-secondary"
              >
                Annuler
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
