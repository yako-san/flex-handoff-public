'use client';
import useSWR, { mutate as swrMutate } from 'swr';
import { jsonFetcher as fetcher } from '@/lib/swr';
import type { Vente, VenteItem } from '@/types/vente';

const EMPTY: Vente[] = [];

/** Toute mutation Vente affecte aussi PIÈCES (col AB stock + col AC réservé)
 *  via le snapshot/recompute côté serveur. Il faut donc invalider le cache
 *  SWR pieces côté client pour que l'UI reflète immédiatement les nouveaux
 *  chiffres sans attendre un focus / refresh manuel. */
async function revalidatePieces() {
  await swrMutate('/api/catalogue/pieces').catch(() => {});
}

/** Construit un VenteItem complet à partir d'un input partiel. */
function buildItem(input: { pieceId: string; sku: string; nom: string; qte: number; prixUnit: number }): VenteItem {
  return {
    pieceId  : input.pieceId,
    sku      : input.sku,
    nom      : input.nom,
    qte      : input.qte,
    prixUnit : input.prixUnit,
    sousTotal: input.qte * input.prixUnit,
  };
}

export function useVentes() {
  const { data, error, isLoading, mutate } = useSWR<Vente[]>('/api/ventes', fetcher, {
    revalidateOnFocus: false,
    // Si le GET échoue (ex. quota Sheets), garder la data précédente plutôt
    // que de basculer en `undefined` — évite que les ventes optimistes
    // disparaissent de l'UI sur une cascade quota.
    keepPreviousData : true,
    // dedupingInterval 30 s : réduit les fetch dupliqués en cas de
    // mutations rapides ou de multiple composants montés.
    dedupingInterval : 30_000,
  });

  /**
   * Création vente — patrón optimiste.
   *   1. POST → si succès, le serveur a écrit la ligne dans _VENTES_.
   *   2. Insertion immédiate dans le cache SWR (sans attendre le GET).
   *   3. Revalidation déclenchée mais sans blocage : si elle échoue
   *      (quota ou autre), la version optimiste reste affichée.
   * Garantit qu'une vente créée ne disparaît jamais de l'UI.
   */
  async function createVente(input: {
    date: string;
    client: string;
    items: { pieceId: string; sku: string; nom: string; qte: number; prixUnit: number }[];
    cost?: boolean;
  }) {
    const res = await fetch('/api/ventes', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(input),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    const body = await res.json();

    // Vente optimiste — venteId vient du serveur. _rows reste vide jusqu'à
    // ce que le revalidate les remplisse (utile pour delete/patch d'item).
    const optimistic: Vente = {
      venteId      : body.venteId,
      date         : input.date,
      client       : input.client,
      items        : input.items.map(buildItem),
      total        : input.items.reduce((s, it) => s + it.qte * it.prixUnit, 0),
      _rows        : [],
      cost         : input.cost ?? false,
      factureNumero: undefined,
      factureDate  : undefined,
      factureUrl   : undefined,
    };
    mutate(
      (prev: Vente[] | undefined) => [optimistic, ...(prev ?? [])],
      { revalidate: true },  // background revalidate ; si fail, on garde optimistic
    );
    revalidatePieces();
    return body;
  }

  /** Delete optimiste : retirer la vente du cache, puis revalidate sans bloquer. */
  async function deleteVente(venteId: string) {
    const res = await fetch(`/api/ventes/${encodeURIComponent(venteId)}`, { method: 'DELETE' });
    if (!res.ok) throw new Error((await res.json()).error);
    mutate(
      (prev: Vente[] | undefined) => (prev ?? []).filter(v => v.venteId !== venteId),
      { revalidate: true },
    );
    revalidatePieces();
  }

  /**
   * v1.1.5+ (cluster 4 item m) — Marque/démarque une vente comme payée.
   * Optimiste : met à jour payeStatus dans le cache, rollback si erreur.
   */
  async function markVentePayee(venteId: string, paye: boolean) {
    // Optimistic update
    mutate(
      (prev: Vente[] | undefined) =>
        (prev ?? []).map(v => v.venteId === venteId ? { ...v, payeStatus: paye ? 'payé' : '' } : v),
      { revalidate: false },
    );
    try {
      const res = await fetch(`/api/ventes/${encodeURIComponent(venteId)}/marquer-payee`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ paye }),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      mutate();  // re-fetch pour confirmation
    } catch (err) {
      mutate();  // rollback
      throw err;
    }
  }

  /**
   * Archivage optimiste : retire la vente du cache (Ventes actives) ; elle
   * réapparaîtra dans /archives. Pas de delta stock (vente déjà facturée).
   */
  async function archiveVente(venteId: string) {
    const res = await fetch(`/api/ventes/${encodeURIComponent(venteId)}/archive`, { method: 'POST' });
    if (!res.ok) throw new Error((await res.json()).error);
    mutate(
      (prev: Vente[] | undefined) => (prev ?? []).filter(v => v.venteId !== venteId),
      { revalidate: true },
    );
    // Invalider aussi le cache SWR archives au cas où la page /archives serait montée.
    swrMutate('/api/ventes/archives').catch(() => {});
  }

  /** Delete item optimiste : retirer l'item du tableau de la vente concernée. */
  async function deleteVenteItem(venteId: string, row: number) {
    const res = await fetch(`/api/ventes/${encodeURIComponent(venteId)}/items/${row}`, { method: 'DELETE' });
    if (!res.ok) throw new Error((await res.json()).error);
    mutate(
      (prev: Vente[] | undefined) =>
        (prev ?? []).map(v => {
          if (v.venteId !== venteId) return v;
          const idx = v._rows.indexOf(row);
          if (idx < 0) return v;
          const newItems = v.items.filter((_, i) => i !== idx);
          const newRows  = v._rows.filter((_, i) => i !== idx);
          return {
            ...v,
            items: newItems,
            _rows: newRows,
            total: newItems.reduce((s, it) => s + it.sousTotal, 0),
          };
        }),
      { revalidate: true },
    );
    revalidatePieces();
  }

  /** Patch qty optimiste : recalcul sousTotal + total. */
  async function patchVenteItemQte(venteId: string, row: number, qte: number) {
    const res = await fetch(`/api/ventes/${encodeURIComponent(venteId)}/items/${row}`, {
      method : 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ qte }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    mutate(
      (prev: Vente[] | undefined) =>
        (prev ?? []).map(v => {
          if (v.venteId !== venteId) return v;
          const idx = v._rows.indexOf(row);
          if (idx < 0) return v;
          const newItems = v.items.map((it, i) =>
            i === idx ? { ...it, qte, sousTotal: qte * it.prixUnit } : it,
          );
          return {
            ...v,
            items: newItems,
            total: newItems.reduce((s, it) => s + it.sousTotal, 0),
          };
        }),
      { revalidate: true },
    );
    revalidatePieces();
  }

  /** Append items optimiste : ajout au tableau de la vente. _rows reste
   *  inconnu localement, sera comblé par le revalidate. */
  async function addItemsToVente(
    venteId: string,
    items  : { pieceId: string; sku: string; nom: string; qte: number; prixUnit: number }[],
  ) {
    const res = await fetch(`/api/ventes/${encodeURIComponent(venteId)}/items`, {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ items }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    const body = await res.json();
    const newItems = items.map(buildItem);
    mutate(
      (prev: Vente[] | undefined) =>
        (prev ?? []).map(v => {
          if (v.venteId !== venteId) return v;
          const merged = [...v.items, ...newItems];
          return { ...v, items: merged, total: merged.reduce((s, it) => s + it.sousTotal, 0) };
        }),
      { revalidate: true },
    );
    revalidatePieces();
    return body;
  }

  async function facturerVente(
    venteId       : string,
    noteClient    : string = '',
    lang?         : 'FR' | 'EN',
    remisePce?    : { type: 'pct' | 'fixed'; value: number },
    modePaiement  : 'comptant' | 'interac' | 'cartes' = 'comptant',
    generatePdf   : boolean = true,
    // v1.0.25+ : statut PAYÉ direct si client paie maintenant (UI checkbox)
    payeMaintenant: boolean = false,
  ) {
    const res = await fetch(`/api/ventes/${encodeURIComponent(venteId)}/facture`, {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ noteClient, lang, remisePce, modePaiement, generatePdf, payeMaintenant }),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || 'Erreur facturation');
    mutate(
      (prev: Vente[] | undefined) =>
        prev?.map(v =>
          v.venteId === venteId
            ? {
                ...v,
                factureNumero: body.factureNumero ?? v.factureNumero,
                factureDate  : body.factureDate  ?? new Date().toISOString().slice(0, 10),
                factureUrl   : body.factureUrl    ?? body.pdfUrl ?? '',
                remiseType   : remisePce?.type,
                remiseValue  : remisePce?.value,
              }
            : v,
        ),
      { revalidate: false },
    );
    revalidatePieces();
    return body as {
      draftId       : string;
      draftUrl      : string;
      message       : string;
      pdfUrl?       : string;
      factureNumero?: string;
      factureDate?  : string;
      factureUrl?   : string;
    };
  }

  /**
   * v1.3.1+ (cluster 7 item f) — Bascule le flag Cost d'une vente brouillon.
   * Refusé si la vente est déjà facturée (factureDate présent).
   * Recompute optimiste : on met à jour `cost` et la prixUnit de chaque
   * item piece selon le catalogue.
   */
  async function setVenteCost(venteId: string, cost: boolean) {
    const res = await fetch(`/api/ventes/${encodeURIComponent(venteId)}/cost`, {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ cost }),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || 'Erreur Cost');
    // Revalidation (les prixUnit recalculés viennent du serveur)
    await mutate();
    return body as { itemsUpdated: number; itemsSkipped: number };
  }

  return {
    ventes: Array.isArray(data) ? data : EMPTY,
    error,
    isLoading,
    createVente,
    deleteVente,
    archiveVente,
    markVentePayee,
    setVenteCost,
    deleteVenteItem,
    patchVenteItemQte,
    addItemsToVente,
    facturerVente,
    mutate,
  };
}
