/**
 * POST /api/ventes/[venteId]/cost  body { cost: boolean }
 *
 * v1.3.1+ (cluster 7 item f) — Bascule le flag Cost d'une vente brouillon.
 * Recalcule prixUnit de chaque item piece selon le nouveau flag
 * (cost = prixCost catalogue, sinon prixBDC).
 *
 * Refusé si la vente est déjà facturée (400).
 */
import { NextResponse } from 'next/server';
import { setVenteCost } from '@/lib/sheets/ventes';

export async function POST(req: Request, { params }: { params: { venteId: string } }) {
  try {
    const body = await req.json().catch(() => ({}));
    const cost = body?.cost === true;
    const result = await setVenteCost(params.venteId, cost);
    return NextResponse.json({ ok: true, venteId: params.venteId, cost, ...result });
  } catch (err: any) {
    const msg = err?.message ?? 'Erreur interne';
    const status = msg.includes('introuvable') ? 404
                 : msg.includes('verrouillé') ? 400
                 : 500;
    return NextResponse.json({ error: msg }, { status });
  }
}
