/**
 * POST /api/po/[poNumber]/rename  body { displayName: string }
 *
 * v1.3.1+ (cluster suite item n) — Override le poNumber affiché par un
 * nom custom (ex. numéro de facture fournisseur reçu après coup).
 * Écrit en col Q de la 1ʳᵉ ligne du PO. La clé poNumber reste inchangée.
 *
 * Passer displayName = '' pour effacer l'override (retour au poNumber).
 */
import { NextResponse } from 'next/server';
import { renamePO } from '@/lib/sheets/po';

export async function POST(req: Request, { params }: { params: { poNumber: string } }) {
  try {
    const body = await req.json().catch(() => ({}));
    const displayName = typeof body?.displayName === 'string' ? body.displayName : '';
    await renamePO(params.poNumber, displayName);
    return NextResponse.json({ ok: true, poNumber: params.poNumber, displayName: displayName.trim() || null });
  } catch (err: any) {
    const msg = err?.message ?? 'Erreur interne';
    const status = msg.includes('introuvable') ? 404 : 500;
    return NextResponse.json({ error: msg }, { status });
  }
}
