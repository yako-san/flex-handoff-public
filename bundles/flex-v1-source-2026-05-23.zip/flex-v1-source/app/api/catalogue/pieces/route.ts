import { NextResponse } from 'next/server';
import { getPieces, addPieceToCatalogue } from '@/lib/sheets/catalogue';
import cache, { CACHE_KEYS } from '@/lib/cache';

/** GET /api/catalogue/pieces — ?refresh=1 pour forcer un fetch frais
 *  (invalide aussi le cache catégories pour que les nouvelles cats
 *  apparaissent sans reload serveur). */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    if (searchParams.get('refresh') === '1') {
      await cache.del(CACHE_KEYS.PIECES);
      await cache.del(CACHE_KEYS.CATEGORIES);
    }
    const pieces = await getPieces();
    return NextResponse.json({ pieces });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/**
 * POST /api/catalogue/pieces
 * Body : {
 *   nom: string;
 *   categorie: string;         // ex. "4. Freins, Patins de route"
 *   qte?: number;
 *   prix?: number;             // prix d'achat ; va dans K/L/M selon fournisseur
 *   fournisseur?: string;
 *   sku?: string;
 *   skuUrl?: string;
 * }
 * Insère une nouvelle pièce dans l'onglet PIÈCES en dupliquant la
 * ligne "Nom ITEM" de la même catégorie principale (copyPaste).
 */
export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (!body.nom) return NextResponse.json({ error: 'nom requis' }, { status: 400 });
    const result = await addPieceToCatalogue({
      nom        : String(body.nom),
      categorie  : String(body.categorie ?? ''),
      qte        : typeof body.qte === 'number' ? body.qte : Number(body.qte) || 0,
      prix       : typeof body.prix === 'number' ? body.prix : Number(body.prix) || 0,
      fournisseur: String(body.fournisseur ?? ''),
      sku        : String(body.sku ?? ''),
      skuUrl     : String(body.skuUrl ?? ''),
      codeBarre  : String(body.codeBarre ?? ''),
      oos        : body.oos === true,
    });
    // v1.3.1+ : qteSac écrit séparément en col F (le template addPieceToCatalogue
    // ne le couvre pas — col F est gap). Update après insert si fourni.
    if (body.qteSac !== undefined && result?.row) {
      const { updatePieceFields } = await import('@/lib/sheets/catalogue');
      await updatePieceFields(result.row, { qteSac: Number(body.qteSac) || undefined });
    }
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
