'use client';
import React, { useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock, SearchInput, AddButton } from '@/components/layout/PageHeader';
import PiecesTabs from '@/components/catalogue/PiecesTabs';
import NotesCell from '@/components/catalogue/NotesCell';
import MultiSelectCat from '@/components/ui/MultiSelectCat';
import { usePieces } from '@/hooks/useCatalogue';
import { usePOs }    from '@/hooks/usePO';
import { frPrix }    from '@/lib/utils/format';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import DragTh from '@/components/ui/DragTh';
import { useColOrder } from '@/hooks/useColOrder';
import { toast } from '@/components/ui/Toast';
// CMD_OPTIONS / CMD_STYLE / CMD_TOOLTIP plus utilisés : la cellule "acmd"
// est passée d'un dropdown 6 valeurs à une checkbox binaire √↔$ (2026-05-16).
import { CubeIcon, ChevronDownIcon, ChevronRightIcon, ArrowRightIcon, ArrowUpTrayIcon } from '@heroicons/react/24/outline';
import type { Piece } from '@/types/catalogue';

/**
 * Onglet Commande — pièces à commander ou en commande, groupées par fournisseur.
 *
 * Affiche les pièces flag = '√' (à commander) ET '$' (en commande chez fournisseur).
 * Une checkbox par ligne permet de basculer rapidement entre les deux états :
 *   - coché   = '$' (placée chez un fournisseur)
 *   - décoché = '√' (à commander, pas encore placée)
 *
 * Chaque bloc fournisseur peut ensuite être transféré en Réception (création
 * d'un PO formel) — le bouton "Transférer en Réception" prend tous les items
 * du groupe.
 *
 * (Demande yako-san 2026-05-16 — remplace le dropdown CMD à 6 options par
 * un workflow checkbox simple sur les 2 états utiles côté commande.)
 */

const COLS = [
  { id: 'acmd',        header: 'statut',       width: '70px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'nom',         header: 'item',         width: '33%',    hCls: 'px-4 py-2',              cCls: 'px-4 py-2 text-gray-800 font-medium whitespace-nowrap overflow-hidden text-ellipsis' },
  { id: 'notes',       header: 'notes',        width: '',       hCls: 'px-3 py-2',              cCls: 'px-2 py-1' },
  { id: 'sku',         header: 'sku',          width: '90px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'oos',         header: 'oos',          width: '48px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'stock',       header: 'stock',        width: '48px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'prix',        header: 'prix',         width: '80px',   hCls: 'px-3 py-2 text-right',  cCls: 'px-3 py-1.5 text-right text-gray-700 font-medium' },
  { id: 'qte',         header: 'qté',          width: '64px',   hCls: 'px-2 py-2 text-center', cCls: 'px-1 py-1.5 text-center' },
  { id: 'sousTotal',   header: 's/total',      width: '80px',   hCls: 'px-3 py-2 text-right',  cCls: 'px-3 py-1.5 text-right text-gray-700 font-medium' },
  { id: 'categorie',   header: 'catégories',   width: '220px',  hCls: 'px-3 py-2',              cCls: 'px-3 py-1.5' },
] as const;

type ColId = typeof COLS[number]['id'];

const FOURNISSEUR_ORDER = ['Babac', 'HLC', 'Brompton', 'C&L'];

function isExcluded(nom: string): boolean {
  if (!nom || nom.trim() === '') return true;
  const n = nom.trim().toLowerCase();
  if (n === 'nom item' || n === 'item') return true;
  if (nom.startsWith('FIN DE')) return true;
  return false;
}

function todayStr(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/** poNumber : FOURN-YYYYMMDD-HHmm (slug sans accents/espaces) */
function genPoNumber(fourn: string): string {
  const slug = fourn
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Za-z0-9]/g, '')
    .toUpperCase() || 'PO';
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `${slug}-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
}

export default function CommandePage() {
  const { pieces, isLoading, patchPiece } = usePieces();
  const { createPO }                      = usePOs();
  const router                            = useRouter();
  const [search, setSearch] = useState('');
  const [busy,   setBusy]   = useState<Set<number>>(new Set());
  const [closed, setClosed] = useState<Set<string>>(new Set());
  const [transferringFourn, setTransferringFourn] = useState<string | null>(null);
  const { orderedCols, dragProps, dragOverId } = useColOrder('commande', COLS as any);

  function toggleFournisseur(name: string) {
    setClosed(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  }

  const filtered = useMemo(() => pieces.filter(p => {
    if (isExcluded(p.nom)) return false;
    // Affiche les pièces "à commander" (√) ET "en commande chez fournisseur" ($).
    // La checkbox dans chaque ligne bascule entre les deux états.
    if (p.flag !== '√' && p.flag !== '$') return false;
    if (!search) return true;
    const q = search.toLowerCase();
    return p.nom.toLowerCase().includes(q)
        || (p.fournisseur ?? '').toLowerCase().includes(q)
        || (p.sku ?? '').toLowerCase().includes(q);
  }), [pieces, search]);

  const categories = useMemo(() =>
    [...new Set(pieces.filter(p => !isExcluded(p.nom)).map(p => p.categorie).filter(Boolean))].sort(),
  [pieces]);

  const grouped = useMemo(() => {
    const map = new Map<string, Piece[]>();
    filtered.forEach(p => {
      const f = p.fournisseur || 'Autres';
      if (!map.has(f)) map.set(f, []);
      map.get(f)!.push(p);
    });
    const entries = [...map.entries()].sort((a, b) => {
      if (a[0] === 'Autres') return 1;
      if (b[0] === 'Autres') return -1;
      const ia = FOURNISSEUR_ORDER.indexOf(a[0]);
      const ib = FOURNISSEUR_ORDER.indexOf(b[0]);
      if (ia >= 0 && ib >= 0) return ia - ib;
      if (ia >= 0) return -1;
      if (ib >= 0) return 1;
      return a[0].localeCompare(b[0], 'fr');
    });
    return new Map(entries);
  }, [filtered]);

  async function save(row: number, fields: Parameters<typeof patchPiece>[1]) {
    setBusy(prev => new Set(prev).add(row));
    try { await patchPiece(row, fields); }
    catch (err: any) { toast(err.message, 'error'); }
    finally { setBusy(prev => { const s = new Set(prev); s.delete(row); return s; }); }
  }

  async function transferer(fourn: string, items: Piece[]) {
    if (!items.length) return;
    const poNumber = genPoNumber(fourn);
    setTransferringFourn(fourn);
    try {
      await createPO({
        poNumber,
        fournisseur : fourn,
        dateCommande: todayStr(),
        items: items.map(p => ({
          nom         : p.nom,
          sku         : p.sku,
          qteCommandee: p.qteACommander || 1,
          prixAchat   : p.prixAchat || p.prixBase || 0,
          pieceRow    : p._row,
          pieceId     : p.pieceId,
          notes       : '',
        })),
      });
      toast(`PO ${poNumber} créé (${items.length} items) — redirection…`);
      router.push('/catalogue/reception');
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setTransferringFourn(null);
    }
  }

  function renderCell(id: ColId, p: Piece) {
    const isBusy = busy.has(p._row);

    switch (id) {
      case 'acmd': {
        // Checkbox : coché = '$' (placée chez fournisseur), décoché = '√' (à commander).
        // Remplace le dropdown à 6 options — la commande page ne montre que
        // ces 2 états, le workflow checkbox est plus rapide en atelier.
        const isPlaced = p.flag === '$';
        return (
          <label
            className="inline-flex items-center justify-center cursor-pointer w-full"
            title={isPlaced ? 'Placée chez fournisseur — décocher pour repasser à commander' : 'À commander — cocher quand placée chez fournisseur'}
            style={{ opacity: isBusy ? 0.4 : 1 }}
          >
            <input
              type="checkbox"
              checked={isPlaced}
              disabled={isBusy}
              onChange={e => save(p._row, { flag: e.target.checked ? '$' : '√' })}
              className="w-5 h-5 cursor-pointer accent-yellow-400"
              aria-label={isPlaced ? 'Pièce placée chez fournisseur' : 'Pièce à commander'}
            />
          </label>
        );
      }
      case 'nom':
        return p.skuUrl
          ? <a href={p.skuUrl} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()}
               className="hover:underline" style={{ color: 'inherit' }} title={p.skuUrl}>{p.nom}</a>
          : <span title={p.nom}>{p.nom}</span>;
      case 'notes':
        return (
          <NotesCell
            value={p.notes}
            disabled={isBusy}
            onSave={val => save(p._row, { notes: val })}
          />
        );
      case 'qte': {
        const q = p.qteACommander || 0;
        const color = q > 0 ? '#2563eb' : 'rgba(0,0,0,0.4)';
        return (
          <div
            className="inline-flex items-center group"
            style={{
              height: '24px',
              borderRadius: '8px',
              overflow: 'hidden',
              border: '1px solid rgba(0,0,0,0.12)',
              backgroundColor: '#fff',
            }}
          >
            {/* Cluster 9 : qté éditable directement (tap pour focus, blur
                pour sauver). Avant : span en lecture seule + boutons ▲▼. */}
            <input
              type="text"
              inputMode="numeric"
              defaultValue={String(q)}
              key={`${p._row}-${q}`}
              disabled={isBusy}
              onBlur={(e) => {
                const v = e.target.value.replace(/[^\d]/g, '');
                const next = Math.max(0, parseInt(v || '0', 10) || 0);
                if (next !== q) save(p._row, { qteACommander: next });
              }}
              onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }}
              className="text-xs font-semibold tabular-nums text-center"
              style={{
                width: '40px',
                height: '24px',
                color,
                border: 'none',
                background: 'transparent',
                outline: 'none',
                padding: 0,
              }}
              title="Tape une qté + Enter pour sauver. ▲▼ aussi disponibles."
            />
            <div
              className="flex flex-col shrink-0"
              style={{
                height: '100%',
                borderLeft: '1px solid rgba(0,0,0,0.1)',
                backgroundColor: 'rgba(0,0,0,0.04)',
              }}
            >
              <button
                type="button"
                disabled={isBusy}
                onClick={() => save(p._row, { qteACommander: q + 1 })}
                className="flex items-center justify-center flex-1 hover:bg-yellow-200 disabled:opacity-40"
                style={{ width: '16px', cursor: 'pointer', color: 'rgba(0,0,0,0.6)', border: 'none', background: 'transparent' }}
                title="Augmenter"
              >
                <span style={{ fontSize: '7px', lineHeight: 1 }}>▲</span>
              </button>
              <button
                type="button"
                disabled={isBusy || q <= 0}
                onClick={() => save(p._row, { qteACommander: Math.max(0, q - 1) })}
                className="flex items-center justify-center flex-1 hover:bg-yellow-200 disabled:opacity-30"
                style={{ width: '16px', cursor: 'pointer', color: 'rgba(0,0,0,0.6)', border: 'none', borderTop: '1px solid rgba(0,0,0,0.1)', background: 'transparent' }}
                title="Diminuer"
              >
                <span style={{ fontSize: '7px', lineHeight: 1 }}>▼</span>
              </button>
            </div>
          </div>
        );
      }
      case 'categorie':
        return (
          <MultiSelectCat
            value={p.categorie}
            options={categories}
            disabled={isBusy}
            onSave={val => save(p._row, { categorie: val })}
          />
        );
      case 'prix':
        return frPrix(p.prixBase);
      case 'sousTotal':
        return frPrix(p.sousTotal);
      case 'stock':
        return (
          <span className={`text-xs font-semibold tabular-nums ${p.stock > 0 ? 'text-green-600' : 'text-gray-400'}`}>
            {p.stock}
          </span>
        );
      case 'sku':
        return p.skuUrl ? (
          <a href={p.skuUrl} target="_blank" rel="noopener noreferrer"
            className="text-xs font-mono text-blue-500 hover:underline truncate block text-center" title={p.skuUrl}>
            {p.sku || p.skuUrl}
          </a>
        ) : (
          <span className="text-xs font-mono text-gray-500 truncate block text-center" title={p.sku}>
            {p.sku || '—'}
          </span>
        );
      case 'oos':
        return p.oos ? (
          <span className="text-xs font-bold text-red-600">OOS</span>
        ) : null;
    }
  }

  function TableColgroup() {
    return (
      <colgroup>
        {orderedCols.map(col => (
          <col key={col.id} style={{ width: (col as any).width || undefined }} />
        ))}
      </colgroup>
    );
  }

  function TableHead() {
    return (
      <thead>
        <tr className="list-header">
          {orderedCols.map(col => (
            <DragTh key={col.id} className={col.hCls} isDragOver={dragOverId === col.id} {...dragProps(col.id)}>
              {col.header}
            </DragTh>
          ))}
        </tr>
      </thead>
    );
  }

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader subtitle="catalogue · pièces à commander" title="Pièces" titleSuffix=": commandes">
          <ToolbarBlock>
            <SearchInput value={search} onChange={setSearch} />
            <PiecesTabs />
          </ToolbarBlock>
          <AddButton disabled title="—" />
        </PageHeader>

        {isLoading && <LoadingSpinner className="py-20" />}

        {!isLoading && (
          <div className="md:bg-black/20 md:rounded-[50px] md:p-5">
           <div className="flex flex-col" style={{ gap: '20px' }}>
            {[...grouped.entries()].map(([fournisseur, items]) => {
              const total = items.reduce((s, p) => s + p.sousTotal, 0);
              const isClosed = closed.has(fournisseur);
              const busyTransfer = transferringFourn === fournisseur;
              return (
              <div key={fournisseur} className="overflow-hidden" style={{ borderRadius: '30px' }}>
                <div
                  className="flex items-center justify-between"
                  style={{ backgroundColor: '#fff056', height: '64px', paddingLeft: '30px', paddingRight: '20px' }}
                >
                  <div className="flex items-center gap-3">
                    <CubeIcon style={{ width: '30px', height: '30px', color: 'rgba(0,0,0,0.5)' }} />
                    <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '24px', fontWeight: 700, lineHeight: 1 }}>
                      {fournisseur}
                    </span>
                    <span style={{ color: 'rgba(0,0,0,0.4)', fontSize: '14px' }}>({items.length})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => window.open(`/api/commande/export?fournisseur=${encodeURIComponent(fournisseur)}`, '_blank')}
                      className="flex items-center gap-1"
                      style={{
                        height: '38px',
                        padding: '0 14px',
                        borderRadius: '32px',
                        backgroundColor: 'rgba(0,0,0,0.15)',
                        color: 'rgba(0,0,0,0.7)',
                        border: 'none',
                        fontSize: '13px',
                        fontWeight: 700,
                        letterSpacing: '0.04em',
                        textTransform: 'uppercase',
                        cursor: 'pointer',
                      }}
                      title={`Télécharger la commande ${fournisseur} en xlsx`}
                    >
                      <ArrowUpTrayIcon style={{ width: '14px', height: '14px' }} /> Export
                    </button>
                    <button
                      onClick={() => transferer(fournisseur, items)}
                      disabled={busyTransfer}
                      className="flex items-center gap-2 disabled:opacity-40"
                      style={{
                        height: '38px',
                        padding: '0 16px',
                        borderRadius: '32px',
                        backgroundColor: '#000',
                        color: '#fff056',
                        border: 'none',
                        fontSize: '13px',
                        fontWeight: 700,
                        letterSpacing: '0.06em',
                        textTransform: 'uppercase',
                        cursor: busyTransfer ? 'not-allowed' : 'pointer',
                      }}
                      title="Créer un PO dans Réception avec ces items"
                    >
                      {busyTransfer ? 'Transfert…' : <>Transférer en Réception <ArrowRightIcon style={{ width: '16px', height: '16px' }} /></>}
                    </button>
                    <button
                      onClick={() => toggleFournisseur(fournisseur)}
                      className="flex items-center justify-center transition-opacity hover:opacity-70"
                      style={{ width: '35px', height: '35px', color: 'rgba(0,0,0,0.5)' }}
                      title={isClosed ? 'Ouvrir' : 'Fermer'}
                    >
                      {isClosed
                        ? <ChevronRightIcon style={{ width: '24px', height: '24px' }} strokeWidth={3} />
                        : <ChevronDownIcon style={{ width: '24px', height: '24px' }} strokeWidth={3} />}
                    </button>
                  </div>
                </div>
                {!isClosed && <div className="overflow-x-auto">
                  <table className="w-full text-left table-fixed">
                    <TableColgroup />
                    <TableHead />
                    <tbody>
                      {items.map((p, i) => {
                        const isOos = !!p.oos;
                        const OOS_COLS = ['oos', 'stock', 'prix', 'qte', 'sousTotal'];
                        const oosPresent = orderedCols
                          .map(c => c.id)
                          .filter(id => OOS_COLS.includes(id));
                        const oosFirst = oosPresent[0];
                        const oosLast  = oosPresent[oosPresent.length - 1];
                        const baseBg = i % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)';
                        return (
                          <tr key={p._row} className={`text-sm ${busy.has(p._row) ? 'opacity-60' : ''}`}>
                            {orderedCols.map(col => {
                              const inPill = isOos && OOS_COLS.includes(col.id);
                              if (inPill) {
                                const isFirst = col.id === oosFirst;
                                const isLast  = col.id === oosLast;
                                const radius = isFirst && isLast ? '20px'
                                  : isFirst ? '20px 0 0 20px'
                                  : isLast  ? '0 20px 20px 0'
                                  : undefined;
                                return (
                                  <td
                                    key={col.id}
                                    style={{
                                      padding: 0,
                                      paddingTop: '2pt',
                                      paddingBottom: '2pt',
                                      paddingRight: 0,
                                      verticalAlign: 'middle',
                                      backgroundColor: baseBg,
                                    }}
                                  >
                                    <div
                                      className={col.cCls}
                                      style={{
                                        backgroundColor: 'rgba(239,68,68,0.3)',
                                        color: '#7f1d1d',
                                        borderRadius: radius,
                                        whiteSpace: 'nowrap',
                                        height: '36px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        boxSizing: 'border-box',
                                      }}
                                    >
                                      {renderCell(col.id as ColId, p)}
                                    </div>
                                  </td>
                                );
                              }
                              return (
                                <td key={col.id} className={col.cCls} style={{ backgroundColor: baseBg }}>
                                  {renderCell(col.id as ColId, p)}
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })}
                      <tr className="list-header">
                        {orderedCols.map(col => (
                          <td key={col.id} className={col.cCls}>
                            {col.id === 'sousTotal' ? <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '16px' }}>{frPrix(total)}</span> : col.id === 'nom' ? 'total fournisseur' : ''}
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>}
              </div>
            );})}

            {filtered.length === 0 && (
              <p className="text-center py-16" style={{ color: 'rgba(255,255,255,0.5)' }}>
                Aucune pièce flaggée « $ » (en commande).
              </p>
            )}
           </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
