export type PieceFlag = '—' | '√' | '$' | '@' | '...';

export interface Piece {
  _row: number;
  flag: PieceFlag | string;  // col B — statut (—/√/$/$$)
  groupe: string;
  nom: string;
  sku: string;               // col S — référence fournisseur (texte affiché)
  skuUrl: string;            // col S — URL hyperlien natif (si disponible)
  prixAchat: number;         // col L
  prixBase: number;          // col O
  prixVente: number;         // col P — prix de vente client
  prixCost: number;          // col Q — prix COST (activé par bouton Cost)
  prixBDC: number;           // col R — prix unitaire
  fournisseur: string;       // col U
  oos: number;               // col V — out of stock
  qteACommander: number;     // col W
  sousTotal: number;         // col X
  categorie: string;         // col AA
  stock: number;             // col AB — stock physique
  stockReserve: number;      // col AC — qté réservée pour BDT actifs (post-APPROUVÉ, pre-FACTURÉ)
  surplus: number;           // col AD — qté surplus à la réception PO
  notes: string;             // col AE — note libre (éditable)
  codeBarre: string;         // col T — code-barre fabricant EAN/UPC (scan)
  pieceId: string;           // col A — ID stable unique (P00001, P00002…)
  /** v1.3.1+ : qté par sac (paquet fournisseur). Ajouté col F PIÈCES
   *  (header `qteSac` écrit manuellement 2026-05-21). Permet de noter
   *  qu'une pièce arrive en paquets de N (ex. câbles vendus par 50). */
  qteSac?: number;
}

export interface Service {
  _row: number;
  serviceId: string;         // col A — ID stable unique (S00001, S00002…)
  label: string;
  duree: string;             // col D — durée brute (ex. "15 min", "1h30")
  categorie: string;
  prix: number;
  categoriePrio: string;     // col F — catégorie prioritaire (éditable)
  categorieAffichee: string; // categoriePrio || categorie
}

export interface Marque {
  nom: string;
}
