/**
 * CRUD ventes directes — onglet _VENTES_ du document INVENTAIRE.
 *
 * Structure : une ligne par item de vente, groupées par venteId.
 * Colonnes A..H :
 *   A=venteId, B=date, C=client, D=pieceId, E=sku, F=nom, G=qte, H=prixUnit
 *
 * À la création d'une vente : décrémente le stock (col AA) du sheet PIÈCES.
 */
import { getSheetsClient, SHEET_IDS, TAB } from './client';
import cache, { CACHE_KEYS } from '@/lib/cache';
import type { Vente, VenteItem } from '@/types/vente';

// Schéma _VENTES_ — 16 colonnes (A à P).
// v1.1.5+ : col P 'payeStatus' ajoutée (cluster 4 item m, 2026-05-16).
// Col O 'modePaiement' déjà ajoutée en v7.0.22.
const VENTES_HEADERS = ['venteId', 'date', 'client', 'pieceId', 'sku', 'nom', 'qte', 'prixUnit', 'factureNumero', 'factureDate', 'factureUrl', 'cost', 'remiseType', 'remiseValue', 'modePaiement', 'payeStatus'];

export async function getVentes(): Promise<Vente[]> {
  const cached = await cache.get<Vente[]>(CACHE_KEYS.VENTES);
  if (cached) return cached;

  await _ensureTab();
  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.VENTES}!A2:P`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });

  const rows = res.data.values ?? [];
  const venteMap = new Map<string, { v: Omit<Vente, 'items' | '_rows' | 'total'>; items: VenteItem[]; _rows: number[] }>();

  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const s = (idx: number) => String(r[idx] ?? '').trim();
    const n = (idx: number) => parseFloat(String(r[idx] ?? '0')) || 0;
    const venteId = s(0);
    if (!venteId) continue;

    if (!venteMap.has(venteId)) {
      // Métadonnées facture portées par la 1ʳᵉ row du groupe uniquement
      const factureNumero = s(8) || undefined;
      const factureDate   = s(9) || undefined;
      const factureUrl    = s(10) || undefined;
      const costRaw       = s(11);
      const cost          = costRaw === 'TRUE' || costRaw === 'true' || costRaw === '1';
      const remiseTypeRaw = s(12);
      const remiseType    = (remiseTypeRaw === 'pct' || remiseTypeRaw === 'fixed')
        ? remiseTypeRaw as 'pct' | 'fixed'
        : undefined;
      const remiseValueRaw = n(13);
      const remiseValue    = remiseValueRaw > 0 ? remiseValueRaw : undefined;
      // v7.0.22+ col O — modePaiement persisté à la facturation.
      const modePaiementRaw = s(14);
      const modePaiement    = (modePaiementRaw === 'comptant' || modePaiementRaw === 'interac' || modePaiementRaw === 'cartes')
        ? modePaiementRaw as 'comptant' | 'interac' | 'cartes'
        : undefined;
      // v1.1.5+ (cluster 4 item m) col P — payeStatus.
      const payeStatusRaw = s(15).toLowerCase();
      const payeStatus    = payeStatusRaw === 'payé' || payeStatusRaw === 'paye' ? 'payé' as const : '' as const;
      venteMap.set(venteId, {
        v: { venteId, date: s(1), client: s(2), factureNumero, factureDate, factureUrl, cost, remiseType, remiseValue, modePaiement, payeStatus },
        items: [],
        _rows: [],
      });
    }
    const entry = venteMap.get(venteId)!;
    const qte = n(6);
    const prixUnit = n(7);
    entry.items.push({
      pieceId  : s(3),
      sku      : s(4),
      nom      : s(5),
      qte,
      prixUnit,
      sousTotal: qte * prixUnit,
    });
    entry._rows.push(i + 2);
  }

  const ventes: Vente[] = [...venteMap.values()].map(({ v, items, _rows }) => ({
    ...v,
    items,
    _rows,
    total: items.reduce((s, it) => s + it.sousTotal, 0),
  }));

  // Tri : la vente la plus récente d'abord, par date de création (col B).
  // Départage : venteId (V{timestamp}) — la plus récemment créée gagne.
  ventes.sort((a, b) => {
    const byDate = (b.date || '').localeCompare(a.date || '');
    if (byDate !== 0) return byDate;
    return (b.venteId || '').localeCompare(a.venteId || '');
  });

  await cache.set(CACHE_KEYS.VENTES, ventes);
  return ventes;
}

export async function createVente(input: {
  date: string;
  client: string;
  items: { pieceId: string; sku: string; nom: string; qte: number; prixUnit: number }[];
  cost?: boolean;
}): Promise<{ venteId: string; factureNumero: string; stockUpdates: { nom: string; delta: number }[] }> {
  if (!input.items.length) throw new Error('Au moins 1 item requis');
  await _ensureTab();
  const sheets = getSheetsClient();

  // Auto-assigne le client virtuel « Walk-in » si pas de client défini.
  // Permet la facturation comptoir sans friction (cf. lib/sheets/clients.ts).
  if (!input.client?.trim()) {
    const { ensureWalkinClient } = await import('./clients');
    const walkin = await ensureWalkinClient();
    input.client = walkin.nomComplet;
  }

  const venteId = `V${Date.now()}`;
  // ⚠ Le numéro de facture (col I) n'est PLUS attribué à la création.
  // Lazy assign : prochainFactureNumero() est appelé à la facturation
  // (POST /api/ventes/[venteId]/facture). Évite les trous dans la séquence
  // quand un brouillon est créé puis supprimé sans avoir été facturé.
  // Le flag cost est porté uniquement par la 1ʳᵉ ligne (col L)
  const rows = input.items.map((item, i) => [
    venteId,
    input.date,
    input.client,
    item.pieceId,
    item.sku,
    item.nom,
    item.qte,
    item.prixUnit,
    '', '', '',                                  // I=factureNumero (vide tant que non facturé), J/K=vides
    i === 0 ? (input.cost ? 'TRUE' : 'FALSE') : '',  // L cost (1ʳᵉ row seulement)
    '', '',                                      // M/N remiseType/Value (remplies à la facturation)
  ]);

  // Append vente lines. ⚠ v6.6.0 : plus de _decrementStock direct ici.
  // Le delta AB + AC est géré par le snapshot/recompute côté route
  // (modèle invariant engagement, cohérent avec BDT).
  await sheets.spreadsheets.values.append({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.VENTES}!A1`,
    valueInputOption: 'RAW',
    insertDataOption: 'INSERT_ROWS',
    requestBody     : { values: rows },
  });

  await cache.del(CACHE_KEYS.VENTES);
  return { venteId, factureNumero: '', stockUpdates: [] };
}

/**
 * Snapshot append-only d'une vente dans l'onglet _BDC_BACKUPS_ (partagé
 * avec les BDC). Best-effort : ne throw jamais. Utilisé avant la
 * suppression d'une vente facturée pour conserver une trace.
 *
 * Format ligne : ts | action | venteId | client | (vide) | JSON lignes
 * _VENTES_ | (vide) | note
 */
export async function snapshotVente(
  venteId: string,
  action : 'delete-vente-facturee' | 'manual',
  note   : string = '',
): Promise<void> {
  try {
    const sheets = getSheetsClient();
    // Lire les lignes _VENTES_ correspondant à ce venteId
    const r = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.VENTES}!A1:N`,
      valueRenderOption: 'FORMATTED_VALUE',
    });
    const allRows = r.data.values ?? [];
    const venteRows = allRows.filter(row => String(row[0] ?? '').trim() === venteId);
    if (venteRows.length === 0) {
      console.warn(`[snapshotVente] aucune ligne pour venteId ${venteId}`);
      return;
    }
    const clientNom = String(venteRows[0]?.[2] ?? '').trim();
    const ts = new Date().toISOString().replace('T', ' ').substring(0, 19);
    await sheets.spreadsheets.values.append({
      spreadsheetId   : SHEET_IDS.INVENTAIRE,
      range           : `${TAB.BDC_BACKUPS}!A1`,
      valueInputOption: 'RAW',
      insertDataOption: 'INSERT_ROWS',
      requestBody     : {
        values: [[
          ts,
          action,
          venteId,
          clientNom,
          '',                            // veloDesc vide pour vente
          JSON.stringify(venteRows),     // lignes _VENTES_ complètes
          '',                            // pas de ligne INVENTAIRE
          note,
        ]],
      },
    });
    console.log(`[snapshotVente] ${action} ${venteId} — ${venteRows.length} lignes snapshot`);
  } catch (err: any) {
    console.warn(`[snapshotVente] échec ${venteId} :`, err?.message ?? err);
  }
}

/**
 * Décrémente le stock col AA pour une liste d'items.
 * Résolution par pieceId > SKU > nom.
 * Exporté pour utilisation par l'archivage des BDC.
 */
export async function _decrementStock(items: { pieceId: string; sku: string; nom: string; qte: number }[]): Promise<{ nom: string; delta: number }[]> {
  return _adjustStock(items, -1);
}

/**
 * Ré-incrémente le stock col AB pour une liste d'items.
 * Miroir strict de _decrementStock — même résolution pieceId > SKU > nom.
 * Utilisé par : désarchivage BDT, suppression vente brouillon, suppression item brouillon.
 */
export async function _incrementStock(items: { pieceId: string; sku: string; nom: string; qte: number }[]): Promise<{ nom: string; delta: number }[]> {
  return _adjustStock(items, 1);
}

async function _adjustStock(
  items: { pieceId: string; sku: string; nom: string; qte: number }[],
  sign: 1 | -1,
): Promise<{ nom: string; delta: number }[]> {
  const sheets = getSheetsClient();
  const stockUpdates: { nom: string; delta: number }[] = [];

  // Charger pieceId, nom, sku des PIÈCES
  const [idRes, lookupRes] = await Promise.all([
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.PIECES,
      range            : `${TAB.PIECES_TAB}!A2:A`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.PIECES,
      range            : `${TAB.PIECES_TAB}!D2:S`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
  ]);
  const idRows = idRes.data.values ?? [];
  const lookupRows = lookupRes.data.values ?? [];

  const pieceIdToRow = new Map<string, number>();
  const skuToRow = new Map<string, number>();
  const nomToRow = new Map<string, number>();
  for (let i = 0; i < Math.max(idRows.length, lookupRows.length); i++) {
    const row = i + 2;
    const pid = String(idRows[i]?.[0] ?? '').trim();
    const nom = String(lookupRows[i]?.[0] ?? '').trim();
    const sku = String(lookupRows[i]?.[15] ?? '').trim();
    if (pid) pieceIdToRow.set(pid, row);
    if (sku) skuToRow.set(sku, row);
    if (nom) nomToRow.set(nom, row);
  }

  const stockUpdatesData: { range: string; values: unknown[][] }[] = [];

  for (const item of items) {
    if (item.qte <= 0) continue;
    // v1.1.5+ (cluster 4 n) — Skip explicite des services (pieceId S-préfixé) :
    // les services vivent dans le catalogue À LA CARTE, pas dans PIÈCES, donc
    // pas de stockPhysique à ajuster. Sans ce skip, un match accidentel par
    // nom décrémenterait le stock de la mauvaise pièce.
    if (item.pieceId && item.pieceId.startsWith('S')) continue;
    const resolvedRow = (item.pieceId && pieceIdToRow.get(item.pieceId))
      || (item.sku && skuToRow.get(item.sku))
      || nomToRow.get(item.nom);
    if (!resolvedRow || resolvedRow <= 0) {
      console.warn(`[ventes] Impossible de résoudre la ligne PIÈCES pour "${item.nom}"`);
      continue;
    }

    // Lire stock actuel
    const stockRes = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.PIECES,
      range            : `${TAB.PIECES_TAB}!AB${resolvedRow}`,
      valueRenderOption: 'UNFORMATTED_VALUE',
    });
    const currentStock = parseFloat(String(stockRes.data.values?.[0]?.[0] ?? '0')) || 0;
    const delta   = sign * item.qte;
    const newStock = Math.max(0, currentStock + delta);

    stockUpdatesData.push({
      range: `${TAB.PIECES_TAB}!AB${resolvedRow}`,
      values: [[newStock]],
    });
    stockUpdates.push({ nom: item.nom, delta });
  }

  if (stockUpdatesData.length > 0) {
    await sheets.spreadsheets.values.batchUpdate({
      spreadsheetId: SHEET_IDS.PIECES,
      requestBody  : { valueInputOption: 'RAW', data: stockUpdatesData },
    });
  }

  return stockUpdates;
}

/**
 * Écrit les métadonnées de facturation (col I/J/K) sur la 1ʳᵉ ligne
 * du groupe venteId. Purge ensuite le cache VENTES.
 */
/**
 * v1.1.5+ (cluster 4 item m) — Marque une vente comme payée.
 * Écrit 'payé' (ou '' pour annuler) dans col P de la 1ʳᵉ ligne du groupe.
 * Pré-condition : la vente doit être facturée (factureDate présent).
 * Post-condition : la vente devient archivable depuis l'UI.
 */
export async function markVentePayee(
  venteId: string,
  paye   : boolean,
): Promise<void> {
  const ventes = await getVentes();
  const v = ventes.find(x => x.venteId === venteId);
  if (!v) throw new Error(`Vente ${venteId} introuvable`);
  if (!v.factureDate) {
    throw new Error(`Vente ${venteId} pas encore facturée — marquer payée impossible`);
  }
  const firstRow = v._rows[0];
  if (!firstRow) throw new Error(`Vente ${venteId} sans ligne sheet`);

  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.VENTES}!P${firstRow}`,
    valueInputOption: 'RAW',
    requestBody     : { values: [[paye ? 'payé' : '']] },
  });
  await cache.del(CACHE_KEYS.VENTES);
}

/**
 * v1.3.1+ (cluster 7 item f) — Bascule le flag Cost d'une vente brouillon.
 * Écrit TRUE/FALSE en col L de la 1ʳᵉ ligne du groupe + recalcule le
 * prixUnit (col H) de chaque item piece en fonction du nouveau flag
 * (priceFor catalogue : cost = prixCost, sinon prixBDC).
 *
 * Pré-condition : la vente DOIT être brouillon (factureDate absent). Une
 * vente déjà facturée a son prix gravé dans la facture PDF — toggler le
 * flag créerait une incohérence.
 *
 * Services (pieceId S-préfixé) : conservent leur prixUnit inchangé —
 * le catalogue À LA CARTE n'a qu'un seul prix par service.
 *
 * Pièces sans match catalogue (rename historique non backfillé) :
 * prixUnit inchangé, warning console.
 */
export async function setVenteCost(
  venteId: string,
  cost   : boolean,
): Promise<{ itemsUpdated: number; itemsSkipped: number }> {
  const ventes = await getVentes();
  const v = ventes.find(x => x.venteId === venteId);
  if (!v) throw new Error(`Vente ${venteId} introuvable`);
  if (v.factureDate) {
    throw new Error(`Vente ${venteId} déjà facturée — Cost verrouillé`);
  }
  const firstRow = v._rows[0];
  if (!firstRow) throw new Error(`Vente ${venteId} sans ligne sheet`);

  const sheets = getSheetsClient();

  // Charger le catalogue pour recalculer les prix.
  const { getPieces } = await import('./catalogue');
  const pieces = await getPieces();
  const byId  = new Map(pieces.filter(p => p.pieceId).map(p => [p.pieceId, p]));
  const bySku = new Map(pieces.filter(p => p.sku).map(p => [p.sku, p]));
  const byNom = new Map(pieces.map(p => [p.nom.trim().toLowerCase(), p]));

  // Recalcule prixUnit pour chaque item (sauf services S-préfixés).
  // Helper local — duplique priceFor() du UI : cost → prixCost || prixAchat || prixBase
  //                                                 sinon → prixBDC || prixBase
  function recomputePrix(piece: typeof pieces[0]): number {
    if (cost) return piece.prixCost || piece.prixAchat || piece.prixBase || 0;
    return piece.prixBDC || piece.prixBase || 0;
  }

  const updates: { range: string; values: unknown[][] }[] = [];
  // Col L (cost flag) sur la 1ʳᵉ ligne
  updates.push({
    range : `${TAB.VENTES}!L${firstRow}`,
    values: [[cost ? 'TRUE' : 'FALSE']],
  });

  let itemsUpdated = 0;
  let itemsSkipped = 0;
  v.items.forEach((item, idx) => {
    // Services : skip recompute (prixUnit conservé)
    if (item.pieceId && item.pieceId.startsWith('S')) {
      itemsSkipped++;
      return;
    }
    const piece = (item.pieceId && byId.get(item.pieceId))
      || (item.sku && bySku.get(item.sku))
      || byNom.get(item.nom.trim().toLowerCase());
    if (!piece) {
      console.warn(`[setVenteCost] Pièce introuvable au catalogue : ${item.nom} — prixUnit conservé`);
      itemsSkipped++;
      return;
    }
    const newPrix = recomputePrix(piece);
    if (newPrix === item.prixUnit) {
      itemsSkipped++;
      return;
    }
    const itemRow = v._rows[idx];
    if (!itemRow) return;
    updates.push({
      range : `${TAB.VENTES}!H${itemRow}`,
      values: [[newPrix]],
    });
    itemsUpdated++;
  });

  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : { valueInputOption: 'RAW', data: updates },
  });
  await cache.del(CACHE_KEYS.VENTES);

  return { itemsUpdated, itemsSkipped };
}

export async function markVenteFacturee(
  venteId: string,
  meta: {
    numero       : string;
    date         : string;
    url          : string;
    remiseType?  : 'pct' | 'fixed';
    remiseValue? : number;
    modePaiement?: 'comptant' | 'interac' | 'cartes';
  },
): Promise<void> {
  const ventes = await getVentes();
  const v = ventes.find(x => x.venteId === venteId);
  if (!v) throw new Error(`Vente ${venteId} introuvable`);
  const firstRow = v._rows[0];
  if (!firstRow) throw new Error(`Vente ${venteId} sans ligne sheet`);

  const sheets = getSheetsClient();
  // Écrit I/J/K (facture meta) + M/N (remise) + O (modePaiement, NOUVEAU
  // v7.0.22). Col L (cost) préservée via 2 requêtes séparées.
  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      valueInputOption: 'RAW',
      data: [
        { range: `${TAB.VENTES}!I${firstRow}:K${firstRow}`, values: [[meta.numero, meta.date, meta.url]] },
        {
          range : `${TAB.VENTES}!M${firstRow}:O${firstRow}`,
          values: [[
            meta.remiseType ?? '',
            (meta.remiseValue && meta.remiseValue > 0) ? meta.remiseValue : '',
            meta.modePaiement ?? 'comptant',
          ]],
        },
      ],
    },
  });
  await cache.del(CACHE_KEYS.VENTES);
}

/**
 * Ajoute des items à une vente existante (non facturée).
 * Réutilise date/client de la vente. Le delta stock (AB + AC) est géré
 * par le snapshot/recompute côté route, pas ici.
 */
export async function appendItemsToVente(
  venteId: string,
  items  : { pieceId: string; sku: string; nom: string; qte: number; prixUnit: number }[],
): Promise<{ stockUpdates: { nom: string; delta: number }[] }> {
  if (!items.length) throw new Error('Au moins 1 item requis');
  const ventes = await getVentes();
  const v = ventes.find(x => x.venteId === venteId);
  if (!v) throw new Error(`Vente ${venteId} introuvable`);
  if (v.factureDate) throw new Error('Vente déjà facturée — ajout d\'item bloqué');

  const sheets = getSheetsClient();
  const rows = items.map(item => [
    venteId, v.date, v.client,
    item.pieceId, item.sku, item.nom,
    item.qte, item.prixUnit,
    '', '', '', '', '', '',
  ]);

  await sheets.spreadsheets.values.append({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.VENTES}!A1`,
    valueInputOption: 'RAW',
    insertDataOption: 'INSERT_ROWS',
    requestBody     : { values: rows },
  });

  await cache.del(CACHE_KEYS.VENTES);
  return { stockUpdates: [] };
}

/**
 * Modifie la qté d'un item d'une vente brouillon (col G _VENTES_).
 * Refuse si la vente est déjà facturée. Le delta stock (AB + AC) est géré
 * par le snapshot/recompute côté route.
 */
export async function patchVenteItemQte(venteId: string, row: number, qte: number): Promise<void> {
  if (!Number.isFinite(qte) || qte < 1) throw new Error('qte doit être un entier >= 1');
  const ventes = await getVentes();
  const v = ventes.find(x => x.venteId === venteId);
  if (!v) throw new Error(`Vente ${venteId} introuvable`);
  if (v.factureDate) throw new Error('Vente déjà facturée — modification de qté bloquée');
  if (!v._rows.includes(row)) throw new Error(`Ligne ${row} non associée à la vente ${venteId}`);

  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.VENTES}!G${row}`,
    valueInputOption: 'RAW',
    requestBody     : { values: [[qte]] },
  });

  await cache.del(CACHE_KEYS.VENTES);
}

/**
 * Supprime une seule ligne d'item d'une vente brouillon.
 * Refuse si la vente est déjà facturée. Delta stock géré côté route.
 */
export async function deleteVenteItem(venteId: string, row: number): Promise<void> {
  const ventes = await getVentes();
  const v = ventes.find(x => x.venteId === venteId);
  if (!v) throw new Error(`Vente ${venteId} introuvable`);
  if (v.factureDate) throw new Error('Vente déjà facturée — suppression d\'item bloquée');
  if (!v._rows.includes(row)) throw new Error(`Ligne ${row} non associée à la vente ${venteId}`);

  const sheets = getSheetsClient();
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const sh = meta.data.sheets?.find(s => s.properties?.title === TAB.VENTES);
  if (!sh?.properties?.sheetId && sh?.properties?.sheetId !== 0) return;

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        deleteDimension: {
          range: {
            sheetId   : sh.properties!.sheetId!,
            dimension : 'ROWS',
            startIndex: row - 1,
            endIndex  : row,
          },
        },
      }],
    },
  });

  await cache.del(CACHE_KEYS.VENTES);
}

/**
 * Supprime une vente entière (brouillon ou facturée). Le delta stock
 * (AB + AC) est géré par le snapshot/recompute côté route.
 *
 * ⚠ v6.6.0 — Conséquence du modèle invariant : supprimer une vente
 * facturée fait remonter AB (la trace de la vente disparaît). Pour conserver
 * un mouvement définitif sur AB, NE PAS supprimer une vente facturée.
 */
export async function deleteVente(venteId: string): Promise<void> {
  const ventes = await getVentes();
  const v = ventes.find(x => x.venteId === venteId);
  if (!v) throw new Error(`Vente ${venteId} introuvable`);

  const sheets = getSheetsClient();

  // 1. Supprimer les lignes dans _VENTES_ (sheet INVENTAIRE)
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const sh = meta.data.sheets?.find(s => s.properties?.title === TAB.VENTES);
  if (sh?.properties?.sheetId !== undefined) {
    const sortedRows = [...v._rows].sort((a, b) => b - a);
    await sheets.spreadsheets.batchUpdate({
      spreadsheetId: SHEET_IDS.INVENTAIRE,
      requestBody  : {
        requests: sortedRows.map(row => ({
          deleteDimension: {
            range: {
              sheetId   : sh.properties!.sheetId!,
              dimension : 'ROWS',
              startIndex: row - 1,
              endIndex  : row,
            },
          },
        })),
      },
    });
  }

  // 2. Cascade : si la vente était facturée, supprimer la ligne
  // correspondante du journal FACTURES → VENTES (col C = facture #).
  if (v.factureNumero) {
    await _deleteFromJournalVentes(v.factureNumero);
  }

  await cache.del(CACHE_KEYS.VENTES);
}

/**
 * Supprime du journal FACTURES → VENTES la (ou les) ligne(s) dont la col C
 * correspond au numéro de facture donné. Supporte le nouveau format `V0007`
 * et l'ancien `V0007-2026-04-23` (matching par préfixe).
 */
async function _deleteFromJournalVentes(factureNumero: string): Promise<void> {
  const sheets = getSheetsClient();

  // 1. Lire les lignes data du journal (à partir de ligne 4)
  const dataRes = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.FACTURES,
    range            : `${TAB.FACTURES_LOG_VENTES}!A4:M`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const rows = dataRes.data.values ?? [];

  // 2. Trouver les lignes matching (col C = idx 2)
  const matchingSheetRows: number[] = [];
  rows.forEach((r, idx) => {
    const val = String(r[2] ?? '').trim();
    if (val === factureNumero || val.startsWith(factureNumero + '-')) {
      matchingSheetRows.push(4 + idx);  // 1-based row
    }
  });
  if (matchingSheetRows.length === 0) return;

  // 3. sheetId numérique du journal VENTES
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.FACTURES,
    fields       : 'sheets.properties',
  });
  const sh = meta.data.sheets?.find(s => s.properties?.title === TAB.FACTURES_LOG_VENTES);
  if (sh?.properties?.sheetId === undefined) return;

  // 4. Delete (descending pour préserver les indices)
  const sortedRows = matchingSheetRows.sort((a, b) => b - a);
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.FACTURES,
    requestBody  : {
      requests: sortedRows.map(row => ({
        deleteDimension: {
          range: {
            sheetId   : sh.properties!.sheetId!,
            dimension : 'ROWS',
            startIndex: row - 1,
            endIndex  : row,
          },
        },
      })),
    },
  });
}

async function _ensureTab(): Promise<void> {
  const sheets = getSheetsClient();
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const exists = (meta.data.sheets ?? []).some(s => s.properties?.title === TAB.VENTES);
  if (exists) return;

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        addSheet: {
          properties: {
            title: TAB.VENTES,
            gridProperties: { rowCount: 2000, columnCount: 14 },
          },
        },
      }],
    },
  });
  await sheets.spreadsheets.values.update({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.VENTES}!A1:N1`,
    valueInputOption: 'RAW',
    requestBody     : { values: [VENTES_HEADERS] },
  });
}

/** Crée l'onglet _VENTES_ARCHIVES_ si absent (mêmes en-têtes que _VENTES_). */
async function _ensureArchivesTab(): Promise<void> {
  const sheets = getSheetsClient();
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const exists = (meta.data.sheets ?? []).some(s => s.properties?.title === TAB.VENTES_ARCHIVES);
  if (exists) return;

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        addSheet: {
          properties: {
            title: TAB.VENTES_ARCHIVES,
            gridProperties: { rowCount: 2000, columnCount: 16 },
          },
        },
      }],
    },
  });
  await sheets.spreadsheets.values.update({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.VENTES_ARCHIVES}!A1:O1`,
    valueInputOption: 'RAW',
    requestBody     : { values: [VENTES_HEADERS_FULL] },
  });
}

/** Headers étendus avec col O (modePaiement) — utilisés pour l'onglet archives. */
const VENTES_HEADERS_FULL = [...VENTES_HEADERS, 'modePaiement'];

/**
 * Archive une vente : copie ses lignes vers _VENTES_ARCHIVES_ puis les
 * supprime de _VENTES_. Pattern miroir de archiverBDC.
 */
export async function archiverVente(venteId: string): Promise<void> {
  await _ensureArchivesTab();
  const ventes = await getVentes();
  const v = ventes.find(x => x.venteId === venteId);
  if (!v) throw new Error(`Vente ${venteId} introuvable`);

  const sheets = getSheetsClient();

  // 1. Lire les lignes complètes (A:O) à archiver
  const sortedRows = [...v._rows].sort((a, b) => a - b);
  const minRow = sortedRows[0];
  const maxRow = sortedRows[sortedRows.length - 1];
  const r = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.VENTES}!A${minRow}:O${maxRow}`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const rows = r.data.values ?? [];

  // 2. Append dans _VENTES_ARCHIVES_
  if (rows.length > 0) {
    await sheets.spreadsheets.values.append({
      spreadsheetId   : SHEET_IDS.INVENTAIRE,
      range           : `${TAB.VENTES_ARCHIVES}!A1`,
      valueInputOption: 'RAW',
      insertDataOption: 'INSERT_ROWS',
      requestBody     : { values: rows },
    });
  }

  // 3. Supprimer de _VENTES_
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const sh = meta.data.sheets?.find(s => s.properties?.title === TAB.VENTES);
  if (sh?.properties?.sheetId !== undefined) {
    const reverseRows = [...v._rows].sort((a, b) => b - a);
    await sheets.spreadsheets.batchUpdate({
      spreadsheetId: SHEET_IDS.INVENTAIRE,
      requestBody  : {
        requests: reverseRows.map(row => ({
          deleteDimension: {
            range: { sheetId: sh.properties!.sheetId!, dimension: 'ROWS', startIndex: row - 1, endIndex: row },
          },
        })),
      },
    });
  }

  await cache.del(CACHE_KEYS.VENTES);
  await cache.del(CACHE_KEYS.VENTES_ARCHIVES);
}

/** Lit les ventes archivées depuis _VENTES_ARCHIVES_. Format identique à getVentes. */
export async function getArchivedVentes(): Promise<Vente[]> {
  const cached = await cache.get<Vente[]>(CACHE_KEYS.VENTES_ARCHIVES);
  if (cached) return cached;

  await _ensureArchivesTab();
  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.VENTES_ARCHIVES}!A2:O`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const rows = res.data.values ?? [];
  const venteMap = new Map<string, { v: Omit<Vente, 'items' | '_rows' | 'total'>; items: VenteItem[]; _rows: number[] }>();

  rows.forEach((row, idx) => {
    const venteId = String(row[0] ?? '').trim();
    if (!venteId) return;
    const item: VenteItem = {
      pieceId  : String(row[3] ?? '').trim(),
      sku      : String(row[4] ?? '').trim(),
      nom      : String(row[5] ?? '').trim(),
      qte      : Number(row[6] ?? 0) || 0,
      prixUnit : Number(row[7] ?? 0) || 0,
      sousTotal: (Number(row[6] ?? 0) || 0) * (Number(row[7] ?? 0) || 0),
    };
    const sheetRow = idx + 2;
    const existing = venteMap.get(venteId);
    if (existing) {
      existing.items.push(item);
      existing._rows.push(sheetRow);
    } else {
      venteMap.set(venteId, {
        v: {
          venteId,
          date         : String(row[1] ?? ''),
          client       : String(row[2] ?? ''),
          factureNumero: String(row[8] ?? '').trim() || undefined,
          factureDate  : String(row[9] ?? '').trim() || undefined,
          factureUrl   : String(row[10] ?? '').trim() || undefined,
          cost         : String(row[11] ?? '').toUpperCase() === 'TRUE',
          remiseType   : (row[12] === 'pct' || row[12] === 'fixed') ? row[12] : undefined,
          remiseValue  : Number(row[13] ?? 0) || undefined,
        },
        items: [item],
        _rows: [sheetRow],
      });
    }
  });

  const ventes: Vente[] = [...venteMap.values()].map(({ v, items, _rows }) => ({
    ...v,
    items,
    _rows,
    total: items.reduce((s, it) => s + it.sousTotal, 0),
  }));

  await cache.set(CACHE_KEYS.VENTES_ARCHIVES, ventes);
  return ventes;
}

/** Désarchive une vente : copie de _VENTES_ARCHIVES_ vers _VENTES_ + delete archive. */
export async function desarchiverVente(venteId: string): Promise<void> {
  const archived = await getArchivedVentes();
  const v = archived.find(x => x.venteId === venteId);
  if (!v) throw new Error(`Vente archivée ${venteId} introuvable`);

  const sheets = getSheetsClient();

  // 1. Lire les lignes complètes (A:O) de _VENTES_ARCHIVES_
  const sortedRows = [...v._rows].sort((a, b) => a - b);
  const minRow = sortedRows[0];
  const maxRow = sortedRows[sortedRows.length - 1];
  const r = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.VENTES_ARCHIVES}!A${minRow}:O${maxRow}`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const rows = r.data.values ?? [];

  // 2. Append dans _VENTES_ (limité à cols A:N pour rétro-compat — col O modePaiement
  //    sera lue en row[14] mais l'append à 14 cols va couper).
  if (rows.length > 0) {
    await sheets.spreadsheets.values.append({
      spreadsheetId   : SHEET_IDS.INVENTAIRE,
      range           : `${TAB.VENTES}!A1`,
      valueInputOption: 'RAW',
      insertDataOption: 'INSERT_ROWS',
      requestBody     : { values: rows },
    });
  }

  // 3. Supprimer de _VENTES_ARCHIVES_
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const sh = meta.data.sheets?.find(s => s.properties?.title === TAB.VENTES_ARCHIVES);
  if (sh?.properties?.sheetId !== undefined) {
    const reverseRows = [...v._rows].sort((a, b) => b - a);
    await sheets.spreadsheets.batchUpdate({
      spreadsheetId: SHEET_IDS.INVENTAIRE,
      requestBody  : {
        requests: reverseRows.map(row => ({
          deleteDimension: {
            range: { sheetId: sh.properties!.sheetId!, dimension: 'ROWS', startIndex: row - 1, endIndex: row },
          },
        })),
      },
    });
  }

  await cache.del(CACHE_KEYS.VENTES);
  await cache.del(CACHE_KEYS.VENTES_ARCHIVES);
}

/** Suppression définitive d'une vente archivée (admin). Pas de retour possible. */
export async function deleteArchivedVente(venteId: string): Promise<void> {
  const archived = await getArchivedVentes();
  const v = archived.find(x => x.venteId === venteId);
  if (!v) throw new Error(`Vente archivée ${venteId} introuvable`);

  const sheets = getSheetsClient();
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const sh = meta.data.sheets?.find(s => s.properties?.title === TAB.VENTES_ARCHIVES);
  if (sh?.properties?.sheetId === undefined) return;

  const reverseRows = [...v._rows].sort((a, b) => b - a);
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: reverseRows.map(row => ({
        deleteDimension: {
          range: { sheetId: sh.properties!.sheetId!, dimension: 'ROWS', startIndex: row - 1, endIndex: row },
        },
      })),
    },
  });

  await cache.del(CACHE_KEYS.VENTES_ARCHIVES);
}
