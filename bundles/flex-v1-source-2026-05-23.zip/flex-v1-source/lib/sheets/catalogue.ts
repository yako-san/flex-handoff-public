/**
 * Lecture du catalogue — pièces, services, marques.
 * Toutes les lectures sont mises en cache 5 min.
 * Équivalent de _getPiecesComposants(), _getServicesALaCarte(), _getMarques().
 */
import { getSheetsClient, SHEET_IDS, TAB, ROW } from './client';
import cache, { CACHE_KEYS } from '@/lib/cache';
import { logError } from '@/lib/log';
import type { Piece, Service, Marque } from '@/types/catalogue';

// ── Pièces (PIÈCES - FLEX-REV — tab "PIÈCES et COMPOSANTS") ──────

export async function getPieces(): Promise<Piece[]> {
  const cached = await cache.get<Piece[]>(CACHE_KEYS.PIECES);
  if (cached) return cached;

  const sheets = getSheetsClient();

  // Lire valeurs + hyperliens natifs col S + IDs col A en parallèle
  const [res, sheetData, idRes] = await Promise.all([
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.PIECES,
      range            : `${TAB.PIECES_TAB}!B2:AE`,
      valueRenderOption: 'UNFORMATTED_VALUE',
    }),
    sheets.spreadsheets.get({
      spreadsheetId: SHEET_IDS.PIECES,
      ranges       : [`${TAB.PIECES_TAB}!S2:S`],
      fields       : 'sheets.data.rowData.values.hyperlink',
    }),
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.PIECES,
      range            : `${TAB.PIECES_TAB}!A2:A`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
  ]);

  const rows = res.data.values ?? [];
  const hyperlinkRows = sheetData.data.sheets?.[0]?.data?.[0]?.rowData ?? [];
  const idRows = idRes.data.values ?? [];

  const pieces = rows
    .map((r, idx) => {
      const p = _rowToPiece(r, idx + 2);
      const cell = (hyperlinkRows as any[])[idx]?.values?.[0];
      if (cell?.hyperlink) p.skuUrl = cell.hyperlink;
      p.pieceId = String(idRows[idx]?.[0] ?? '').trim();
      return p;
    })
    .filter((p): p is Piece => !!p.nom && p.nom !== 'Nom ITEM');

  await cache.set(CACHE_KEYS.PIECES, pieces);
  return pieces;
}

/** Retourne les catégories uniques des pièces. */
export async function getCategories(): Promise<string[]> {
  const cached = await cache.get<string[]>(CACHE_KEYS.CATEGORIES);
  if (cached) return cached;

  const pieces = await getPieces();
  const cats   = [...new Set(pieces.map(p => p.categorie).filter(Boolean))].sort();
  await cache.set(CACHE_KEYS.CATEGORIES, cats);
  return cats;
}

// ── Services (À LA CARTE) ─────────────────────────────────────────

export async function getServices(): Promise<Service[]> {
  const cached = await cache.get<Service[]>(CACHE_KEYS.SERVICES);
  if (cached) return cached;

  const sheets = getSheetsClient();

  // v5.7.5 : les forfaits ont migré dans un onglet dédié "FORFAITS".
  // On lit les deux en parallèle, forfaits d'abord pour préserver l'ordre
  // d'affichage (forfait puis ses sous-items '—' / '-') attendu par
  // BDCPanel.forfaitSubItems. L'ancien onglet "À LA CARTE" reste la source
  // des services à la carte.
  const [forfaitsRes, carteRes] = await Promise.all([
    sheets.spreadsheets.values
      .get({
        spreadsheetId    : SHEET_IDS.SERVICES,
        range            : `${TAB.FORFAITS_TAB}!A5:F`,  // col A = serviceId
        valueRenderOption: 'UNFORMATTED_VALUE',
      })
      .catch(() => ({ data: { values: [] as unknown[][] } })),
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.SERVICES,
      range            : `${TAB.SERVICES_TAB}!A6:F`,   // col A = serviceId, ligne 5 = template
      valueRenderOption: 'UNFORMATTED_VALUE',
    }),
  ]);

  const forfaitsRows = forfaitsRes.data.values ?? [];
  const carteRows    = carteRes.data.values    ?? [];

  // ⚠ Les deux onglets (FORFAITS et À LA CARTE) sont mergés ici. Leurs
  // numéros de ligne réels se chevauchent (FORFAITS row 6 vs À LA CARTE
  // row 6). Pour éviter que `_row` (utilisé comme clé de sélection dans
  // les popups) ne collisionne, on ajoute un offset de 100000 aux rows
  // des forfaits. La sélection d'un forfait ne cochera donc plus
  // accidentellement une ligne À LA CARTE avec le même numéro.
  // (Les API qui écrivent dans les sheets utilisent serviceId, pas _row.)
  const FORFAIT_ROW_OFFSET = 100_000;
  const services: Service[] = [
    ...forfaitsRows.map((r, idx) => _rowToService(r, idx + 5 + FORFAIT_ROW_OFFSET)),
    ...carteRows   .map((r, idx) => _rowToService(r, idx + 6)),  // À LA CARTE : B6+ (5=template)
  ].filter((s): s is Service => !!s.label);

  await cache.set(CACHE_KEYS.SERVICES, services);
  return services;
}

/**
 * Ajoute un nouveau service au catalogue À LA CARTE.
 *
 * v5.7.5 : les forfaits ont migré dans l'onglet FORFAITS. L'onglet
 * À LA CARTE ne contient plus que les services à la carte.
 *
 * Layout des lignes :
 *  - 5      : ligne template (formules + formats) à dupliquer
 *  - 6+     : services à la carte (la nouvelle ligne y est insérée)
 *
 * Insère une nouvelle ligne 6 en dupliquant la ligne template (5), puis
 * remplit B/C/D/F. Le prix (col E) est calculé par la formule.
 */
export async function addService(
  label    : string,
  categorie: string,
  duree    : string = '',
): Promise<{ prix: number; row: number }> {
  const sheets    = getSheetsClient();
  const sheetId   = await _getServicesSheetId();
  const TEMPLATE  = 5;               // 1-based : ligne template
  const tplIdx0   = TEMPLATE - 1;    // 0-based : 4
  const insertIdx = TEMPLATE;        // 0-based : 5 → insère APRÈS la template
  const newRow    = TEMPLATE + 1;    // 1-based : 6 — la nouvelle ligne créée

  // 1. Insérer une ligne APRÈS le template (ligne 29)
  // 2. CopyPaste le template (ligne 28) vers la nouvelle ligne (29)
  //    Après insertion à index 28, le template à index 27 reste inchangé.
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.SERVICES,
    requestBody  : {
      requests: [
        {
          insertDimension: {
            range: { sheetId, dimension: 'ROWS', startIndex: insertIdx, endIndex: insertIdx + 1 },
            inheritFromBefore: true,
          },
        },
        {
          copyPaste: {
            source     : { sheetId, startRowIndex: tplIdx0,    endRowIndex: tplIdx0 + 1 },
            destination: { sheetId, startRowIndex: insertIdx,  endRowIndex: insertIdx + 1 },
            pasteType  : 'PASTE_NORMAL',
          },
        },
      ],
    },
  });

  // 3. Générer un serviceId unique (S00001…)
  const nextSvcId = await _nextServiceId();

  // 4. Écrire les valeurs A (serviceId), B (label), D (durée), F (categorie dropdown)
  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.SERVICES,
    requestBody  : {
      valueInputOption: 'USER_ENTERED',
      data: [
        { range: `${TAB.SERVICES_TAB}!A${newRow}`, values: [[nextSvcId]] },
        { range: `${TAB.SERVICES_TAB}!B${newRow}`, values: [[label]] },
        { range: `${TAB.SERVICES_TAB}!D${newRow}`, values: [[duree]] },
        { range: `${TAB.SERVICES_TAB}!F${newRow}`, values: [[categorie]] },
      ],
    },
  });

  // 4. Lire le prix calculé par la formule de col E
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.SERVICES,
    range            : `${TAB.SERVICES_TAB}!E${newRow}`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const prix = parseFloat(String(res.data.values?.[0]?.[0] ?? '0')) || 0;

  await cache.del(CACHE_KEYS.SERVICES);
  return { prix, row: newRow };
}

/** Cache du sheetId de l'onglet À LA CARTE */
let _servicesSheetIdCache: number | null = null;
async function _getServicesSheetId(): Promise<number> {
  if (_servicesSheetIdCache !== null) return _servicesSheetIdCache;
  const sheets = getSheetsClient();
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.SERVICES,
    fields       : 'sheets.properties',
  });
  const sh = meta.data.sheets?.find(s => s.properties?.title === TAB.SERVICES_TAB);
  if (sh?.properties?.sheetId === undefined) {
    throw new Error(`Onglet "${TAB.SERVICES_TAB}" introuvable`);
  }
  _servicesSheetIdCache = sh.properties.sheetId ?? null;
  if (_servicesSheetIdCache === null) {
    throw new Error(`Onglet "${TAB.SERVICES_TAB}" sans sheetId`);
  }
  return _servicesSheetIdCache;
}

// ── Marques (_PARAMÈTRES_) ────────────────────────────────────────

const DEFAULT_MARQUES = [
  'Autre','Argon18','Bianchi','Brompton','Cannondale','Cervélo',
  'Devinci','Giant','Kona','Louis Garneau','Marin','Marinoni',
  'Miele','Moose','Norco','Opus','Panorama','Peugeot',
  'Rocky Mountain','Specialized','Trek','Triban',
];

export async function getMarques(forceRefresh = false): Promise<Marque[]> {
  if (forceRefresh) await cache.del(CACHE_KEYS.MARQUES);
  const cached = await cache.get<Marque[]>(CACHE_KEYS.MARQUES);
  if (cached) return cached;

  try {
    const sheets = getSheetsClient();
    const res    = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.PARAMS}!A${ROW.MARQUES_START}:A`,
      valueRenderOption: 'FORMATTED_VALUE',
    });

    const rows   = res.data.values ?? [];
    const noms   = rows
      .map(r => String(r[0] ?? '').trim())
      .filter(n =>
        n
        && !n.startsWith('🔧')
        && !n.startsWith('ℹ')          // ℹ️ ou ℹ devant texte d'instruction
        && n !== 'Marque'
        && !n.includes('>')            // texte d'instruction (ex. "Après modif > menu > …")
        && !n.includes('→')            // idem flèche unicode (ex. "ℹ️ … → menu …")
        && !/^(après|apres)\s/i.test(n)
      );
    const marques: Marque[] = (noms.length ? noms : DEFAULT_MARQUES).map(nom => ({ nom }));
    await cache.set(CACHE_KEYS.MARQUES, marques);
    return marques;
  } catch {
    const marques: Marque[] = DEFAULT_MARQUES.map(nom => ({ nom }));
    await cache.set(CACHE_KEYS.MARQUES, marques);
    return marques;
  }
}

/**
 * Ajoute une nouvelle marque dans l'onglet _PARAMÈTRES_ du document INVENTAIRE.
 */
export async function addMarque(nom: string): Promise<void> {
  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.append({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.PARAMS}!A${ROW.MARQUES_START}`,
    valueInputOption : 'RAW',
    insertDataOption : 'INSERT_ROWS',
    requestBody      : { values: [[nom]] },
  });
  await cache.del(CACHE_KEYS.MARQUES);
}

// ── Mutations catalogue ───────────────────────────────────────────

/**
 * Met à jour les champs flag (col B), sku (col S), fournisseur (col T),
 * prixBDC (col R) ou categorie (col Z) d'une pièce. Schéma post col Q COST.
 */
export async function updatePieceFields(
  row   : number,
  fields: { flag?: string; sku?: string; fournisseur?: string; categorie?: string; prixBDC?: number; qteACommander?: number; notes?: string; nom?: string; prixAchat?: number; codeBarre?: string; oos?: boolean; qteSac?: number },
): Promise<void> {
  const sheets = getSheetsClient();
  const data: { range: string; values: unknown[][] }[] = [];

  // Schéma post-insertion col T = codeBarre (toutes les cols après S
  // décalées de +1 par rapport à l'ancien schéma).
  if (fields.flag          !== undefined) data.push({ range: `${TAB.PIECES_TAB}!B${row}`,  values: [[fields.flag]]          });
  if (fields.sku           !== undefined) data.push({ range: `${TAB.PIECES_TAB}!S${row}`,  values: [[fields.sku]]           });
  if (fields.codeBarre     !== undefined) data.push({ range: `${TAB.PIECES_TAB}!T${row}`,  values: [[fields.codeBarre]]     });
  if (fields.oos           !== undefined) data.push({ range: `${TAB.PIECES_TAB}!V${row}`,  values: [[fields.oos]]           });
  if (fields.fournisseur   !== undefined) data.push({ range: `${TAB.PIECES_TAB}!U${row}`,  values: [[fields.fournisseur]]   });
  if (fields.prixBDC       !== undefined) data.push({ range: `${TAB.PIECES_TAB}!R${row}`,  values: [[fields.prixBDC]]       });
  if (fields.categorie     !== undefined) data.push({ range: `${TAB.PIECES_TAB}!AA${row}`, values: [[fields.categorie]]     });
  if (fields.qteACommander !== undefined) data.push({ range: `${TAB.PIECES_TAB}!W${row}`,  values: [[fields.qteACommander]] });
  if (fields.notes         !== undefined) data.push({ range: `${TAB.PIECES_TAB}!AE${row}`, values: [[fields.notes]]         });
  if (fields.nom           !== undefined) data.push({ range: `${TAB.PIECES_TAB}!D${row}`,  values: [[fields.nom]]           });
  if (fields.prixAchat     !== undefined) data.push({ range: `${TAB.PIECES_TAB}!L${row}`,  values: [[fields.prixAchat]]     });
  if (fields.qteSac        !== undefined) data.push({ range: `${TAB.PIECES_TAB}!F${row}`,  values: [[fields.qteSac]]        });

  if (data.length === 0) return;

  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.PIECES,
    requestBody  : { valueInputOption: 'RAW', data },
  });
  await cache.del(CACHE_KEYS.PIECES);
}

/**
 * Met à jour les champs d'un service (label B, durée D, catégoriePrio F).
 * Si la durée est modifiée, relit la col E (prix calculé par formule sheet)
 * et le renvoie pour que le client puisse mettre à jour son state local.
 */
export async function updateServiceFields(
  row   : number,
  fields: { categoriePrio?: string; label?: string; duree?: string },
): Promise<{ prix?: number }> {
  const sheets = getSheetsClient();
  const data: { range: string; values: unknown[][] }[] = [];
  // Col B = label (titre du service)
  if (fields.label !== undefined)
    data.push({ range: `${TAB.SERVICES_TAB}!B${row}`, values: [[fields.label]] });
  // Col D = durée (minutes ou format HH:MM — la formule prix de E utilise D)
  if (fields.duree !== undefined)
    data.push({ range: `${TAB.SERVICES_TAB}!D${row}`, values: [[fields.duree]] });
  // Col F = catégorie prioritaire (override de la catégorie auto)
  if (fields.categoriePrio !== undefined)
    data.push({ range: `${TAB.SERVICES_TAB}!F${row}`, values: [[fields.categoriePrio]] });
  if (data.length === 0) return {};
  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.SERVICES,
    requestBody  : { valueInputOption: 'RAW', data },
  });
  await cache.del(CACHE_KEYS.SERVICES);

  // Si la durée a changé, relire le prix calculé par la formule (col E) pour
  // le renvoyer au client → permet la maj du prix en temps réel sans
  // re-fetch complet du catalogue.
  if (fields.duree !== undefined) {
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.SERVICES,
      range            : `${TAB.SERVICES_TAB}!E${row}`,
      valueRenderOption: 'UNFORMATTED_VALUE',
    });
    const prix = parseFloat(String(res.data.values?.[0]?.[0] ?? '0')) || 0;
    return { prix };
  }
  return {};
}

/**
 * Retourne les fournisseurs uniques du catalogue (non vides).
 */
export async function getFournisseurs(): Promise<string[]> {
  const pieces = await getPieces();
  return [...new Set(pieces.map(p => p.fournisseur).filter(Boolean))].sort();
}

/**
 * Ajoute une nouvelle pièce dans le catalogue PIÈCES.
 *
 * Trouve la ligne "Nom ITEM" de la MÊME catégorie principale (ex. "4. Freins"),
 * insère une nouvelle ligne juste en-dessous et y copie les formules +
 * formatage de la ligne template via copyPaste (PASTE_NORMAL). Les colonnes
 * P/Q/R contiennent des formules de prix de vente calculées depuis le
 * prix d'achat (K/L/M selon fournisseur) — ces formules sont héritées.
 *
 * Schéma des colonnes d'écriture (1-based) :
 *   B  flag              '√'
 *   D  nom               full nom (Marque, Nom)
 *   H  qté               quantité
 *   K  prix d'achat Babac     (si fournisseur === 'Babac')
 *   L  prix d'achat autres    (fournisseur hors Babac/HLC)
 *   M  prix d'achat HLC       (si fournisseur === 'HLC')
 *   S  sku                    (texte ; hyperlink si skuUrl fourni)
 *   T  fournisseur
 *   Z  categorie complète (ex. "4. Freins, Patins de route")
 */
export async function addPieceToCatalogue(input: {
  nom         : string;
  categorie   : string;
  qte?        : number;
  prix?       : number;
  fournisseur?: string;
  sku?        : string;
  skuUrl?     : string;
  codeBarre?  : string;
  oos?        : boolean;
}): Promise<{ row: number; pieceId: string }> {
  const { nom, categorie, qte = 0, prix = 0, fournisseur = '', sku = '', skuUrl = '', codeBarre = '', oos = false } = input;
  const sheets = getSheetsClient();

  // 1. Lire toutes les lignes pour localiser le template
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.PIECES,
    range            : `${TAB.PIECES_TAB}!B2:AD`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const rows = res.data.values ?? [];
  const s    = (r: unknown[], i: number) => String(r[i] ?? '').trim();

  /** Extrait la catégorie principale (avant la première virgule). */
  const mainCat = (raw: string): string => {
    const t = (raw ?? '').trim();
    const idx = t.indexOf(',');
    return idx < 0 ? t : t.slice(0, idx).trim();
  };

  const targetMain = mainCat(categorie);

  // 2. Trouver la ligne "Nom ITEM" de la même catégorie principale.
  //    La ligne "Nom ITEM" elle-même n'a pas forcément col AA remplie, donc
  //    on la lie à la première pièce (avec col AA) qui la suit.
  //    (col D = index 2 depuis B, col AA = index 25 depuis B — post insertion col T codeBarre)
  const sectionMainToNomItemRow = new Map<string, number>();
  let pendingNomItemRow: number | null = null;
  for (let i = 0; i < rows.length; i++) {
    const nom    = s(rows[i], 2);
    const catRaw = s(rows[i], 25);
    if (nom === 'Nom ITEM') {
      pendingNomItemRow = i + 2; // 1-based
      continue;
    }
    if (pendingNomItemRow !== null && catRaw) {
      const m = mainCat(catRaw);
      if (m && !sectionMainToNomItemRow.has(m)) {
        sectionMainToNomItemRow.set(m, pendingNomItemRow);
      }
    }
  }

  let templateRow = sectionMainToNomItemRow.get(targetMain) ?? -1;

  // Fallback : n'importe quelle ligne "Nom ITEM"
  if (templateRow < 0) {
    for (let i = 0; i < rows.length; i++) {
      if (s(rows[i], 2) === 'Nom ITEM') {
        templateRow = i + 2;
        break;
      }
    }
  }

  // Fallback ultime : dernière ligne + 1 (sans template = pas de formules)
  const insertAfter = templateRow > 0 ? templateRow : rows.length + 1;

  // 3. Récupérer le sheetId de l'onglet PIÈCES
  const spreadsheet = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.PIECES,
    fields       : 'sheets.properties',
  });
  const sheet = spreadsheet.data.sheets?.find(
    (s: any) => s.properties?.title === TAB.PIECES_TAB,
  );
  const sheetId = sheet?.properties?.sheetId ?? 0;

  // 4. Insert + CopyPaste de la ligne template (Nom ITEM de la section)
  const startIdx0 = insertAfter;       // 0-based : on insère JUSTE APRÈS le Nom ITEM
  const tplIdx0   = insertAfter - 1;   // 0-based : la template elle-même
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.PIECES,
    requestBody  : {
      requests: [
        {
          insertDimension: {
            range: { sheetId, dimension: 'ROWS', startIndex: startIdx0, endIndex: startIdx0 + 1 },
            inheritFromBefore: true,
          },
        },
        {
          // Source = template (tplIdx0) ; destination = ligne insérée (startIdx0).
          // L'insert préalable a décalé les lignes SOUS la template, pas la
          // template elle-même, donc tplIdx0 reste valide.
          copyPaste: {
            source     : { sheetId, startRowIndex: tplIdx0,   endRowIndex: tplIdx0 + 1 },
            destination: { sheetId, startRowIndex: startIdx0, endRowIndex: startIdx0 + 1 },
            pasteType  : 'PASTE_NORMAL',
          },
        },
      ],
    },
  });

  // 5. Écrire les valeurs dans la nouvelle ligne
  const newRow = insertAfter + 1; // 1-based

  // Sélection de la colonne prix selon le fournisseur
  //   Babac → K (col prix d'achat Babac)
  //   HLC   → M (col prix d'achat HLC)
  //   autres → L (col prix d'achat autres)
  const fournNorm = fournisseur.toLowerCase();
  const prixCol =
    fournNorm === 'babac' ? 'K' :
    fournNorm === 'hlc'   ? 'M' : 'L';

  // Générer un pieceId unique pour la nouvelle ligne
  const nextId = await _nextPieceId();

  const updates: { range: string; values: unknown[][] }[] = [
    { range: `${TAB.PIECES_TAB}!A${newRow}`, values: [[nextId]]    },
    { range: `${TAB.PIECES_TAB}!B${newRow}`, values: [['$']]       },
    { range: `${TAB.PIECES_TAB}!D${newRow}`, values: [[nom]]        },
    { range: `${TAB.PIECES_TAB}!H${newRow}`, values: [[qte]]        },
    { range: `${TAB.PIECES_TAB}!${prixCol}${newRow}`, values: [[prix]] },
    { range: `${TAB.PIECES_TAB}!U${newRow}`,  values: [[fournisseur]] },
    { range: `${TAB.PIECES_TAB}!AA${newRow}`, values: [[categorie]]   },
  ];
  if (codeBarre) {
    updates.push({ range: `${TAB.PIECES_TAB}!T${newRow}`, values: [[codeBarre]] });
  }
  if (oos) {
    updates.push({ range: `${TAB.PIECES_TAB}!V${newRow}`, values: [[true]] });
  }

  // SKU plain text uniquement ici. Si skuUrl fourni, on écrit le texte
  // via USER_ENTERED puis on attache le hyperlink via updateCells (voir
  // plus bas) — les formules =HYPERLINK() sont locale-dependent (français
  // attend ";" au lieu de ","), donc on utilise textFormatRuns.link.
  const skuText = sku || skuUrl;
  if (skuText) {
    updates.push({ range: `${TAB.PIECES_TAB}!S${newRow}`, values: [[skuText]] });
  }

  // Écriture : USER_ENTERED (formulas dans les cols P/Q/R déjà héritées via copyPaste).
  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.PIECES,
    requestBody  : {
      valueInputOption: 'USER_ENTERED',
      data: updates,
    },
  });

  // 5b. Attacher le hyperlink à la cellule SKU (col S = index 18, 0-based)
  // via textFormatRuns — locale-independent, contrairement à =HYPERLINK().
  if (skuUrl && skuText) {
    await sheets.spreadsheets.batchUpdate({
      spreadsheetId: SHEET_IDS.PIECES,
      requestBody  : {
        requests: [{
          updateCells: {
            range: {
              sheetId,
              startRowIndex   : newRow - 1,
              endRowIndex     : newRow,
              startColumnIndex: 18,  // col S (0-based)
              endColumnIndex  : 19,
            },
            rows: [{
              values: [{
                userEnteredValue: { stringValue: skuText },
                textFormatRuns  : [{
                  startIndex: 0,
                  format    : { link: { uri: skuUrl } },
                }],
              }],
            }],
            fields: 'userEnteredValue,textFormatRuns',
          },
        }],
      },
    });
  }

  await cache.del(CACHE_KEYS.PIECES);
  await cache.del(CACHE_KEYS.CATEGORIES);

  return { row: newRow, pieceId: nextId };
}

// ── Import bulk Brompton ──────────────────────────────────────────

/**
 * Input d'une ligne Brompton à importer (déjà filtrée Fabricant='Brompton').
 * - nom             : col H Nom d'article (obligatoire)
 * - sku             : col P Code d'article (obligatoire pour match/ID)
 * - categorieSuffix : col B Catégorie du fichier (ex. "A line", "G-Line"…)
 * - prixBDC         : col J Prix   → PIÈCES col R
 * - prixAchat       : col K Coût   → PIÈCES col L
 * - notes           : col T Description → PIÈCES col AE
 */
export interface BromptonImportRow {
  nom             : string;
  sku             : string;
  categorieSuffix?: string;
  prixBDC?        : number;
  prixAchat?      : number;
  notes?          : string;
}

export interface BromptonImportReport {
  added  : { sku: string; nom: string }[];
  updated: { sku: string; nom: string; row: number }[];
  skipped: { sku: string; nom: string; reason: string }[];
}

/** Normalise un SKU pour matching (trim + lowercase + ws collapse). */
function _normSku(s: string): string {
  return String(s ?? '').trim().toLowerCase().replace(/\s+/g, ' ');
}

/**
 * Import bulk de pièces Brompton : cherche par SKU dans le catalogue
 * existant, met à jour si trouvé, crée sinon.
 *
 * - Catégorie finale      : "9. Brompton, {categorieSuffix}" (suffix trimmed)
 * - Fournisseur forcé     : "Flex"
 * - Champs écrasés si MAJ : prixBDC (R), prixAchat (L), notes (AE),
 *                           fournisseur (T), categorie (Z). Nom et SKU
 *                           ne sont pas touchés (le match est déjà par SKU
 *                           et on évite de renommer par surprise).
 */
export async function bulkImportBromptonPieces(
  rows: BromptonImportRow[],
): Promise<BromptonImportReport> {
  const report: BromptonImportReport = { added: [], updated: [], skipped: [] };
  if (!rows.length) return report;

  // 1. Index des pièces existantes par SKU normalisé
  const pieces  = await getPieces();
  const bySku   = new Map<string, Piece>();
  for (const p of pieces) {
    const k = _normSku(p.sku);
    if (k) bySku.set(k, p);
  }

  // 2. Traitement ligne à ligne
  for (const r of rows) {
    const sku = String(r.sku ?? '').trim();
    const nom = String(r.nom ?? '').trim();
    if (!sku) { report.skipped.push({ sku: '', nom, reason: 'SKU vide' }); continue; }
    if (!nom) { report.skipped.push({ sku, nom: '', reason: 'Nom vide' }); continue; }

    const suffix    = (r.categorieSuffix ?? '').trim();
    const categorie = suffix ? `9. Brompton, ${suffix}` : '9. Brompton';

    const existing = bySku.get(_normSku(sku));
    try {
      if (existing) {
        await updatePieceFields(existing._row, {
          prixBDC    : r.prixBDC,
          prixAchat  : r.prixAchat,
          notes      : r.notes,
          fournisseur: 'Flex',
          categorie,
        });
        report.updated.push({ sku, nom, row: existing._row });
      } else {
        // addPieceToCatalogue écrit le prix d'achat dans col L (fournisseur
        // != Babac/HLC), mais n'écrit pas col R (prixBDC) ni notes. On
        // enchaîne donc avec updatePieceFields pour compléter.
        await addPieceToCatalogue({
          nom,
          categorie,
          fournisseur: 'Flex',
          sku,
          prix: r.prixAchat ?? 0,  // → col L
        });
        // Le pieceId vient d'être créé — relire le catalogue pour trouver la row.
        await cache.del(CACHE_KEYS.PIECES);
        const fresh    = await getPieces();
        const newPiece = fresh.find(p => _normSku(p.sku) === _normSku(sku));
        if (newPiece) {
          await updatePieceFields(newPiece._row, {
            prixBDC: r.prixBDC,
            notes  : r.notes,
          });
        }
        report.added.push({ sku, nom });
      }
    } catch (err: any) {
      report.skipped.push({ sku, nom, reason: err?.message ?? 'Erreur inconnue' });
    }
  }

  await cache.del(CACHE_KEYS.PIECES);
  await cache.del(CACHE_KEYS.CATEGORIES);
  return report;
}

// ── Helpers ───────────────────────────────────────────────────────

function _rowToPiece(r: unknown[], rowNum: number): Piece {
  const s = (i: number) => String(r[i] ?? '').trim();
  const n = (i: number) => parseFloat(String(r[i] ?? '0')) || 0;

  // Schéma post-introduction de la col Q "COST" (bouton Cost) — toutes les
  // colonnes à partir de Q sont décalées d'une position vers la droite par
  // rapport à l'ancien layout.
  return {
    _row           : rowNum,
    flag           : s(0),              // col B (index 0) — statut (—/√/$/$$)
    groupe         : s(1),              // col C
    nom            : s(2),              // col D
    sku            : s(17),             // col S (index 17) — référence fournisseur
    skuUrl         : '',                // rempli après avec les hyperliens natifs
    prixAchat      : n(10),             // col L (index 10) — inchangé
    prixBase       : n(13),             // col O (index 13) — inchangé
    prixVente      : n(14),             // col P (index 14) — prix de vente client
    prixCost       : n(15),             // col Q (index 15) — NOUVEAU prix COST
    prixBDC        : n(16) || n(13),    // col R (index 16) — prix unitaire ; fallback col O si R vide
    codeBarre      : s(18),             // col T (index 18) — code-barre EAN/UPC fabricant
    qteSac         : n(4) || undefined, // col F (index 4) — qté par sac (v1.3.1+)
    fournisseur    : s(19),             // col U (index 19)
    oos            : r[20] === true || String(r[20] ?? '').toUpperCase() === 'TRUE' ? 1 : 0, // col V (index 20) — OOS checkbox
    qteACommander  : n(21),             // col W (index 21)
    sousTotal      : n(22) || (n(13) * n(21)),  // col X (index 22), fallback = prix (O) × qté (W)
    categorie      : s(25),             // col AA (index 25)
    stock          : n(26),             // col AB (index 26) — stock physique
    stockReserve   : n(27),             // col AC (index 27) — qté réservée pour BDT actifs (post-APPROUVÉ, pre-FACTURÉ)
    surplus        : n(28),             // col AD (index 28) — qté surplus à la réception PO
    notes          : s(29),             // col AE (index 29) — note libre éditable
    pieceId        : '',                // col A — rempli après via lecture séparée
  };
}

/** Génère le prochain pieceId (P00001, P00002…) en lisant le max existant. */
async function _nextPieceId(): Promise<string> {
  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.PIECES,
    range            : `${TAB.PIECES_TAB}!A2:A`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const ids = (res.data.values ?? [])
    .map(r => String(r[0] ?? '').trim())
    .filter(id => /^P\d+$/.test(id))
    .map(id => parseInt(id.slice(1)));
  const maxNum = ids.length > 0 ? Math.max(...ids) : 0;
  return `P${String(maxNum + 1).padStart(5, '0')}`;
}

/** Génère le prochain serviceId (S00001, S00002…) en lisant le max existant
 *  depuis col A des deux onglets (FORFAITS + À LA CARTE).
 *
 *  V1.0 hardening (P0.6) : avant ce fix, la lecture FORFAITS swallow toute
 *  erreur (`.catch(() => values: [])`) → si l'API Sheets était saturée, le
 *  maxNum était calculé sur À LA CARTE seul → on pouvait réutiliser un
 *  serviceId déjà existant dans FORFAITS = collision d'IDs. Maintenant, si
 *  une des deux lectures échoue après les 8 retries gaxios, on abort la
 *  génération pour préserver l'unicité globale des IDs.
 */
export async function _nextServiceId(): Promise<string> {
  const sheets = getSheetsClient();
  let forfRes, carteRes;
  try {
    [forfRes, carteRes] = await Promise.all([
      sheets.spreadsheets.values.get({
        spreadsheetId: SHEET_IDS.SERVICES,
        range: `${TAB.FORFAITS_TAB}!A5:A`,
        valueRenderOption: 'FORMATTED_VALUE',
      }),
      sheets.spreadsheets.values.get({
        spreadsheetId: SHEET_IDS.SERVICES,
        range: `${TAB.SERVICES_TAB}!A6:A`,
        valueRenderOption: 'FORMATTED_VALUE',
      }),
    ]);
  } catch (err: any) {
    const msg = err?.message ?? 'erreur Sheets';
    logError('next-service-id-read-failed', { error: msg });
    throw new Error(
      `Génération serviceId bloquée : impossible de lire FORFAITS + À LA CARTE ` +
      `(${msg}). Réessaie dans 30 s — l'API Sheets est probablement saturée.`,
    );
  }
  const all = [...(forfRes.data.values ?? []), ...(carteRes.data.values ?? [])];
  const ids = all
    .map(r => String(r[0] ?? '').trim())
    .filter(id => /^S\d+$/.test(id))
    .map(id => parseInt(id.slice(1)));
  const maxNum = ids.length > 0 ? Math.max(...ids) : 0;
  return `S${String(maxNum + 1).padStart(5, '0')}`;
}

function _rowToService(r: unknown[], rowNum: number): Service {
  const s = (i: number) => String(r[i] ?? '').trim();
  const n = (i: number) => parseFloat(String(r[i] ?? '0')) || 0;

  const catSrc  = s(2);  // col C (index 2 depuis A)
  const catPrio = s(5);  // col F (index 5 depuis A)

  return {
    _row             : rowNum,
    serviceId        : s(0),  // col A — ID stable (S00001…)
    label            : s(1),  // col B
    duree            : s(3),  // col D — durée (ex. "15 min", "1h30")
    categorie        : catSrc,
    prix             : n(4),  // col E (index 4 depuis A)
    categoriePrio    : catPrio,
    categorieAffichee: catPrio || catSrc,
  };
}
