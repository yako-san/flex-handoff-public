/**
 * CRUD Bons de commande fournisseurs — onglet _PO_ du document INVENTAIRE.
 *
 * Structure flat : une ligne par item de commande, groupées par poNumber.
 * Colonnes A..M : poNumber, fournisseur, dateCommande, dateReception,
 *   status, nom, sku, qteCommandee, qteRecue, prixAchat, recu, pieceRow, notes
 */
import { getSheetsClient, SHEET_IDS, TAB } from './client';
import cache, { CACHE_KEYS } from '@/lib/cache';
import { normSearch } from '@/lib/utils/format';
import { pieceKey } from '@/lib/utils/pieces';
import type { PO, POLineItem, POStatus } from '@/types/po';

// v1.1.3 — Col P `stockSyncedAt` ajoutée pour idempotence sync-stock (Item 2 audit).
// Persistée sur la 1ʳᵉ ligne du PO uniquement.
// v1.3.1+ — Col Q `displayName` ajoutée (override d'affichage poNumber, ex.
// numéro de facture fournisseur). Persistée sur la 1ʳᵉ ligne du PO uniquement.
const PO_HEADERS = [
  'poNumber', 'fournisseur', 'dateCommande', 'dateReception', 'status',
  'nom', 'sku', 'qteCommandee', 'qteRecue', 'prixAchat', 'recu', 'pieceRow', 'notes', 'pieceId', 'categorie',
  'stockSyncedAt', 'displayName',
];
const PO_NB_COLS = PO_HEADERS.length;
/** Convertit 1-indexé → lettre Excel (1→A, 16→P, 27→AA). */
function _colLetter(n: number): string {
  let s = '';
  while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); }
  return s;
}
const PO_LAST_COL = _colLetter(PO_NB_COLS); // 'P'

// ── Lecture ──────────────────────────────────────────────────────

export async function getPOs(): Promise<PO[]> {
  const cached = await cache.get<PO[]>(CACHE_KEYS.POS);
  if (cached) return cached;

  await _ensureTab();
  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.PO}!A2:${PO_LAST_COL}`,
    valueRenderOption: 'FORMATTED_VALUE',
  });

  const rows = res.data.values ?? [];
  const poMap = new Map<string, { po: Omit<PO, 'items' | '_rows'>; items: POLineItem[]; _rows: number[] }>();

  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const s = (idx: number) => String(r[idx] ?? '').trim();
    const n = (idx: number) => parseFloat(String(r[idx] ?? '0')) || 0;
    const poNumber = s(0);
    if (!poNumber) continue;

    if (!poMap.has(poNumber)) {
      poMap.set(poNumber, {
        po: {
          poNumber,
          fournisseur   : s(1),
          dateCommande  : s(2),
          dateReception : s(3) || null,
          status        : (s(4) || 'EN ATTENTE') as POStatus,
          // v1.1.3 — Item 2 : col P stockSyncedAt (ISO ts). Première ligne du
          // PO seulement — les autres lignes peuvent rester vides.
          stockSyncedAt : s(15) || null,
          // v1.3.1+ : col Q displayName (override d'affichage)
          displayName   : s(16) || undefined,
        },
        items: [],
        _rows: [],
      });
    } else {
      const entry = poMap.get(poNumber)!;
      if (!entry.po.stockSyncedAt && s(15)) {
        // Failsafe : si jamais la 1ʳᵉ ligne avait été dé-cochée et qu'une autre
        // ligne porte la valeur, on la propage. Ne devrait pas arriver en pratique.
        entry.po.stockSyncedAt = s(15);
      }
      if (!entry.po.displayName && s(16)) entry.po.displayName = s(16);
    }

    const entry = poMap.get(poNumber)!;
    entry.items.push({
      nom          : s(5),
      sku          : s(6),
      qteCommandee : n(7),
      qteRecue     : n(8),
      prixAchat    : n(9),
      recu         : r[10] === true || String(r[10] ?? '').toUpperCase() === 'TRUE',
      pieceRow     : parseInt(String(r[11] ?? '-1')) || -1,
      notes        : s(12),
      pieceId      : s(13),
      categorie    : s(14),
    });
    entry._rows.push(i + 2); // 1-based
  }

  const pos: PO[] = [...poMap.values()].map(({ po, items, _rows }) => ({
    ...po,
    items,
    _rows,
  }));

  await cache.set(CACHE_KEYS.POS, pos);
  return pos;
}

export async function getPO(poNumber: string): Promise<PO | null> {
  const pos = await getPOs();
  return pos.find(p => p.poNumber === poNumber) ?? null;
}

// ── Création ────────────────────────────────────────────────────

export async function createPO(input: {
  poNumber    : string;
  fournisseur : string;
  dateCommande: string;
  items       : Omit<POLineItem, 'qteRecue' | 'recu'>[];
}): Promise<void> {
  await _ensureTab();
  const sheets = getSheetsClient();

  const rows = input.items.map(item => [
    input.poNumber,
    input.fournisseur,
    input.dateCommande,
    '',                            // dateReception
    'EN ATTENTE',                  // status
    item.nom,
    item.sku,
    item.qteCommandee,
    0,                             // qteRecue
    item.prixAchat,
    false,                         // recu
    item.pieceRow,
    item.notes,
    item.pieceId || '',            // pieceId (col N)
    item.categorie || '',          // categorie (col O)
    '',                            // stockSyncedAt (col P) — vide à la création
    '',                            // displayName (col Q) — vide à la création
  ]);

  await sheets.spreadsheets.values.append({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.PO}!A1`,
    valueInputOption: 'RAW',
    insertDataOption: 'INSERT_ROWS',
    requestBody     : { values: rows },
  });

  await cache.del(CACHE_KEYS.POS);
}

// ── Ajout de lignes à un PO existant ────────────────────────────

export async function addLinesToPO(
  poNumber: string,
  items: Omit<POLineItem, 'qteRecue' | 'recu'>[],
): Promise<void> {
  const po = await getPO(poNumber);
  if (!po) throw new Error(`PO ${poNumber} introuvable`);
  if (po.status !== 'EN ATTENTE') throw new Error(`PO ${poNumber} n'est plus modifiable (statut: ${po.status})`);

  const sheets = getSheetsClient();

  const rows = items.map(item => [
    po.poNumber,
    po.fournisseur,
    po.dateCommande,
    '',              // dateReception
    'EN ATTENTE',
    item.nom,
    item.sku,
    item.qteCommandee,
    0,               // qteRecue
    item.prixAchat,
    false,           // recu
    item.pieceRow,
    item.notes,
    item.pieceId || '',   // pieceId (col N)
    item.categorie || '', // categorie (col O)
    '',                   // stockSyncedAt (col P) — vide
    '',                   // displayName (col Q) — vide
  ]);

  await sheets.spreadsheets.values.append({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.PO}!A1`,
    valueInputOption: 'RAW',
    insertDataOption: 'INSERT_ROWS',
    requestBody     : { values: rows },
  });

  await cache.del(CACHE_KEYS.POS);
}

/**
 * v1.3.1+ (cluster suite item n) — Override le poNumber affiché par un
 * nom custom (ex. numéro de facture fournisseur reçu après coup).
 * Écrit la valeur en col Q de la 1ʳᵉ ligne du PO. La clé poNumber reste
 * inchangée — le reste du code (matching items, redirect, etc.) continue
 * de l'utiliser. Seul l'UI affiche displayName si présent.
 *
 * Pour effacer l'override : passer '' (chaîne vide).
 */
export async function renamePO(poNumber: string, displayName: string): Promise<void> {
  const po = await getPO(poNumber);
  if (!po) throw new Error(`PO ${poNumber} introuvable`);
  const firstRow = po._rows[0];
  if (!firstRow) throw new Error(`PO ${poNumber} sans ligne sheet`);

  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.PO}!Q${firstRow}`,
    valueInputOption: 'RAW',
    requestBody     : { values: [[displayName.trim()]] },
  });
  await cache.del(CACHE_KEYS.POS);
}

/**
 * v1.0.8+ — Création d'une PO ad-hoc en réception immédiate.
 *
 * Cas d'usage : items qui arrivent à l'atelier SANS bon de commande
 * formel (achat magasin, dépôt, dépannage). Le scan d'un SKU appelle
 * cette fonction qui :
 *
 *  1. Crée une PO `ADHOC-YYYYMMDD-HHMMSS` en status='RECU' directement
 *     (qteRecue = qte fournie, recu=true, dateReception=today)
 *  2. Appelle syncStockForPO pour incrémenter le stock physique col AB
 *     du catalogue PIÈCES (et auto-créer la pièce si SKU/nom inconnu)
 *  3. Retourne le poNumber généré (visible dans la page Commandes pour
 *     trace/audit) + la pièce créée le cas échéant.
 *
 * Notes :
 *  - Si plus tard l'utilisateur veut associer cette ADHOC à une PO réelle
 *    (ex. la facture fournisseur arrive après-coup), il pourra le faire
 *    manuellement depuis la page Commandes (à venir).
 *  - Ne crée pas de doublon stock — syncStockForPO match par pieceId/sku/nom.
 */
export async function createAdhocPO(input: {
  fournisseur: string;
  pieceId    ?: string;
  sku         : string;
  nom         : string;
  qte         : number;
  prixAchat   : number;
  notes      ?: string;
}): Promise<{ poNumber: string; sync: Awaited<ReturnType<typeof syncStockForPO>> }> {
  await _ensureTab();
  const sheets = getSheetsClient();

  // poNumber unique : ADHOC-YYYYMMDD-HHMMSS (ISO compact)
  const now = new Date();
  const yyyymmdd = now.toISOString().slice(0, 10).replace(/-/g, '');
  const hhmmss   = now.toISOString().slice(11, 19).replace(/:/g, '');
  const poNumber = `ADHOC-${yyyymmdd}-${hhmmss}`;
  const today    = now.toISOString().slice(0, 10);

  const row = [
    poNumber,                    // A poNumber
    input.fournisseur,           // B fournisseur
    today,                       // C dateCommande
    today,                       // D dateReception
    'RECU',                      // E status — réception immédiate
    input.nom,                   // F nom
    input.sku,                   // G sku
    input.qte,                   // H qteCommandee = qte reçue
    input.qte,                   // I qteRecue
    input.prixAchat,             // J prixAchat
    true,                        // K recu = true
    -1,                          // L pieceRow (-1 = sera résolu par syncStockForPO)
    input.notes ?? '',           // M notes
    input.pieceId ?? '',         // N pieceId
    '',                          // O categorie (optionnel — peut être ajustée plus tard)
    '',                          // P stockSyncedAt — syncStockForPO marquera juste après
  ];

  await sheets.spreadsheets.values.append({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.PO}!A1`,
    valueInputOption: 'RAW',
    insertDataOption: 'INSERT_ROWS',
    requestBody     : { values: [row] },
  });
  await cache.del(CACHE_KEYS.POS);

  // Alimente le stock + crée la pièce dans le catalogue si manquante.
  // v1.1.3 — Item 2 : on marque immédiatement le PO comme synced pour
  // qu'un clic ultérieur sur « sync-stock » dans la page Commandes ne
  // double pas le stock (la route refusera avec 409 ALREADY_SYNCED).
  const sync = await syncStockForPO(poNumber);
  await markPOStockSynced(poNumber);

  return { poNumber, sync };
}

/**
 * v1.0.14+ — Fusionne des PO ADHOC dans une PO cible.
 *
 * Cas d'usage : un mécano scanne pendant la semaine des items reçus en
 * vrac (chaque scan crée un `ADHOC-YYYYMMDD-HHMMSS`). Quand la facture
 * Babac arrive en fin de semaine, l'utilisateur crée la PO `BABAC-XXX`
 * et veut **regrouper** les ADHOC du même fournisseur dedans pour avoir
 * un seul PO consolidé (audit, comptabilité, état des reçus complet).
 *
 * Comportement :
 *  - Pour chaque ADHOC source :
 *    * append toutes ses lignes items dans la PO cible (poNumber = cible,
 *      dateCommande = cible, status = cible — le reste préservé)
 *    * marque l'ADHOC comme `ANNULE` avec note "Fusionné dans BABAC-XXX"
 *      pour traçabilité (pas de suppression dure).
 *  - PAS de re-sync stock — les ADHOC ont déjà appliqué leur delta lors
 *    de leur création initiale (`syncStockForPO` post-`createAdhocPO`).
 *
 * Validation :
 *  - PO cible doit exister
 *  - PO cible doit être en EN ATTENTE ou PARTIEL (pas RECU/ANNULE)
 *  - Chaque ADHOC source doit exister, status RECU et poNumber `^ADHOC-`
 */
export async function mergeAdhocPOsIntoPO(
  targetPoNumber : string,
  adhocPoNumbers : string[],
): Promise<{ merged: number; itemsAppended: number; errors: { poNumber: string; error: string }[] }> {
  const errors: { poNumber: string; error: string }[] = [];
  if (!targetPoNumber) throw new Error('targetPoNumber requis');
  if (!Array.isArray(adhocPoNumbers) || adhocPoNumbers.length === 0) {
    throw new Error('adhocPoNumbers requis (au moins 1)');
  }

  // 1. Charger la PO cible et valider
  const target = await getPO(targetPoNumber);
  if (!target) throw new Error(`PO cible ${targetPoNumber} introuvable`);
  if (target.status !== 'EN ATTENTE' && target.status !== 'PARTIEL') {
    throw new Error(`PO cible ${targetPoNumber} non modifiable (statut: ${target.status})`);
  }

  // 2. Charger chaque ADHOC source
  const sources: PO[] = [];
  for (const poNumber of adhocPoNumbers) {
    if (!/^ADHOC-/.test(poNumber)) {
      errors.push({ poNumber, error: 'pas un ADHOC' });
      continue;
    }
    const src = await getPO(poNumber);
    if (!src) {
      errors.push({ poNumber, error: 'introuvable' });
      continue;
    }
    sources.push(src);
  }
  if (sources.length === 0) {
    return { merged: 0, itemsAppended: 0, errors };
  }

  // 3. Append les lignes des ADHOC dans la PO cible. On reprend les
  //    valeurs telles quelles (qteRecue, recu=true) pour préserver
  //    l'historique de réception. Le stock a déjà été appliqué.
  const sheets = getSheetsClient();
  const today = new Date().toISOString().slice(0, 10);
  const newRows: unknown[][] = [];
  for (const src of sources) {
    for (const item of src.items) {
      newRows.push([
        target.poNumber,           // A poNumber ← cible
        target.fournisseur,        // B fournisseur ← cible (en théorie identique)
        target.dateCommande,       // C dateCommande ← cible
        today,                     // D dateReception ← aujourd'hui
        target.status,             // E status ← cible
        item.nom,                  // F nom
        item.sku,                  // G sku
        item.qteCommandee,         // H qteCommandee
        item.qteRecue,             // I qteRecue (préservé depuis ADHOC)
        item.prixAchat,            // J prixAchat
        item.recu,                 // K recu (true depuis ADHOC)
        item.pieceRow,             // L pieceRow
        `${item.notes ?? ''}${item.notes ? ' · ' : ''}fusionné de ${src.poNumber}`.trim(),
        item.pieceId || '',        // N pieceId
        item.categorie || '',      // O categorie
        '',                        // P stockSyncedAt (stock déjà appliqué côté ADHOC source)
      ]);
    }
  }
  if (newRows.length > 0) {
    await sheets.spreadsheets.values.append({
      spreadsheetId   : SHEET_IDS.INVENTAIRE,
      range           : `${TAB.PO}!A1`,
      valueInputOption: 'RAW',
      insertDataOption: 'INSERT_ROWS',
      requestBody     : { values: newRows },
    });
  }

  // 4. Marquer chaque ADHOC source comme ANNULE avec note de traçabilité
  const cancelUpdates: { range: string; values: unknown[][] }[] = [];
  for (const src of sources) {
    for (const row of src._rows) {
      cancelUpdates.push(
        { range: `${TAB.PO}!E${row}`, values: [['ANNULE']] },
        { range: `${TAB.PO}!M${row}`, values: [[`fusionné dans ${target.poNumber}`]] },
      );
    }
  }
  if (cancelUpdates.length > 0) {
    await sheets.spreadsheets.values.batchUpdate({
      spreadsheetId: SHEET_IDS.INVENTAIRE,
      requestBody  : { valueInputOption: 'RAW', data: cancelUpdates },
    });
  }

  await cache.del(CACHE_KEYS.POS);
  return { merged: sources.length, itemsAppended: newRows.length, errors };
}

// ── Mise à jour ligne ───────────────────────────────────────────

export async function updatePOLine(
  sheetRow: number,
  fields  : { qteCommandee?: number; qteRecue?: number; recu?: boolean; notes?: string; categorie?: string },
): Promise<{ stockDelta?: number; createdPiece?: PieceAutoCreated }> {
  // Migration de colonnes (le sheet existant peut n'avoir que 14 cols — sans
  // la col O catégorie). _ensureTab étend à 15 cols si besoin.
  await _ensureTab();
  const sheets = getSheetsClient();

  // Si on change qteRecue ou recu → pre-lire la ligne pour calculer le delta de stock
  let stockDelta = 0;
  let itemContext: {
    fournisseur: string; nom: string; sku: string; qteCommandee: number;
    prixAchat: number; pieceId: string; categorie: string; newQteRecue: number;
  } | null = null;

  if (fields.qteRecue !== undefined || fields.recu !== undefined) {
    const cur = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.PO}!A${sheetRow}:O${sheetRow}`,
      valueRenderOption: 'FORMATTED_VALUE',
    });
    const row = cur.data.values?.[0] ?? [];
    const fournisseur  = String(row[1] ?? '');
    const nom          = String(row[5] ?? '');
    const sku          = String(row[6] ?? '');
    const qteCommandee = parseFloat(String(row[7] ?? '0')) || 0;
    const oldQteRecue  = parseFloat(String(row[8] ?? '0')) || 0;
    const prixAchat    = parseFloat(String(row[9] ?? '0')) || 0;
    const pieceId      = String(row[13] ?? '');
    const categorie    = String(row[14] ?? '');

    // Calcul de la nouvelle qteRecue :
    //   - fields.qteRecue prioritaire si fourni
    //   - sinon fields.recu true → qteCommandee ; false → 0
    let newQteRecue = oldQteRecue;
    if (fields.qteRecue !== undefined) newQteRecue = fields.qteRecue;
    else if (fields.recu === true)  newQteRecue = qteCommandee;
    else if (fields.recu === false) newQteRecue = 0;

    stockDelta = newQteRecue - oldQteRecue;
    if (stockDelta !== 0 && nom) {
      itemContext = { fournisseur, nom, sku, qteCommandee, prixAchat, pieceId, categorie, newQteRecue };
    }
  }

  const data: { range: string; values: unknown[][] }[] = [];
  if (fields.qteCommandee !== undefined) {
    data.push({ range: `${TAB.PO}!H${sheetRow}`, values: [[fields.qteCommandee]] });
  }
  if (fields.qteRecue !== undefined) {
    data.push({ range: `${TAB.PO}!I${sheetRow}`, values: [[fields.qteRecue]] });
  }
  if (fields.recu !== undefined) {
    data.push({ range: `${TAB.PO}!K${sheetRow}`, values: [[fields.recu]] });
  }
  if (fields.notes !== undefined) {
    data.push({ range: `${TAB.PO}!M${sheetRow}`, values: [[fields.notes]] });
  }
  if (fields.categorie !== undefined) {
    data.push({ range: `${TAB.PO}!O${sheetRow}`, values: [[fields.categorie]] });
  }

  if (data.length > 0) {
    await sheets.spreadsheets.values.batchUpdate({
      spreadsheetId: SHEET_IDS.INVENTAIRE,
      requestBody  : { valueInputOption: 'RAW', data },
    });
  }

  // Application du delta de stock (+création auto si pièce absente)
  let createdPiece: PieceAutoCreated | undefined;
  if (itemContext) {
    try {
      createdPiece = await _applyStockDelta(itemContext, stockDelta);
    } catch (err: any) {
      console.warn(`[po] applyStockDelta "${itemContext.nom}" échoué :`, err?.message ?? err);
    }
  }

  await cache.del(CACHE_KEYS.POS);
  if (stockDelta !== 0) await cache.del(CACHE_KEYS.PIECES);

  return { stockDelta, createdPiece };
}

/**
 * Applique les qteRecue courantes d'un PO au stock du catalogue — one-shot.
 * Utilisé pour réparer un PO dont les reçus ont été cochés avant l'auto-sync
 * temps réel (v5.14.0). Idempotent du côté auto-création mais PAS du côté
 * stock : chaque appel ADD qteRecue au stock courant.
 *
 * v1.1.3 — Item 2 audit : l'idempotence est désormais protégée par la
 * colonne `stockSyncedAt` (col P). La route `/api/po/[id]/sync-stock`
 * refuse le 2e appel sauf `force=true`. Cette fonction ne fait QUE
 * appliquer le delta ; le marquage est fait par le caller via
 * `markPOStockSynced`.
 */
export async function syncStockForPO(
  poNumber: string,
): Promise<{ applied: number; createdPieces: PieceAutoCreated[]; totalDelta: number }> {
  const po = await getPO(poNumber);
  if (!po) throw new Error(`PO ${poNumber} introuvable`);

  const createdPieces: PieceAutoCreated[] = [];
  let applied = 0;
  let totalDelta = 0;

  for (const item of po.items) {
    if (!item.qteRecue || item.qteRecue <= 0) continue;
    const ctx = {
      fournisseur : po.fournisseur,
      nom         : item.nom,
      sku         : item.sku,
      qteCommandee: item.qteCommandee,
      prixAchat   : item.prixAchat,
      pieceId     : item.pieceId,
      categorie   : item.categorie || '',
      newQteRecue : item.qteRecue,
    };
    try {
      const created = await _applyStockDelta(ctx, item.qteRecue);
      if (created) createdPieces.push(created);
      applied++;
      totalDelta += item.qteRecue;
    } catch (err: any) {
      console.warn(`[po] syncStockForPO "${item.nom}" échoué :`, err?.message ?? err);
    }
  }

  await cache.del(CACHE_KEYS.PIECES);
  return { applied, createdPieces, totalDelta };
}

/**
 * Applique un delta de stock à une pièce du catalogue. Si la pièce n'existe
 * pas (pas de match par pieceId/sku/nom/nom-tolérant), la crée d'abord via
 * addPieceToCatalogue avec les infos du PO.
 * Retourne la pièce créée (si création), sinon undefined.
 */
async function _applyStockDelta(
  ctx: { fournisseur: string; nom: string; sku: string; qteCommandee: number; prixAchat: number; pieceId: string; categorie: string; newQteRecue: number },
  delta: number,
): Promise<PieceAutoCreated | undefined> {
  const sheets = getSheetsClient();

  // Charger les maps de résolution (pieceId/sku/nom + nom tolérant)
  const [idLookupRes, lookupRes] = await Promise.all([
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.PIECES,
      range            : `${TAB.PIECES_TAB}!A2:A`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.PIECES,
      range            : `${TAB.PIECES_TAB}!D2:S`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
  ]);
  const idRows = idLookupRes.data.values ?? [];
  const lookupRows = lookupRes.data.values ?? [];

  let resolvedRow = 0;
  let matched: string | null = null;
  for (let i = 0; i < Math.max(idRows.length, lookupRows.length); i++) {
    const row = i + 2;
    const pid = String(idRows[i]?.[0] ?? '').trim();
    const nom = String(lookupRows[i]?.[0] ?? '').trim();
    const sku = String(lookupRows[i]?.[15] ?? '').trim();
    if (ctx.pieceId && pid === ctx.pieceId) { resolvedRow = row; matched = 'pieceId'; break; }
    if (ctx.sku && sku === ctx.sku)         { if (!resolvedRow) { resolvedRow = row; matched = 'sku'; } }
    if (nom === ctx.nom)                    { if (!resolvedRow) { resolvedRow = row; matched = 'nom'; } }
  }
  // Fallback : nom tolérant
  if (!resolvedRow) {
    const target = normSearch(ctx.nom);
    for (let i = 0; i < lookupRows.length; i++) {
      const nom = String(lookupRows[i]?.[0] ?? '').trim();
      if (nom && normSearch(nom) === target) { resolvedRow = i + 2; matched = 'nom-tolérant'; break; }
    }
  }

  let createdPiece: PieceAutoCreated | undefined;

  // Aucune pièce trouvée → auto-création
  if (!resolvedRow) {
    const { addPieceToCatalogue } = await import('./catalogue');
    const created = await addPieceToCatalogue({
      nom         : ctx.nom,
      categorie   : ctx.categorie || '',
      qte         : 0,
      prix        : ctx.prixAchat,
      fournisseur : ctx.fournisseur,
      sku         : ctx.sku || '',
    });
    resolvedRow = created.row;
    createdPiece = { nom: ctx.nom, pieceId: created.pieceId };
  }

  // Lecture stock actuel + application du delta (col AB post-insertion T=codeBarre)
  const stockRes = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.PIECES,
    range            : `${TAB.PIECES_TAB}!AB${resolvedRow}`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const currentStock = parseFloat(String(stockRes.data.values?.[0]?.[0] ?? '0')) || 0;
  const newStock = Math.max(0, currentStock + delta);

  // Flag : '@' si reçu complet, '#' si partiel, '$' si aucune qté reçue
  const flag = ctx.newQteRecue === 0 ? '$'
             : ctx.newQteRecue >= ctx.qteCommandee ? '@' : '#';

  const updates: { range: string; values: unknown[][] }[] = [
    { range: `${TAB.PIECES_TAB}!AB${resolvedRow}`, values: [[newStock]] },
    { range: `${TAB.PIECES_TAB}!B${resolvedRow}`,  values: [[flag]] },
  ];
  // Prix d'achat (col K/L/M selon fournisseur)
  if (ctx.prixAchat > 0) {
    const fournNorm = ctx.fournisseur.toLowerCase();
    const prixCol = fournNorm === 'babac' ? 'K' : fournNorm === 'hlc' ? 'M' : 'L';
    updates.push({ range: `${TAB.PIECES_TAB}!${prixCol}${resolvedRow}`, values: [[ctx.prixAchat]] });
  }

  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.PIECES,
    requestBody  : { valueInputOption: 'RAW', data: updates },
  });

  console.log(`[po] Stock ${matched || 'créé'} "${ctx.nom}" : ${currentStock} → ${newStock} (delta ${delta >= 0 ? '+' : ''}${delta})`);
  return createdPiece;
}

// ── Suppression ligne ───────────────────────────────────────────

export async function deletePOLine(sheetRow: number): Promise<void> {
  const sheets = getSheetsClient();
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const sh = meta.data.sheets?.find(s => s.properties?.title === TAB.PO);
  if (!sh?.properties?.sheetId && sh?.properties?.sheetId !== 0) return;

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        deleteDimension: {
          range: {
            sheetId   : sh.properties.sheetId!,
            dimension : 'ROWS',
            startIndex: sheetRow - 1,
            endIndex  : sheetRow,
          },
        },
      }],
    },
  });
  await cache.del(CACHE_KEYS.POS);
}

// ── Finalisation ────────────────────────────────────────────────

/**
 * Finalise la réception d'un PO :
 * 1. Met à jour le statut (RECU ou PARTIEL)
 * 2. Écrit la date de réception
 * 3. Met à jour le stock (col AA) dans le sheet PIÈCES pour chaque item reçu
 * 4. Met à jour le flag catalogue (col B) : '@' si reçu, laisse inchangé sinon
 * 5. Met à jour les BDC actifs : pièces correspondantes '$' → '@'
 */
export interface PieceAutoCreated { nom: string; pieceId: string }

export async function finalizePO(poNumber: string): Promise<{
  received: number;
  notReceived: number;
  stockUpdates: { nom: string; delta: number }[];
  missing: { nom: string; sku: string; cmd: number; recu: number; manquant: number }[];
  createdPieces: PieceAutoCreated[];
}> {
  // Forcer lecture fraîche du PO (éviter données périmées du cache)
  await cache.del(CACHE_KEYS.POS);
  const po = await getPO(poNumber);
  if (!po) throw new Error(`PO ${poNumber} introuvable`);

  const sheets = getSheetsClient();
  const today = new Date().toISOString().slice(0, 10);

  // Classifier les items
  const fullyReceived: { item: typeof po.items[0]; poRow: number }[] = [];
  const partialItems:  { item: typeof po.items[0]; poRow: number }[] = [];
  const notReceived:   { item: typeof po.items[0]; poRow: number }[] = [];

  for (let i = 0; i < po.items.length; i++) {
    const it = po.items[i];
    const poRow = po._rows[i];
    if (it.qteRecue >= it.qteCommandee) fullyReceived.push({ item: it, poRow });
    else if (it.qteRecue > 0) partialItems.push({ item: it, poRow });
    else notReceived.push({ item: it, poRow });
  }

  const hasRemaining = partialItems.length > 0 || notReceived.length > 0;
  const newStatus: POStatus =
    (fullyReceived.length === 0 && partialItems.length === 0) ? 'ANNULE' :
    hasRemaining ? 'PARTIEL' : 'RECU';

  // 1. Mettre à jour le PO dans le sheet _PO_
  const poUpdates: { range: string; values: unknown[][] }[] = [];

  // Mettre à jour chaque item du PO selon son état
  for (const { item, poRow } of partialItems) {
    // Partiel : cmd ← restant, reçu ← 0 (reset pour prochain cycle)
    const remaining = item.qteCommandee - item.qteRecue;
    poUpdates.push(
      { range: `${TAB.PO}!H${poRow}`, values: [[remaining]] },   // cmd ← restant
      { range: `${TAB.PO}!I${poRow}`, values: [[0]] },            // reçu ← 0
      { range: `${TAB.PO}!K${poRow}`, values: [[false]] },        // checkbox ← false
    );
  }

  for (const { item, poRow } of fullyReceived) {
    const isSurplus = item.qteRecue > item.qteCommandee;
    const surplusQte = item.qteRecue - item.qteCommandee;
    // Conserver les valeurs originales pour l'historique
    poUpdates.push(
      { range: `${TAB.PO}!H${poRow}`, values: [[item.qteCommandee]] }, // cmd ← garde original
      { range: `${TAB.PO}!I${poRow}`, values: [[item.qteRecue]] },     // reçu ← garde total reçu
      { range: `${TAB.PO}!K${poRow}`, values: [[true]] },              // checkbox ← true
    );
    if (isSurplus) {
      poUpdates.push(
        { range: `${TAB.PO}!M${poRow}`, values: [[`surplus +${surplusQte}`]] },
      );
    }
  }

  // Statut + date sur toutes les lignes
  for (const row of po._rows) {
    poUpdates.push(
      { range: `${TAB.PO}!E${row}`, values: [[newStatus]] },
    );
    if (newStatus === 'RECU') {
      poUpdates.push({ range: `${TAB.PO}!D${row}`, values: [[today]] });
    }
  }

  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : { valueInputOption: 'RAW', data: poUpdates },
  });

  // 2. Mettre à jour le stock dans PIÈCES pour tous les items avec qteRecue > 0
  const allWithReceipt = [...fullyReceived, ...partialItems];
  const stockUpdates: { nom: string; delta: number }[] = [];
  const pieceUpdates: { range: string; values: unknown[][] }[] = [];

  // Charger pieceId (col A), nom (col D) et SKU (col S) pour résoudre les bonnes lignes
  const [idLookupRes, lookupRes] = await Promise.all([
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.PIECES,
      range            : `${TAB.PIECES_TAB}!A2:A`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.PIECES,
      range            : `${TAB.PIECES_TAB}!D2:S`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
  ]);
  const idRows = idLookupRes.data.values ?? [];
  const lookupRows = lookupRes.data.values ?? [];

  const pieceIdToRow = new Map<string, number>();
  const skuToRow = new Map<string, number>();
  const nomToRow = new Map<string, number>();
  const normNomToRow = new Map<string, number>(); // nom normalisé (accents/casse) → row
  for (let i = 0; i < Math.max(idRows.length, lookupRows.length); i++) {
    const row = i + 2;
    const pid = String(idRows[i]?.[0] ?? '').trim();
    const nom = String(lookupRows[i]?.[0] ?? '').trim();
    const sku = String(lookupRows[i]?.[15] ?? '').trim();
    if (pid) pieceIdToRow.set(pid, row);
    if (sku) skuToRow.set(sku, row);
    if (nom) nomToRow.set(nom, row);
    if (nom) {
      const key = normSearch(nom);
      if (key && !normNomToRow.has(key)) normNomToRow.set(key, row);
    }
  }

  // Pour auto-créer des pièces sans dupliquer addPieceToCatalogue import circulaire,
  // on l'importe dynamiquement. Le flag '@' sera mis juste après par pieceUpdates.
  const { addPieceToCatalogue } = await import('./catalogue');
  const createdPieces: { nom: string; pieceId: string }[] = [];
  // v1.0.10+ : tracker les pièces fraîchement créées DANS ce finalize. Pour
  // celles-ci, on doit appliquer le stock (le delta n'a pas été appliqué via
  // updateLine temps réel car la pièce n'existait pas). Pour les pièces déjà
  // existantes, le stock est DÉJÀ à jour grâce à updateLine — ne PAS
  // re-appliquer (sinon double comptage : bug HLC reporté par utilisateur).
  const justCreatedRows = new Set<number>();

  for (const { item } of allWithReceipt) {
    // Résolution : pieceId exact → sku exact → nom exact → nom tolérant (accents/casse)
    let resolvedRow = (item.pieceId && pieceIdToRow.get(item.pieceId))
      || (item.sku && skuToRow.get(item.sku))
      || nomToRow.get(item.nom)
      || (item.nom && normNomToRow.get(normSearch(item.nom)))
      || 0;

    // Aucune ligne PIÈCES trouvée → auto-création (évite que les items du PO
    // disparaissent silencieusement du stock). La pièce est créée avec son
    // stock = qteRecue et flag '@'. Catégorie vide → template fallback.
    if (!resolvedRow || resolvedRow <= 0) {
      try {
        const created = await addPieceToCatalogue({
          nom         : item.nom,
          categorie   : item.categorie || '',  // catégorie choisie dans Réception
          qte         : 0,                     // pas de qté à commander
          prix        : item.prixAchat,
          fournisseur : po.fournisseur,
          sku         : item.sku || '',
        });
        resolvedRow = created.row;
        justCreatedRows.add(created.row);  // track pour appliquer le stock
        createdPieces.push({ nom: item.nom, pieceId: created.pieceId });
        // Mettre à jour les maps pour éviter de re-créer si même item apparaît 2x
        if (created.pieceId) pieceIdToRow.set(created.pieceId, created.row);
        if (item.sku)         skuToRow.set(item.sku, created.row);
        nomToRow.set(item.nom, created.row);
        const key = normSearch(item.nom);
        if (key) normNomToRow.set(key, created.row);
      } catch (err: any) {
        console.warn(`[po] Création auto pièce "${item.nom}" échouée :`, err?.message ?? err);
        continue;
      }
    }

    // Flag : @ si reçu exact, # si partiel ou surplus
    const flag = item.qteRecue === item.qteCommandee ? '@' : '#';
    const surplusQte = item.qteRecue > item.qteCommandee ? item.qteRecue - item.qteCommandee : 0;

    // v1.0.10+ : update stock SEULEMENT si pièce nouvellement créée. Sinon
    // le delta a déjà été appliqué temps réel par updateLine à chaque toggle
    // dans la page /reception. Re-appliquer ici causait un DOUBLE comptage.
    if (justCreatedRows.has(resolvedRow)) {
      // Lire le stock actuel (=0 puisque créée à l'instant) puis ajouter qteRecue
      const stockReadRes = await sheets.spreadsheets.values.get({
        spreadsheetId    : SHEET_IDS.PIECES,
        range            : `${TAB.PIECES_TAB}!AB${resolvedRow}`,
        valueRenderOption: 'UNFORMATTED_VALUE',
      });
      const currentStock = parseFloat(String(stockReadRes.data.values?.[0]?.[0] ?? '0')) || 0;
      pieceUpdates.push(
        { range: `${TAB.PIECES_TAB}!AB${resolvedRow}`, values: [[currentStock + item.qteRecue]] },
      );
    }

    pieceUpdates.push(
      { range: `${TAB.PIECES_TAB}!B${resolvedRow}`,  values: [[flag]] },
    );

    // Mettre à jour le prix d'achat dans la colonne du fournisseur (Babac→K, HLC→M, autres→L)
    if (item.prixAchat > 0) {
      const fournNorm = po.fournisseur.toLowerCase();
      const prixCol = fournNorm === 'babac' ? 'K'
                    : fournNorm === 'hlc'   ? 'M'
                    : 'L';
      pieceUpdates.push({ range: `${TAB.PIECES_TAB}!${prixCol}${resolvedRow}`, values: [[item.prixAchat]] });
    }
    // Écrire le surplus dans col AD si > 0 (v6.4.0 : AC réquisitionnée pour qté réservée).
    if (surplusQte > 0) {
      pieceUpdates.push({ range: `${TAB.PIECES_TAB}!AD${resolvedRow}`, values: [[surplusQte]] });
    }
    // Reset qteACommander seulement si 100% reçu ou surplus (col W post-décalage)
    if (item.qteRecue >= item.qteCommandee) {
      pieceUpdates.push({ range: `${TAB.PIECES_TAB}!W${resolvedRow}`, values: [[0]] });
    } else {
      // Partiel : qteACommander ← restant
      pieceUpdates.push({ range: `${TAB.PIECES_TAB}!W${resolvedRow}`, values: [[item.qteCommandee - item.qteRecue]] });
    }
    stockUpdates.push({ nom: item.nom, delta: item.qteRecue });
  }

  if (pieceUpdates.length > 0) {
    await sheets.spreadsheets.values.batchUpdate({
      spreadsheetId: SHEET_IDS.PIECES,
      requestBody  : { valueInputOption: 'RAW', data: pieceUpdates },
    });
  }

  // 3. Mettre à jour les BDC actifs : pièces '$' → '@' pour les items reçus.
  //    v1.1.5+ : matching par pieceKey (privilégie pieceId, fallback nom)
  //    pour survivre aux renames de pièces catalogue.
  try {
    const { getBDCs } = await import('./bdc');
    const bdcs = await getBDCs(true);
    const receivedKeys = new Set(
      allWithReceipt.map(({ item }) => pieceKey({ pieceId: item.pieceId, nom: item.nom })),
    );
    const bdcUpdates: { range: string; values: unknown[][] }[] = [];

    for (const bdc of bdcs) {
      for (const bdcItem of bdc.items) {
        if (bdcItem.piece && bdcItem.piece.cmd === '$' && receivedKeys.has(pieceKey(bdcItem.piece))) {
          bdcUpdates.push({
            range : `${TAB.BDC}!R${bdcItem._row}`,
            values: [['@']],
          });
        }
      }
    }

    if (bdcUpdates.length > 0) {
      await sheets.spreadsheets.values.batchUpdate({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        requestBody  : { valueInputOption: 'RAW', data: bdcUpdates },
      });
    }
  } catch (err: any) {
    console.warn('[po] BDC sync failed:', err.message);
  }

  // Invalider les caches
  await cache.del(CACHE_KEYS.POS);
  await cache.del(CACHE_KEYS.PIECES);
  await cache.del(CACHE_KEYS.BDCS);

  // Rapport des items manquants
  const missing = [
    ...partialItems.map(({ item }) => ({ nom: item.nom, sku: item.sku, cmd: item.qteCommandee, recu: item.qteRecue, manquant: item.qteCommandee - item.qteRecue })),
    ...notReceived.map(({ item }) => ({ nom: item.nom, sku: item.sku, cmd: item.qteCommandee, recu: 0, manquant: item.qteCommandee })),
  ];

  return { received: allWithReceipt.length, notReceived: notReceived.length, stockUpdates, missing, createdPieces };
}

// ── Réouverture ────────────────────────────────────────────────

export async function reopenPO(poNumber: string): Promise<void> {
  const po = await getPO(poNumber);
  if (!po) throw new Error(`PO ${poNumber} introuvable`);

  const sheets = getSheetsClient();
  const data: { range: string; values: unknown[][] }[] = [];

  for (const row of po._rows) {
    data.push(
      { range: `${TAB.PO}!D${row}`, values: [['']] },          // clear dateReception
      { range: `${TAB.PO}!E${row}`, values: [['EN ATTENTE']] }, // reset status
    );
  }

  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : { valueInputOption: 'RAW', data },
  });

  await cache.del(CACHE_KEYS.POS);
}

// ── Helpers ─────────────────────────────────────────────────────

async function _ensureTab(): Promise<void> {
  const sheets = getSheetsClient();
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const existing = (meta.data.sheets ?? []).find(
    s => s.properties?.title === TAB.PO,
  );
  const needCols = PO_NB_COLS; // 16 — incl. stockSyncedAt (col P, v1.1.3)
  const headerRange = `${TAB.PO}!A1:${PO_LAST_COL}1`;

  // Tab existe déjà : vérifier qu'il a assez de colonnes, sinon l'étendre
  if (existing) {
    const sheetId = existing.properties?.sheetId;
    const cur     = existing.properties?.gridProperties?.columnCount ?? 0;
    if (sheetId !== undefined && cur < needCols) {
      await sheets.spreadsheets.batchUpdate({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        requestBody  : {
          requests: [{
            updateSheetProperties: {
              properties: {
                sheetId,
                gridProperties: { columnCount: needCols },
              },
              fields: 'gridProperties.columnCount',
            },
          }],
        },
      });
      // Écrire/mettre à jour la ligne d'en-tête pour les colonnes ajoutées
      await sheets.spreadsheets.values.update({
        spreadsheetId   : SHEET_IDS.INVENTAIRE,
        range           : headerRange,
        valueInputOption: 'RAW',
        requestBody     : { values: [PO_HEADERS] },
      });
    }
    return;
  }

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        addSheet: {
          properties: {
            title: TAB.PO,
            gridProperties: { rowCount: 2000, columnCount: needCols },
          },
        },
      }],
    },
  });

  await sheets.spreadsheets.values.update({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : headerRange,
    valueInputOption: 'RAW',
    requestBody     : { values: [PO_HEADERS] },
  });
}

/**
 * v1.1.3 — Item 2 : marque le PO comme stock-synced sur la 1ʳᵉ ligne
 * (col P = stockSyncedAt). Empêche un 2e appel à `/sync-stock` de doubler
 * le stock du catalogue.
 *
 * Retourne `true` si la valeur a été écrite, `false` si le PO était
 * introuvable. Le caller doit valider avant que `stockSyncedAt` était
 * vide (sinon idempotence cassée — c'est la responsabilité de la route).
 */
export async function markPOStockSynced(
  poNumber: string,
  isoTs: string = new Date().toISOString(),
): Promise<boolean> {
  await _ensureTab();
  const po = await getPO(poNumber);
  if (!po || po._rows.length === 0) return false;

  const sheets = getSheetsClient();
  const firstRow = po._rows[0];
  await sheets.spreadsheets.values.update({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.PO}!${PO_LAST_COL}${firstRow}`,
    valueInputOption: 'RAW',
    requestBody     : { values: [[isoTs]] },
  });
  await cache.del(CACHE_KEYS.POS);
  return true;
}
