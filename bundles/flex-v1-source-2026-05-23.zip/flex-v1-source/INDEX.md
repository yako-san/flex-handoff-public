# INDEX — flex-v1-source (2026-05-23)

> Bundle V1 source actualisé. HEAD `aa07cf9` (PR #18 merged — v1.3.1 +
> tous clusters 1-10 + cluster suite).
> Précédent bundle : 2026-05-20 (avant 8 PRs supplémentaires).

---

## 1. Version V1 figée

| Champ | Valeur |
|---|---|
| Repo | `yako-san/flex-rev-app` (privé) |
| HEAD bundle | `aa07cf9` (2026-05-23) |
| APP_VERSION | `v1.3.1` (constante dans `components/layout/AppShell.tsx`) |
| Stack | Next.js 14.2.29 + TypeScript strict + Google Sheets API v4 + NextAuth v5 beta |

## 2. Changements depuis le bundle précédent (2026-05-20)

PRs #10-#18 mergées :
- **Cluster 6** : tri PO desc, ÉVAL jaune top, TTC display, retire CC factures
- **Cluster 7** : Cost éditable vente brouillon (`setVenteCost` + recompute prixUnit)
- **Cluster 8** : Dashboard bloc "en commande", tri à facturer top, pills statut factures
- **Cluster 9** : qté commande inline éditable, qteSac col F, PO displayName col Q
- **Cluster 10** : inventaire fond noir 20%, fenêtre suivi 1-14j, scan picker existant
- Service durée=0 → "gratuit" italique grisé
- PieceForm `onSelectExisting` callback
- Vente HT + TTC card display
- Bouton Facturer retiré de Nouvelle vente

Voir `docs/v2-handoff/CHANGES-CLUSTER-SESSION-2026-05-16.md` côté repo
v1 privé (ou la copie publique `docs/handoff/` côté `yako-san/flex`).

---

## 3. CIBLE PORT IMMÉDIAT : page BDT détail

### Fichier principal

`app/inventaire/[id]/page.tsx` — page server component qui charge le BDT
via `getBDC()` + le client + le vélo, puis passe les props aux composants
client.

### Composants UI (tous dans `components/bdc/`)

| Fichier | Rôle |
|---|---|
| **`BDCHeader.tsx`** | Header sticky en haut de la page : numéro BDT, client, vélo, statut, evalStatus, mécanos assignés |
| **`BDCPanel.tsx`** ⭐ | **LE composant central** — table services (gauche) + table pièces (droite), gestion items, totaux, remises, avance |
| **`BDCItemRow.tsx`** | Ligne d'item (utilisé dans le rendu du PDF/preview) |
| **`BDCTotaux.tsx`** | Bloc total bas : Services + Pièces = HT — avance? — total facture TTC. Modal d'édition de l'avance. |
| **`PiecesPopup.tsx`** | Modal ajout pièces (search + filtre catégorie + cocher + qté + draft localStorage) |
| **`ServicesPopup.tsx`** | Modal ajout services (idem pour SERVICES À LA CARTE) |
| **`ArchiveChoiceDialog.tsx`** | Dialog 4 boutons paiement+archive (Comptant/Interac/Cartes/Refusé) |
| **`FactureStatusPanel.tsx`** | Statut facture post-émission (PAYÉ/ÉMIS/ANNULÉ + mode paiement) |
| **`CheckboxAction.tsx`** | Pattern customConfirm via modal (envoyer éval, sortir BDT, etc.) |
| **`VeloHistory.tsx`** | Historique BDT du vélo (BDT précédents archivés) |

### Hook + API + Data

| Fichier | Rôle |
|---|---|
| **`hooks/useBDC.ts`** | Hook SWR — `addItems`, `deleteItem`, `patchItem`, `setRemise`, `setAvance`, etc. Optimistic UI partout. |
| **`hooks/useBDCs.ts`** | Liste tous les BDT (pour inventaire) |
| **`app/api/bdc/[id]/route.ts`** | GET BDT (rare — la liste suffit) ; PATCH (statut, mecano, noteClient, etc.) |
| **`app/api/bdc/[id]/items/route.ts`** ⭐ | POST add items (services OU pièces) ; DELETE item ; PATCH item |
| **`app/api/bdc/[id]/remises/route.ts`** | PATCH remises (services + pièces, % ou $) |
| **`app/api/bdc/[id]/avance/route.ts`** | PATCH avance (montant, mode, note) |
| **`app/api/bdc/[id]/evaluation/route.ts`** | PATCH evalStatus (APPROUVE/REDUX/ATTENTE/REFUSE) + checkEval |
| **`app/api/bdc/[id]/facturer/route.ts`** | POST émettre facture PDF + Gmail draft + write factureNumero/Date |
| **`app/api/bdc/[id]/archiver/route.ts`** | POST archiver le BDT (FACTURÉ/LIVRÉ/REFUSÉ) |
| **`lib/sheets/bdc.ts`** ⭐ | Couche data : `getBDC`, `insertPieces`, `insertServices`, `patchBDCItem`, `patchBDCItemFields`, `_recalcTotaux` |
| **`lib/sheets/bdc-filters.ts`** | `filterServiceItems` (exclut séparateurs forfait) |
| **`lib/sheets/reservation.ts`** ⭐ | Modèle stock invariant — `snapshotStock`, `safeRecomputeStockState`, `_computeFromSource` |
| **`types/bdc.ts`** | `BDC`, `BDCItem`, `BDCPieceItem`, `BDCServiceItem`, `AddPieceInput`, `AddServiceInput`, `AddItemsPayload` |

### Helpers transversaux

| Fichier | Rôle |
|---|---|
| **`lib/utils/pieces.ts`** | `pceNomClean`, `stripIconPrefix`, `pieceKey()` (cluster 1) |
| **`lib/utils/format.ts`** | `frPrix(n)` formatage CAD, `normSearch(s)`, parsing dates |
| **`lib/utils/statuts.ts`** | `STATUTS`, `STATUTS_ORDER`, `CMD_OPTIONS`, `nextStatusOnAssign`, `OPQ_COLORS` |
| **`lib/finances/taxes.ts`** | `computeTaxes(sousTotal)` — Québec TPS 5%, TVQ 9.975% |

---

## 4. Invariants métier BDT (critiques pour le port V2)

### Structure du BDT dans la sheet

Une BDT est une **séquence de lignes dans l'onglet `BONS DE COMMANDES`** :

```
BON  ← row d'en-tête (ID, dates, checkboxes, vélo, evalStatus col J)
GAP  ← row client (col H = nomComplet, col V noteClient EVAL, col W noteClient FACTURE)
SEP0 ← row vide séparateur
ITEM ← rows services + pièces (dynamique, ajoutés/supprimés à la volée)
ITEM
...
BTN  ← row boutons "Ajouter" (K = services, P = pièces)
TOT  ← row totaux (col N = totalServices, col T = totalPieces)
SEP  ← row séparation
```

`getBDC()` dénormalise en `BDC { id, dateIn, clientNom, veloDesc, items[], totalServices, totalPieces, … }`.

### Remises (col I ligne BON, format JSON)

Stockées sur la ligne BON :
- `remiseSvc?: { type: 'pct' | 'fixed'; value: number }`
- `remisePce?: { type: 'pct' | 'fixed'; value: number }`

Appliquées **avant** taxes. Une remise pour services, une autre pour pièces.

### Avance (col I ligne BON, JSON v1.0.17+)

```ts
avance?: {
  montant: number;
  mode?: 'comptant' | 'interac' | 'cartes';
  note?: string;
}
```

Déduite du **reste à payer** (post-taxes) sans toucher au total HT.
Affichée comme lien souligné "avance ?" cliquable → modal d'édition.

### evalStatus (col J ligne BON)

5 états : `''` | `'APPROUVE'` | `'REDUX'` | `'ATTENTE'` | `'REFUSE'`.
Distinct de `velo.status`. Backwards-compat : si vide ET `checkOk=true` → APPROUVE.

### Mécanos (cols N/O/P ARCHIVES + INVENTAIRE)

- `evalMecano` (col N) : qui a fait l'éval
- `mecaMecano` (col O) : qui fait la mécanique
- `ctrlMecano` (col P) : qui fait le contrôle qualité

Assigner un mécano à `eval` peut **auto-transitionner** le `velo.status`
(RV/REÇU → ÉVAL.). Idem pour `meca` (→ ON BENCH) et `ctrl` (→ CTRL QLTÉ).
Logique dans `nextStatusOnAssign()` (`lib/utils/statuts.ts`).

### Stock réservé v7.0.0+ (cols AB/AC du sheet PIÈCES)

- `stockPhysique` (col AB) — quantité physique
- `stockReserve` (col AC) — quantité réservée par BDT actifs (`RESERVED_STATUSES = APPROUVÉ, ON BENCH, CTRL QLTÉ, FINI, LIVRÉ`)

À chaque mutation BDT (items, status), appeler `safeRecomputeStockState`
qui recalcule `stockReserve` from-source. Modèle "invariant engagement" —
voir `lib/sheets/reservation.ts` pour le détail.

### pieceId stable v1.1.5+ (cluster 1)

Items pièces du BDT stockent `pieceId` en **col O** de BONS DE COMMANDES,
en plus du nom (col P). Lookup catalogue : helper `pieceKey()` privilégie
`pieceId` (stable), fallback nom normalisé. Survit aux renames de pièces.

### Service "gratuit" (durée=0 → prix=0)

Un service avec `prix === 0` reste dans le BDT, affiché "gratuit" italique
grisé au lieu de "0,00 $". Permet de baisser la durée à 0:00 via les
chevrons ▲▼ pour offrir un service sans le supprimer.

### Format bloc total BDT (refondu v1.3.x)

Pattern : `Services X + Pièces Y = (X+Y) HT — avance? — total facture TTC$`
- Gauche : décomposition + lien "avance ?" (modal d'édition)
- Droite : "total facture" + montant TTC en gros jaune (`#fff056`)
- Si avance : "reste à payer" + montant TTC barré + reste

### Transitions de statut critiques

- `RV/REÇU` → `ÉVAL.` (mécano éval assigné)
- `ÉVAL.` → `EN ATTENTE` (evalStatus = ATTENTE/REDUX)
- `ÉVAL.` → `APPROUVÉ` (evalStatus = APPROUVE)
- `ÉVAL.` → **archive REFUSÉ** (evalStatus = REFUSE + bouton archiver)
- `APPROUVÉ` → `ON BENCH` (mécano méca assigné)
- `ON BENCH` → `CTRL QLTÉ` (mécano ctrl assigné)
- `CTRL QLTÉ` → `FINI` (manuel)
- `FINI` → `FACTURER` (manuel) → `FACTURÉ` (facturation émise) → archive `FACTURÉ`/`LIVRÉ`

### Workflow checkboxes (cols D/E/F/G ligne BON)

- `checkEval` (col D) — évaluation envoyée au client
- `checkOk` (col E) — OK (legacy, backwards-compat)
- `checkBds` (col F) — bon de sortie envoyé
- `checkOut` (col G) — vélo sorti

Activer une checkbox déclenche `setCheckEval` / `setCheckBds` / `setCheckOut`
qui peut déclencher des transitions auto.

---

## 5. Patron suggéré pour le port V2

### Phase A — Modèle Prisma (foundation backend)

V2 a déjà :
- `Bdc` (= BDT)
- `BdcItem` (= service OU pièce)
- `Velo`, `Client`, `Piece`, `Service`

Vérifie :
- Champ `Bdc.remiseSvc`/`remisePce` JSON
- Champ `Bdc.avance` JSON
- Champ `Bdc.evalStatus` enum
- `BdcItem.pieceId` FK (cluster 1 V1) — déjà mappé en V2 si import est passé

### Phase B — Page `[id]/page.tsx` server component

Charge en parallèle : `bdc`, `client`, `velo`, `services`, `pieces` (catalogue).
Passe aux composants client.

### Phase C — Composants UI clients

Ordre suggéré :
1. **`<BDCHeader>`** — sticky top, statique
2. **`<BDCPanel>`** — le gros morceau, 2 colonnes services + pièces
3. **`<BDCTotaux>`** — bloc bas, format HT/TTC + avance
4. **`<PiecesPopup>` + `<ServicesPopup>`** — modals d'ajout
5. **`<ArchiveChoiceDialog>`** — dialog 4 boutons paiement+archive
6. **`<FactureStatusPanel>`** — statut post-facture
7. **`<VeloHistory>`** — historique BDT du vélo

### Phase D — Server actions / API routes

Mapper chaque route V1 vers une server action V2 :
- POST add items → `addBdcItems({ bdcId, type, items })`
- DELETE item → `deleteBdcItem({ bdcId, itemId })`
- PATCH item → `patchBdcItem(...)`
- PATCH remises → `setBdcRemises(...)`
- PATCH avance → `setBdcAvance(...)`
- PATCH evalStatus → `setBdcEvalStatus(...)`
- POST facturer → `facturerBdc(...)` (génère PDF + Gmail draft)
- POST archiver → `archiverBdc(...)`

À chaque mutation : recompute stock (équivalent V2 de `safeRecomputeStockState`).

### Phase E — Tests Vitest

Couvrir au minimum :
- Add piece → stockReserve incrémente
- Set evalStatus REFUSE + archive → stockReserve relâché
- Add service prix=0 → item reste, total inchangé
- Patch item prix → totals recalculés correctement
- Remise pct + fixed → calcul taxes correct (cf `computeTaxes`)

---

## 6. Capture visuelle de référence

Dans le repo public `yako-san/flex` :
- `docs/handoff/comparatif-v1-v2/1b-bon de travail v1.png` — état V1 (cible)
- `docs/handoff/comparatif-v1-v2/1b-bon de travail v2.png` — état V2 actuel

Compare side-by-side pour identifier ce qui manque visuellement.

---

## 7. Sécurité (vérifié au bundling)

✅ Aucun `.env*`, `client_secret_*`, `flex-rev-*.json`
✅ Aucun OAuth token, refresh token, SHEET_ID hardcodé dans le code
✅ Tous secrets via `process.env.*`

---

**Préparé le 2026-05-23** — HEAD `aa07cf9`. Total 292 fichiers, 2.7 MB.
