# FLEX-REV

Application de gestion d'atelier de réparation de vélo — système maison de
Yako Cyclo (Montréal). Le backend est entièrement piloté par Google Sheets
(5 documents) ce qui permet à l'admin de consulter / corriger les données
directement dans Drive sans passer par l'UI.

## Stack

| Couche       | Choix |
|--------------|-------|
| Framework    | Next.js 14 (App Router, TypeScript strict) |
| Storage      | Google Sheets API v4 |
| Auth         | NextAuth v5 + Google OAuth (gmail.compose, drive.file) |
| Cache        | Vercel KV (Upstash Redis) + L1 in-memory (node-cache) |
| Data fetch   | SWR |
| PDF          | @react-pdf/renderer |
| UI           | Tailwind + Headless UI + Heroicons |
| Tests        | Vitest |

## Quickstart

```bash
npm install
cp .env.example .env.local    # remplir les Google Sheet IDs + NextAuth secrets
npm run dev
```

Variables clés (toutes en env, jamais hardcodées) :

| Var                       | Rôle |
|---------------------------|------|
| `SHEETS_INVENTAIRE_ID`    | Document principal (INVENTAIRE, BDC, ARCHIVES, _VENTES_, _DEPENSES_, _PARAMÈTRES_) |
| `SHEETS_PIECES_ID`        | Catalogue PIÈCES (séparé pour mises à jour fournisseur) |
| `SHEETS_ACHATS_ID`        | Catalogue ACHATS |
| `SHEETS_CLIENTS_ID`       | Annuaire CLIENTS |
| `SHEETS_FACTURES_ID`      | Journal comptable factures |
| `KV_REST_API_URL`         | Vercel KV (cache cross-lambda + lock distribué) |
| `NEXTAUTH_SECRET`         | Sessions NextAuth |
| `GOOGLE_CLIENT_ID/SECRET` | OAuth Google |
| `ENABLE_DEV_ENDPOINTS`    | Mettre à `1` pour exposer `/api/admin/test-cycle` & co (sinon 403) |
| `SHEETS_PIECES_DEV_ID`    | (Optionnel) ID du sheet PIÈCES DEV pour le flag `isDev` dans /api/sync |

## Scripts

```bash
npm run dev         # next dev
npm run build       # next build
npm run lint        # next lint
npm run test        # vitest run
```

## Architecture

```
app/                     Routes (App Router)
├── api/                 Endpoints REST (Sheets-backed)
├── inventaire/          Page principale BDT actifs
├── catalogue/           Pièces + Services + Réception PO
├── ventes/              Ventes directes (POS)
├── clients/             Annuaire + photos
├── depenses/            Module fiscal (TPS/TVQ FPZ-500)
└── aide/                Tutoriels mécaniciens
components/              UI partagée
lib/
├── sheets/              CRUD par onglet (clients, bdc, po, ventes, depenses…)
├── auth/                NextAuth + requireAdmin()
├── utils/               Helpers (statuts, format, dates)
├── distributedLock.ts   Verrous KV cross-lambda (compteurs ID/facture)
└── cache.ts             L1 + L2 cache 2-niveaux
types/                   Modèles TypeScript partagés
docs/tutoriels/          Aide mécano + changelog v2 (section 12)
```

## Sécurité (audit v1.1.x)

- `lib/auth/requireAdmin.ts` : helper utilisé sur toutes les routes
  destructives (DELETE clients/bdc/inventaire/po/archives) et tous les
  endpoints `/api/admin/*`. Fail-safe : `yako.cyclo@gmail.com` reste admin
  même si la liste sheet est cassée.
- Lock distribué (`lib/distributedLock.ts`) : Vercel KV SETNX sur les
  compteurs B2 (ID vélo) et B3 (facture vente). Évite les doublons quand
  2 utilisateurs cliquent « Facturer » depuis 2 lambdas différents.
- Idempotence : `/api/po/[id]/sync-stock` refuse le 2e appel via col P
  `stockSyncedAt` (409 ALREADY_SYNCED, force=true pour rattraper).
- Endpoints dev (`test-cycle`, `test-stock`, `restore-bdc`) gardés par
  `requireAdmin()` ET `ENABLE_DEV_ENDPOINTS=1`.

## Convention de version

`components/layout/AppShell.tsx` exporte `APP_VERSION` — bump à chaque
release. Affiché dans le footer de la sidebar. Les commits portent le
même n° (`feat(v1.1.x):` / `sec(v1.1.x):` / `refactor(v1.1.x):`…).

Sprint en cours : voir `docs/tutoriels/12-changements-v2.md` (changelog
vivant pour synchronisation vers le repo v2 SaaS multi-tenant `flex`).
