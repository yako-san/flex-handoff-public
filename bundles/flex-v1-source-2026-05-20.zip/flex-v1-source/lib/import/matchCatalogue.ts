/**
 * Match les items importés avec le catalogue PIÈCES.
 * Résolution : SKU exact → nom fuzzy → non matché.
 */
import type { Piece } from '@/types/catalogue';
import type { ColumnMap } from './parseFile';

export interface MatchedItem {
  /** Données brutes de la ligne importée */
  raw: unknown[];
  /** Valeurs extraites selon le columnMap */
  sku: string;
  description: string;
  qty: number;
  price: number;
  /** Format / variation extrait depuis le fichier (col Format/Variation/Size…) */
  format: string;
  /** Code-barre EAN/UPC/GTIN extrait depuis le fichier (écrit en col T du sheet) */
  barcode: string;
  /** Pièce matchée dans le catalogue (null si non trouvée) */
  piece: Piece | null;
  /** Type de match */
  matchType: 'barcode' | 'sku' | 'nom' | 'none';
}

/**
 * Normalise une chaîne pour la comparaison fuzzy :
 * minuscule, sans accents, sans ponctuation superflue.
 */
function norm(s: string): string {
  return s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[,\-–—()]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Match un tableau de lignes importées avec le catalogue PIÈCES.
 */
export function matchItems(
  rows: unknown[][],
  columnMap: ColumnMap,
  pieces: Piece[],
): MatchedItem[] {
  // Index rapide par SKU
  const skuIndex = new Map<string, Piece>();
  for (const p of pieces) {
    if (p.sku) skuIndex.set(p.sku.trim().toLowerCase(), p);
  }

  // Index rapide par code-barre (EAN/UPC)
  const barcodeIndex = new Map<string, Piece>();
  for (const p of pieces) {
    if (p.codeBarre) barcodeIndex.set(p.codeBarre.trim(), p);
  }

  // Index par nom normalisé (pour fuzzy)
  const nomIndex = new Map<string, Piece>();
  for (const p of pieces) {
    if (p.nom && p.nom !== 'Nom ITEM' && !p.nom.startsWith('FIN DE')) {
      nomIndex.set(norm(p.nom), p);
    }
  }

  return rows.map(row => {
    const sku = columnMap.sku !== null ? String(row[columnMap.sku] ?? '').trim() : '';
    const description = columnMap.description !== null ? String(row[columnMap.description] ?? '').trim() : '';
    const qty = columnMap.qty !== null ? (parseFloat(String(row[columnMap.qty] ?? '0')) || 0) : 1;
    const price = columnMap.price !== null ? (parseFloat(String(row[columnMap.price] ?? '0')) || 0) : 0;
    const format = columnMap.format !== null ? String(row[columnMap.format] ?? '').trim() : '';
    const barcode = columnMap.barcode !== null ? String(row[columnMap.barcode] ?? '').trim() : '';

    // 1. Match par code-barre EAN/UPC exact (prioritaire si présent)
    if (barcode) {
      const piece = barcodeIndex.get(barcode);
      if (piece) return { raw: row, sku, description, qty, price, format, barcode, piece, matchType: 'barcode' as const };
    }

    // 2. Match par SKU exact
    if (sku) {
      const piece = skuIndex.get(sku.toLowerCase());
      if (piece) return { raw: row, sku, description, qty, price, format, barcode, piece, matchType: 'sku' as const };
    }

    // 3. Match par nom (fuzzy : le nom importé contient le nom catalogue ou vice versa)
    if (description) {
      const normDesc = norm(description);
      // Exact match normalisé
      const exact = nomIndex.get(normDesc);
      if (exact) return { raw: row, sku, description, qty, price, format, barcode, piece: exact, matchType: 'nom' as const };

      // Partiel : le nom catalogue est contenu dans la description importée
      for (const [normNom, piece] of nomIndex.entries()) {
        if (normDesc.includes(normNom) || normNom.includes(normDesc)) {
          return { raw: row, sku, description, qty, price, format, barcode, piece, matchType: 'nom' as const };
        }
      }
    }

    // 4. Non matché
    return { raw: row, sku, description, qty, price, format, barcode, piece: null, matchType: 'none' as const };
  });
}
