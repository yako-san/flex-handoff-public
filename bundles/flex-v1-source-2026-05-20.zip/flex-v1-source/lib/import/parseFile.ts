/**
 * Parse un fichier xlsx ou csv en tableau brut + détection automatique
 * de la ligne header et des colonnes pertinentes (SKU, Qté, Prix, Description).
 *
 * Basé sur l'analyse des fichiers HLC réels :
 * - Métadonnées en lignes 0-7 (n° facture, date, etc.)
 * - Header à ligne variable (7-9)
 * - Données items après le header jusqu'à ligne vide ou "Sub Total"
 */
import * as XLSX from 'xlsx';

// ── Types ──────────────────────────────────────────────────────

export interface ParsedFile {
  /** Nom du fichier uploadé */
  fileName: string;
  /** Métadonnées extraites (n° facture, date, n° commande…) */
  meta: Record<string, string>;
  /** Noms des colonnes détectées */
  headers: string[];
  /** Index de la ligne header dans le fichier brut */
  headerRowIndex: number;
  /** Données brutes (lignes après le header, avant Sub Total) */
  rows: unknown[][];
  /** Mapping auto-détecté des colonnes */
  columnMap: ColumnMap;
}

export interface ColumnMap {
  sku: number | null;
  description: number | null;
  qty: number | null;
  price: number | null;
  /** Colonne 'format' / 'variation' / 'size' (appendée au nom à l'import) */
  format: number | null;
  /** Colonne 'montant' / 'amount' / 'total ligne' — source de vérité pour le total
   *  ligne quand le xlsx est incohérent (kit vendu en lot avec prix/unité ≠ prix/kit). */
  amount: number | null;
  /** Colonne code-barre EAN/UPC/GTIN — écrite dans col T du sheet PIÈCES.
   *  Détectée dans les factures HLC entre autres. */
  barcode: number | null;
  /** Colonnes supplémentaires disponibles (index → nom) */
  extra: { index: number; name: string }[];
}

// ── Détection de colonnes ──────────────────────────────────────

// Les listes sont ORDONNÉES du plus spécifique au plus générique :
//   - un header qui matche un candidat en position 0 obtient un meilleur score
//   - un header qui matche plusieurs candidats conserve son MEILLEUR score
//   - un match exact bat toujours un match par substring
// Ça permet de distinguer "PRIX COÛTANT" (spécifique) de "PRIX VENDANT"
// (générique) ou "qté" (exact) de "QTÉ / CAISSES" (substring).
const SKU_NAMES = [
  'nº d\'article', 'n° d\'article', 'item number', 'item #', 'part number',
  'code produit', 'code article', 'no article', 'code',
  'sku', 'référence', 'reference', 'ref',
];
const QTY_NAMES = [
  'qté', 'qty', 'qte',
  'quantité', 'quantity', 'ordered',
];
const PRICE_NAMES = [
  'prix coûtant', 'prix coutant', 'prix coutant ', // spécifique : coût d'achat
  'unit cost', 'coûtant', 'coutant', 'cost',
  'prix net', 'net price', 'prix unitaire', 'unit price',
  'prix', 'price',
];
const DESC_NAMES = [
  'description', 'désignation', 'designation',
  'produits consommateur', 'produit', 'produits',
  'nom', 'name', 'item',
];
const FORMAT_NAMES = [
  'format', 'variation', 'size', 'taille', 'volume', 'option',
];
const AMOUNT_NAMES = [
  'montant', 'amount', 'line total', 'sous-total', 'subtotal', 'sub total', 'total',
];
const BARCODE_NAMES = [
  'ean', 'upc', 'gtin', 'code-barre', 'code barre', 'codebarre', 'barcode', 'bar code',
  'code à barres', 'code a barres', 'code à barre', 'code a barre',
];

/** Score d'adéquation entre un header et une liste de candidats ordonnée.
 *  Exact match : 10000 - pos  (pos 0 = 10000, pos 1 = 9999, …)
 *  Substring   :  1000 - pos  (pos 0 = 1000,  pos 1 = 999,  …)
 *  Pas de match : 0
 *  Si plusieurs candidats matchent, on conserve le MEILLEUR score. */
function scoreHeader(header: string, candidates: string[]): number {
  const h = header.toLowerCase().trim();
  if (!h) return 0;
  let best = 0;
  for (let i = 0; i < candidates.length; i++) {
    const c = candidates[i];
    if (h === c) best = Math.max(best, 10000 - i);
    else if (h.includes(c)) best = Math.max(best, 1000 - i);
  }
  return best;
}

function detectColumnMap(headers: string[]): ColumnMap {
  // Ordre de résolution : SKU → description → qty → price → format.
  // Un header déjà attribué à un type est retiré des candidats pour les types
  // suivants (ex. "CODE PRODUIT" part en SKU et ne peut plus aller en desc).
  const targets: { name: keyof Omit<ColumnMap, 'extra'>; list: string[] }[] = [
    { name: 'barcode',     list: BARCODE_NAMES }, // EAN/UPC — prioritaire (spécifique)
    { name: 'sku',         list: SKU_NAMES    },
    { name: 'description', list: DESC_NAMES   },
    { name: 'qty',         list: QTY_NAMES    },
    { name: 'price',       list: PRICE_NAMES  },
    { name: 'format',      list: FORMAT_NAMES },
    { name: 'amount',      list: AMOUNT_NAMES },
  ];

  const result: Partial<ColumnMap> = { sku: null, description: null, qty: null, price: null, format: null, amount: null, barcode: null };
  const used = new Set<number>();

  for (const { name, list } of targets) {
    let bestI = -1;
    let bestS = 0;
    for (let i = 0; i < headers.length; i++) {
      if (used.has(i) || !headers[i]) continue;
      const s = scoreHeader(headers[i], list);
      if (s > bestS) { bestS = s; bestI = i; }
    }
    if (bestI >= 0) {
      (result as any)[name] = bestI;
      used.add(bestI);
    }
  }

  const extra: { index: number; name: string }[] = [];
  for (let i = 0; i < headers.length; i++) {
    if (!used.has(i) && headers[i]) extra.push({ index: i, name: headers[i] });
  }
  result.extra = extra;
  return result as ColumnMap;
}

// ── Détection de la ligne header ───────────────────────────────

function findHeaderRow(allRows: unknown[][]): number {
  // Cherche la première ligne avec ≥ 3 colonnes texte non-vides
  for (let i = 0; i < Math.min(allRows.length, 20); i++) {
    const row = allRows[i];
    if (!row) continue;
    const textCols = row.filter(c => typeof c === 'string' && c.trim().length > 0);
    if (textCols.length >= 3) {
      // Vérifier que c'est bien un header (contient au moins un mot-clé connu)
      const joined = textCols.map(c => String(c).toLowerCase()).join(' ');
      if (SKU_NAMES.some(k => joined.includes(k)) || DESC_NAMES.some(k => joined.includes(k)) || QTY_NAMES.some(k => joined.includes(k))) {
        return i;
      }
    }
  }
  // Fallback : première ligne avec ≥ 4 colonnes texte
  for (let i = 0; i < Math.min(allRows.length, 20); i++) {
    const row = allRows[i];
    if (!row) continue;
    const textCols = row.filter(c => typeof c === 'string' && c.trim().length > 0);
    if (textCols.length >= 4) return i;
  }
  return 0;
}

// ── Extraction des métadonnées ─────────────────────────────────

const META_KEYS: Record<string, string> = {
  'nº de facture': 'invoiceNumber',
  'order number': 'orderNumber',
  'nº de commande': 'orderNumber',
  'nº bc': 'poNumber',
  'po number': 'poNumber',
  'date': 'date',
  'order date': 'date',
  'client': 'client',
  'type de commande': 'orderType',
  'submitted by': 'submittedBy',
};

function extractMeta(rows: unknown[][], headerIdx: number): Record<string, string> {
  const meta: Record<string, string> = {};
  for (let i = 0; i < headerIdx; i++) {
    const row = rows[i];
    if (!row || row.length < 2) continue;
    const key = String(row[0] ?? '').toLowerCase().trim();
    const val = String(row[1] ?? '').trim();
    if (!key || !val) continue;
    const metaKey = META_KEYS[key];
    if (metaKey) meta[metaKey] = val;
  }
  return meta;
}

// ── Parse principal ────────────────────────────────────────────

export function parseBuffer(buffer: ArrayBuffer, fileName: string): ParsedFile {
  const wb = XLSX.read(buffer, { type: 'array' });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const allRows: unknown[][] = XLSX.utils.sheet_to_json(ws, { header: 1 });

  const headerRowIndex = findHeaderRow(allRows);
  const headerRow = allRows[headerRowIndex] as string[];
  const headers = headerRow.map(h => String(h ?? '').trim());

  // Extraire les métadonnées (lignes avant le header)
  const meta = extractMeta(allRows, headerRowIndex);

  // Extraire les données après le header. Arrêt quand TOUS les cells de la
  // ligne sont vides (≥ 2 lignes vides d'affilée = fin de table), ou quand
  // une cellule contient "Sub Total" / "Total" (peu importe la colonne).
  const rows: unknown[][] = [];
  let blankStreak = 0;
  for (let i = headerRowIndex + 1; i < allRows.length; i++) {
    const row = allRows[i];
    const cells = (row ?? []).map(c => String(c ?? '').trim());
    const joined = cells.join(' ').toLowerCase();
    const allBlank = cells.every(c => !c);
    // Stop définitif sur une ligne de total
    if (/\b(sub\s*total|grand\s*total|^total\b)/i.test(joined)) break;
    if (allBlank) {
      blankStreak++;
      if (blankStreak >= 2) break;    // 2 lignes vides de suite = fin
      continue;                        // 1 ligne vide isolée → on tolère
    }
    blankStreak = 0;
    rows.push(row);
  }

  const columnMap = detectColumnMap(headers);

  // Post-traitement : héritage de la description depuis la ligne parent.
  // Cas Mint'n Dry : un produit avec plusieurs formats a une ligne "parent"
  // portant le nom, puis des sous-lignes portant seulement le format (60ml,
  // 236ml, 710ml…) + qté + prix. Sans héritage, les sous-lignes sont soit
  // masquées (filtre desc vide) soit importées sans nom.
  //
  // Les placeholder dashes (— – - −) sont traités comme vides → pas utilisés
  // comme description parent (sinon la vraie description suivante serait
  // ignorée et le dash deviendrait le nom hérité).
  const DASH_ONLY = /^[\s\u2013\u2014\u2212-]+$/;
  if (columnMap.description !== null) {
    let lastDesc = '';
    for (const r of rows) {
      const idx = columnMap.description;
      const cur = String(r[idx] ?? '').trim();
      const isBlank = !cur || DASH_ONLY.test(cur);
      if (!isBlank) { lastDesc = cur; }
      else if (lastDesc) { r[idx] = lastDesc; }
    }
  }

  // Post-traitement : sentence case pour les descriptions ALL CAPS.
  // Les fournisseurs écrivent souvent les noms en MAJUSCULES (« LUBRIFIANT
  // CÉRAMIQUE SEC »). On convertit en sentence case (« Lubrifiant céramique
  // sec ») pour un rendu lisible dans le catalogue. On laisse intacts les
  // strings qui ont déjà une casse mixte (= déjà formatés par l'utilisateur).
  if (columnMap.description !== null) {
    for (const r of rows) {
      const idx = columnMap.description;
      r[idx] = sentenceCaseIfAllCaps(String(r[idx] ?? ''));
    }
  }

  // Post-traitement : normaliser qty via MONTANT quand le xlsx est incohérent.
  // Cas STARTER KIT Mint'n Dry : col qty=48 unités × prix=246/kit → total
  // faux de 11808 au lieu du MONTANT réel 492. On recalcule qty = amount/price
  // pour que qty × prix == montant sur chaque ligne.
  if (columnMap.amount !== null && columnMap.qty !== null && columnMap.price !== null) {
    const ai = columnMap.amount, qi = columnMap.qty, pi = columnMap.price;
    for (const r of rows) {
      const amount = parseFloat(String(r[ai] ?? '').replace(',', '.')) || 0;
      const price  = parseFloat(String(r[pi] ?? '').replace(',', '.')) || 0;
      const qty    = parseFloat(String(r[qi] ?? '').replace(',', '.')) || 0;
      if (amount > 0 && price > 0 && qty > 0) {
        const expectedAmount = qty * price;
        // Tolérance 1 % pour ignorer les arrondis
        if (Math.abs(expectedAmount - amount) / amount > 0.01) {
          r[qi] = Math.round((amount / price) * 100) / 100;
        }
      }
    }
  }

  return { fileName, meta, headers, headerRowIndex, rows, columnMap };
}

/** Convertit "LUBRIFIANT CÉRAMIQUE SEC" → "Lubrifiant céramique sec".
 *  Noop si le texte a déjà des minuscules (respect de la casse utilisateur). */
function sentenceCaseIfAllCaps(s: string): string {
  if (!s) return s;
  const letters = s.replace(/[^\p{L}]/gu, '');
  if (letters.length === 0) return s;
  if (letters !== letters.toUpperCase()) return s; // casse mixte → laisser
  const lower = s.toLowerCase();
  return lower.charAt(0).toUpperCase() + lower.slice(1);
}
