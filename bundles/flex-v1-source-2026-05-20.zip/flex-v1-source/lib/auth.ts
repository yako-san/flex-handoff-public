import NextAuth from 'next-auth';
import Google from 'next-auth/providers/google';

const allowedEmails = (process.env.NEXTAUTH_ALLOWED_EMAILS ?? '')
  .split(',')
  .map(e => e.trim())
  .filter(Boolean);

export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [
    Google({
      clientId     : process.env.AUTH_GOOGLE_ID!,
      clientSecret : process.env.AUTH_GOOGLE_SECRET!,
      authorization: {
        params: {
          scope       : 'openid email profile https://www.googleapis.com/auth/gmail.compose https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/contacts https://www.googleapis.com/auth/calendar.events',
          access_type : 'offline',
          // `prompt: consent` force Google à afficher l'écran de consent
          // à chaque login ET à émettre un refresh_token frais — sinon,
          // si l'utilisateur a déjà autorisé l'app, Google skip le
          // consent et ne renvoie PAS de refresh_token, ce qui bloque
          // les cron background (Calendar sync).
          prompt      : 'consent',
        },
      },
    }),
  ],
  callbacks: {
    async signIn({ user }) {
      if (!allowedEmails.length) return true;
      return allowedEmails.includes(user.email ?? '');
    },
    async jwt({ token, account }) {
      // Stocker les tokens lors de la connexion. On NE écrase PAS le
      // refresh_token si le nouveau login n'en fournit pas — Google ne
      // renvoie le refresh_token qu'à la toute première autorisation ; sur
      // les logins suivants il est absent et ça effacerait notre token.
      if (account?.access_token) {
        token.googleAccessToken  = account.access_token;
        if (account.refresh_token) {
          token.googleRefreshToken = account.refresh_token;
        }
        // expires_at est en secondes (UNIX), on le convertit en ms
        token.googleTokenExpiry  = account.expires_at
          ? account.expires_at * 1000
          : Date.now() + 3600 * 1000;
        return token;
      }

      // Rafraîchir le token s'il expire dans moins de 60 secondes
      const expiry = (token.googleTokenExpiry as number) ?? 0;
      if (token.googleRefreshToken && Date.now() > expiry - 60_000) {
        try {
          const res = await fetch('https://oauth2.googleapis.com/token', {
            method : 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body   : new URLSearchParams({
              client_id     : process.env.AUTH_GOOGLE_ID!,
              client_secret : process.env.AUTH_GOOGLE_SECRET!,
              grant_type    : 'refresh_token',
              refresh_token : token.googleRefreshToken as string,
            }),
          });
          const refreshed = await res.json();
          if (refreshed.access_token) {
            token.googleAccessToken = refreshed.access_token;
            token.googleTokenExpiry = Date.now() + (refreshed.expires_in ?? 3600) * 1000;
          }
        } catch (e) {
          console.error('[auth] token refresh failed', e);
        }
      }
      return token;
    },
    async session({ session, token }) {
      // v1.1.8 — Item 11 : module augmentation `types/next-auth.d.ts`
      // déclare ces champs sur Session/JWT → plus de cast `as any`.
      if (session.user && token.sub) {
        session.user.id = token.sub;
      }
      // Exposer les tokens Gmail à l'API route (server-side uniquement)
      session.googleAccessToken  = typeof token.googleAccessToken  === 'string' ? token.googleAccessToken  : undefined;
      session.googleRefreshToken = typeof token.googleRefreshToken === 'string' ? token.googleRefreshToken : undefined;
      return session;
    },
  },
  pages: {
    signIn : '/login',
    error  : '/login',
  },
});
