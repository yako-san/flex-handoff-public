/**
 * Tests `lib/bdc-helpers.ts` — v1.1.9 / Items 5 + 9 audit.
 *
 * Garde-fous sur les helpers extraits de BDCPanel. Si on change la regex
 * de `parseSvcTemps` ou la logique de matching tolérant `normSvcKey`,
 * ces tests cassent au lieu de bugs silencieux sur les durées de service.
 */
import { describe, it, expect } from 'vitest';
import {
  parseSvcTemps,
  normSvcKey,
  svcTailKey,
  svcLabel,
  pceLabel,
  computeMontant,
  parseDureeToMinutes,
  computeTotalDuree,
} from '../bdc-helpers';

describe('parseSvcTemps — extraction "(45 min)" en queue de nom', () => {
  it('extrait "(45 min)"', () => {
    const r = parseSvcTemps('🧰 Mise au point complète (45 min)');
    expect(r.label).toBe('🧰 Mise au point complète');
    expect(r.temps).toBe('(45 min)');
  });

  it('extrait "(1 h)" et "(1 heure)"', () => {
    expect(parseSvcTemps('Inspect. (1 h)').temps).toBe('(1 h)');
    expect(parseSvcTemps('Forfait (1 heure)').temps).toBe('(1 heure)');
  });

  it('pas de durée → temps vide, label inchangé', () => {
    const r = parseSvcTemps('🔧 Réglage frein');
    expect(r.label).toBe('🔧 Réglage frein');
    expect(r.temps).toBe('');
  });

  it('parenthèses au milieu du nom : pas considérées comme durée', () => {
    const r = parseSvcTemps('Service (special) avec autres mots');
    expect(r.temps).toBe('');
  });
});

describe('normSvcKey — matching tolérant', () => {
  it('strip emoji + lowercase + collapse spaces', () => {
    expect(normSvcKey('🧰  Mise au   Point ')).toBe('mise au point');
  });
  it('strip ponctuation et espaces de tête', () => {
    expect(normSvcKey(': Réglage')).toBe('réglage');
  });
  it('deux noms emoji-différents produisent la même clé', () => {
    expect(normSvcKey('🧰 Mise au point')).toBe(normSvcKey('🔧 Mise au point'));
  });
});

describe('svcTailKey — queue après séparateur', () => {
  it('extrait après ":" si ≥ 5 chars', () => {
    expect(svcTailKey('Remplac. : 4 câbles dérailleur')).toBe('4 câbles dérailleur');
  });
  it('extrait après " — "', () => {
    expect(svcTailKey('Forfait — pédalier complet')).toBe('pédalier complet');
  });
  it('retourne "" si pas de séparateur', () => {
    expect(svcTailKey('Réglage frein')).toBe('');
  });
  it('retourne "" si queue < 5 chars', () => {
    expect(svcTailKey('Forfait : OK')).toBe('');
  });
});

describe('svcLabel + pceLabel', () => {
  it('svcLabel = { display, temps }', () => {
    const r = svcLabel('Forfait (30 min)');
    expect(r.display).toBe('Forfait');
    expect(r.temps).toBe('(30 min)');
  });
  it('pceLabel ajoute le préfixe ⚙️', () => {
    expect(pceLabel('Chaîne 11v')).toBe('⚙️ : Chaîne 11v');
  });
});

describe('computeMontant — remise pct ou flat', () => {
  it('pct : 10 % sur 100 = 10', () => {
    expect(computeMontant(100, { type: 'pct', value: 10 })).toBe(10);
  });
  it('pct : arrondi à 2 décimales (33 % sur 99,99 = 33.00)', () => {
    expect(computeMontant(99.99, { type: 'pct', value: 33 })).toBe(33);
  });
  it('flat : cap au montant total', () => {
    expect(computeMontant(50, { type: 'fixed', value: 80 })).toBe(50);
  });
  it('remise <= 0 → 0', () => {
    expect(computeMontant(100, { type: 'pct', value: 0 })).toBe(0);
    expect(computeMontant(100, { type: 'fixed', value: -5 })).toBe(0);
  });
});

describe('parseDureeToMinutes — formats variés', () => {
  it('"1:45" → 105', () => {
    expect(parseDureeToMinutes('1:45')).toBe(105);
  });
  it('"45 min" → 45', () => {
    expect(parseDureeToMinutes('45 min')).toBe(45);
  });
  it('"2 h" → 120', () => {
    expect(parseDureeToMinutes('2 h')).toBe(120);
  });
  it('vide ou format inconnu → 0', () => {
    expect(parseDureeToMinutes('')).toBe(0);
    expect(parseDureeToMinutes('???')).toBe(0);
  });
});

describe('computeTotalDuree — somme + format h:mm', () => {
  const dureeMap = new Map<string, string>([
    ['Mise au point', '45 min'],
    ['Remplacement', '1:30'],
  ]);

  it('somme 45 + 90 = 2h15', () => {
    const items = [
      { service: { nom: 'Mise au point', status: '' } },
      { service: { nom: 'Remplacement', status: '' } },
    ] as any;
    expect(computeTotalDuree(items, dureeMap)).toBe('2:15');
  });

  it('override via service.status prime sur le catalogue', () => {
    const items = [
      { service: { nom: 'Mise au point', status: '2 h' } }, // override 2 h
    ] as any;
    expect(computeTotalDuree(items, dureeMap)).toBe('2:00');
  });

  it('"..." dans status = pas d\'override (utilise catalogue)', () => {
    const items = [
      { service: { nom: 'Mise au point', status: '...' } },
    ] as any;
    expect(computeTotalDuree(items, dureeMap)).toBe('0:45');
  });

  it('fallback parseSvcTemps si pas dans dureeMap', () => {
    const items = [
      { service: { nom: 'Service ad hoc (15 min)', status: '' } },
    ] as any;
    expect(computeTotalDuree(items, dureeMap)).toBe('0:15');
  });
});
