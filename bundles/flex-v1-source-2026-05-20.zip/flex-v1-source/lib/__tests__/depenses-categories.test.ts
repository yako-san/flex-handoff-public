/**
 * Tests des helpers fiscaux dépenses — v1.1.6 / Item 9 audit.
 *
 * Couvre :
 *   - `deductibleFactor` : règle des 50 % repas + usagePct combiné
 *   - `t2125LineFor` : mapping catégorie → ligne T2125 + fallback 9270
 *
 * Hors scope (besoin de mocks Sheets) :
 *   - CRUD `createDepense` / `updateDepense` — testés manuellement contre
 *     la copie DEV du sheet INVENTAIRE.
 */
import { describe, it, expect } from 'vitest';
import {
  deductibleFactor,
  t2125LineFor,
  CATEGORIE_DEDUCTIBLE_PCT,
  CATEGORIE_T2125,
  DEPENSE_CATEGORIES,
} from '../depenses-categories';

describe('deductibleFactor — règle 50 % × usagePct', () => {
  it('catégorie hors map = 100 % déductible (défaut)', () => {
    expect(deductibleFactor('Fournitures de bureau')).toBe(1);
    expect(deductibleFactor('Assurances')).toBe(1);
  });

  it('Repas et représentation = 50 %', () => {
    expect(deductibleFactor('Repas et représentation')).toBe(0.5);
  });

  it('usagePct seul ramène le facteur (sans cat réduite)', () => {
    expect(deductibleFactor('Téléphone / Internet', 60)).toBeCloseTo(0.6, 10);
    expect(deductibleFactor('Téléphone / Internet', 80)).toBeCloseTo(0.8, 10);
  });

  it('usagePct combiné avec cat 50 % = multiplication', () => {
    // 50 % cat × 80 % usage = 40 %
    expect(deductibleFactor('Repas et représentation', 80)).toBeCloseTo(0.4, 10);
    // 50 % cat × 100 % usage = 50 %
    expect(deductibleFactor('Repas et représentation', 100)).toBeCloseTo(0.5, 10);
  });

  it('usagePct undefined / null traités comme 100 %', () => {
    expect(deductibleFactor('Repas et représentation', undefined)).toBe(0.5);
    expect(deductibleFactor('Repas et représentation', null)).toBe(0.5);
  });

  it('usagePct hors borne est clampé [0, 100]', () => {
    // > 100 : clampé à 100 (= 100 % usage)
    expect(deductibleFactor('Fournitures de bureau', 150)).toBe(1);
    // < 0 : clampé à 0 → facteur 0
    expect(deductibleFactor('Fournitures de bureau', -10)).toBe(0);
  });

  it('NaN / Infinity sur usagePct traités comme 100 %', () => {
    expect(deductibleFactor('Fournitures de bureau', NaN)).toBe(1);
    expect(deductibleFactor('Fournitures de bureau', Infinity)).toBe(1);
  });

  it('catégorie inconnue + usagePct = règle 100 % cat × usage', () => {
    expect(deductibleFactor('Catégorie qui n\'existe pas', 50)).toBe(0.5);
  });
});

describe('t2125LineFor — mapping catégorie → ligne T2125', () => {
  it('toute catégorie déclarée a une ligne T2125 valide (4 chiffres)', () => {
    for (const cat of DEPENSE_CATEGORIES) {
      const { ligne, libelle } = t2125LineFor(cat);
      expect(ligne, `catégorie "${cat}" sans ligne T2125`).toMatch(/^\d{4}$/);
      expect(libelle.length, `catégorie "${cat}" sans libellé`).toBeGreaterThan(0);
    }
  });

  it('catégorie inconnue retombe sur 9270 Autres', () => {
    const fallback = t2125LineFor('Pas une vraie catégorie');
    expect(fallback.ligne).toBe('9270');
    expect(fallback.libelle).toMatch(/Autres/);
  });

  it('Achats marchandises = ligne 8320', () => {
    expect(t2125LineFor('Achats marchandises pour revente').ligne).toBe('8320');
  });

  it('Repas et représentation = ligne 8523', () => {
    expect(t2125LineFor('Repas et représentation').ligne).toBe('8523');
  });
});

describe('CATEGORIE_DEDUCTIBLE_PCT — couverture stricte', () => {
  it('toutes les clés de la map existent dans DEPENSE_CATEGORIES', () => {
    // Sinon le helper deductibleFactor ne s'appliquera jamais (catégorie
    // ne sera jamais choisie via le dropdown UI).
    const cats = new Set<string>(DEPENSE_CATEGORIES);
    for (const cat of Object.keys(CATEGORIE_DEDUCTIBLE_PCT)) {
      expect(cats.has(cat), `clé "${cat}" absente de DEPENSE_CATEGORIES`).toBe(true);
    }
  });

  it('toutes les valeurs sont entre 0 et 100 exclus de 0', () => {
    for (const [cat, pct] of Object.entries(CATEGORIE_DEDUCTIBLE_PCT)) {
      expect(pct, `cat "${cat}" : pct hors borne`).toBeGreaterThan(0);
      expect(pct, `cat "${cat}" : pct hors borne`).toBeLessThanOrEqual(100);
    }
  });
});

describe('CATEGORIE_T2125 — couverture stricte', () => {
  it('toutes les clés correspondent à une catégorie déclarée', () => {
    const cats = new Set<string>(DEPENSE_CATEGORIES);
    for (const cat of Object.keys(CATEGORIE_T2125)) {
      expect(cats.has(cat), `clé "${cat}" absente de DEPENSE_CATEGORIES`).toBe(true);
    }
  });

  it('toutes les catégories sont couvertes par CATEGORIE_T2125', () => {
    // Pas de catégorie qui retomberait silencieusement sur le fallback 9270
    // alors qu'on aurait dû lui assigner une ligne précise.
    for (const cat of DEPENSE_CATEGORIES) {
      expect(CATEGORIE_T2125[cat], `cat "${cat}" sans mapping T2125`).toBeDefined();
    }
  });
});
