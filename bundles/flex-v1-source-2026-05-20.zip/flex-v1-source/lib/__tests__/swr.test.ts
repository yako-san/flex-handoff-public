/**
 * Tests `lib/swr.ts` — v1.1.6 / Item 9 audit.
 *
 * Sert surtout de garde-fou contre une régression où `jsonFetcherStrict`
 * cesserait de lever pour une réponse !ok (cas qui ferait crasher useBDC
 * et useDepenses qui s'attendent à un throw — ils gèrent `error` séparé
 * de `data`).
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { jsonFetcher, jsonFetcherStrict } from '../swr';

const realFetch = globalThis.fetch;

function mockFetch(status: number, body: any) {
  globalThis.fetch = vi.fn(async () => ({
    ok    : status >= 200 && status < 300,
    status,
    json  : async () => body,
  })) as any;
}

afterEach(() => {
  globalThis.fetch = realFetch;
  vi.restoreAllMocks();
});

describe('jsonFetcher (plain)', () => {
  it('retourne le JSON quel que soit le status', async () => {
    mockFetch(200, { ok: true, value: 42 });
    expect(await jsonFetcher('/api/whatever')).toEqual({ ok: true, value: 42 });
  });

  it('retourne aussi le payload sur erreur (pas de throw)', async () => {
    mockFetch(500, { error: 'boom' });
    // Comportement attendu : `data` reçoit `{ error: 'boom' }`. Le composant
    // gère via la forme du payload.
    expect(await jsonFetcher('/api/whatever')).toEqual({ error: 'boom' });
  });
});

describe('jsonFetcherStrict', () => {
  it('200 → retourne le JSON', async () => {
    mockFetch(200, { ok: true });
    expect(await jsonFetcherStrict('/api/whatever')).toEqual({ ok: true });
  });

  it('500 → throw avec le message d\'erreur du body', async () => {
    mockFetch(500, { error: 'sheets quota exceeded' });
    await expect(jsonFetcherStrict('/api/whatever')).rejects.toThrow('sheets quota exceeded');
  });

  it('403 sans body lisible → throw avec HTTP <status>', async () => {
    globalThis.fetch = vi.fn(async () => ({
      ok    : false,
      status: 403,
      json  : async () => { throw new Error('not JSON'); },
    })) as any;
    await expect(jsonFetcherStrict('/api/whatever')).rejects.toThrow('HTTP 403');
  });
});
