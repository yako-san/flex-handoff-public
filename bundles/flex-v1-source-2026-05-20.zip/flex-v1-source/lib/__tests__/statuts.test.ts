/**
 * Tests `lib/utils/statuts.ts` — v1.1.6 / Item 9 audit.
 *
 * Couvre les helpers d'affichage (getStatutStyle, getArchiveStatutDisplay,
 * PO_STATUS_STYLE) consolidés en v1.1.4. Sert de garde-fou contre
 * un drift accidentel des codes couleur (incident type v1.0.20 où le
 * rouge REFUSÉ avait fini en rose pâle à un endroit, rouge franc à un
 * autre).
 */
import { describe, it, expect } from 'vitest';
import {
  STATUTS,
  getStatutStyle,
  getArchiveStatutDisplay,
  PO_STATUS_STYLE,
  PO_STATUS_LABEL,
  nextStatusOnAssign,
} from '../utils/statuts';

describe('getStatutStyle — vocabulaire couleur BDT', () => {
  it('retourne backgroundColor + color pour les statuts connus', () => {
    const s = getStatutStyle('APPROUVÉ');
    expect(s.backgroundColor).toBe(STATUTS['APPROUVÉ'].bg);
    expect(s.color).toBe(STATUTS['APPROUVÉ'].fg);
  });

  it('statut inconnu = gris neutre + texte noir (pas de crash)', () => {
    expect(getStatutStyle('PAS_UN_STATUT')).toEqual({
      backgroundColor: '#f5f5f5',
      color: '#000000',
    });
  });

  it('REFUSÉ est rouge franc (#d92020) — invariant depuis v1.0.20', () => {
    // Si jamais quelqu'un revient au rose pâle, ce test casse.
    const s = getStatutStyle('REFUSÉ');
    expect(s.backgroundColor.toLowerCase()).toBe('#d92020');
    expect(s.color.toLowerCase()).toBe('#ffffff');
  });
});

describe('getArchiveStatutDisplay — helper page /archives', () => {
  it('REFUSÉ majuscule → rouge franc + label "REFUSÉ"', () => {
    const r = getArchiveStatutDisplay('REFUSÉ');
    expect(r.bg.toLowerCase()).toBe('#d92020');
    expect(r.label).toBe('REFUSÉ');
  });

  it('REFUSE (sans accent) accepté aussi — robustesse', () => {
    // Cas observé sur d'anciennes archives où l'accent avait sauté à
    // l'import / export. Le helper doit traiter les deux comme équivalents.
    const r = getArchiveStatutDisplay('REFUSE');
    expect(r.label).toBe('REFUSÉ');
  });

  it('autre statut → gris + label "Archivé"', () => {
    const r = getArchiveStatutDisplay('FACTURÉ');
    expect(r.bg).toBe('#e0e0e0');
    expect(r.label).toBe('Archivé');
  });

  it('undefined / vide → gris + Archivé', () => {
    expect(getArchiveStatutDisplay(undefined).label).toBe('Archivé');
    expect(getArchiveStatutDisplay('').label).toBe('Archivé');
    expect(getArchiveStatutDisplay('   ').label).toBe('Archivé');
  });
});

describe('PO_STATUS_STYLE / PO_STATUS_LABEL — page /catalogue/reception', () => {
  it('couvre les 4 statuts PO du type union', () => {
    for (const s of ['EN ATTENTE', 'PARTIEL', 'RECU', 'ANNULE']) {
      expect(PO_STATUS_STYLE[s], `PO_STATUS_STYLE manque "${s}"`).toBeDefined();
      expect(PO_STATUS_LABEL[s], `PO_STATUS_LABEL manque "${s}"`).toBeDefined();
    }
  });

  it('libellés affichés sont accentués', () => {
    expect(PO_STATUS_LABEL['RECU']).toBe('REÇU');
    expect(PO_STATUS_LABEL['ANNULE']).toBe('ANNULÉ');
  });
});

describe('nextStatusOnAssign — workflow auto BDT', () => {
  it('eval : RV/REÇU → ÉVAL. dès qu\'un mécano est assigné', () => {
    expect(nextStatusOnAssign('eval', 'Bob', 'RV')).toBe('ÉVAL.');
    expect(nextStatusOnAssign('eval', 'Bob', 'REÇU')).toBe('ÉVAL.');
  });

  it('eval : ne dégrade pas un statut plus avancé', () => {
    expect(nextStatusOnAssign('eval', 'Bob', 'ON BENCH')).toBeNull();
    expect(nextStatusOnAssign('eval', 'Bob', 'FACTURÉ')).toBeNull();
  });

  it('meca : RV/REÇU/ÉVAL./APPROUVÉ → ON BENCH', () => {
    expect(nextStatusOnAssign('meca', 'Alice', 'RV')).toBe('ON BENCH');
    expect(nextStatusOnAssign('meca', 'Alice', 'ÉVAL.')).toBe('ON BENCH');
    expect(nextStatusOnAssign('meca', 'Alice', 'APPROUVÉ')).toBe('ON BENCH');
  });

  it('ctrl : ON BENCH → CTRL QLTÉ', () => {
    expect(nextStatusOnAssign('ctrl', 'Charlie', 'ON BENCH')).toBe('CTRL QLTÉ');
    expect(nextStatusOnAssign('ctrl', 'Charlie', 'APPROUVÉ')).toBeNull();
  });

  it('mécano vidé (chaîne vide) = pas de progression', () => {
    expect(nextStatusOnAssign('eval', '', 'REÇU')).toBeNull();
    expect(nextStatusOnAssign('meca', '', 'ÉVAL.')).toBeNull();
  });
});
