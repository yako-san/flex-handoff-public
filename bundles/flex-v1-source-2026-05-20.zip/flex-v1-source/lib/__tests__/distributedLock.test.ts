/**
 * Tests `lib/distributedLock.ts` — v1.1.6 / Item 9 audit.
 *
 * Couvre la branche fallback (KV_REST_API_URL absent → no-op cross-lambda,
 * acquireLock retourne un token immédiatement, releaseLock no-op). C'est
 * le chemin de code utilisé en dev local + tests.
 *
 * La branche réelle (Vercel KV) est testée manuellement contre la prod
 * via les compteurs B2/B3 — pas mockable utilement ici (Upstash SDK).
 */
import { describe, it, expect, beforeAll } from 'vitest';

// Force le mode "KV absent" AVANT l'import du module — le flag est figé
// à l'évaluation du module via `!!process.env.KV_REST_API_URL`.
beforeAll(() => {
  delete process.env.KV_REST_API_URL;
});

describe('distributedLock — fallback dev (KV absent)', () => {
  it('acquireLock retourne un token UUID-shape immédiatement', async () => {
    const { acquireLock } = await import('../distributedLock');
    const token = await acquireLock('test-key', 15);
    // UUID v4 : 8-4-4-4-12 hex
    expect(token).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i);
  });

  it('acquireLock concurrent ne lance pas (pas de coordination en dev)', async () => {
    const { acquireLock } = await import('../distributedLock');
    const [a, b, c] = await Promise.all([
      acquireLock('counter:test', 15),
      acquireLock('counter:test', 15),
      acquireLock('counter:test', 15),
    ]);
    // Chaque appel a obtenu un token différent — c'est OK, le test signale
    // juste qu'aucun ne throw et que les 3 acquisitions « réussissent »
    // (le Mutex local de counter.ts protège dans la même lambda).
    expect(typeof a).toBe('string');
    expect(typeof b).toBe('string');
    expect(typeof c).toBe('string');
    expect(new Set([a, b, c]).size).toBe(3);
  });

  it('releaseLock no-op (pas d\'exception même avec token bidon)', async () => {
    const { releaseLock } = await import('../distributedLock');
    await expect(releaseLock('test-key', 'token-bidon')).resolves.toBeUndefined();
  });

  it('withDistributedLock wrap try/finally — exécute fn et propage le résultat', async () => {
    const { withDistributedLock } = await import('../distributedLock');
    const result = await withDistributedLock('compute', 15, async () => 42);
    expect(result).toBe(42);
  });

  it('withDistributedLock propage les exceptions de fn', async () => {
    const { withDistributedLock } = await import('../distributedLock');
    await expect(
      withDistributedLock('boom', 15, async () => {
        throw new Error('explosion contrôlée');
      }),
    ).rejects.toThrow('explosion contrôlée');
  });
});
