/**
 * Helper serveur — vérifie que l'utilisateur de la session est admin.
 *
 * Source de vérité : clé `admin_emails` du sheet _EMAIL_TEMPLATES_
 * (JSON array). Comparaison casse insensible sur session.user.email.
 *
 * Fallback fail-safe : yako.cyclo@gmail.com est TOUJOURS admin même si
 * la liste sheet est vide / cassée — évite de se verrouiller dehors.
 *
 * Usage dans une route :
 *   const check = await requireAdmin();
 *   if (!check.ok) return NextResponse.json({ error: check.error }, { status: check.status });
 */
import { auth } from '../auth';
import { getEmailTemplates } from '../sheets/emailTemplates';

const FAIL_SAFE_ADMIN = 'yako.cyclo@gmail.com';

export async function requireAdmin(): Promise<
  | { ok: true; email: string }
  | { ok: false; error: string; status: 401 | 403 }
> {
  const session = await auth();
  const email   = (session?.user?.email ?? '').trim().toLowerCase();
  if (!email) {
    return { ok: false, error: 'Non authentifié', status: 401 };
  }

  // Fail-safe : yako.cyclo@gmail.com est toujours admin
  if (email === FAIL_SAFE_ADMIN) return { ok: true, email };

  // Lookup admin_emails depuis le sheet
  try {
    const tpl = await getEmailTemplates();
    const raw = tpl.admin_emails ?? '';
    const arr = JSON.parse(raw);
    const list: string[] = Array.isArray(arr)
      ? arr.map((s: any) => String(s).trim().toLowerCase()).filter(Boolean)
      : [];
    if (list.includes(email)) return { ok: true, email };
  } catch {
    // JSON cassé ou sheet down → seul le fail-safe reste admin
  }

  return { ok: false, error: 'Accès réservé aux administrateurs', status: 403 };
}
