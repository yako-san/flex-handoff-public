/**
 * Helpers pour la gestion d'erreurs — v1.1.8 / Item 11 audit.
 *
 * Convention : tout nouveau `catch` devrait utiliser `catch (err: unknown)`
 * et passer par `errMessage(err)` plutôt que `err: any`. À terme, on pourra
 * activer `useUnknownInCatchVariables` dans tsconfig (~252 catch à
 * migrer — pas en un seul commit).
 *
 * Usage :
 *
 *   } catch (err: unknown) {
 *     logError('depenses-post-failed', { error: errMessage(err) });
 *     return NextResponse.json({ error: errMessage(err) }, { status: 500 });
 *   }
 */

/**
 * Extrait un message d'erreur safe depuis un `unknown` (catch).
 *
 * Priorité :
 *   1. Error native → err.message
 *   2. Objet avec .message string → ce message
 *   3. String → telle quelle
 *   4. Autre → String(err)
 */
export function errMessage(err: unknown): string {
  if (err instanceof Error) return err.message;
  if (typeof err === 'string') return err;
  if (err && typeof err === 'object' && 'message' in err) {
    const m = (err as { message: unknown }).message;
    if (typeof m === 'string') return m;
  }
  return String(err ?? 'Erreur inconnue');
}

/**
 * Type guard : true si l'erreur a une structure Google API error
 * (.code, .errors[]). Utile pour identifier un quota Sheets exceeded
 * vs une vraie erreur applicative.
 */
export function isGoogleApiError(err: unknown): err is {
  code: number;
  message: string;
  errors?: Array<{ reason?: string; message?: string }>;
} {
  return !!err
    && typeof err === 'object'
    && 'code' in err
    && typeof (err as { code: unknown }).code === 'number';
}
