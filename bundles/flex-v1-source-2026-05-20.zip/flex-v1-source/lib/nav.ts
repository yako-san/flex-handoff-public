/**
 * Définition centralisée des items du menu gauche + helper pour résoudre
 * l'icône associée à un pathname. Utilisé par AppShell (rendu menu) et
 * PageHeader (icône en-tête).
 */
import React from 'react';
import {
  TagIcon,
  ArchiveBoxArrowDownIcon,
  Cog6ToothIcon,
  IdentificationIcon,
  WrenchScrewdriverIcon,
  BanknotesIcon,
  CubeIcon,
  ChartBarIcon,
  QuestionMarkCircleIcon,
  ReceiptPercentIcon,
} from '@heroicons/react/24/outline';

export interface NavItem {
  href: string;
  label: string;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  /** Taille du label en mode étendu (px). Défaut 18. */
  labelSize?: number;
  /** Style "petit" : label en minuscules, poids léger. */
  small?: boolean;
  /** Chemins supplémentaires qui activent aussi cet item (ex. sous-pages
   *  qui ne sont pas dans le menu mais partagent la même catégorie). */
  matches?: string[];
  /** v1.0.26+ : item visible uniquement pour les admins (filter via
   *  useIsAdmin côté UI). Le guard de sécurité réel est côté serveur
   *  (requireAdmin) sur les routes — ce flag est juste pour l'affichage. */
  adminOnly?: boolean;
}

export const NAV: NavItem[] = [
  { href: '/inventaire',         label: 'INVENTAIRE', icon: TagIcon },
  { href: '/catalogue/ventes',   label: 'VENTES',     icon: BanknotesIcon },
  { href: '/catalogue/services', label: 'SERVICES',   icon: WrenchScrewdriverIcon },
  { href: '/catalogue/pieces',   label: 'PIÈCES',     icon: CubeIcon,
    matches: [
      '/commandes',
      '/catalogue/fournisseurs',
      '/catalogue/reception',
      '/catalogue/commande',
    ],
  },
  { href: '/clients',            label: 'CLIENTS',    icon: IdentificationIcon },
];

/** Items accessibles via le dropdown du logo (ne s'affichent pas dans le menu principal). */
export const LOGO_MENU: NavItem[] = [
  { href: '/dashboard',          label: 'Dashboard',  icon: ChartBarIcon },
  { href: '/archives',           label: 'Archives',   icon: ArchiveBoxArrowDownIcon },
  // v1.0.26+ : page Dépenses admin only — comptabilité / TPS-TVQ / T2125
  { href: '/depenses',           label: 'Dépenses',   icon: ReceiptPercentIcon, adminOnly: true },
  { href: '/parametres',         label: 'Paramètres', icon: Cog6ToothIcon },
  { href: '/aide',               label: 'Aide',       icon: QuestionMarkCircleIcon },
];

/**
 * Retourne l'item NAV dont le href (ou un des `matches`) correspond le plus
 * spécifiquement au pathname. Ex. /catalogue/reception → item PIÈCES.
 * Retourne undefined si aucun match.
 */
export function resolveNavItem(pathname: string): NavItem | undefined {
  let best: NavItem | undefined;
  let bestLen = 0;
  const all = [...NAV, ...LOGO_MENU];
  for (const item of all) {
    const candidates = [item.href, ...(item.matches ?? [])];
    for (const c of candidates) {
      const m = pathname === c || pathname.startsWith(c + '/');
      if (m && c.length > bestLen) {
        bestLen = c.length;
        best = item;
      }
    }
  }
  return best;
}
