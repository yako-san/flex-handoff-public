/**
 * lib/config.ts — Configuration de l'atelier
 *
 * Modifier EQUIPE avec les initiales/prénoms des membres de l'équipe.
 * Ces valeurs apparaissent dans les dropdown Évaluation / Mécanique / Ctrl qualité.
 * La chaîne vide '' représente "— (non assigné)".
 */
export const EQUIPE: string[] = [
  '',              // — non assigné
  'François',
  'Jean-François',
  'yako',
];

/**
 * Tailles de vélo standardisées utilisées dans VeloForm et la fiche vélo.
 * Ordre grand → petit pour matcher la perception visuelle (XXL en haut).
 * Les tailles numériques (24/26) sont pour les vélos enfants.
 */
export const VELO_TAILLES: readonly string[] = [
  '',      // — non renseigné
  'XXL',
  'XL',
  'L',
  'M',
  'S',
  'XS',
  'XSS',
  '24',
  '26',
];
