/**
 * Calculs de taxes Québec — TPS 5 % + TVQ 9,975 %.
 *
 * Conforme à LTA art. 165 et LTVQ art. 16 : taxes calculées sur le HT
 * (sous-total) indépendamment du mode de paiement. Arrondi par taxe puis
 * sommation, conforme à la pratique Revenu Québec (calculs séparés).
 *
 * Pure : pas d'I/O, pas de Sheets, déterministe.
 */

export const TPS_RATE = 0.05;
export const TVQ_RATE = 0.09975;

export interface TaxBreakdown {
  /** Sous-total HT (= input). */
  sousTotal : number;
  /** TPS 5 % du HT, arrondi cent. */
  tps       : number;
  /** TVQ 9,975 % du HT, arrondi cent. */
  tvq       : number;
  /** TPS + TVQ (déjà arrondi par taxe). */
  taxes     : number;
  /** sousTotal + taxes, arrondi cent. */
  grandTotal: number;
}

/** Arrondi commercial à 2 décimales (banker-round non utilisé). */
function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

export function computeTaxes(sousTotal: number): TaxBreakdown {
  const tps        = round2(sousTotal * TPS_RATE);
  const tvq        = round2(sousTotal * TVQ_RATE);
  const taxes      = round2(tps + tvq);
  const grandTotal = round2(sousTotal + taxes);
  return { sousTotal, tps, tvq, taxes, grandTotal };
}
