import { describe, it, expect } from 'vitest';
import { computeTaxes, TPS_RATE, TVQ_RATE } from '../taxes';

describe('computeTaxes — TPS 5 % + TVQ 9,975 % Québec', () => {
  it('happy path : sous-total 100,00 → TPS 5,00 / TVQ 9,98 / TTC 114,98', () => {
    const r = computeTaxes(100);
    expect(r.sousTotal).toBe(100);
    expect(r.tps).toBe(5);
    expect(r.tvq).toBe(9.98);          // 9.975 arrondi à 9.98
    expect(r.taxes).toBe(14.98);
    expect(r.grandTotal).toBe(114.98);
  });

  it('arrondi au cent par taxe (pratique Revenu Québec) — sous-total 33,33', () => {
    const r = computeTaxes(33.33);
    // TPS : 33.33 * 0.05 = 1.6665 → 1.67
    // TVQ : 33.33 * 0.09975 = 3.3247... → 3.32
    expect(r.tps).toBe(1.67);
    expect(r.tvq).toBe(3.32);
    expect(r.taxes).toBe(4.99);
    expect(r.grandTotal).toBe(38.32);
  });

  it('sous-total 0 → toutes les taxes à 0', () => {
    const r = computeTaxes(0);
    expect(r.tps).toBe(0);
    expect(r.tvq).toBe(0);
    expect(r.taxes).toBe(0);
    expect(r.grandTotal).toBe(0);
  });

  it('sous-total négatif (avoir/remboursement) reste cohérent', () => {
    // Note IEEE-754 : -100 * 0.09975 = -9.975000000000001 (drift), donc
    // *100 → -997.5000000000001 → Math.round arrondit à -998 → -9.98.
    // Symétrie du happy path 100 → 9.98 préservée par accident heureux.
    const r = computeTaxes(-100);
    expect(r.tps).toBe(-5);
    expect(r.tvq).toBe(-9.98);
    expect(r.taxes).toBe(-14.98);
    expect(r.grandTotal).toBe(-114.98);
  });

  it('grand montant : 9999.99', () => {
    const r = computeTaxes(9999.99);
    // TPS : 499.9995 → 500.00
    // TVQ : 997.499... → 997.50
    expect(r.tps).toBe(500);
    expect(r.tvq).toBe(997.5);
    expect(r.taxes).toBe(1497.5);
    expect(r.grandTotal).toBe(11497.49);
  });

  it('précision flottante : pas de drift sur multiples décimales', () => {
    // 0.1 * 0.05 sans arrondi = 0.005000000000000001 (drift JS)
    const r = computeTaxes(0.1);
    expect(r.tps).toBe(0.01);          // arrondi : 0.005 → 0.01
    expect(r.tvq).toBe(0.01);          // 0.009975 → 0.01
    expect(r.grandTotal).toBe(0.12);
  });

  it('constants exposées correspondent aux taux légaux', () => {
    expect(TPS_RATE).toBe(0.05);
    expect(TVQ_RATE).toBe(0.09975);
  });
});
