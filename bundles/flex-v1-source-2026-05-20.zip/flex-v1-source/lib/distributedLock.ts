/**
 * Verrou distribué (cross-lambda) via Vercel KV.
 *
 * v1.1.3 — Item 3 audit sécurité. Vercel route chaque requête vers un lambda
 * indépendant ; un `Mutex` local (async-mutex) ne protège donc QUE le burst
 * dans la même instance. Sous charge réelle (2 utilisateurs cliquant
 * « Facturer » en même temps depuis 2 navigateurs), 2 lambdas peuvent lire
 * la même valeur du compteur B3 → 2 factures avec le MÊME numéro.
 *
 * Pattern utilisé : SET key value NX EX ttl (Redis SETNX + expiration).
 *   - `nx: true` → set seulement si la clé n'existe pas (acquisition atomique)
 *   - `ex: ttlSec` → la clé expire automatiquement (failsafe si le caller crash)
 *
 * Fallback : si `KV_REST_API_URL` n'est pas configuré (dev local, tests
 * unitaires), `acquireLock` retourne toujours `true` sans aucune coordination.
 * Le code redevient alors équivalent au comportement v1.1.2 (Mutex local seul).
 *
 * Usage :
 *
 *   const release = await withDistributedLock('counter:facture', 30, async () => {
 *     // section critique : read + write Sheets
 *   });
 *
 * En cas d'échec d'acquisition au bout de `maxWaitMs`, lance
 * `DistributedLockTimeoutError` — le caller doit la mapper sur un 503 ou
 * laisser l'utilisateur réessayer.
 */
import { kv } from '@vercel/kv';
import { randomUUID } from 'crypto';

const KV_ENABLED = !!process.env.KV_REST_API_URL;

export class DistributedLockTimeoutError extends Error {
  constructor(key: string, waitedMs: number) {
    super(`Lock '${key}' indisponible après ${waitedMs}ms`);
    this.name = 'DistributedLockTimeoutError';
  }
}

/** Tente d'acquérir le verrou jusqu'à `maxWaitMs`. Retourne le token (à
 *  passer à `releaseLock`) ou lance `DistributedLockTimeoutError`. */
export async function acquireLock(
  key: string,
  ttlSec: number = 30,
  maxWaitMs: number = 5000,
): Promise<string> {
  const token = randomUUID();
  if (!KV_ENABLED) return token; // dev local : pas de coordination

  const fullKey = `lock:${key}`;
  const deadline = Date.now() + maxWaitMs;
  let attempt = 0;

  while (Date.now() < deadline) {
    try {
      const result = await kv.set(fullKey, token, { nx: true, ex: ttlSec });
      // Upstash : retourne 'OK' si la clé a été créée, null sinon
      if (result === 'OK') return token;
    } catch (err: any) {
      // KV indisponible (rate limit, panne) → on échoue ouvert (cas dégradé)
      console.warn('[lock] acquire failed:', key, err?.message);
      return token;
    }
    // Backoff progressif : 50ms, 100ms, 200ms, 400ms, 400ms...
    const wait = Math.min(50 * Math.pow(2, attempt++), 400);
    await new Promise(r => setTimeout(r, wait));
  }

  throw new DistributedLockTimeoutError(key, maxWaitMs);
}

/** Libère le verrou seulement si le token correspond (évite de libérer
 *  un verrou qui aurait expiré et été re-acquis par quelqu'un d'autre). */
export async function releaseLock(key: string, token: string): Promise<void> {
  if (!KV_ENABLED) return;
  const fullKey = `lock:${key}`;
  try {
    // Pseudo-CAS : lit la valeur, ne supprime que si ça matche.
    // Pas atomique, mais TTL=30s limite la fenêtre de drift.
    const current = await kv.get<string>(fullKey);
    if (current === token) await kv.del(fullKey);
  } catch (err: any) {
    console.warn('[lock] release failed:', key, err?.message);
  }
}

/** Wrapper try/finally : acquiert, exécute, libère systématiquement. */
export async function withDistributedLock<T>(
  key: string,
  ttlSec: number,
  fn: () => Promise<T>,
): Promise<T> {
  const token = await acquireLock(key, ttlSec);
  try {
    return await fn();
  } finally {
    await releaseLock(key, token);
  }
}
