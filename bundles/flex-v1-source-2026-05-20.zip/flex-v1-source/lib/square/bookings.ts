/**
 * Intégration Square Booking API (MVP lecture seule).
 *
 * Docs : https://developer.squareup.com/reference/square/bookings-api
 *
 * Auth : Personal Access Token côté serveur (env var SQUARE_ACCESS_TOKEN,
 *        récupéré dans Square Dashboard → Developer → Credentials).
 * Location : ID de l'atelier (env var SQUARE_LOCATION_ID).
 * Environnement : SQUARE_ENV = 'production' (défaut) ou 'sandbox'.
 *
 * Endpoints utilisés :
 *  - GET /v2/bookings?location_id=…&start_at_min=…&start_at_max=…
 *  - GET /v2/customers/{customer_id}
 *  - GET /v2/catalog/object/{object_id} (pour le nom du service)
 *
 * Le code fait 1 requête bookings + N requêtes customer (une par RDV) en
 * parallèle. Cache in-memory 2 min pour ne pas hammer Square à chaque
 * Dashboard refresh.
 */
import cache from '@/lib/cache';

const BASE_URL = 'https://connect.squareup.com';
const SANDBOX_URL = 'https://connect.squareupsandbox.com';
const SQUARE_VERSION = '2024-10-17';
const CACHE_KEY = 'square-bookings';
const CACHE_TTL_SECONDS = 120;

export interface SquareBooking {
  id         : string;
  startAt    : string;     // ISO
  status     : string;     // ACCEPTED, CANCELLED_BY_SELLER, etc.
  durationMin: number;
  customerId : string;
  /** Resolved client (si fetched) */
  customer?  : {
    id        : string;
    prenom    : string;
    nom       : string;
    email     : string;
    tel       : string;
    /** Note libre du customer profile Square (champ note) */
    customerProfileNote?: string;
  };
  /** Noms des services réservés, séparés par " · " */
  services   : string;
  locationId : string;
  /** Note client laissée lors du booking Square (champ customer_note) */
  customerNote?: string;
  /** Note interne du seller (champ seller_note) */
  sellerNote?  : string;
  /** veloId du BDT déjà créé pour ce RDV (null si pas encore sync) — enrichi par /api/square/bookings */
  syncedVeloId?: string | null;
}

/**
 * v1.0.22+ : détecte si un RV Square correspond à un retrait ou essayage
 * (workflow secondaire — pas de création de BDT auto). Ces RV apparaissent
 * au Dashboard mais doivent être **liés manuellement** à un BDT existant du
 * client (typiquement le BDT déjà facturé pour lequel le client revient).
 *
 * Règle : match substring case-insensitive sur les mots `retrait` ou
 * `essayage` dans le libellé des services. Le RV `dépôt et évaluation` n'est
 * PAS concerné — il continue de créer un BDT comme d'habitude.
 *
 * Exemples qui matchent :
 *   - "👋 Rencontre : retrait et essayage"
 *   - "👋 Rencontre : essayage et position de conduite"
 *   - "Retrait final"
 *   - "Essayage seul"
 */
export function isRetraitEssayage(services: string | null | undefined): boolean {
  const s = (services ?? '').toLowerCase();
  return s.includes('retrait') || s.includes('essayage');
}

function baseUrl(): string {
  return process.env.SQUARE_ENV === 'sandbox' ? SANDBOX_URL : BASE_URL;
}

function headers(): HeadersInit {
  const token = process.env.SQUARE_ACCESS_TOKEN;
  if (!token) throw new Error('SQUARE_ACCESS_TOKEN non configuré (env var manquante)');
  return {
    'Authorization' : `Bearer ${token}`,
    'Square-Version': SQUARE_VERSION,
    'Content-Type'  : 'application/json',
  };
}

/** Appel API générique avec gestion d'erreur. */
async function sqFetch<T = any>(path: string): Promise<T> {
  const res = await fetch(`${baseUrl()}${path}`, { headers: headers(), cache: 'no-store' });
  if (!res.ok) {
    const txt = await res.text().catch(() => '');
    throw new Error(`Square ${path} → ${res.status} : ${txt.slice(0, 200)}`);
  }
  return res.json();
}

/** Liste les RDV Square dans la fenêtre [now − 24 h, now + daysAhead].
 *  Square limite chaque requête à 31 j max → on paginate en chunks de
 *  30 j si daysAhead > 30.
 *
 *  v1.0.19+ : la borne basse est `now − 24 h` (et non `now`) pour garder
 *  les RDV récents visibles le jour-même au dashboard (cf. demande user :
 *  « Garder les rdv dans le Dashboard jusqu'au rv »). */
export async function getUpcomingBookings(daysAhead = 30): Promise<SquareBooking[]> {
  const cached = await cache.get<SquareBooking[]>(CACHE_KEY);
  if (cached) return cached;

  const locationId = process.env.SQUARE_LOCATION_ID;
  if (!locationId) throw new Error('SQUARE_LOCATION_ID non configuré');

  const CHUNK_DAYS = 30;
  const now        = new Date();
  // v1.0.19+ : Garder les RDV visibles 24 h après leur début. Couvre le
  // cas où le client arrive avec du retard, ou que le BDT n'a pas encore
  // été créé pour le RDV en cours. Au-delà de 24 h, le RDV est considéré
  // « passé » et disparaît du dashboard. Le user peut toujours le
  // récupérer dans Square Bookings directement si besoin.
  const startMin   = new Date(now.getTime() - 24 * 3600 * 1000);
  const end        = new Date(now.getTime() + daysAhead * 86400_000);

  // Collecte en paginant par fenêtres de 30j
  const raw: any[] = [];
  let windowStart = startMin;
  while (windowStart < end) {
    const windowEnd = new Date(Math.min(
      windowStart.getTime() + CHUNK_DAYS * 86400_000,
      end.getTime(),
    ));
    const params = new URLSearchParams({
      location_id : locationId,
      start_at_min: windowStart.toISOString(),
      start_at_max: windowEnd.toISOString(),
      limit       : '50',
    });
    const data = await sqFetch<{ bookings?: any[] }>(`/v2/bookings?${params}`);
    raw.push(...(data.bookings ?? []));
    windowStart = windowEnd;
  }

  // Résolution parallèle des customers + services
  const customerIds = [...new Set(raw.map(b => b.customer_id).filter(Boolean))];
  const serviceIds  = [...new Set(raw.flatMap(b => (b.appointment_segments ?? []).map((s: any) => s.service_variation_id)).filter(Boolean))];

  const [customers, services] = await Promise.all([
    Promise.all(customerIds.map(id => sqFetch<any>(`/v2/customers/${id}`).catch(() => null))),
    // include_related_objects=true → ramène aussi l'ITEM parent pour
    // récupérer son nom (item_data.name) au lieu du nom de variation
    // (ex. "Article de base" qui est le défaut Square).
    Promise.all(serviceIds.map(id  =>
      sqFetch<any>(`/v2/catalog/object/${id}?include_related_objects=true`).catch(() => null)
    )),
  ]);
  const customerMap = new Map<string, any>();
  customers.forEach(c => { if (c?.customer) customerMap.set(c.customer.id, c.customer); });
  const serviceMap = new Map<string, string>();
  services.forEach(s => {
    const obj = s?.object;
    if (!obj?.id) return;
    // Priorité : nom du parent ITEM (plus parlant que la variation)
    const parentItemId = obj.item_variation_data?.item_id;
    let parentName = '';
    if (parentItemId && Array.isArray(s.related_objects)) {
      const parent = s.related_objects.find((r: any) => r.id === parentItemId && r.type === 'ITEM');
      parentName = (parent?.item_data?.name ?? '').trim();
    }
    const variationName = (obj.item_variation_data?.name ?? '').trim();
    // Si le parent a un nom et la variation est "Article de base" (défaut)
    // ou identique au parent → utilise le parent. Sinon "Parent — Variation"
    // pour les cas où la variation est significative (ex. tailles).
    let displayName: string;
    if (!parentName && !variationName) return;
    if (!parentName) displayName = variationName;
    else if (!variationName || variationName === 'Article de base' || variationName === parentName) {
      displayName = parentName;
    } else {
      displayName = `${parentName} — ${variationName}`;
    }
    if (displayName) serviceMap.set(obj.id, displayName);
  });

  const bookings: SquareBooking[] = raw.map(b => {
    const cust = customerMap.get(b.customer_id);
    const segs = b.appointment_segments ?? [];
    const svcNames = segs.map((s: any) => serviceMap.get(s.service_variation_id)).filter(Boolean);
    const totalMin = segs.reduce((t: number, s: any) => t + (s.duration_minutes ?? 0), 0);
    return {
      id         : b.id,
      startAt    : b.start_at,
      status     : b.status,
      durationMin: totalMin,
      customerId : b.customer_id,
      customer   : cust ? {
        id    : cust.id,
        prenom: (cust.given_name  ?? '').trim(),
        nom   : (cust.family_name ?? '').trim(),
        email : (cust.email_address ?? '').trim(),
        tel   : (cust.phone_number ?? '').trim(),
        customerProfileNote: (cust.note ?? '').trim() || undefined,
      } : undefined,
      services   : svcNames.join(' · '),
      customerNote: (b.customer_note ?? '').trim() || undefined,
      sellerNote  : (b.seller_note   ?? '').trim() || undefined,
      locationId : b.location_id ?? locationId,
    };
  })
  // Tri chronologique ascendant
  .sort((a, b) => (a.startAt || '').localeCompare(b.startAt || ''));

  await cache.set(CACHE_KEY, bookings, CACHE_TTL_SECONDS);
  return bookings;
}

/** Force la re-lecture au prochain appel (bypass cache). */
export async function invalidateBookingsCache(): Promise<void> {
  await cache.del(CACHE_KEY);
}

/**
 * Fetch d'un booking par ID. Inclut les CANCELLED_* (contrairement à
 * la liste GET /v2/bookings qui ne retourne que ACCEPTED par défaut).
 * Retourne null si introuvable.
 */
export async function getBookingById(bookingId: string): Promise<{
  id     : string;
  status : string;
  startAt: string;
} | null> {
  try {
    const data = await sqFetch<{ booking?: any }>(`/v2/bookings/${bookingId}`);
    const b = data.booking;
    if (!b) return null;
    return {
      id     : b.id,
      status : String(b.status ?? ''),
      startAt: String(b.start_at ?? ''),
    };
  } catch {
    return null;
  }
}
