/**
 * Handlers pour les évènements Square Booking reçus via webhook.
 *
 * Évènements gérés :
 *  - booking.created  → crée le BDT (réutilise sync logique)
 *  - booking.updated  → met à jour date/heure du vélo + Calendar event
 *  - booking.canceled → supprime BDT (si encore RV) + Calendar event
 *
 * Idempotence : on lit toujours `_EMAIL_TEMPLATES_` pour savoir si le
 * booking est déjà mappé, donc safe en cas de webhook redélivré.
 */
import { getEmailTemplates,
         saveEmailTemplates }      from '@/lib/sheets/emailTemplates';
import { getUpcomingBookings,
         invalidateBookingsCache } from './bookings';
import { syncUpcomingBookings,
         syncCancellations }       from './sync';
import { getVelo, updateVelo }     from '@/lib/sheets/inventaire';
import { isoToMontrealDateHeure }  from '@/lib/utils/format';
import { getOwnerAccessToken,
         NoOwnerTokenError }       from '@/lib/google/ownerToken';
import { createCalendarEvent,
         deleteCalendarEvent }     from '@/lib/google/calendar';

/**
 * booking.created : déclenche un mini-sync ciblé. On invalide le cache
 * des bookings puis on appelle syncUpcomingBookings qui fera le bon job
 * (dédupe par sq_<id>, créé client+vélo+BDC+Calendar si nouveau).
 */
export async function handleBookingCreated(_bookingId: string): Promise<void> {
  await invalidateBookingsCache();
  await syncUpcomingBookings(180);
}

/**
 * booking.updated : si la date/heure ou les services ont changé,
 * met à jour la date1 du vélo INVENTAIRE et l'event Calendar (delete +
 * recreate, plus simple que un PATCH).
 */
export async function handleBookingUpdated(bookingId: string): Promise<void> {
  await invalidateBookingsCache();
  const tpl = await getEmailTemplates();
  const veloId  = (tpl[`sq_${bookingId}`] ?? '').trim();
  const eventId = (tpl[`sq_cal_${bookingId}`] ?? '').trim();
  if (!veloId) {
    // Pas encore mappé → on traite comme un création
    await syncUpcomingBookings(180);
    return;
  }

  const bookings = await getUpcomingBookings(180);
  const booking  = bookings.find(b => b.id === bookingId);
  if (!booking) return;
  if (booking.status && /CANCEL/i.test(booking.status)) {
    // Si le booking est annulé, on délègue à syncCancellations
    await syncCancellations(180);
    return;
  }

  // Met à jour la date1 du vélo (heure du RDV)
  try {
    const velo = await getVelo(veloId);
    if (velo) {
      const newDate = isoToMontrealDateHeure(booking.startAt) || booking.startAt;
      if (velo.date1 !== newDate) {
        await updateVelo(veloId, { date1: newDate });
      }
    }
  } catch (err: any) {
    console.warn('[webhook update] updateVelo échec', err?.message);
  }

  // Recrée l'event Calendar (delete + create) si owner token dispo
  try {
    const ownerToken = await getOwnerAccessToken();
    if (eventId) {
      try {
        await deleteCalendarEvent(eventId, ownerToken.accessToken, ownerToken.refreshToken);
      } catch { /* best-effort */ }
    }
    if (booking.customer) {
      const clientNom = `${booking.customer.prenom} ${booking.customer.nom}`.trim();
      const newEventId = await createCalendarEvent({
        summary     : `RDV ${booking.services || 'Éval.'} : ${clientNom}`,
        startAtIso  : booking.startAt,
        durationMin : booking.durationMin || 60,
        description : [
          `Client : ${clientNom}`,
          booking.customer.email ? `Courriel : ${booking.customer.email}` : '',
          booking.customer.tel ? `Tél : ${booking.customer.tel}` : '',
          `Services : ${booking.services || 'À renseigner au RDV'}`,
          '',
          `BDT FLEX-REV : #${veloId}`,
        ].filter(Boolean).join('\n'),
        attendeeEmail: booking.customer.email || undefined,
        attendeeName : clientNom,
      }, ownerToken.accessToken, ownerToken.refreshToken);
      await saveEmailTemplates({ [`sq_cal_${bookingId}`]: newEventId });
    }
  } catch (err: any) {
    if (!(err instanceof NoOwnerTokenError)) {
      console.warn('[webhook update] Calendar échec', err?.message);
    }
  }
}

/**
 * booking.canceled : délègue à syncCancellations qui sait nettoyer
 * (delete vélo + BDC si encore RV, sinon juste retire le mapping).
 */
export async function handleBookingCanceled(_bookingId: string): Promise<void> {
  await invalidateBookingsCache();
  await syncCancellations(180);
}
