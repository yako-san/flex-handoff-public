/**
 * Orchestration de la synchronisation Square → FLEX-REV.
 *
 * Deux opérations principales, partagées par le cron auto-sync
 * (/api/square/sync) et par le bouton manuel du Dashboard
 * (/api/square/create-bdt) :
 *
 *  1. syncUpcomingBookings()  — pour chaque RDV ACCEPTED à venir qui
 *     n'a pas encore de mapping `sq_<id>` dans _EMAIL_TEMPLATES_ :
 *     crée client (si nécessaire) + vélo (statut RV) + BDC, puis
 *     mémorise le mapping bookingId → veloId.
 *
 *  2. syncCancellations()     — pour chaque mapping `sq_<id>` existant,
 *     vérifie si le RDV Square correspondant est maintenant annulé
 *     (status CANCELLED_*). Si oui ET que le vélo est toujours en
 *     statut RV (pas encore avancé), supprime le vélo + BDC + mapping.
 *     Si le vélo a avancé, on supprime seulement le mapping pour
 *     éviter de réessayer en boucle.
 *
 * Les deux fonctions sont safe à appeler plusieurs fois (idempotent).
 */
import { getUpcomingBookings, getBookingById, isRetraitEssayage } from './bookings';
import { getClients, creerClient } from '@/lib/sheets/clients';
import { addVelo, getVelo, deleteVelo } from '@/lib/sheets/inventaire';
import { creerBon, deleteBDC } from '@/lib/sheets/bdc';
import { prochainID } from '@/lib/sheets/counter';
import { getEmailTemplates, saveEmailTemplates } from '@/lib/sheets/emailTemplates';
import { telDigits, isoToMontrealDateHeure, isoToMontrealDateHeureInline } from '@/lib/utils/format';
import { getOwnerAccessToken, NoOwnerTokenError } from '@/lib/google/ownerToken';
import { createCalendarEvent, deleteCalendarEvent } from '@/lib/google/calendar';

export interface SyncResult {
  created        : Array<{ bookingId: string; veloId: string; clientName: string }>;
  cancelled      : Array<{ bookingId: string; veloId: string; deleted: boolean }>;
  skipped        : number;
  errors         : Array<{ bookingId: string; error: string }>;
  /** Erreurs spécifiques à la création Calendar — best-effort, n'empêche
   *  pas la création du BDT mais permet à l'UI/admin de voir ce qui plante
   *  côté token Google (refresh révoqué, scope manquant, quota, etc.). */
  calendarErrors?: Array<{ bookingId: string; error: string }>;
  /** Statut global owner token. 'ok' = présent et fonctionne, 'missing' =
   *  env var GOOGLE_OWNER_REFRESH_TOKEN absente, 'failed' = présente mais
   *  échec d'échange (token révoqué/expiré). */
  ownerTokenStatus?: 'ok' | 'missing' | 'failed';
}

/**
 * Crée les BDT manquants pour tous les RDV à venir non encore synchronisés.
 * Retourne la liste des créations + erreurs.
 */
export async function syncUpcomingBookings(daysAhead = 180): Promise<Omit<SyncResult, 'cancelled'>> {
  const result: Omit<SyncResult, 'cancelled'> = {
    created: [], skipped: 0, errors: [],
    calendarErrors: [], ownerTokenStatus: 'missing',
  };

  const bookings  = await getUpcomingBookings(daysAhead);
  const templates = await getEmailTemplates();

  // On charge clients 1 seule fois (au lieu de N fois dans la boucle)
  const grouped    = await getClients(false);
  const allClients = [...grouped.recents, ...grouped.actifs, ...grouped.autres];

  // Token Google owner (si configuré) — utilisé pour créer l'évènement
  // Calendar. Si absent, on skip juste la partie Calendar.
  let ownerToken: { accessToken: string; refreshToken: string } | null = null;
  try {
    ownerToken = await getOwnerAccessToken();
    result.ownerTokenStatus = 'ok';
  } catch (err) {
    if (err instanceof NoOwnerTokenError) {
      result.ownerTokenStatus = 'missing';
    } else {
      result.ownerTokenStatus = 'failed';
      const msg = (err as any)?.message ?? String(err);
      console.warn('[sync] getOwnerAccessToken échec :', msg);
      // Une seule erreur globale, même si N RDV à syncer.
      result.calendarErrors!.push({ bookingId: '*', error: `Owner token : ${msg}` });
    }
  }

  for (const booking of bookings) {
    try {
      // Ignorer les RDV annulés ou sans client
      if (booking.status && /CANCEL/i.test(booking.status)) {
        result.skipped++;
        continue;
      }
      if (!booking.customer) {
        result.skipped++;
        continue;
      }

      // Déjà synchronisé ?
      if (templates[`sq_${booking.id}`]) {
        result.skipped++;
        continue;
      }

      // v1.0.22+ : RV retrait/essayage = ne PAS créer de BDT auto. Ces RV
      // doivent être liés manuellement à un BDT existant du client (le BDT
      // pour lequel le client revient). Action côté Dashboard via le bouton
      // « 🔗 Lier au BDT » + modal liste BDT actifs du client.
      // Le RV reste visible au Dashboard tant que dans la fenêtre 24h grace
      // (cf v1.0.19), puis disparaît naturellement.
      if (isRetraitEssayage(booking.services)) {
        result.skipped++;
        continue;
      }

      // Matching client par email ou téléphone normalisé
      const emailNorm = booking.customer.email.toLowerCase().trim();
      const telNorm   = telDigits(booking.customer.tel);
      const existing  = allClients.find(c => {
        if (emailNorm && (c.courriel ?? '').toLowerCase() === emailNorm) return true;
        if (telNorm   && telDigits(c.tel) === telNorm) return true;
        return false;
      });

      let clientNom: string;
      if (existing) {
        clientNom = existing.nomComplet;
      } else {
        const nouveau = await creerClient({
          prenom  : booking.customer.prenom || 'Client',
          nom     : booking.customer.nom    || 'Square',
          tel     : booking.customer.tel,
          courriel: booking.customer.email,
          commPref: (templates.client_default_commpref as any) || 'Courriel,Texto',
          lang    : ((templates.client_default_lang === 'EN' ? 'EN' : 'FR') as any),
          lead    : 'yako.cyclo',
          notes   : `Pré-inscription Square · RDV ${isoToMontrealDateHeure(booking.startAt)}${booking.services ? ' · ' + booking.services : ''}`,
        } as any);
        clientNom = nouveau.nomComplet;
        // On l'ajoute à la liste en mémoire pour que le prochain RDV du même
        // client (peu probable mais possible) le retrouve sans re-créer.
        allClients.push({ ...nouveau });
      }

      const veloId = await prochainID();
      // Construit la note interne : texte auto avant séparation, note
      // client (et seller) après. Convention même que les autres BDT.
      const sepLine    = '──────────────────────';
      // v1.0.20+ : date inline (virgule au lieu de \n) + retrait du préfixe
      // « Services : » pour rester compact et lisible en haut de note.
      const autoHeader = [
        `Pré-inscription Square — ${isoToMontrealDateHeureInline(booking.startAt)}`,
        `Client : ${clientNom}`,
        booking.services || '',
      ].filter(Boolean).join('\n');
      const userNotes = [
        booking.customerNote ? `Note client : ${booking.customerNote}` : '',
        booking.sellerNote   ? `Note seller : ${booking.sellerNote}`   : '',
      ].filter(Boolean).join('\n\n');
      const noteInterne = `${autoHeader}\n${sepLine}\n${userNotes}`.trim();

      await addVelo(veloId, {
        client: clientNom,
        status: 'RV',
        date1 : isoToMontrealDateHeure(booking.startAt) || booking.startAt,
        notes : noteInterne,
      });
      await creerBon(veloId, clientNom, booking.services || 'À renseigner au RDV');
      await saveEmailTemplates({ [`sq_${booking.id}`]: veloId });

      // Créer l'événement Calendar (best-effort, ownerToken peut être null)
      if (ownerToken) {
        try {
          const eventId = await createCalendarEvent({
            summary     : `RDV ${booking.services || 'Éval.'} : ${clientNom}`,
            startAtIso  : booking.startAt,
            durationMin : booking.durationMin || 60,
            description : [
              `Client : ${clientNom}`,
              booking.customer.email ? `Courriel : ${booking.customer.email}` : '',
              booking.customer.tel ? `Tél : ${booking.customer.tel}` : '',
              `Services : ${booking.services || 'À renseigner au RDV'}`,
              '',
              `BDT FLEX-REV : #${veloId}`,
            ].filter(Boolean).join('\n'),
            attendeeEmail: booking.customer.email || undefined,
            attendeeName : clientNom,
          }, ownerToken.accessToken, ownerToken.refreshToken);
          await saveEmailTemplates({ [`sq_cal_${booking.id}`]: eventId });
        } catch (calErr: any) {
          const msg = calErr?.message ?? String(calErr);
          console.warn('[sync] Calendar event création échec pour', booking.id, ':', msg);
          result.calendarErrors!.push({ bookingId: booking.id, error: msg });
        }
      }

      result.created.push({ bookingId: booking.id, veloId, clientName: clientNom });
    } catch (err: any) {
      result.errors.push({
        bookingId: booking.id,
        error    : err?.message ?? 'Erreur inconnue',
      });
    }
  }

  return result;
}

/**
 * Détecte les annulations Square et nettoie les BDT correspondants.
 * On regarde la fenêtre large (180j) — si un booking mappé n'y est plus
 * ou est en statut CANCELLED_*, on nettoie.
 */
export async function syncCancellations(daysAhead = 180): Promise<Pick<SyncResult, 'cancelled' | 'errors'>> {
  const out: Pick<SyncResult, 'cancelled' | 'errors'> = { cancelled: [], errors: [] };

  const bookings  = await getUpcomingBookings(daysAhead);
  const templates = await getEmailTemplates();
  const bookingById = new Map(bookings.map(b => [b.id, b]));

  // Token Google owner pour supprimer l'évènement Calendar (optionnel)
  let ownerToken: { accessToken: string; refreshToken: string } | null = null;
  try { ownerToken = await getOwnerAccessToken(); } catch { /* pas configuré */ }

  // Toutes les clés sq_* dans les templates — on filtre sq_<id> (pas
  // sq_cal_<id> qui est l'eventId Calendar)
  const syncedKeys = Object.keys(templates).filter(k =>
    k.startsWith('sq_') && !k.startsWith('sq_cal_'),
  );

  for (const key of syncedKeys) {
    const bookingId = key.replace(/^sq_/, '');
    const veloId    = templates[key];
    if (!veloId) continue;

    // Fetch le statut actuel : la liste /v2/bookings ne retourne pas
    // les CANCELLED par défaut, donc si pas trouvé dans la liste on
    // fait un GET ciblé /v2/bookings/{id} qui inclut tous les statuts.
    let status = '';
    const fromList = bookingById.get(bookingId);
    if (fromList) {
      status = fromList.status ?? '';
    } else {
      const fetched = await getBookingById(bookingId);
      if (!fetched) continue; // booking vraiment introuvable (supprimé hard) → skip
      status = fetched.status;
    }
    if (!/CANCEL/i.test(status)) continue;

    try {
      const velo = await getVelo(veloId);
      // Supprimer l'évènement Calendar correspondant (si owner token
      // configuré ET qu'on a stocké un eventId)
      const calKey   = `sq_cal_${bookingId}`;
      const eventId  = templates[calKey];
      if (ownerToken && eventId) {
        try {
          await deleteCalendarEvent(eventId, ownerToken.accessToken, ownerToken.refreshToken);
        } catch (calErr: any) {
          console.warn('[sync] Calendar delete échec pour', eventId, ':', calErr?.message);
        }
        await saveEmailTemplates({ [calKey]: '' });
      }

      // Si le vélo existe toujours en statut RV → on peut supprimer.
      // Sinon (a avancé : REÇU, ÉVAL., etc.) → on préserve le BDT et
      // on nettoie juste le mapping pour ne pas re-loop.
      if (velo && velo.status === 'RV') {
        // Supprimer BDC puis vélo (ordre important si checks FK futurs)
        try { await deleteBDC(veloId); } catch { /* best-effort */ }
        try { await deleteVelo(veloId); } catch { /* best-effort */ }
        await saveEmailTemplates({ [key]: '' });
        out.cancelled.push({ bookingId, veloId, deleted: true });
      } else {
        // Vélo avancé ou inexistant → juste nettoyer le mapping
        await saveEmailTemplates({ [key]: '' });
        out.cancelled.push({ bookingId, veloId, deleted: false });
      }
    } catch (err: any) {
      out.errors.push({
        bookingId,
        error: err?.message ?? 'Erreur inconnue',
      });
    }
  }

  return out;
}
