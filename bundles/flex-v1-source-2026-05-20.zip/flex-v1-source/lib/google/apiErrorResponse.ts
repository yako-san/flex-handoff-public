import { NextResponse } from 'next/server';
import { GoogleAuthError, isAuthError } from './withTokenRetry';

/**
 * Transforme une erreur de route API en NextResponse standardisée.
 *
 * - GoogleAuthError (token expiré + refresh raté) → 401 avec
 *   `{ error, code: 'GOOGLE_AUTH_EXPIRED', reconnect: true }`
 * - Autre 401 (sans refresh possible) → idem fallback
 * - Toute autre erreur → 500 avec `{ error }`
 *
 * Le champ `reconnect: true` permet au client d'afficher un toast /
 * bannière avec un CTA « Se reconnecter » plutôt qu'un message cryptique.
 */
export function googleApiError(err: any): NextResponse {
  if (err instanceof GoogleAuthError) {
    return NextResponse.json(
      { error: err.userMessage, code: err.code, reconnect: true },
      { status: 401 },
    );
  }
  if (isAuthError(err)) {
    return NextResponse.json(
      {
        error   : 'Session Google expirée — reconnecte-toi pour continuer',
        code    : 'GOOGLE_AUTH_EXPIRED',
        reconnect: true,
      },
      { status: 401 },
    );
  }
  return NextResponse.json(
    { error: err?.message || 'Erreur inconnue' },
    { status: 500 },
  );
}
