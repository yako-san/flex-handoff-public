/**
 * Google Calendar (v3) — création + suppression d'événements RDV Square.
 *
 * Utilise l'OAuth utilisateur (yako.cyclo@gmail.com) — les événements sont
 * créés dans SON calendrier principal, pas dans un service account.
 *
 * Prérequis Google Cloud Console :
 *   - Calendar API activée
 *   - Scope `https://www.googleapis.com/auth/calendar.events` dans
 *     l'OAuth consent (ajouté dans lib/auth.ts)
 *
 * Timezone forcée : America/Toronto (les horaires Square sont en UTC,
 * on les passe tels quels à Google qui gère la conversion locale).
 */
import { google } from 'googleapis';
import { withTokenRetry } from './withTokenRetry';

function getCalendar(accessToken: string, refreshToken?: string) {
  const oauth2Client = new google.auth.OAuth2(
    process.env.AUTH_GOOGLE_ID,
    process.env.AUTH_GOOGLE_SECRET,
  );
  oauth2Client.setCredentials({
    access_token : accessToken,
    refresh_token: refreshToken ?? null,
  });
  return google.calendar({ version: 'v3', auth: oauth2Client });
}

export interface EventData {
  /** Titre affiché dans le calendrier. Ex : "RDV Éval. : Étienne Mayrand" */
  summary    : string;
  /** Date/heure de début — ISO string (peut être UTC ou avec offset) */
  startAtIso : string;
  /** Durée en minutes (défaut 60 si < 5) */
  durationMin: number;
  /** Description longue (services, lien BDT, etc.) */
  description?: string;
  /** Email du client à inviter — il recevra l'invitation Calendar */
  attendeeEmail?: string;
  /** Nom du client pour l'affichage de l'attendee */
  attendeeName?: string;
}

/**
 * Crée un événement dans le calendrier principal (primary).
 * Envoie l'invitation à l'attendee (sendUpdates: all).
 * Retourne l'eventId (pour pouvoir le supprimer plus tard).
 */
export async function createCalendarEvent(
  data          : EventData,
  accessToken   : string,
  refreshToken ?: string,
): Promise<string> {
  return withTokenRetry(async (token) => {
    const cal = getCalendar(token, refreshToken);
    const start = new Date(data.startAtIso);
    const duration = Math.max(data.durationMin || 0, 5); // minimum 5 min
    const end = new Date(start.getTime() + duration * 60_000);

    const attendees = data.attendeeEmail
      ? [{
          email       : data.attendeeEmail,
          displayName : data.attendeeName ?? undefined,
          responseStatus: 'needsAction' as const,
        }]
      : undefined;

    const res = await cal.events.insert({
      calendarId : 'primary',
      sendUpdates: 'all',   // email invitation au client
      requestBody: {
        summary    : data.summary,
        description: data.description,
        start      : {
          dateTime: start.toISOString(),
          timeZone: 'America/Toronto',
        },
        end        : {
          dateTime: end.toISOString(),
          timeZone: 'America/Toronto',
        },
        attendees,
        reminders  : {
          useDefault: false,
          overrides : [
            { method: 'popup', minutes: 60 },
            { method: 'email', minutes: 24 * 60 },
          ],
        },
      },
    });

    const eventId = res.data.id;
    if (!eventId) throw new Error('Calendar : eventId absent de la réponse');
    return eventId;
  }, accessToken, refreshToken);
}

/**
 * Supprime un événement du calendrier primary. Best-effort : 404 = déjà
 * supprimé, pas d'erreur. Envoie la notification d'annulation aux attendees.
 */
export async function deleteCalendarEvent(
  eventId       : string,
  accessToken   : string,
  refreshToken ?: string,
): Promise<void> {
  if (!eventId) return;
  await withTokenRetry(async (token) => {
    const cal = getCalendar(token, refreshToken);
    try {
      await cal.events.delete({
        calendarId : 'primary',
        eventId    ,
        sendUpdates: 'all',
      });
    } catch (err: any) {
      const status = err?.response?.status ?? err?.code;
      if (status !== 404 && status !== 410) throw err;
      // 404/410 → déjà supprimé, on ne throw pas
    }
  }, accessToken, refreshToken);
}
