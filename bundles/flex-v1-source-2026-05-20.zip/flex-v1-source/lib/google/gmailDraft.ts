/**
 * Helper léger pour créer un brouillon Gmail texte simple (pas de PDF,
 * pas de HTML, pas de CC). Utilisé pour les courriels de suivi
 * post-archivage.
 */
import { google } from 'googleapis';
import { withTokenRetry } from './withTokenRetry';

export interface DraftInput {
  to        : string;
  subject   : string;
  /** Corps texte brut. Les retours à la ligne sont préservés. */
  body      : string;
}

function gmailClient(accessToken: string, refreshToken?: string) {
  const oauth2 = new google.auth.OAuth2(
    process.env.AUTH_GOOGLE_ID,
    process.env.AUTH_GOOGLE_SECRET,
  );
  oauth2.setCredentials({
    access_token : accessToken,
    refresh_token: refreshToken ?? null,
  });
  return google.gmail({ version: 'v1', auth: oauth2 });
}

/**
 * Crée un brouillon Gmail dans la boîte du user connecté.
 *
 * Le body peut contenir du HTML (`<strong>`, `<a href="…">…</a>`, etc.)
 * — les tags seront rendus par Gmail. Les retours à la ligne `\n` sont
 * convertis en `<br>` pour préserver le formatage des templates en
 * texte brut. Si le template ne contient aucun tag HTML, le rendu reste
 * lisible (juste des paragraphes séparés par <br>).
 *
 * Retourne { draftId, draftUrl } pour ouvrir le brouillon dans Gmail.
 */
export async function createSimpleDraft(
  input        : DraftInput,
  accessToken  : string,
  refreshToken?: string,
): Promise<{ draftId: string; draftUrl: string }> {
  return withTokenRetry(async (token) => {
    const gmail = gmailClient(token, refreshToken);

    const subjectEncoded = `=?UTF-8?B?${Buffer.from(input.subject).toString('base64')}?=`;

    // Détection : le body contient-il du HTML déjà rendu ?
    const looksLikeHtml = /<\w+[\s>]/.test(input.body);

    // Conversion : si pas de HTML, on échappe les caractères spéciaux
    // pour qu'ils s'affichent correctement, puis on remplace les \n
    // par <br>. Si HTML présent, on remplace juste les \n par \n + <br>
    // (préserve l'indentation visuelle du source HTML).
    const escapeHtml = (s: string) =>
      s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

    const htmlBody = looksLikeHtml
      ? input.body.replace(/\r?\n/g, '<br>\n')
      : `<div style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.5;">${escapeHtml(input.body).replace(/\r?\n/g, '<br>\n')}</div>`;

    const rawParts = [
      `To: ${input.to}`,
      `Subject: ${subjectEncoded}`,
      'MIME-Version: 1.0',
      'Content-Type: text/html; charset=UTF-8',
      'Content-Transfer-Encoding: base64',
      '',
      ...(Buffer.from(htmlBody, 'utf-8').toString('base64').match(/.{1,76}/g) ?? []),
    ];
    const encoded = Buffer.from(rawParts.join('\r\n')).toString('base64url');

    const draft = await gmail.users.drafts.create({
      userId     : 'me',
      requestBody: { message: { raw: encoded } },
    });

    return {
      draftId : draft.data.id ?? '',
      draftUrl: 'https://mail.google.com/mail/u/0/#drafts',
    };
  }, accessToken, refreshToken);
}
