/**
 * ownerToken — résout un { accessToken, refreshToken } Google pour des
 * contextes serveur qui n'ont pas de session utilisateur active
 * (cron Vercel, sync auto…).
 *
 * Stratégie :
 *  1. Si `GOOGLE_OWNER_REFRESH_TOKEN` est défini (Vercel env var) →
 *     échange contre un access_token frais.
 *  2. Sinon → throw (le caller décide de sauter la feature, ex. cron
 *     saute la création Calendar si pas configuré).
 *
 * Pour récupérer le refresh_token initial : l'utilisateur admin
 * (yako.cyclo) ouvre /api/admin/refresh-token une fois après s'être
 * re-logué avec le nouveau scope calendar.events, puis copie la valeur
 * dans la Vercel env var `GOOGLE_OWNER_REFRESH_TOKEN`.
 */

export class NoOwnerTokenError extends Error {
  constructor() {
    super('GOOGLE_OWNER_REFRESH_TOKEN non configuré');
    this.name = 'NoOwnerTokenError';
  }
}

/**
 * Échange le refresh_token owner contre un access_token frais.
 * Throw NoOwnerTokenError si la env var n'est pas configurée.
 */
export async function getOwnerAccessToken(): Promise<{ accessToken: string; refreshToken: string }> {
  const refreshToken = process.env.GOOGLE_OWNER_REFRESH_TOKEN;
  if (!refreshToken) throw new NoOwnerTokenError();

  const res = await fetch('https://oauth2.googleapis.com/token', {
    method : 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body   : new URLSearchParams({
      client_id    : process.env.AUTH_GOOGLE_ID!,
      client_secret: process.env.AUTH_GOOGLE_SECRET!,
      grant_type   : 'refresh_token',
      refresh_token: refreshToken,
    }),
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => '');
    throw new Error(`Owner token refresh échoué (${res.status}) : ${txt.slice(0, 200)}`);
  }
  const data = await res.json();
  const accessToken = data?.access_token as string | undefined;
  if (!accessToken) throw new Error('Owner token refresh : access_token absent de la réponse');
  return { accessToken, refreshToken };
}
