/**
 * withTokenRetry — wrapper robuste pour les appels Google APIs OAuth
 * (Drive, Gmail, People) qui gère automatiquement les tokens expirés.
 *
 * Pattern d'utilisation :
 *   const result = await withTokenRetry(
 *     (accessToken) => someGoogleApiCall(accessToken),
 *     accessToken,
 *     refreshToken,
 *   );
 *
 * Comportement :
 *   1. Première tentative avec accessToken actuel
 *   2. Si 401/Invalid Credentials ET refreshToken dispo :
 *      → tente un refresh explicite via /oauth2/token
 *      → retry avec le nouveau accessToken
 *   3. Si le retry échoue aussi (ou pas de refreshToken) :
 *      → throw une GoogleAuthError avec message utilisateur clair
 *
 * Avantage vs catch silencieux : l'erreur remonte proprement et peut être
 * affichée par l'appelant (toast, bannière, 401 API → reconnecte-toi).
 */

export class GoogleAuthError extends Error {
  public readonly code = 'GOOGLE_AUTH_EXPIRED';
  public readonly userMessage: string;
  constructor(userMessage: string, cause?: unknown) {
    super(userMessage);
    this.userMessage = userMessage;
    this.name = 'GoogleAuthError';
    if (cause) (this as any).cause = cause;
  }
}

/** Détecte si une erreur Google API est un 401 / credentials invalides. */
export function isAuthError(err: any): boolean {
  if (!err) return false;
  const code   = err.code ?? err.status ?? err.response?.status;
  const msg    = err.message ?? '';
  const errors = err.errors ?? err.response?.data?.error?.errors ?? [];
  if (code === 401) return true;
  if (/invalid.?credentials|invalid.?grant|unauthoriz/i.test(String(msg))) return true;
  if (Array.isArray(errors) && errors.some((e: any) => /authError|authentic/i.test(e?.reason ?? ''))) return true;
  return false;
}

/** Échange un refresh_token contre un nouveau access_token auprès de Google. */
async function refreshAccessToken(refreshToken: string): Promise<string | null> {
  try {
    const res = await fetch('https://oauth2.googleapis.com/token', {
      method : 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body   : new URLSearchParams({
        client_id    : process.env.AUTH_GOOGLE_ID!,
        client_secret: process.env.AUTH_GOOGLE_SECRET!,
        grant_type   : 'refresh_token',
        refresh_token: refreshToken,
      }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return (data?.access_token as string | undefined) ?? null;
  } catch {
    return null;
  }
}

/**
 * Exécute `fn(accessToken)` avec retry automatique en cas de 401.
 *
 * Si le retry échoue aussi (ou s'il n'y a pas de refreshToken dispo),
 * throw GoogleAuthError avec un message utilisateur actionnable.
 * Les autres erreurs (non-auth) sont re-throw telles quelles.
 */
export async function withTokenRetry<T>(
  fn: (accessToken: string) => Promise<T>,
  accessToken: string,
  refreshToken: string | undefined,
): Promise<T> {
  try {
    return await fn(accessToken);
  } catch (err) {
    if (!isAuthError(err)) throw err;
    if (!refreshToken) {
      throw new GoogleAuthError(
        'Session Google expirée — reconnecte-toi pour continuer',
        err,
      );
    }
    const newToken = await refreshAccessToken(refreshToken);
    if (!newToken) {
      throw new GoogleAuthError(
        'Impossible de rafraîchir la session Google — déconnecte-toi puis reconnecte-toi',
        err,
      );
    }
    try {
      return await fn(newToken);
    } catch (err2) {
      if (isAuthError(err2)) {
        throw new GoogleAuthError(
          'Session Google invalide après refresh — reconnecte-toi',
          err2,
        );
      }
      throw err2;
    }
  }
}
