/**
 * Google Contacts (People API) sync.
 *
 * Utilise l'OAuth utilisateur (yako.cyclo@gmail.com) — les contacts sont
 * créés dans SON carnet, pas dans un service account.
 *
 * Prérequis Google Cloud Console :
 *   - People API activée
 *   - Scope `https://www.googleapis.com/auth/contacts` dans OAuth consent
 *
 * Structure : tous les clients FLEX-REV sont ajoutés au groupe (label)
 * "Clients" — créé automatiquement s'il n'existe pas.
 */
import { google } from 'googleapis';
import type { people_v1 } from 'googleapis';
import { withTokenRetry } from './withTokenRetry';
import { telE164 } from '../utils/format';

const CLIENTS_GROUP_NAME = 'Clients';

function getPeople(accessToken: string, refreshToken?: string): people_v1.People {
  const oauth2Client = new google.auth.OAuth2(
    process.env.AUTH_GOOGLE_ID,
    process.env.AUTH_GOOGLE_SECRET,
  );
  oauth2Client.setCredentials({
    access_token : accessToken,
    refresh_token: refreshToken ?? null,
  });
  return google.people({ version: 'v1', auth: oauth2Client });
}

/** Retourne le resourceName du groupe "Clients" (le crée si absent). */
export async function ensureClientsGroup(
  accessToken: string,
  refreshToken?: string,
): Promise<string> {
  const people = getPeople(accessToken, refreshToken);

  const list = await people.contactGroups.list({
    pageSize: 200,
    groupFields: 'name,groupType,memberCount',
  });

  // Match tolérant (casse, accents, espaces) au cas où le groupe existait déjà
  // sous une casse différente.
  const norm = (s: string) =>
    s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  const target = norm(CLIENTS_GROUP_NAME);
  const existing = (list.data.contactGroups ?? []).find(
    g => g.groupType === 'USER_CONTACT_GROUP' && g.name && norm(g.name) === target,
  );
  if (existing?.resourceName) {
    console.log('[contacts] groupe Clients existant :', existing.resourceName, '—', existing.memberCount, 'membres');
    return existing.resourceName;
  }

  console.log('[contacts] création du groupe Clients');
  const created = await people.contactGroups.create({
    requestBody: { contactGroup: { name: CLIENTS_GROUP_NAME } },
  });
  if (!created.data.resourceName) {
    throw new Error('Impossible de créer le groupe Clients dans Contacts Google');
  }
  return created.data.resourceName;
}

/**
 * Ajoute un contact au groupe Clients. Non-bloquant (log + return false en
 * cas d'erreur) pour ne pas perdre le resourceName si le contact est
 * déjà créé mais que l'ajout-groupe échoue.
 */
async function addToClientsGroup(
  contactResourceName: string,
  accessToken: string,
  refreshToken?: string,
): Promise<boolean> {
  try {
    const people = getPeople(accessToken, refreshToken);
    const groupResourceName = await ensureClientsGroup(accessToken, refreshToken);
    const res = await people.contactGroups.members.modify({
      resourceName: groupResourceName,
      requestBody : { resourceNamesToAdd: [contactResourceName] },
    });
    const notFound     = res.data.notFoundResourceNames   ?? [];
    const cannotMutate = res.data.canNotRemoveLastContactGroupResourceNames ?? [];
    if (notFound.length > 0) {
      console.error('[contacts] add-to-group notFound :', notFound);
      return false;
    }
    if (cannotMutate.length > 0) {
      console.error('[contacts] add-to-group cannotMutate :', cannotMutate);
    }
    return true;
  } catch (err: any) {
    const detail = err?.response?.data || err?.errors || err?.message || err;
    console.error('[contacts] add-to-group failed for', contactResourceName, ':', detail);
    return false;
  }
}

interface ContactData {
  prenom: string;
  nom: string;
  tel?: string;
  indicatif?: string;  // ex. '+1', '+33' — pour normaliser tel en E.164
  courriel?: string;
  notes?: string;
  lead?: string;
  commPref?: string;
  lang?: string;
}

function buildPersonBody(c: ContactData): people_v1.Schema$Person {
  const person: people_v1.Schema$Person = {
    names: [{ givenName: c.prenom || '', familyName: c.nom || '' }],
  };
  if (c.courriel) {
    person.emailAddresses = [{ value: c.courriel, type: 'home' }];
  }
  if (c.tel) {
    // Format E.164 (+CCXXXXXXXXXX) requis pour iOS Messages.app — sans
    // country code, les SMS depuis vCards importés tombent en « Not
    // Delivered » car iMessage ne sait pas vers quel pays router.
    const normalized = telE164(c.tel, c.indicatif) || c.tel;
    person.phoneNumbers = [{ value: normalized, type: 'mobile' }];
  }
  const memo = [
    c.lead     ? `Lead: ${c.lead}`         : '',
    c.commPref ? `Comm.: ${c.commPref}`    : '',
    c.lang     ? `Langue: ${c.lang}`       : '',
    c.notes    ? `\nNotes:\n${c.notes}`    : '',
  ].filter(Boolean).join('\n');
  if (memo) {
    person.biographies = [{ value: memo, contentType: 'TEXT_PLAIN' }];
  }
  person.userDefined = [{ key: 'FLEX-REV', value: 'client' }];
  return person;
}

/**
 * Crée un contact et l'ajoute au groupe Clients.
 * Retourne le resourceName du contact créé (people/c…).
 *
 * Si l'ajout au groupe échoue, le contact reste créé et le resourceName est
 * retourné quand même — un upsert ultérieur retentera l'ajout.
 */
export async function createContact(
  c: ContactData,
  accessToken: string,
  refreshToken?: string,
): Promise<string> {
  const people = getPeople(accessToken, refreshToken);

  const res = await people.people.createContact({
    requestBody: buildPersonBody(c),
  });
  const resourceName = res.data.resourceName;
  if (!resourceName) throw new Error('Création contact Google sans resourceName');

  const added = await addToClientsGroup(resourceName, accessToken, refreshToken);
  if (!added) {
    console.warn('[contacts] contact créé mais pas ajouté au groupe Clients :', resourceName);
  }

  return resourceName;
}

/**
 * Met à jour un contact existant par resourceName.
 * Re-vérifie etag + updates champs names/emails/phones/biographies.
 */
export async function updateContact(
  resourceName: string,
  c: ContactData,
  accessToken: string,
  refreshToken?: string,
): Promise<void> {
  const people = getPeople(accessToken, refreshToken);

  // 1. Lire etag à jour
  const current = await people.people.get({
    resourceName,
    personFields: 'metadata,names,emailAddresses,phoneNumbers,biographies,userDefined',
  });
  const etag = current.data.etag;
  if (!etag) throw new Error('etag manquant pour update contact');

  const body = { ...buildPersonBody(c), etag };

  await people.people.updateContact({
    resourceName,
    updatePersonFields: 'names,emailAddresses,phoneNumbers,biographies,userDefined',
    requestBody: body,
  });

  // S'assurer qu'il est dans le groupe Clients (idempotent, loggé si échec)
  await addToClientsGroup(resourceName, accessToken, refreshToken);
}

/**
 * Upsert : update si resourceName fourni ET valide, sinon create.
 * Retourne le resourceName (nouveau ou existant).
 * Gère la rotation si le contact a été supprimé manuellement de Google.
 */
export async function upsertContact(
  c: ContactData,
  existingResourceName: string | undefined,
  accessToken: string,
  refreshToken?: string,
): Promise<string> {
  return withTokenRetry(async (token) => {
    if (existingResourceName) {
      try {
        await updateContact(existingResourceName, c, token, refreshToken);
        return existingResourceName;
      } catch (err: any) {
        // 404 = contact supprimé côté Google → on en recrée un
        const status = err?.response?.status ?? err?.code;
        if (status !== 404) throw err;
      }
    }
    return createContact(c, token, refreshToken);
  }, accessToken, refreshToken);
}

/**
 * Ajoute une liste de resourceNames au groupe Clients en UNE seule requête
 * (plus efficace que les appels unitaires). L'API People `members.modify`
 * accepte plusieurs resourceNames d'un coup.
 * Retourne { added, notFound }.
 */
export async function addManyToClientsGroup(
  resourceNames: string[],
  accessToken: string,
  refreshToken?: string,
): Promise<{ added: number; notFound: string[] }> {
  if (resourceNames.length === 0) return { added: 0, notFound: [] };
  const people = getPeople(accessToken, refreshToken);
  const groupResourceName = await ensureClientsGroup(accessToken, refreshToken);

  // L'API limite à 1000 membres par modify — on chunk par 200 pour rester safe
  const CHUNK = 200;
  let added = 0;
  const notFound: string[] = [];
  for (let i = 0; i < resourceNames.length; i += CHUNK) {
    const chunk = resourceNames.slice(i, i + CHUNK);
    const res = await people.contactGroups.members.modify({
      resourceName: groupResourceName,
      requestBody : { resourceNamesToAdd: chunk },
    });
    const nf = res.data.notFoundResourceNames ?? [];
    notFound.push(...nf);
    added += chunk.length - nf.length;
  }
  return { added, notFound };
}

/** Supprime un contact Google (utilisé quand on supprime un client FLEX-REV). */
export async function deleteContact(
  resourceName: string,
  accessToken: string,
  refreshToken?: string,
): Promise<void> {
  if (!resourceName) return;
  await withTokenRetry(async (token) => {
    const people = getPeople(token, refreshToken);
    await people.people.deleteContact({ resourceName }).catch(err => {
      const status = err?.response?.status ?? err?.code;
      if (status !== 404) throw err;
    });
  }, accessToken, refreshToken);
}
