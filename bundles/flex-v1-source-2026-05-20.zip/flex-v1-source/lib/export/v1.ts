/**
 * Export v1 — JSON pivot normalisé pour la migration vers v2 (Postgres).
 *
 * Format conçu pour être :
 *   - **autonome** : un seul fichier JSON contient l'intégralité de l'état
 *     persisté de l'atelier au moment du dump (clients, vélos, BDT actifs,
 *     archives, ventes, ventes archivées, catalogue pièces/services, PO,
 *     équipe, journaux factures, paramètres, compteurs, templates emails,
 *     tailles vélo).
 *   - **multi-tenant ready** : un champ `workshop` au top-level + clés
 *     d'identification stables permettant à v2 de l'attribuer à un tenant.
 *   - **denormalized-aware** : les relations Sheets (clientNom, bdcId,
 *     pieceId, serviceId) sont conservées telles quelles. v2 les normalise
 *     en FKs lors de l'import.
 *   - **lossless** : aucun champ n'est dropped — y compris notes internes,
 *     timestamps, _row sources, JSON archives, etc. Si v1 le savait, v2
 *     peut le retrouver.
 *
 * Schema version :
 *   - 1.0.0 : version initiale (2 mai 2026)
 *   - 1.1.0 : ajout `templates` (emails), `tailles` (vélo), `parametres`
 *             (raw `_PARAMÈTRES_` Sheet) — demandé par session V2 pour
 *             hydrater Workshop.emailTemplates + Marque.taillesDisponibles.
 */
import type { BDC } from '@/types/bdc';
import type { Velo } from '@/types/velo';
import type { Client } from '@/types/client';
import type { Vente } from '@/types/vente';
import type { Piece, Service, Marque } from '@/types/catalogue';
import type { PO } from '@/types/po';
import type { EquipeMember } from '@/types/equipe';

import { getSheetsClient, SHEET_IDS, TAB, ROW } from '@/lib/sheets/client';
import { getBDCs, getArchivedBDCs } from '@/lib/sheets/bdc';
import { getVelos } from '@/lib/sheets/inventaire';
import { getClients } from '@/lib/sheets/clients';
import { getVentes } from '@/lib/sheets/ventes';
import { getPieces, getServices, getMarques } from '@/lib/sheets/catalogue';
import { getPOs } from '@/lib/sheets/po';
import { getEquipeMembers } from '@/lib/sheets/equipe';
import { getEmailTemplates } from '@/lib/sheets/emailTemplates';
import { VELO_TAILLES } from '@/lib/config';

export const EXPORT_SCHEMA_VERSION = '1.1.0';

export interface ExportV1 {
  schemaVersion: typeof EXPORT_SCHEMA_VERSION;
  exportedAt   : string;        // ISO-8601 UTC
  appVersion   : string;        // ex. 'v7.0.27'
  workshop     : WorkshopMeta;

  counters     : { veloId: number; factureNumero: number };
  marques      : Marque[];

  clients      : Client[];
  velos        : Velo[];

  bdcs         : BDC[];
  bdcsArchives : BDC[];         // statut archivé, JSON col X préservé en `items`

  ventes         : Vente[];
  ventesArchives : VenteArchive[];

  catalogue: {
    pieces  : Piece[];
    services: Service[];        // forfaits inclus (mergés via getServices)
  };

  pos    : PO[];
  equipe : EquipeMember[];

  facturesJournal: {
    bdt    : FactureLogEntry[];
    ventes : FactureLogEntry[];
    legacy : FactureLogEntry[];
  };

  /** v1.1.0+ : templates email (clé/valeur).
   *  Source : Sheet `_EMAIL_TEMPLATES_` du doc INVENTAIRE, mergé avec
   *  les defaults de `lib/emailTemplateDefaults.ts`. Clés observées :
   *  EVAL_FR, EVAL_EN, FACTURE_BDT_FR, FACTURE_BDT_EN, FACTURE_VENTE_FR,
   *  FACTURE_VENTE_EN, RAPPEL_FR, SMS_SUIVI, etc. (varie selon ce que
   *  l'utilisateur a personnalisé).
   *  Mapping V2 : Workshop.emailTemplates JSONB. */
  templates: Record<string, string>;

  /** v1.1.0+ : tailles vélo standardisées (XXL → XS, XSS, 24, 26).
   *  Source : `lib/config.ts` const `VELO_TAILLES`. Inclut '' (non
   *  renseigné) en première position pour les dropdowns.
   *  Mapping V2 : Marque.taillesDisponibles JSONB (réplique pour
   *  chaque marque, ou table dédiée Tailles). */
  tailles: readonly string[];

  /** v1.1.0+ : contenu brut de l'onglet `_PARAMÈTRES_` du doc INVENTAIRE.
   *  Inclut compteurs (B2, B3) déjà extraits dans `counters`, marques
   *  (A37-A65) déjà extraites dans `marques`, plus toutes les autres clés
   *  legacy non exploitées par le code v1 mais potentiellement utiles
   *  pour V2 (ex. réglages trouvés à l'audit).
   *  Format raw : `FactureLogEntry[]` (row 1-based, rawCols col-by-col). */
  parametres: FactureLogEntry[];
}

export interface WorkshopMeta {
  /** ID stable pour la migration v2 (mono-tenant en v1). */
  id       : 'yako-cyclo';
  name     : 'Yako Cyclo';
  lang     : 'FR';
  currency : 'CAD';
  timezone : 'America/Montreal';
}

/**
 * Ligne du journal factures, format brut tel que stocké dans l'onglet.
 * Layout différent BDT vs ventes (cf factures.ts:_ecrireLogFacture) — on
 * conserve les colonnes telles quelles (rawCols), v2 normalisera.
 */
export interface FactureLogEntry {
  row     : number;             // ligne 1-based dans l'onglet source
  rawCols : (string | number | boolean)[];
}

export interface VenteArchive {
  row     : number;
  rawCols : (string | number | boolean)[];
}

const WORKSHOP: WorkshopMeta = {
  id      : 'yako-cyclo',
  name    : 'Yako Cyclo',
  lang    : 'FR',
  currency: 'CAD',
  timezone: 'America/Montreal',
};

/**
 * Lit toutes les sources Sheets en parallèle et assemble le JSON pivot.
 * Coût : ~12 reads Sheets en parallèle. Sous quota normal.
 */
export async function buildExportV1(appVersion: string): Promise<ExportV1> {
  const [
    bdcs, bdcsArchives, velos, clientsGrouped, ventes,
    pieces, services, marques, pos, equipe,
    counters, facturesBdt, facturesVentes, facturesLegacy, ventesArchives,
    templates, parametres,
  ] = await Promise.all([
    getBDCs(),
    getArchivedBDCs(),
    getVelos(),
    getClients(true),
    getVentes(),
    getPieces(),
    getServices(),
    getMarques(),
    getPOs(),
    getEquipeMembers(),
    _readCounters(),
    _readRawSheet(SHEET_IDS.FACTURES, TAB.FACTURES_LOG_BDT,    'A2:Z'),
    _readRawSheet(SHEET_IDS.FACTURES, TAB.FACTURES_LOG_VENTES, 'A2:Z'),
    _readRawSheet(SHEET_IDS.FACTURES, TAB.FACTURES_LOG,        'A2:Z'),
    _readRawSheet(SHEET_IDS.INVENTAIRE, TAB.VENTES_ARCHIVES,   'A2:Z'),
    // v1.1.0+ : templates emails + raw _PARAMÈTRES_
    getEmailTemplates(),
    _readRawSheet(SHEET_IDS.INVENTAIRE, TAB.PARAMS,            'A1:Z'),
  ]);

  const clients = [
    ...clientsGrouped.recents,
    ...clientsGrouped.actifs,
    ...clientsGrouped.autres,
  ];

  return {
    schemaVersion: EXPORT_SCHEMA_VERSION,
    exportedAt   : new Date().toISOString(),
    appVersion,
    workshop     : WORKSHOP,

    counters,
    marques,

    clients,
    velos,
    bdcs,
    bdcsArchives,
    ventes,
    ventesArchives: ventesArchives.map(_toRawEntry),

    catalogue: { pieces, services },

    pos,
    equipe,

    facturesJournal: {
      bdt   : facturesBdt   .map(_toRawEntry),
      ventes: facturesVentes.map(_toRawEntry),
      legacy: facturesLegacy.map(_toRawEntry),
    },

    // v1.1.0+ : nouvelles clés
    templates,
    tailles   : VELO_TAILLES,
    parametres: parametres.map(_toRawEntry),
  };
}

// ── Helpers internes ─────────────────────────────────────────────────

async function _readCounters(): Promise<{ veloId: number; factureNumero: number }> {
  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.batchGet({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    ranges           : [
      `${TAB.PARAMS}!B${ROW.COUNTER_ROW}`,
      `${TAB.PARAMS}!B${ROW.FACTURE_COUNTER_ROW}`,
    ],
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const veloIdRaw   = res.data.valueRanges?.[0]?.values?.[0]?.[0];
  const factureRaw  = res.data.valueRanges?.[1]?.values?.[0]?.[0];
  return {
    veloId       : parseInt(String(veloIdRaw ?? '0'), 10) || 0,
    factureNumero: parseInt(String(factureRaw ?? '0'), 10) || 0,
  };
}

/** Lit un onglet brut sous forme de matrice. Retourne [] si l'onglet n'existe pas. */
async function _readRawSheet(
  spreadsheetId: string,
  tab          : string,
  a1Range      : string,
): Promise<{ row: number; values: any[] }[]> {
  const sheets = getSheetsClient();
  try {
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range            : `${tab}!${a1Range}`,
      valueRenderOption: 'UNFORMATTED_VALUE',
    });
    const rows = res.data.values ?? [];
    // a1Range commence à A2 → row réelle = i + 2.
    const offset = parseInt(a1Range.match(/\d+/)?.[0] ?? '2', 10);
    return rows.map((r, i) => ({ row: i + offset, values: r ?? [] }));
  } catch (err: any) {
    // Onglet absent (ex. legacy FACTURES dans un nouveau document) → array vide.
    if (err?.code === 400 || /Unable to parse range/.test(err?.message ?? '')) return [];
    throw err;
  }
}

function _toRawEntry(r: { row: number; values: any[] }): FactureLogEntry {
  return { row: r.row, rawCols: r.values as (string | number | boolean)[] };
}
