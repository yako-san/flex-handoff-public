/**
 * Filtres purs pour la normalisation des items entrants côté BDC.
 *
 * Extrait de `bdc.ts` pour permettre des tests unitaires sans tirer
 * tout le module Sheets. Pure : pas d'I/O.
 */
import type { AddServiceInput } from '@/types/bdc';

/**
 * Exclut les entrées qui ne sont pas de vrais services :
 *   - sous-items de forfait `"- xxx"` / `"— xxx"` / `"—xxx"`
 *   - séparateurs `"--"` / `"-"` / `"—"`
 *   - nom vide / blanc
 *
 * Ces lignes sont présentes dans le catalogue comme descriptions
 * de forfait, mais ne doivent jamais devenir des ITEM indépendants.
 */
export function filterServiceItems(items: AddServiceInput[]): AddServiceInput[] {
  return items.filter(item => {
    const nom = (item?.nom ?? '').trim();
    if (!nom) return false;
    if (nom === '--' || nom === '-' || nom === '—') return false;
    // Accepte "- " / "— " (avec espace) ET "—" (sans espace suivi d'un emoji
    // ou autre caractère, ex. "—🧰 Ajust.")
    if (nom.startsWith('- ')) return false;
    if (nom.startsWith('—')) return false;
    return true;
  });
}
