/**
 * CRUD clients — document CLIENTS FLEX-REV (clientsExtId dans le GAS).
 * Équivalent de _getClients(), creerFicheClient(), _getVelosClient().
 *
 * ── Layout colonnes (v1.1.11+) ────────────────────────────────────
 * B  Prénom    C  Nom       D  Tél       E  Courriel   F  Comm.
 * G  LEAD      H  GContact  I  BDC IDs   J  Vélos
 * K  Date IN   L  Date OUT  M  Notes     N  Lang       O  Remise
 * P  Indicatif Q  Adresse postale
 * R  Employeur (entrepriseName)     v1.1.11+
 * S  Adresse employeur (entrepriseAdresse) v1.1.11+
 * ─────────────────────────────────────────────────────────────────
 */
import { getSheetsClient, SHEET_IDS, TAB, ROW, BDC_COL, BDC_TAG } from './client';
import { todayStr, stripMarkdownLink } from '@/lib/utils/format';
import cache, { CACHE_KEYS } from '@/lib/cache';
import type { Client, ClientFormData, ClientsGrouped } from '@/types/client';

const DATA_ROW  = 5;  // données dès ligne 5

// ── Lecture ───────────────────────────────────────────────────────

/**
 * Retourne tous les clients, groupés en : recents (vide) / actifs / autres.
 * Un client est "actif" s'il n'a pas de dateOut OU s'il a au moins un BDC encore actif.
 * Résultat mis en cache 5 min.
 * @param fresh Si true, invalide le cache avant de lire (force rechargement)
 */
export async function getClients(fresh = false): Promise<ClientsGrouped> {
  if (fresh) await cache.del(CACHE_KEYS.CLIENTS);
  const cached = await cache.get<ClientsGrouped>(CACHE_KEYS.CLIENTS);
  if (cached) return cached;

  const [clients, activeBdcIds, inventaireBdcMap] = await Promise.all([
    _readAllClients(),
    _getActiveBdcIds(),
    _getInventaireBdcByClient(),
  ]);

  // Enrichir les bdcIds de chaque client avec ceux trouvés dans INVENTAIRE/BDC/ARCHIVES.
  // (la col I du sheet CLIENTS peut être incomplète)
  // Matching tolérant : normalise la clé (trim, espaces collapsés, lowercase, sans accents)
  // pour attraper les variantes "Prénom  Nom", "prenom nom", "Prénom Nom ", etc.
  const normKey = (s: string) =>
    s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  const normMap = new Map<string, string[]>();
  for (const [key, ids] of inventaireBdcMap.entries()) {
    const k = normKey(key);
    if (!normMap.has(k)) normMap.set(k, []);
    for (const id of ids) {
      if (!normMap.get(k)!.includes(id)) normMap.get(k)!.push(id);
    }
  }
  for (const c of clients) {
    const invIds = normMap.get(normKey(c.nomComplet)) ?? [];
    const merged = new Set([...c.bdcIds, ...invIds]);
    c.bdcIds = [...merged].sort();
  }

  const grouped = _groupClients(clients, activeBdcIds);
  await cache.set(CACHE_KEYS.CLIENTS, grouped);
  return grouped;
}

/** Retourne les vélos d'un client (col J, multi-ligne). */
export async function getVelosClient(clientNom: string): Promise<string[]> {
  const clients = await _readAllClients();
  const c       = clients.find(cl => cl.nomComplet === clientNom);
  if (!c) return [];
  return c.velos;
}

// ── Mutation ──────────────────────────────────────────────────────

/**
 * Crée une fiche client dans CLIENTS FLEX-REV.
 * Équivalent de creerFicheClient() dans le GAS.
 */
export async function creerClient(data: ClientFormData): Promise<Client> {
  const sheets = getSheetsClient();
  const today  = todayStr();

  const row = [
    '',               // col A — vide
    data.prenom,      // col B
    data.nom,         // col C
    data.tel,         // col D
    data.courriel,    // col E
    data.commPref,    // col F
    data.lead,        // col G — LEAD
    '',               // col H — vide
    '',               // col I — BDC IDs (vide au départ)
    '',               // col J — vélos (vide au départ)
    today,            // col K — dateIn
    '',               // col L — dateOut (vide = actif)
    data.notes ?? '', // col M
    data.lang ?? 'FR',// col N — préférence de langue communications
    data.remise ?? '', // col O — % remise (vide si 0)
    data.indicatif ?? '+1', // col P — indicatif pays E.164
    data.adressePostale ?? '', // col Q — adresse postale
    data.entrepriseName ?? '',     // col R — v1.1.11+ employeur (rare)
    data.entrepriseAdresse ?? '',  // col S — v1.1.11+ adresse employeur
  ];

  await sheets.spreadsheets.values.append({
    spreadsheetId    : SHEET_IDS.CLIENTS,
    range            : `${TAB.CLIENTS_EXT}!A${DATA_ROW}`,
    valueInputOption : 'RAW',  // préserver tel "0514…" et autres ID textuels
    insertDataOption : 'INSERT_ROWS',
    requestBody      : { values: [row] },
  });

  await cache.del(CACHE_KEYS.CLIENTS); // invalider le cache

  const all = await _readAllClients();
  const nom = `${data.prenom} ${data.nom}`.trim();
  return all.find(c => c.nomComplet === nom)!;
}

/**
 * S'assure qu'un client virtuel « Walk-in » existe dans CLIENTS.
 * Utilisé pour les ventes comptoir sans client identifié.
 *
 * Caractéristiques :
 *  - prénom = 'Walk-in', nom = '' → nomComplet = 'Walk-in'
 *  - courriel = 'walkin@cycloflex.local' → détecté côté factures.ts pour
 *    SKIP la création de brouillon Gmail (pas d'envoi vers fausse adresse)
 *  - lead = 'Cyclo Flex', lang = 'FR', commPref = ''
 *
 * Retourne le Client (créé ou existant).
 */
export async function ensureWalkinClient(): Promise<Client> {
  const WALKIN_NOM = 'Walk-in';
  const all = await _readAllClients();
  const existing = all.find(c => c.nomComplet === WALKIN_NOM);
  if (existing) return existing;

  return creerClient({
    prenom   : 'Walk-in',
    nom      : '',
    tel      : '',
    courriel : 'walkin@cycloflex.local',
    commPref : '' as any,
    lead     : 'Cyclo Flex' as any,
    lang     : 'FR' as any,
    notes    : 'Client virtuel pour ventes comptoir sans client identifié. Email .local → pas de brouillon Gmail à la facturation.',
    indicatif: '+1',
  });
}

/**
 * Écrit le resourceName Google Contact (col H) pour un client donné.
 * Utilisé après création ou upsert contact Google.
 */
export async function setGoogleResourceName(row: number, resourceName: string): Promise<void> {
  if (!row || !resourceName) return;
  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId   : SHEET_IDS.CLIENTS,
    range           : `${TAB.CLIENTS_EXT}!H${row}`,
    valueInputOption: 'RAW',
    requestBody     : { values: [[resourceName]] },
  });
  await cache.del(CACHE_KEYS.CLIENTS);
}

/**
 * Ajoute un ID BDC à la col I d'un client + aligne col J (vélos).
 * Équivalent de _clientsExtAjouterID() dans le GAS.
 */
export async function ajouterBDCId(clientNom: string, bdcId: string): Promise<void> {
  const sheets  = getSheetsClient();
  const clients = await _readAllClients();
  const c       = clients.find(cl => cl.nomComplet === clientNom);
  if (!c || c._row < 0) return;

  const ids  = [...c.bdcIds];
  if (ids.includes(bdcId)) return;
  ids.push(bdcId);

  const velos = [...c.velos];
  while (velos.length < ids.length) velos.push('');

  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.CLIENTS,
    requestBody  : {
      valueInputOption: 'RAW',
      data: [
        { range: `${TAB.CLIENTS_EXT}!I${c._row}`, values: [[ids.join('\n')]] },   // col I
        { range: `${TAB.CLIENTS_EXT}!J${c._row}`, values: [[velos.join('\n')]] }, // col J
      ],
    },
  });

  await cache.del(CACHE_KEYS.CLIENTS);
}

/**
 * Retire un ID BDC de la col I d'un client + la ligne correspondante de
 * la col J (vélos). Miroir de ajouterBDCId. Noop si le client ou l'ID
 * est introuvable. Utilisé quand un vélo change de client.
 */
export async function retirerBDCId(clientNom: string, bdcId: string): Promise<void> {
  if (!clientNom || !bdcId) return;
  const sheets  = getSheetsClient();
  const clients = await _readAllClients();
  const c       = clients.find(cl => cl.nomComplet === clientNom);
  if (!c || c._row < 0) return;

  const idx = c.bdcIds.indexOf(bdcId);
  if (idx < 0) return;

  const ids   = c.bdcIds.filter((_, i) => i !== idx);
  const velos = c.velos.filter((_, i) => i !== idx);

  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.CLIENTS,
    requestBody  : {
      valueInputOption: 'RAW',
      data: [
        { range: `${TAB.CLIENTS_EXT}!I${c._row}`, values: [[ids.join('\n')]] },
        { range: `${TAB.CLIENTS_EXT}!J${c._row}`, values: [[velos.join('\n')]] },
      ],
    },
  });

  await cache.del(CACHE_KEYS.CLIENTS);
}

/**
 * Variante de retirerBDCId qui prend le numéro de ligne plutôt que le
 * nomComplet (évite un re-lookup côté appelant).
 */
export async function retirerBDCIdByRow(row: number, bdcId: string): Promise<void> {
  if (!row || !bdcId) return;
  const clients = await _readAllClients();
  const c = clients.find(cl => cl._row === row);
  if (!c) return;
  return retirerBDCId(c.nomComplet, bdcId);
}

/**
 * Retire un bdcId de TOUTES les fiches CLIENTS qui le référencent.
 * Utilisé après deleteArchivedBDC pour éviter les pills 'fantômes'
 * orphelines dans la fiche client.
 */
export async function retirerBDCIdGlobal(bdcId: string): Promise<void> {
  if (!bdcId) return;
  const sheets  = getSheetsClient();
  const clients = await _readAllClients();
  const data: { range: string; values: unknown[][] }[] = [];
  for (const c of clients) {
    const idx = c.bdcIds.indexOf(bdcId);
    if (idx < 0) continue;
    const ids   = c.bdcIds.filter((_, i) => i !== idx);
    const velos = c.velos.filter((_, i) => i !== idx);
    data.push(
      { range: `${TAB.CLIENTS_EXT}!I${c._row}`, values: [[ids.join('\n')]] },
      { range: `${TAB.CLIENTS_EXT}!J${c._row}`, values: [[velos.join('\n')]] },
    );
  }
  if (data.length === 0) return;
  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.CLIENTS,
    requestBody  : { valueInputOption: 'RAW', data },
  });
  await cache.del(CACHE_KEYS.CLIENTS);
}

/**
 * Met à jour le Lead (col G) d'un client.
 */
export async function patchClientLead(row: number, lead: string): Promise<void> {
  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.CLIENTS,
    range            : `${TAB.CLIENTS_EXT}!G${row}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [[lead]] },
  });
  await cache.del(CACHE_KEYS.CLIENTS);
}

/**
 * Met à jour des champs arbitraires d'un client (B prénom, C nom, D tél,
 * E courriel, F commPref, G lead, M notes).
 */
export async function patchClient(
  row: number,
  fields: Partial<{
    prenom   : string;
    nom      : string;
    tel      : string;
    courriel : string;
    commPref : string;
    lead     : string;
    notes    : string;
    lang     : string;
    remise   : number | string;
    indicatif: string;
    adressePostale: string;
    entrepriseName: string;
    entrepriseAdresse: string;
  }>,
): Promise<void> {
  const FIELD_TO_COL: Record<string, string> = {
    prenom           : 'B',
    nom              : 'C',
    tel              : 'D',
    courriel         : 'E',
    commPref         : 'F',
    lead             : 'G',
    notes            : 'M',
    lang             : 'N',
    remise           : 'O',
    indicatif        : 'P',
    adressePostale   : 'Q',
    entrepriseName   : 'R',  // v1.1.11+
    entrepriseAdresse: 'S',  // v1.1.11+
  };

  const data = Object.entries(fields)
    .filter(([k, v]) => v !== undefined && FIELD_TO_COL[k])
    .map(([k, v]) => ({
      range : `${TAB.CLIENTS_EXT}!${FIELD_TO_COL[k]}${row}`,
      values: [[v ?? '']],
    }));

  if (!data.length) return;

  const sheets = getSheetsClient();
  // RAW pour préserver les chaînes telles quelles (ex. téléphone "0514…"
  // ne doit pas être converti en nombre 514…).
  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.CLIENTS,
    requestBody  : { valueInputOption: 'RAW', data },
  });

  await cache.del(CACHE_KEYS.CLIENTS);
}

/**
 * Supprime la ligne d'un client (suppression définitive dans la feuille).
 */
export async function deleteClient(row: number): Promise<void> {
  const sheets = getSheetsClient();

  // Trouver le sheetId de l'onglet CLIENTS_EXT
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.CLIENTS,
    fields       : 'sheets.properties',
  });
  const sheet = meta.data.sheets?.find(s => s.properties?.title === TAB.CLIENTS_EXT);
  const sheetId = sheet?.properties?.sheetId;
  if (sheetId === undefined) throw new Error(`Onglet "${TAB.CLIENTS_EXT}" introuvable`);

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.CLIENTS,
    requestBody  : {
      requests: [{
        deleteDimension: {
          range: {
            sheetId,
            dimension  : 'ROWS',
            startIndex : row - 1, // 0-based
            endIndex   : row,
          },
        },
      }],
    },
  });

  await cache.del(CACHE_KEYS.CLIENTS);
}

/**
 * Écrit la date de sortie (col L) d'un client lors de l'archivage d'un BDC.
 */
export async function setDateOut(clientNom: string, date: string): Promise<void> {
  const sheets  = getSheetsClient();
  const clients = await _readAllClients();
  const c       = clients.find(cl => cl.nomComplet === clientNom);
  if (!c || c._row < 0) return;

  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.CLIENTS,
    range            : `${TAB.CLIENTS_EXT}!L${c._row}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [[date]] },
  });

  await cache.del(CACHE_KEYS.CLIENTS);
}

// ── Helpers privés ────────────────────────────────────────────────

/**
 * Retourne l'ensemble des BDC IDs encore actifs (non archivés) dans INVENTAIRE.
 * Utilisé pour décider si un client avec dateOut doit aller dans "actifs".
 */
async function _getActiveBdcIds(): Promise<Set<string>> {
  const sheets = getSheetsClient();
  const res    = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!A${ROW.BDC_INS}:B`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const ids = new Set<string>();
  for (const r of (res.data.values ?? [])) {
    if (String(r[BDC_COL.TAG - 1] ?? '').trim() === BDC_TAG.BON) {
      const id = String(r[BDC_COL.ID - 1] ?? '').trim();
      if (id) ids.add(id);
    }
  }
  return ids;
}

/**
 * Lit INVENTAIRE + BONS DE COMMANDES pour construire une map clientNom → [bdcId, ...].
 * Couvre les BDC actifs (INVENTAIRE) ET les BDC terminés/en cours (BONS DE COMMANDES).
 * Permet de retrouver TOUS les BDC d'un client même si la col I du sheet CLIENTS est incomplète.
 */
async function _getInventaireBdcByClient(): Promise<Map<string, string[]>> {
  const sheets = getSheetsClient();

  // Lire en parallèle : INVENTAIRE + BDC + ARCHIVES
  const [invRes, bdcRes, archRes] = await Promise.all([
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.INVENTAIRE}!D${ROW.INS_ROW}:H`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.BDC}!A${ROW.BDC_INS}:H`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `'${TAB.ARCHIVES}'!D5:H`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
  ]);

  const map = new Map<string, string[]>();

  // 1. INVENTAIRE — chaque vélo a un ID (col D) et un client (col H)
  for (const r of (invRes.data.values ?? [])) {
    const id     = String(r[0] ?? '').trim();   // col D = BDC ID
    const client = String(r[4] ?? '').trim();   // col H = Client
    if (!id || !client || client === 'Sélection →') continue;
    if (!map.has(client)) map.set(client, []);
    if (!map.get(client)!.includes(id)) map.get(client)!.push(id);
  }

  // 2. BONS DE COMMANDES — tag BON donne l'ID, tag GAP donne le nom client
  let currentBdcId = '';
  for (const r of (bdcRes.data.values ?? [])) {
    const tag = String(r[0] ?? '').trim();
    if (tag === BDC_TAG.BON) {
      currentBdcId = String(r[1] ?? '').trim();
    } else if (tag === BDC_TAG.GAP && currentBdcId) {
      const client = String(r[7] ?? '').trim();  // col H = nom client
      if (client) {
        if (!map.has(client)) map.set(client, []);
        if (!map.get(client)!.includes(currentBdcId)) map.get(client)!.push(currentBdcId);
      }
    }
  }

  // 3. ARCHIVES 2026 — col D (index 0) = ID, col H (index 4) = Client
  for (const r of (archRes.data.values ?? [])) {
    const id     = String(r[0] ?? '').trim();
    const client = String(r[4] ?? '').trim();
    if (!id || !client || id === 'ID') continue;
    if (!map.has(client)) map.set(client, []);
    if (!map.get(client)!.includes(id)) map.get(client)!.push(id);
  }

  return map;
}

async function _readAllClients(): Promise<Client[]> {
  const sheets = getSheetsClient();
  // v1.1.11+ : range étendu B:S (auparavant B:Q) pour inclure
  // entrepriseName (R) + entrepriseAdresse (S).
  const res    = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.CLIENTS,
    range            : `${TAB.CLIENTS_EXT}!B${DATA_ROW}:S`,
    valueRenderOption: 'FORMATTED_VALUE',
  });

  const rows = res.data.values ?? [];
  return rows
    .map((r, idx) => _rowToClient(r, idx + DATA_ROW))
    .filter((c): c is Client => !!c.nomComplet);
}

/**
 * Mappe une ligne de la feuille vers un objet Client.
 * Lecture depuis B:S (index 0=B … 17=S).
 *
 * B(0)=Prénom  C(1)=Nom      D(2)=Tél     E(3)=Courriel   F(4)=Comm.
 * G(5)=LEAD    H(6)=GContact I(7)=BDC IDs J(8)=Vélos
 * K(9)=DateIN  L(10)=DateOUT M(11)=Notes  N(12)=Lang (FR|EN)
 * O(13)=Remise P(14)=Indicatif (E.164, ex. '+1', '+33')
 * Q(15)=Adresse postale (texte libre multi-ligne — v7.0.30+)
 * R(16)=Employeur — entrepriseName (v1.1.11+)
 * S(17)=Adresse employeur — entrepriseAdresse (v1.1.11+)
 */
function _rowToClient(r: unknown[], rowNum: number): Client {
  const s = (i: number) => String(r[i] ?? '').trim();

  const prenom     = s(0);
  const nom        = s(1);
  const nomComplet = `${prenom} ${nom}`.trim();

  const bdcRaw  = s(7);  // col I — BDC IDs
  const veloRaw = s(8);  // col J — vélos

  const rawLang  = s(12).toUpperCase();
  const lang     = rawLang === 'EN' ? 'EN' : 'FR';
  const remiseN  = parseInt(s(13), 10);  // col O — % remise (0/10/15/25/50)
  // col P — indicatif pays. Default '+1' si vide (Canada/USA — 95% des cas).
  const rawIndic = s(14);
  const indicatif = rawIndic
    ? (rawIndic.startsWith('+') ? rawIndic : `+${rawIndic.replace(/\D/g, '')}`)
    : '+1';

  return {
    _row     : rowNum,
    prenom,
    nom,
    nomComplet,
    tel      : s(2),
    indicatif,
    courriel : stripMarkdownLink(s(3)),
    commPref : s(4) as any,
    lead     : s(5) as any,  // col G
    googleResourceName: s(6) || undefined, // col H — resourceName Google Contact
    bdcIds   : bdcRaw  ? bdcRaw.split('\n').map(v => v.trim()).filter(Boolean)  : [],
    velos    : veloRaw ? veloRaw.split('\n').map(v => v.trim()).filter(Boolean) : [],
    dateIn   : s(9),           // col K
    dateOut  : s(10) || null,  // col L
    notes    : s(11),          // col M
    lang,                      // col N
    remise   : isFinite(remiseN) && remiseN > 0 ? remiseN : 0, // col O
    adressePostale: s(15) || undefined, // col Q
    entrepriseName   : s(16) || undefined, // col R — v1.1.11+
    entrepriseAdresse: s(17) || undefined, // col S — v1.1.11+
  };
}

function _groupClients(clients: Client[], activeBdcIds: Set<string>): ClientsGrouped {
  const actifs : Client[] = [];
  const autres : Client[] = [];

  clients.forEach(c => {
    // Actif si au moins un de ses BDC est encore actif dans INVENTAIRE
    // Un client avec dateOut mais un BDC actif reste "actif"
    // Un client sans BDC et sans dateOut reste "actif"
    const hasActiveBdc = c.bdcIds.some(id => activeBdcIds.has(id));
    const hasBdcs      = c.bdcIds.length > 0;
    if (hasActiveBdc || (!hasBdcs && !c.dateOut)) {
      actifs.push(c);
    } else {
      autres.push(c);
    }
  });

  const alpha = (arr: Client[]) =>
    arr.sort((a, b) => a.nomComplet.localeCompare(b.nomComplet, 'fr'));
  alpha(actifs);
  alpha(autres);

  // recents toujours vide — les "derniers créés" sont désormais dans actifs/autres
  return { recents: [], actifs, autres };
}
