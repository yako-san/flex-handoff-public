/**
 * Équipe atelier — onglet _EQUIPE_ du document INVENTAIRE.
 *
 * Layout (v7.0.18) :
 *   Ligne 4 : en-têtes
 *   Lignes 5+ : données
 *   Col B Nom | C Courriel | D Tél | E Indicatif | F Lang | G Rôle | H Active | I Notes
 *
 * Auto-création de l'onglet à la première lecture si absent.
 * Auto-migration depuis _EMAIL_TEMPLATES_!equipe_list (JSON simple) si
 * l'onglet est vide à la première lecture.
 */
import { getSheetsClient, SHEET_IDS, TAB } from './client';
import { stripMarkdownLink } from '@/lib/utils/format';
import type { EquipeMember, EquipeMemberFormData } from '@/types/equipe';

const DATA_ROW = 5;
const HEADERS = ['', 'Prénom', 'Courriel', 'Tél', 'Indicatif', 'Lang', 'Rôle', 'Active', 'Notes', 'Surnom', 'Nom'];
//                A   B         C         D    E          F     G      H       I       J        K (ajout v7.0.20, en fin pour rétro-compat)

async function _findSheetId(): Promise<number | null> {
  const sheets = getSheetsClient();
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const found = meta.data.sheets?.find(s => s.properties?.title === TAB.EQUIPE);
  return found?.properties?.sheetId ?? null;
}

/** Crée l'onglet _EQUIPE_ s'il n'existe pas + écrit les en-têtes. */
async function _ensureEquipeTab(): Promise<void> {
  const sheets = getSheetsClient();
  const sheetId = await _findSheetId();
  if (sheetId !== null) {
    // Onglet existe — vérifier qu'il y a au moins les en-têtes ligne 4
    const head = await sheets.spreadsheets.values.get({
      spreadsheetId: SHEET_IDS.INVENTAIRE,
      range        : `${TAB.EQUIPE}!A4:I4`,
    });
    if (!head.data.values?.length) {
      await sheets.spreadsheets.values.update({
        spreadsheetId    : SHEET_IDS.INVENTAIRE,
        range            : `${TAB.EQUIPE}!A4`,
        valueInputOption : 'RAW',
        requestBody      : { values: [HEADERS] },
      });
    }
    return;
  }

  // Création de l'onglet
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        addSheet: { properties: { title: TAB.EQUIPE, gridProperties: { columnCount: 12, rowCount: 200 } } },
      }],
    },
  });
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.EQUIPE}!A4`,
    valueInputOption : 'RAW',
    requestBody      : { values: [HEADERS] },
  });
}

/** Migration auto : peuple _EQUIPE_ depuis equipe_list si vide. */
async function _migrateFromEmailTemplates(): Promise<void> {
  const sheets = getSheetsClient();
  const dataRes = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.EQUIPE}!B${DATA_ROW}:B`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  if ((dataRes.data.values?.length ?? 0) > 0) return;  // déjà des données

  // Lire equipe_list legacy
  try {
    const { getEmailTemplates } = await import('./emailTemplates');
    const tpl = await getEmailTemplates();
    const raw = tpl.equipe_list ?? '';
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr) || arr.length === 0) return;
    const noms: string[] = arr.map(x => String(x).trim()).filter(Boolean);

    const rows = noms.map(nom => [
      '',     // A
      nom,    // B Prénom (les valeurs legacy de equipe_list étaient
              //          juste des prénoms / surnoms, pas des noms complets)
      '',     // C Courriel
      '',     // D Tél
      '+1',   // E Indicatif
      'FR',   // F Lang
      'Mécanicien', // G Rôle
      'TRUE', // H Active
      '',     // I Notes
      '',     // J Surnom
      '',     // K Nom de famille
    ]);
    await sheets.spreadsheets.values.append({
      spreadsheetId   : SHEET_IDS.INVENTAIRE,
      range           : `${TAB.EQUIPE}!A${DATA_ROW}`,
      valueInputOption: 'RAW',
      insertDataOption: 'INSERT_ROWS',
      requestBody     : { values: rows },
    });
    console.log(`[equipe] migré ${noms.length} membres depuis equipe_list`);
  } catch {
    // pas de equipe_list valide — laisse l'onglet vide
  }
}

/** Lit tous les membres de l'équipe depuis l'onglet _EQUIPE_. */
export async function getEquipeMembers(): Promise<EquipeMember[]> {
  await _ensureEquipeTab();
  await _migrateFromEmailTemplates();

  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.EQUIPE}!A${DATA_ROW}:K`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const rows = res.data.values ?? [];
  return rows
    .map((r, idx) => {
      const prenom = String(r[1] ?? '').trim();
      if (!prenom) return null;
      // Active : couvre locale FR ('FAUX'/'VRAI') ET locale EN ('FALSE'/'TRUE'),
      // ainsi que les checkboxes vides (default = active). Le check précédent
      // ne couvrait que 'FALSE' → bug en sheet locale FR-CA où une case
      // décochée renvoie 'FAUX' (interprété comme actif par erreur).
      const activeRaw = String(r[7] ?? '').trim().toUpperCase();
      const active = activeRaw !== 'FALSE' && activeRaw !== 'FAUX';
      return {
        _row     : idx + DATA_ROW,
        prenom,                                          // col B
        courriel : stripMarkdownLink(String(r[2] ?? '')),
        tel      : String(r[3] ?? '').trim(),
        indicatif: String(r[4] ?? '').trim() || '+1',
        lang     : (String(r[5] ?? '').trim().toUpperCase() === 'EN' ? 'EN' : 'FR') as 'FR' | 'EN',
        role     : String(r[6] ?? '').trim(),
        active,
        notes    : String(r[8] ?? '').trim(),
        surnom   : String(r[9] ?? '').trim(),            // col J
        nom      : String(r[10] ?? '').trim(),           // col K (NOUVEAU v7.0.20)
      } satisfies EquipeMember;
    })
    .filter((m): m is EquipeMember => m !== null);
}

/** Crée un nouveau membre de l'équipe. Retourne l'EquipeMember créé. */
export async function creerEquipeMember(data: EquipeMemberFormData): Promise<EquipeMember> {
  await _ensureEquipeTab();
  const sheets = getSheetsClient();
  const row = [
    '',
    data.prenom,                                  // B Prénom
    data.courriel ?? '',                          // C
    data.tel ?? '',                               // D
    data.indicatif ?? '+1',                       // E
    data.lang ?? 'FR',                            // F
    data.role ?? '',                              // G
    data.active === false ? 'FALSE' : 'TRUE',     // H
    data.notes ?? '',                             // I
    data.surnom ?? '',                            // J Surnom
    data.nom ?? '',                               // K Nom
  ];
  await sheets.spreadsheets.values.append({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.EQUIPE}!A${DATA_ROW}`,
    valueInputOption: 'RAW',
    insertDataOption: 'INSERT_ROWS',
    requestBody     : { values: [row] },
  });
  const all = await getEquipeMembers();
  return all.find(m => m.nom === data.nom) ?? all[all.length - 1];
}

/** Patch champs d'un membre par numéro de ligne. */
export async function patchEquipeMember(
  row: number,
  fields: Partial<EquipeMemberFormData>,
): Promise<void> {
  const FIELD_TO_COL: Record<string, string> = {
    prenom   : 'B',  // (renommé depuis « nom » legacy v7.0.20)
    courriel : 'C',
    tel      : 'D',
    indicatif: 'E',
    lang     : 'F',
    role     : 'G',
    active   : 'H',
    notes    : 'I',
    surnom   : 'J',
    nom      : 'K',  // NOUVEAU v7.0.20 — nom de famille
  };
  const sheets = getSheetsClient();
  const data = Object.entries(fields)
    .filter(([k, v]) => v !== undefined && FIELD_TO_COL[k])
    .map(([k, v]) => {
      let val: any = v;
      if (k === 'active') val = v === false ? 'FALSE' : 'TRUE';
      return {
        range : `${TAB.EQUIPE}!${FIELD_TO_COL[k]}${row}`,
        values: [[val ?? '']],
      };
    });
  if (!data.length) return;
  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : { valueInputOption: 'RAW', data },
  });
}

/** Supprime la ligne d'un membre. */
export async function deleteEquipeMember(row: number): Promise<void> {
  const sheets = getSheetsClient();
  const sheetId = await _findSheetId();
  if (sheetId === null) throw new Error(`Onglet ${TAB.EQUIPE} introuvable`);
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        deleteDimension: {
          range: { sheetId, dimension: 'ROWS', startIndex: row - 1, endIndex: row },
        },
      }],
    },
  });
}
