/**
 * CRUD BDC (Bons de Commande) — onglet "BONS DE COMMANDES" du document principal.
 *
 * Structure d'un BDC dans Sheets (une séquence de lignes typées) :
 *   BON  — en-tête (ID, date, checkboxes D/E/F/G, vélo col H)
 *   GAP  — nom client (col H, italic gris)
 *   SEP0 — ligne vide séparateur (v4.4.0)
 *   ITEM — lignes services + pièces (dynamique)
 *   BTN  — boutons "Ajouter" (K = services, P = pièces)
 *   TOT  — totaux
 *   SEP  — barre séparatrice
 *
 * Cette couche dénormalise la structure plate en objets structurés.
 */
import { Mutex } from 'async-mutex';
import { getSheetsClient, SHEET_IDS, TAB, BDC_COL, BDC_GAP_COL, BDC_TAG, ROW } from './client';
// NOTE : la range de lecture est étendue jusqu'à W pour inclure CMD_NOTE (col 23).
import { todayStr, parseSheetsDate } from '@/lib/utils/format';
import cache, { CACHE_KEYS } from '@/lib/cache';
import { logError, logWarn } from '@/lib/log';
import type { BDC, BDCItem, AddServiceInput, AddPieceInput } from '@/types/bdc';
import { filterServiceItems } from './bdc-filters';

// Mutex global de création de BDC. Empêche deux appels concurrents
// (double-clic UI, cron Square + clic manuel, retry frontend) qui
// frappent le même lambda chaud d'insérer le même BDC deux fois avant
// que le check d'existence du second appel ait pu voir l'écriture du
// premier. Ne protège pas le cas cross-lambda — couvert par
// l'invalidation cache KV + re-read fresh dans _findBonRow.
const creerBonMutex = new Mutex();

/** Invalide le cache getBDCs — à appeler après toute mutation du sheet BDC.
 *  N'invalide PAS le _findRowCache (rowNums stables tant qu'on ne fait pas
 *  d'insert/delete de lignes). Appelez _clearFindRowCache() en plus dans
 *  les fonctions qui décalent les lignes (archivage, désarchivage, delete). */
export async function invalidateBDCsCache(): Promise<void> {
  await cache.del(CACHE_KEYS.BDCS);
}

// ── Lecture ───────────────────────────────────────────────────────

/** Lit tous les BDC actifs (sheet BONS DE COMMANDES).
 *
 *  ⚠ Les lignes BDC (BON + GAP) stockent clientNom et veloDesc au moment
 *  de la création et ne sont jamais automatiquement synchronisées avec
 *  les corrections faites plus tard sur la page BDT (qui mettent à jour
 *  INVENTAIRE via patchVelo). Pour éviter que les évaluations/factures
 *  générées utilisent des données périmées, on enrichit SYSTÉMATIQUEMENT
 *  chaque BDC avec les données fraîches de la ligne INVENTAIRE. Si le
 *  vélo n'existe plus dans INVENTAIRE (BDC fantôme), on garde les
 *  valeurs lues dans le BDC comme fallback.
 */
export async function getBDCs(fresh = false): Promise<BDC[]> {
  if (fresh) await cache.del(CACHE_KEYS.BDCS);
  const cached = await cache.get<BDC[]>(CACHE_KEYS.BDCS);
  if (cached) return cached;

  const sheets = getSheetsClient();

  // Lire BDC + INVENTAIRE (D..W pour client/vélo + notes EXT eval/facture)
  const [bdcRes, invRes] = await Promise.all([
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.BDC}!A${ROW.BDC_INS}:W`,
      valueRenderOption: 'UNFORMATTED_VALUE',
    }),
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.INVENTAIRE}!D${ROW.INS_ROW}:W`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
  ]);

  const bdcs = parseBDCRows(bdcRes.data.values ?? [], ROW.BDC_INS);

  // Build map ID → { client, veloDesc, noteClientEval, noteClientFacture }
  // col D=ID (idx 0), H=Client (idx 4), I=Marque (5), J=Modèle (6),
  // K=Couleur (7), L=Taille (8), V=NoteEvalExt (idx 18), W=NoteFactureExt (idx 19)
  const invMap = new Map<string, {
    client: string; veloDesc: string;
    noteClientEval: string; noteClientFacture: string;
  }>();
  for (const r of (invRes.data.values ?? [])) {
    const id      = String(r[0] ?? '').trim();
    if (!id) continue;
    const client  = String(r[4] ?? '').trim();
    const marque  = String(r[5] ?? '').trim();
    const modele  = String(r[6] ?? '').trim();
    const couleur = String(r[7] ?? '').trim();
    const taille  = String(r[8] ?? '').trim();
    const veloDesc = [marque, modele, couleur, taille].filter(Boolean).join(', ');
    // r index = col offset depuis D : V=offset 18 (V-D), W=offset 19
    const noteClientEval    = String(r[18] ?? '').trim();
    const noteClientFacture = String(r[19] ?? '').trim();
    invMap.set(id, { client, veloDesc, noteClientEval, noteClientFacture });
  }

  // Override systématique — INVENTAIRE est la source de vérité pour le
  // nom du client, la description du vélo, et les notes EXT (eval/facture).
  for (const bdc of bdcs) {
    const inv = invMap.get(bdc.id);
    if (!inv) continue;  // BDC fantôme — garder les valeurs du BDC
    if (inv.client && inv.client !== 'Sélection →') {
      bdc.clientNom = inv.client;
    }
    if (inv.veloDesc) {
      bdc.veloDesc = inv.veloDesc;
    }
    bdc.noteClient        = inv.noteClientEval;
    bdc.noteClientFacture = inv.noteClientFacture;
  }

  await cache.set(CACHE_KEYS.BDCS, bdcs);
  return bdcs;
}

/** Lit un BDC par son ID. */
export async function getBDC(id: string): Promise<BDC | null> {
  const bdcs = await getBDCs();
  return bdcs.find(b => b.id === String(id)) ?? null;
}

/**
 * Parse les lignes brutes du sheet BDC en tableau de BDC structurés.
 * Une seule requête Sheets pour lire tout le sheet.
 */
export function parseBDCRows(rows: unknown[][], startRow: number): BDC[] {
  const bdcs: BDC[] = [];
  let current: (typeof bdcs)[0] | null = null;

  rows.forEach((r, idx) => {
    const rowNum = idx + startRow;
    const tag    = String(r[BDC_COL.TAG  - 1] ?? '').trim();
    const id     = String(r[BDC_COL.ID   - 1] ?? '').trim();
    const num    = (i: number) => parseFloat(String(r[i - 1] ?? '0')) || 0;
    const str    = (i: number) => String(r[i - 1] ?? '').trim();

    if (tag === BDC_TAG.BON) {
      // Col I (BDC_COL.SVC_ID = 9) utilisée sur la ligne BON pour stocker
      // les remises persistées en JSON : {"svc":{...},"pce":{...}}
      const remisesRaw = str(BDC_COL.SVC_ID);
      let remiseSvc: BDC['remiseSvc'];
      let remisePce: BDC['remisePce'];
      let avance   : BDC['avance'];
      if (remisesRaw) {
        try {
          const parsed = JSON.parse(remisesRaw);
          if (parsed?.svc && typeof parsed.svc.value === 'number') {
            remiseSvc = { type: parsed.svc.type === 'fixed' ? 'fixed' : 'pct', value: parsed.svc.value };
          }
          if (parsed?.pce && typeof parsed.pce.value === 'number') {
            remisePce = { type: parsed.pce.type === 'fixed' ? 'fixed' : 'pct', value: parsed.pce.value };
          }
          // v1.0.15 : avance était un simple `number`. v1.0.17 : devient
          // un objet {montant, mode, note}. Le parser accepte les deux.
          if (typeof parsed?.avance === 'number' && parsed.avance > 0) {
            avance = { montant: parsed.avance };
          } else if (parsed?.avance && typeof parsed.avance === 'object') {
            const m = Number(parsed.avance.montant);
            if (Number.isFinite(m) && m > 0) {
              const modeRaw = String(parsed.avance.mode ?? '').trim();
              const mode = (['comptant','interac','cartes'].includes(modeRaw) ? modeRaw : undefined) as
                'comptant' | 'interac' | 'cartes' | undefined;
              const note = String(parsed.avance.note ?? '').trim() || undefined;
              avance = { montant: m, mode, note };
            }
          }
        } catch { /* ancien contenu non-JSON : ignore */ }
      }
      // Lecture evalStatus (col J). Backwards compat : si vide et checkOk
      // est true (ancien flag boolean) → on infère APPROUVE.
      const checkOk      = !!r[BDC_COL.OK - 1];
      const evalStRaw    = String(r[BDC_COL.EVAL_ST - 1] ?? '').trim().toUpperCase();
      const validStatuts = ['APPROUVE', 'REDUX', 'ATTENTE', 'REFUSE'] as const;
      let evalStatus: '' | typeof validStatuts[number] = '';
      if ((validStatuts as readonly string[]).includes(evalStRaw)) {
        evalStatus = evalStRaw as typeof validStatuts[number];
      } else if (checkOk) {
        evalStatus = 'APPROUVE';
      }

      current = {
        id,
        dateIn     : parseSheetsDate(r[BDC_COL.IN - 1]) ?? str(BDC_COL.IN),
        veloDesc   : str(BDC_COL.VELO),
        clientNom  : '',
        noteClient : '',
        checkEval  : !!r[BDC_COL.EVAL - 1],
        checkOk,
        checkBds   : !!r[BDC_COL.BDS  - 1],
        checkOut   : !!r[BDC_COL.OUT  - 1],
        evalStatus,
        items      : [],
        totalServices: 0,
        totalPieces  : 0,
        _bonRow    : rowNum,
        remiseSvc,
        remisePce,
        avance,
      };
      bdcs.push(current);
      return;
    }

    if (!current) return;

    if (tag === BDC_TAG.GAP) {
      current.clientNom         = str(BDC_COL.VELO);                       // col H = nom client
      current.noteClient        = str(BDC_GAP_COL.NOTE_CLIENT);            // col V = note ÉVAL
      current.noteClientFacture = str(BDC_GAP_COL.NOTE_CLIENT_FACTURE);    // col W = note FACTURE
      return;
    }

    if (tag === BDC_TAG.TOT) {
      current.totalServices = num(BDC_COL.SVC_PX);
      current.totalPieces   = num(BDC_COL.PCE_TOT);
      return;
    }

    if (tag === BDC_TAG.SEP) {
      current = null; // fin du bloc
      return;
    }

    if (tag === BDC_TAG.ITEM) {
      const item: BDCItem = { _row: rowNum };

      const svcNom = str(BDC_COL.SVC);
      if (svcNom) {
        // v1.0.7+ : col J (EVAL_ST, index 10) sur ligne ITEM service est
        // libre — utilisée pour stocker un JSON `[true,false,...]` des
        // sous-items cochés (cross-device, persiste atelier ↔ maison).
        let subStates: boolean[] | undefined;
        const subRaw = str(BDC_COL.EVAL_ST);
        if (subRaw && (subRaw.startsWith('[') || subRaw.startsWith('{'))) {
          try {
            const parsed = JSON.parse(subRaw);
            if (Array.isArray(parsed) && parsed.every(b => typeof b === 'boolean')) {
              subStates = parsed;
            }
          } catch { /* JSON invalide — ignore, fallback undefined */ }
        }
        item.service = {
          serviceId: str(BDC_COL.SVC_ID) || undefined,
          nom   : svcNom,
          fait  : !!r[BDC_COL.SVC_CHK - 1],
          status: str(BDC_COL.SVC_TXT),
          prix  : num(BDC_COL.SVC_PX),
          subStates,
        };
      }

      const pceNom = str(BDC_COL.PCE);
      if (pceNom) {
        const pceId = str(BDC_COL.PCE_ID);   // col O — pieceId stable (v1.1.5+)
        item.piece = {
          pieceId  : pceId || undefined,
          nom      : pceNom,
          prix     : num(BDC_COL.PCE_PX),
          cmd      : str(BDC_COL.PCE_CHK),
          qte      : num(BDC_COL.PCE_QTE),
          sousTotal: num(BDC_COL.PCE_TOT),
          flag     : str(BDC_COL.PCE_FLAG),
          cmdNote  : str(BDC_COL.CMD_NOTE),  // col W — note commande fournisseur
        };
      }

      if (item.service || item.piece) current.items.push(item);
    }
  });

  return bdcs;
}

// ── Création ──────────────────────────────────────────────────────

/**
 * Crée les 6 lignes d'un nouveau BDC (BON/GAP/SEP0/BTN/TOT/SEP).
 * Équivalent de _creerBon() dans le GAS.
 */
export async function creerBon(idStr: string, clientNom = '', veloDesc = ''): Promise<void> {
  return creerBonMutex.runExclusive(async () => {
    // Force fresh read — un autre lambda peut avoir déjà créé le BDC.
    // Le del KV se propage cross-lambda (cf lib/cache.ts L2).
    await invalidateBDCsCache();

    // ⚠ Idempotence : si un BDC existe déjà avec ce ID (double-click, race
    // entre cron + clic manuel, ou appel multiple), on ne recrée pas. Sinon
    // on se retrouve avec 12 lignes au lieu de 6 dans le sheet.
    //
    // V1.0 hardening : on ne swallow plus les erreurs du check d'existence.
    // Avant : `.catch(() => -1)` traitait toute erreur (quota 429, réseau,
    // 5xx) comme « pas trouvé » → l'append créait un doublon. Cas observé
    // en prod : BDT 0106 quadruplé sous saturation Sheets API. Maintenant,
    // si le check échoue après les 8 retries gaxios, on abort la création
    // et on remonte une erreur explicite à la route API.
    let existingRow: number;
    try {
      existingRow = await _findBonRow(idStr);
    } catch (err: any) {
      const msg = err?.message ?? 'erreur Sheets';
      console.error(`[creerBon] check existence BDC ${idStr} échoué — abort :`, msg);
      throw new Error(
        `Création BDC ${idStr} bloquée : impossible de vérifier l'existence du BDC ` +
        `(${msg}). Réessaie dans 30 s — l'API Sheets est probablement saturée.`,
      );
    }
    if (existingRow > 0) {
      console.warn(`[creerBon] BDC ${idStr} déjà existant ligne ${existingRow} — skip`);
      return;
    }

    const sheets = getSheetsClient();
    const today  = todayStr();

    // 6 lignes — 22 colonnes chacune
    const empty = () => Array(BDC_COL.NB_COLS).fill('');

    const bon   = empty(); bon[BDC_COL.TAG - 1] = BDC_TAG.BON;  bon[BDC_COL.ID - 1] = idStr; bon[BDC_COL.IN - 1] = today; bon[BDC_COL.EVAL-1]=false; bon[BDC_COL.OK-1]=false; bon[BDC_COL.BDS-1]=false; bon[BDC_COL.OUT-1]=false; bon[BDC_COL.VELO-1]=veloDesc;
    const gap   = empty(); gap[BDC_COL.TAG - 1] = BDC_TAG.GAP;  gap[BDC_COL.ID - 1] = idStr; gap[BDC_COL.VELO-1] = clientNom;
    const sep0  = empty(); sep0[BDC_COL.TAG- 1] = BDC_TAG.SEP0;
    const btn   = empty(); btn[BDC_COL.TAG - 1] = BDC_TAG.BTN;  btn[BDC_COL.ID - 1] = idStr; btn[BDC_COL.SVC-1]=false; btn[BDC_COL.PCE-1]=false;
    const tot   = empty(); tot[BDC_COL.TAG - 1] = BDC_TAG.TOT;  tot[BDC_COL.SVC-1]='↑ Ajouter'; tot[BDC_COL.SVC_CHK-1]='total'; tot[BDC_COL.SVC_PX-1]=0; tot[BDC_COL.PCE-1]='↑ Ajouter'; tot[BDC_COL.PCE_CHK-1]='total'; tot[BDC_COL.PCE_TOT-1]=0;
    const sep   = empty(); sep[BDC_COL.TAG - 1] = BDC_TAG.SEP;

    await sheets.spreadsheets.values.append({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.BDC}!A${ROW.BDC_INS}`,
      valueInputOption : 'RAW',
      insertDataOption : 'INSERT_ROWS',
      requestBody      : { values: [bon, gap, sep0, btn, tot, sep] },
    });
  });
}

// ── Insertion d'items ─────────────────────────────────────────────

/**
 * Insère N lignes vides à `insertRow`, puis écrit `rows`. Si l'écriture
 * échoue, supprime les lignes vides pour éviter de corrompre le BDT
 * (rollback). Si le rollback échoue aussi, log severe — la corruption
 * est inévitable et nécessite un repair manuel via `repairBdcTotaux`.
 *
 * V1.0 hardening (P0.2) : avant ce helper, `insertServices` et
 * `insertPieces` faisaient deux appels API séquentiels sans rollback.
 * Si quota expirait après les 8 retries gaxios entre insertDimension et
 * values.update, le BDT se retrouvait avec N lignes ITEM vides au milieu
 * du bloc, polluant le PDF d'évaluation et les totaux.
 */
async function _safeInsertItemRows(
  bdcId    : string,
  insertRow: number,
  rows     : unknown[][],
): Promise<void> {
  const sheets   = getSheetsClient();
  const sheetId  = await _getBDCSheetId(sheets);
  const startIdx = insertRow - 1;
  const endIdx   = insertRow - 1 + rows.length;

  // Étape 1 : créer les N lignes vides.
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        insertDimension: {
          range: { sheetId, dimension: 'ROWS', startIndex: startIdx, endIndex: endIdx },
          inheritFromBefore: true,
        },
      }],
    },
  });

  // Étape 2 : écrire les valeurs. Si ça échoue, rollback les lignes vides.
  try {
    await sheets.spreadsheets.values.update({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.BDC}!A${insertRow}:V${insertRow + rows.length - 1}`,
      valueInputOption : 'RAW',
      requestBody      : { values: rows },
    });
  } catch (err: any) {
    const msg = err?.message ?? 'erreur inconnue';
    logWarn('bdc-insert-update-failed', {
      bdcId, insertRow, nRows: rows.length, error: msg,
    });
    // Rollback : supprimer les lignes vides.
    try {
      await sheets.spreadsheets.batchUpdate({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        requestBody  : {
          requests: [{
            deleteDimension: {
              range: { sheetId, dimension: 'ROWS', startIndex: startIdx, endIndex: endIdx },
            },
          }],
        },
      });
      logWarn('bdc-insert-rolled-back', { bdcId, insertRow, nRows: rows.length });
      throw new Error(
        `Écriture des items BDC ${bdcId} échouée — annulation effectuée. ` +
        `Réessaie dans 30 s. Détail : ${msg}`,
      );
    } catch (rollbackErr: any) {
      // Le rollback a échoué — la corruption est inévitable. Le BDT a N
      // lignes vides au milieu de son bloc. Il faudra réparer via
      // repairBdcTotaux + suppression manuelle des lignes vides.
      logError('bdc-insert-rollback-failed', {
        bdcId,
        insertRow,
        nRows         : rows.length,
        updateError   : msg,
        rollbackError : rollbackErr?.message ?? 'erreur inconnue',
      });
      throw new Error(
        `Écriture des items BDC ${bdcId} échouée ET annulation impossible — ` +
        `BDT corrompu, lignes vides à supprimer manuellement (rangée ${insertRow}, ` +
        `${rows.length} ligne(s)). Détail : ${msg}`,
      );
    }
  }
}

/**
 * Insère des services dans un BDC.
 * Équivalent de _insererServices() dans le GAS.
 */
export async function insertServices(bdcId: string, items: AddServiceInput[]): Promise<void> {
  await invalidateBDCsCache();
  const bdc = await getBDC(bdcId);
  if (!bdc) throw new Error(`BDC ${bdcId} introuvable`);

  // Filet de sécurité : exclure les entrées qui ne sont pas de vrais services
  // (sous-items de forfait, séparateurs, noms vides). Cf bdc-filters.ts.
  items = filterServiceItems(items);
  if (items.length === 0) return;

  const insertRow = _insertBoundary(bdc);

  const rows = items.map(item => {
    const r = Array(BDC_COL.NB_COLS).fill('');
    r[BDC_COL.TAG    - 1] = BDC_TAG.ITEM;
    r[BDC_COL.ID     - 1] = bdcId;
    r[BDC_COL.SVC_ID - 1] = item.serviceId || '';   // col I — ID stable
    r[BDC_COL.SVC    - 1] = item.nom;
    r[BDC_COL.SVC_CHK- 1] = false;
    r[BDC_COL.SVC_TXT- 1] = '...';
    r[BDC_COL.SVC_PX - 1] = item.prix;
    return r;
  });

  await _safeInsertItemRows(bdcId, insertRow, rows);
  await _recalcTotaux(bdcId);
}

/**
 * Insère des pièces dans un BDC.
 * Équivalent de _insererPieces() dans le GAS.
 */
export async function insertPieces(bdcId: string, items: AddPieceInput[]): Promise<void> {
  await invalidateBDCsCache();
  const bdc = await getBDC(bdcId);
  if (!bdc) throw new Error(`BDC ${bdcId} introuvable`);

  const insertRow = _insertBoundary(bdc);

  const rows = items.map(item => {
    const r = Array(BDC_COL.NB_COLS).fill('');
    r[BDC_COL.TAG     - 1] = BDC_TAG.ITEM;
    r[BDC_COL.ID      - 1] = bdcId;
    r[BDC_COL.PCE_ID  - 1] = item.pieceId ?? '';   // col O — pieceId stable (v1.1.5+)
    r[BDC_COL.PCE     - 1] = item.nom;
    r[BDC_COL.PCE_PX  - 1] = item.prix;
    r[BDC_COL.PCE_CHK - 1] = '...';
    r[BDC_COL.PCE_QTE - 1] = item.qte;
    r[BDC_COL.PCE_TOT - 1] = item.prix * item.qte;
    r[BDC_COL.PCE_FLAG- 1] = item.flag ?? '';
    return r;
  });

  await _safeInsertItemRows(bdcId, insertRow, rows);
  await _recalcTotaux(bdcId);
}

// ── Workflow checkboxes ───────────────────────────────────────────

/** PATCH évaluation envoyée (checkbox EVAL = D). */
export async function setCheckEval(bdcId: string, value: boolean): Promise<void> {
  await invalidateBDCsCache();
  const row = await _findBonRow(bdcId);
  if (row < 0) throw new Error(`BDC ${bdcId} introuvable`);

  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!D${row}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [[value]] },
  });
}

/** PATCH approbation (checkbox OK = E) → statut APPROUVÉ dans INVENTAIRE. */
export async function setCheckOk(bdcId: string, value: boolean): Promise<void> {
  await invalidateBDCsCache();
  const row = await _findBonRow(bdcId);
  if (row < 0) throw new Error(`BDC ${bdcId} introuvable`);

  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!E${row}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [[value]] },
  });
}

/** PATCH bon-de-sortie (checkbox BDS = F). */
export async function setCheckBds(bdcId: string, value: boolean): Promise<void> {
  await invalidateBDCsCache();
  const row = await _findBonRow(bdcId);
  if (row < 0) throw new Error(`BDC ${bdcId} introuvable`);

  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!F${row}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [[value]] },
  });
}

/** PATCH evalStatus (col J ligne BON) — '' | APPROUVE | REDUX | ATTENTE | REFUSE.
 *  Aussi écrit checkOk (col E) = true ssi status === 'APPROUVE' pour
 *  rester compatible avec le code legacy qui se base sur checkOk. */
export async function setEvalStatus(
  bdcId: string,
  value: '' | 'APPROUVE' | 'REDUX' | 'ATTENTE' | 'REFUSE',
): Promise<void> {
  await invalidateBDCsCache();
  const row = await _findBonRow(bdcId);
  if (row < 0) throw new Error(`BDC ${bdcId} introuvable`);

  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      valueInputOption: 'RAW',
      data: [
        { range: `${TAB.BDC}!J${row}`, values: [[value]] },             // col J
        { range: `${TAB.BDC}!E${row}`, values: [[value === 'APPROUVE']] }, // col E (legacy)
      ],
    },
  });
}

/** Set col G (checkOut) de la ligne BON. Utilisé pour décocher
 *  Archiver et permettre de re-cliquer pour archiver à nouveau. */
export async function setCheckOut(bdcId: string, value: boolean): Promise<void> {
  await invalidateBDCsCache();
  const row = await _findBonRow(bdcId);
  if (row < 0) throw new Error(`BDC ${bdcId} introuvable`);

  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!G${row}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [[value]] },
  });
}

/**
 * Archive un BDC (checkbox OUT = G) :
 * - copie les lignes vers ARCHIVES 2026
 * - supprime les lignes sources
 * - écrit dateOUT dans CLIENTS
 * Équivalent de _archiverBDCParId() dans le GAS.
 */
// ── BACKUPS append-only ──────────────────────────────────────────────
//
// Avant chaque opération destructive (archivage, désarchivage, refus
// d'évaluation), on snapshot l'état complet du BDC dans un onglet append-only
// `_BDC_BACKUPS_`. Cet onglet ne doit JAMAIS être modifié ou nettoyé : il
// constitue le filet de sécurité pour récupérer un BDC perdu ou corrompu.
//
// Schéma BDC_BACKUPS :
//   A timestamp (ISO yyyy-MM-dd HH:mm:ss UTC)
//   B action     ('archive' | 'desarchive' | 'archive-refuse')
//   C bdcId
//   D clientNom
//   E veloDesc
//   F json_bdc_rows  (JSON des lignes BON→SEP de BONS DE COMMANDES)
//   G json_inv_row   (JSON de la ligne INVENTAIRE A:X)
//   H note           (texte libre, ex. raison)
const _BACKUPS_HEADERS = [
  'timestamp', 'action', 'bdcId', 'clientNom', 'veloDesc',
  'json_bdc_rows', 'json_inv_row', 'note',
];

/** Crée l'onglet _BDC_BACKUPS_ s'il n'existe pas, avec ligne d'en-tête. */
async function _ensureBackupsTab(): Promise<void> {
  const sheets = getSheetsClient();
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const exists = (meta.data.sheets ?? []).some(
    s => s.properties?.title === TAB.BDC_BACKUPS,
  );
  if (exists) return;

  // Créer l'onglet
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        addSheet: {
          properties: {
            title: TAB.BDC_BACKUPS,
            gridProperties: { rowCount: 2000, columnCount: 8 },
          },
        },
      }],
    },
  });

  // Écrire les en-têtes
  await sheets.spreadsheets.values.update({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.BDC_BACKUPS}!A1:H1`,
    valueInputOption: 'RAW',
    requestBody     : { values: [_BACKUPS_HEADERS] },
  });
}

/**
 * Snapshot append-only d'un BDC dans l'onglet _BDC_BACKUPS_. Best-effort :
 * ne throw jamais — un échec de snapshot ne doit pas bloquer l'opération
 * principale. Le snapshot capture les lignes BONS DE COMMANDES (BON→SEP)
 * et la ligne INVENTAIRE complète (A:X) au moment de l'appel.
 *
 * @param bdcId  ID du BDC à snapshoter
 * @param action 'archive' | 'desarchive' | 'archive-refuse'
 * @param note   message libre (raison, contexte)
 */
export async function snapshotBDC(
  bdcId : string,
  action: 'archive' | 'desarchive' | 'archive-refuse' | 'pre-delete' | 'manual',
  note  : string = '',
): Promise<void> {
  try {
    const sheets = getSheetsClient();
    await _ensureBackupsTab();

    // 1. Tenter de lire le BDC actuel (BONS DE COMMANDES)
    let bdcRows: unknown[][] = [];
    let clientNom = '';
    let veloDesc  = '';
    try {
      const bdc = await getBDC(bdcId);
      if (bdc) {
        clientNom = bdc.clientNom ?? '';
        veloDesc  = bdc.veloDesc ?? '';
        const sepRow = await _findSepRow(bdc._bonRow);
        if (sepRow > 0) {
          const r = await sheets.spreadsheets.values.get({
            spreadsheetId    : SHEET_IDS.INVENTAIRE,
            range            : `${TAB.BDC}!A${bdc._bonRow}:W${sepRow}`,
            valueRenderOption: 'FORMATTED_VALUE',
          });
          bdcRows = r.data.values ?? [];
        }
      }
    } catch (err: any) {
      console.warn(`[snapshotBDC] lecture BDC ${bdcId} échouée :`, err?.message ?? err);
    }

    // 2. Tenter de lire la ligne INVENTAIRE
    let invRow: unknown[] = [];
    try {
      const { findVeloRow } = await import('./inventaire');
      const veloRow = await findVeloRow(bdcId);
      if (veloRow > 0) {
        const r = await sheets.spreadsheets.values.get({
          spreadsheetId    : SHEET_IDS.INVENTAIRE,
          range            : `${TAB.INVENTAIRE}!A${veloRow}:W${veloRow}`,
          valueRenderOption: 'FORMATTED_VALUE',
        });
        invRow = r.data.values?.[0] ?? [];
      }
    } catch (err: any) {
      console.warn(`[snapshotBDC] lecture INVENTAIRE ${bdcId} échouée :`, err?.message ?? err);
    }

    // 3. Si on n'a strictement rien, on logue et on sort (pas d'append vide)
    if (bdcRows.length === 0 && invRow.length === 0) {
      console.warn(`[snapshotBDC] aucune donnée à sauvegarder pour BDC ${bdcId}`);
      return;
    }

    // 4. Append dans BDC_BACKUPS
    const ts = new Date().toISOString().replace('T', ' ').substring(0, 19);
    await sheets.spreadsheets.values.append({
      spreadsheetId   : SHEET_IDS.INVENTAIRE,
      range           : `${TAB.BDC_BACKUPS}!A1`,
      valueInputOption: 'RAW',
      insertDataOption: 'INSERT_ROWS',
      requestBody     : {
        values: [[
          ts,
          action,
          bdcId,
          clientNom,
          veloDesc,
          JSON.stringify(bdcRows),
          JSON.stringify(invRow),
          note,
        ]],
      },
    });

    console.log(`[snapshotBDC] ${action} ${bdcId} — ${bdcRows.length} BDC rows + ${invRow.length} inv cols snapshot`);
  } catch (err: any) {
    // Best-effort absolu : on ne propage jamais
    console.warn(`[snapshotBDC] échec global ${bdcId} :`, err?.message ?? err);
  }
}

export interface BDCBackupEntry {
  /** Numéro de ligne dans _BDC_BACKUPS_ (pour debug/référence) */
  _row: number;
  timestamp: string;
  action: string;      // archive | desarchive | archive-refuse | pre-delete | pre-delete-archive | manual
  bdcId: string;
  clientNom: string;
  veloDesc: string;
  note: string;
  /** True si des données BDC ont été capturées (rows BON→SEP). */
  hasBdcRows: boolean;
  /** True si une ligne INVENTAIRE a été capturée. */
  hasInvRow: boolean;
}

/**
 * Lit les entrées de _BDC_BACKUPS_, les plus récentes en premier.
 * Ne renvoie PAS les JSON bruts (bdc_rows, inv_row) — uniquement les
 * métadonnées pour listing. Pour récupérer un snapshot complet il faut
 * ouvrir le sheet directement (ou ajouter un endpoint dédié).
 */
export async function getBDCBackups(limit = 200): Promise<BDCBackupEntry[]> {
  const sheets = getSheetsClient();
  // Ligne 1 = en-têtes, données dès ligne 2
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC_BACKUPS}!A2:H`,
    valueRenderOption: 'FORMATTED_VALUE',
  }).catch(err => {
    // Onglet pas encore créé → pas d'entries
    if ((err as any)?.code === 400) return { data: { values: [] } } as any;
    throw err;
  });

  const rows: unknown[][] = res.data.values ?? [];
  const entries: BDCBackupEntry[] = [];
  rows.forEach((r: unknown[], idx: number) => {
    const s = (i: number) => String(r[i] ?? '').trim();
    const bdcId = s(2);
    if (!bdcId) return;
    entries.push({
      _row      : idx + 2,
      timestamp : s(0),
      action    : s(1),
      bdcId,
      clientNom : s(3),
      veloDesc  : s(4),
      note      : s(7),
      hasBdcRows: s(5).length > 2, // '[]' ou '' → false
      hasInvRow : s(6).length > 2,
    });
  });

  // Plus récents en premier, cap au `limit`
  return entries.reverse().slice(0, limit);
}

/**
 * Archive un BDC avec le statut « REFUSÉ » écrit dans la colonne C
 * (status) de INVENTAIRE avant la copie vers ARCHIVES. Utilisé quand
 * le client refuse les travaux évalués — pas de facture générée.
 *
 * Le statut REFUSÉ est ensuite affiché en rouge dans la page Vélos
 * (au lieu du gris « Archivé » par défaut).
 */
export async function archiverBDCRefuse(bdcId: string): Promise<void> {
  await invalidateBDCsCache();
  // Snapshot AVANT toute modification destructive
  await snapshotBDC(bdcId, 'archive-refuse', 'Évaluation refusée par le client');

  const sheets = getSheetsClient();
  const { findVeloRow } = await import('./inventaire');
  const veloRow = await findVeloRow(bdcId);

  if (veloRow > 0) {
    // Écrit le statut REFUSÉ dans col C — il sera copié vers ARCHIVES
    // par archiverBDC ci-dessous (qui copie A:W de la ligne INVENTAIRE).
    await sheets.spreadsheets.values.update({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.INVENTAIRE}!C${veloRow}`,
      valueInputOption : 'RAW',
      requestBody      : { values: [['REFUSÉ']] },
    });
  }

  // Flux d'archivage standard — le statut REFUSÉ écrit ci-dessus sera
  // copié vers ARCHIVES col C avec le reste de la ligne INVENTAIRE.
  await archiverBDC(bdcId);
}

export async function archiverBDC(bdcId: string): Promise<void> {
  await invalidateBDCsCache();
  // Lignes décalées → invalider les lookup caches (BON et VELO)
  _clearFindRowCache();
  const { _clearFindVeloRowCache } = await import('./inventaire');
  _clearFindVeloRowCache();
  // Snapshot AVANT toute modification destructive — best-effort, ne bloque pas
  await snapshotBDC(bdcId, 'archive');

  const sheets = getSheetsClient();
  const allBDCs = await getBDCs();
  const bdc     = allBDCs.find(b => b.id === bdcId);
  if (!bdc) throw new Error(`BDC ${bdcId} introuvable`);

  // ── 1. Trouver la ligne INVENTAIRE du vélo ──
  const { findVeloRow } = await import('./inventaire');
  const veloRow = await findVeloRow(bdcId);

  // ── 2. Préparer les totaux et items du BDC ──
  // ⚠ On recalcule les totaux depuis les items (pas depuis bdc.totalServices /
  // bdc.totalPieces lu de la ligne TOT) car la ligne TOT peut être désynchro
  // si un item a été ajouté sans recalc (cf. BDT0120 archivé à 29,00 au lieu
  // de 29,75). Source de vérité = les items eux-mêmes.
  const totalServices = bdc.items.reduce((s, i) => s + (i.service?.prix ?? 0), 0);
  const totalPieces   = bdc.items.reduce((s, i) => s + (i.piece?.sousTotal ?? 0), 0);
  const svcNames = bdc.items
    .filter(it => it.service)
    .map(it => it.service!.nom)
    .join('\n');
  const pceNames = bdc.items
    .filter(it => it.piece)
    .map(it => it.piece!.nom)
    .join('\n');

  // ── 3. Écrire services/pièces texte + dates dans la ligne INVENTAIRE avant copie ──
  // Nouveau schéma INVENTAIRE (v7.0.4) :
  //   N=ÉVAL méca, O=MÉCA, P=CTRL, Q=NOTE_VELO,
  //   R=SERVICES texte, S=PIÈCES texte,
  //   U=NOTES INTERNES, V=NOTE EVAL ext, W=NOTE FACTURE ext.
  // Plus besoin de backup notes internes (col U dédiée, pas écrasée).
  // Totaux services/pièces calculés à la volée (plus persistés en sheet).
  if (veloRow > 0) {
    const { todayStr } = await import('@/lib/utils/format');
    const dateOutArchive = todayStr();
    const dateTravaux    = todayStr();

    const data: { range: string; values: unknown[][] }[] = [
      { range: `${TAB.INVENTAIRE}!R${veloRow}`, values: [[svcNames]] },        // col R = SERVICES
      { range: `${TAB.INVENTAIRE}!S${veloRow}`, values: [[pceNames]] },        // col S = PIÈCES
      // Date OUT (col G) = date+heure de l'archivage — toujours écrire
      { range: `${TAB.INVENTAIRE}!G${veloRow}`, values: [[dateOutArchive]] },
    ];
    // totalServices / totalPieces gardés en variables — pourront être passés
    // à ARCHIVES après la copie si nécessaire (cf ci-dessous).
    void totalServices; void totalPieces;

    // Date travaux (col F) — écrire seulement si vide
    const curF = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.INVENTAIRE}!F${veloRow}`,
      valueRenderOption: 'FORMATTED_VALUE',
    });
    const colFVal = String(curF.data.values?.[0]?.[0] ?? '').trim();
    if (!colFVal) {
      data.push({ range: `${TAB.INVENTAIRE}!F${veloRow}`, values: [[dateTravaux]] });
    }

    await sheets.spreadsheets.values.batchUpdate({
      spreadsheetId: SHEET_IDS.INVENTAIRE,
      requestBody  : { valueInputOption: 'RAW', data },
    });

    // ── 4. Lire la ligne INVENTAIRE complète et copier vers ARCHIVES ligne 5 ──
    // INVENTAIRE A:W (23 cols) — Layout :
    //   A B C(status) D(id) E F G H(client) I-M(vélo) N(eval) O(meca) P(ctrl)
    //   Q(noteVélo) R(svc text) S(pce text) T(libre) U(notes int)
    //   V(note eval ext) W(note facture ext)
    // ARCHIVES A:X (24 cols) — Layout (avec 2 cols supplémentaires totaux) :
    //   ... idem N→R (vélo/mécanos/svc), S(total svc) T(pce text)
    //   U(total pce) V(notes int) W(note eval ext) X(note facture ext) Y(JSON)
    // Donc : remap INVENTAIRE col → ARCHIVES col en insérant totaux S et U.
    const invRes = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.INVENTAIRE}!A${veloRow}:W${veloRow}`,
      valueRenderOption: 'FORMATTED_VALUE',
    });

    if (invRes.data.values?.length) {
      const inv = invRes.data.values[0];
      // Remplir avec '' jusqu'à index 22 pour éviter les undefined
      while (inv.length < 23) inv.push('');
      // Reconstruire la ligne ARCHIVES en insérant totaux $ services (S=18)
      // et totaux $ pièces (U=20).
      const archRow: unknown[] = [
        inv[0],          // A
        false,           // B = checkbox archivé (FALSE)
        inv[2],          // C status
        inv[3],          // D ID
        inv[4],          // E date entrée
        inv[5],          // F date travaux
        inv[6],          // G date sortie
        inv[7],          // H client
        inv[8],          // I marque
        inv[9],          // J modèle
        inv[10],         // K couleur
        inv[11],         // L taille
        inv[12],         // M série
        inv[13],         // N eval méca
        inv[14],         // O méca méca
        inv[15],         // P ctrl méca
        inv[16],         // Q noteVélo
        inv[17],         // R services texte
        totalServices,   // S = total $ services (calculé, NOUVEAU dans ARCHIVES)
        inv[18],         // T pièces texte (était INVENTAIRE.S)
        totalPieces,     // U = total $ pièces (calculé, NOUVEAU dans ARCHIVES)
        inv[20],         // V notes internes (était INVENTAIRE.U)
        inv[21],         // W note eval ext (était INVENTAIRE.V)
        inv[22],         // X note facture ext (était INVENTAIRE.W)
      ];

      // Trouver le sheetId de ARCHIVES
      const archMeta = await sheets.spreadsheets.get({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        fields       : 'sheets.properties',
      });
      const archSheet = archMeta.data.sheets?.find(s => s.properties?.title === TAB.ARCHIVES);
      const archSheetId = archSheet?.properties?.sheetId;

      if (archSheetId !== undefined) {
        // Insérer une nouvelle ligne à la position 5 (index 4, 0-based) → décale les données existantes
        await sheets.spreadsheets.batchUpdate({
          spreadsheetId: SHEET_IDS.INVENTAIRE,
          requestBody  : {
            requests: [{
              insertDimension: {
                range: {
                  sheetId   : archSheetId,
                  dimension : 'ROWS',
                  startIndex: 4,   // ligne 5 (0-based = 4)
                  endIndex  : 5,
                },
                inheritFromBefore: true,  // copie le formatage de la ligne 4/5
              },
            }],
          },
        });

        // Écrire les données dans la ligne 5 (archRow remappée avec totaux)
        await sheets.spreadsheets.values.update({
          spreadsheetId    : SHEET_IDS.INVENTAIRE,
          range            : `'${TAB.ARCHIVES}'!A5`,
          valueInputOption : 'RAW',
          requestBody      : { values: [archRow] },
        });
      }
    }

    // ⚠ v6.5.0 — Plus de décrément stock à l'archivage. Le décrément AB
    // est désormais déclenché à la FACTURATION (status FACTURÉ), pas à
    // l'archivage. Un BDT archivé sans avoir été facturé (REFUSÉ, abandon)
    // ne consomme aucune pièce. Un BDT facturé avant archivage a déjà eu
    // son décrément ; le ré-archivage ne le re-fait pas.

    // ── 5. Supprimer la ligne INVENTAIRE ──
    const invMeta = await sheets.spreadsheets.get({
      spreadsheetId: SHEET_IDS.INVENTAIRE,
      fields       : 'sheets.properties',
    });
    const invSheet = invMeta.data.sheets?.find(s => s.properties?.title === TAB.INVENTAIRE);
    const invSheetId = invSheet?.properties?.sheetId;
    if (invSheetId !== undefined) {
      await sheets.spreadsheets.batchUpdate({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        requestBody  : {
          requests: [{
            deleteDimension: {
              range: {
                sheetId   : invSheetId,
                dimension : 'ROWS',
                startIndex: veloRow - 1,
                endIndex  : veloRow,
              },
            },
          }],
        },
      });
    }
  }

  // ── 6. Sauvegarder les lignes BDC en JSON dans ARCHIVES col Y avant suppression ──
  // (Col X était utilisée avant le décalage v7.0.4 ; maintenant Y, après les
  //  notes EXT eval/facture en V/W/X.)
  const bonRow = bdc._bonRow;
  const sepRow = await _findSepRow(bonRow);
  if (sepRow < 0) throw new Error(`SEP introuvable pour BDC ${bdcId}`);

  // Lire les lignes BDC brutes (BON→SEP)
  const bdcLinesRes = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!A${bonRow}:W${sepRow}`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const bdcLines = bdcLinesRes.data.values ?? [];

  // Écrire le JSON dans ARCHIVES col Y (ligne 5, la ligne qu'on vient d'insérer)
  if (bdcLines.length > 0) {
    await sheets.spreadsheets.values.update({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `'${TAB.ARCHIVES}'!Y5`,
      valueInputOption : 'RAW',
      requestBody      : { values: [[JSON.stringify(bdcLines)]] },
    });
  }

  const nbRows  = sepRow - bonRow + 1;
  const sheetId = await _getBDCSheetId(sheets);
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        deleteDimension: {
          range: {
            sheetId   : sheetId,
            dimension : 'ROWS',
            startIndex: bonRow - 1,
            endIndex  : bonRow - 1 + nbRows,
          },
        },
      }],
    },
  });
}

// ── Archives ──────────────────────────────────────────────────────

/**
 * Lit tous les BDC archivés depuis l'onglet ARCHIVES 2026.
 * Même structure que les BDC actifs — parsés avec parseBDCRows.
 */
/**
 * Lit les BDC archivés depuis ARCHIVES 2026.
 * Le format ARCHIVES est celui d'INVENTAIRE (pas de tags BON/GAP/ITEM) :
 *   Col B = checkbox (FALSE/TRUE)
 *   Col C = Status (FACTURER, FACTURÉ, LIVRÉ…)
 *   Col D = ID (0100, 0101…)
 *   Col E = Date entrée
 *   Col F = Date travaux
 *   Col G = Date sortie
 *   Col H = Client
 *   Col I = Marque
 *   Col J = Modèle
 *   Col K = Couleur
 *   Col L = Taille
 *   Col M = # série
 *   Col S = Services (texte)
 *   Col T = Total $ services
 *   Col U = Pièces (texte)
 *   Col V = Total $ pièces
 *   Col W = Notes
 * Les 4 premières lignes sont des en-têtes.
 */
export async function getArchivedBDCs(): Promise<BDC[]> {
  const sheets = getSheetsClient();
  // 2 lectures parallèles :
  // Layout ARCHIVES (v7.0.4) : A:Y (25 cols). Cf rowToVelo et archiverBDC.
  //  - FORMATTED_VALUE pour textes (dates, noms, JSON).
  //  - UNFORMATTED_VALUE pour totaux S (total $ svc) et U (total $ pce)
  //    — sinon les cells formatées "0 $" renvoient des valeurs arrondies
  //    (bug : 28,75 lu comme 29,00).
  const [resF, resU] = await Promise.all([
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `'${TAB.ARCHIVES}'!A5:Y`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `'${TAB.ARCHIVES}'!S5:U`,
      valueRenderOption: 'UNFORMATTED_VALUE',
    }),
  ]);

  const rows = resF.data.values ?? [];
  const totRows = resU.data.values ?? [];  // col S(0), T(1), U(2)
  const bdcs: BDC[] = [];
  const ARCHIVE_DATA_START = 5; // les données commencent à la ligne 5

  for (let idx = 0; idx < rows.length; idx++) {
    const r = rows[idx];
    const s   = (i: number) => String(r[i] ?? '').trim();
    const id  = s(3);  // col D = ID
    if (!id || id === 'ID') continue;  // skip headers/vides

    // Reconstituer les items depuis le JSON en col Y (était col X avant
    // le décalage v7.0.4) — lignes brutes BDC sauvegardées à l'archivage.
    let items: BDCItem[] = [];
    const colY = String(r[24] ?? '').trim();
    if (colY && colY.startsWith('[')) {
      try {
        const bdcLines = JSON.parse(colY) as unknown[][];
        const parsed = parseBDCRows(bdcLines, 1);
        if (parsed.length > 0) items = parsed[0].items;
      } catch { /* JSON malformé — on laisse items vide */ }
    }

    // Totaux archivés : priorité au calcul depuis items (source de vérité
    // si le JSON col Y est présent). Fallback sur la valeur brute UNFORMATTED
    // (col S/U) qui n'est pas arrondie par le format du sheet.
    const totRow = totRows[idx] ?? [];
    const totSvcRaw = Number(totRow[0] ?? 0) || 0;  // S (unformatted)
    const totPceRaw = Number(totRow[2] ?? 0) || 0;  // U (unformatted)
    const totSvcFromItems = items.reduce((s, i) => s + (i.service?.prix ?? 0), 0);
    const totPceFromItems = items.reduce((s, i) => s + (i.piece?.sousTotal ?? 0), 0);

    bdcs.push({
      id,
      dateIn       : s(4),          // col E = Date entrée
      dateOut      : s(6) || undefined,  // col G = Date sortie
      veloDesc     : [s(8), s(9), s(10), s(11)].filter(Boolean).join(', '), // Marque, Modèle, Couleur, Taille
      clientNom    : s(7),          // col H = Client
      noteClient   : '',
      checkEval    : false,
      checkOk      : false,
      checkBds     : false,
      checkOut     : !!s(6),        // a une date sortie
      items,
      // Si on a des items JSON, on utilise leur somme (toujours exacte).
      // Sinon on utilise la valeur UNFORMATTED du sheet (jamais arrondie).
      totalServices: items.length > 0 ? totSvcFromItems : totSvcRaw,
      totalPieces  : items.length > 0 ? totPceFromItems : totPceRaw,
      _bonRow      : idx + ARCHIVE_DATA_START,  // numéro de ligne réel dans ARCHIVES
      archiveStatus: s(2),          // col C = Status (ex. 'REFUSÉ', 'LIVRÉ')
      evalMecano   : s(13),         // col N = mécanicien évaluation (était O)
      mecaMecano   : s(14),         // col O = mécanicien mécanique  (était P)
      ctrlMecano   : s(15),         // col P = mécanicien ctrl. qlté (était Q)
      noteVelo     : s(16),         // col Q = Note sur le vélo (était N)
      noteInterne  : s(21),         // col V = notes internes (était W)
    });
  }

  return bdcs;
}

/**
 * Désarchive un BDC : copie la ligne ARCHIVES vers INVENTAIRE, puis supprime de ARCHIVES.
 * Écrit col B = FALSE (checkbox) dans INVENTAIRE.
 */
/**
 * Modifie une date dans ARCHIVES 2026.
 * field: 'dateIn' → col E, 'dateTravaux' → col F, 'dateOut' → col G
 */
export async function patchArchiveDate(archiveRow: number, field: string, value: string): Promise<void> {
  const colMap: Record<string, string> = {
    dateIn      : 'E',
    dateTravaux : 'F',
    dateOut     : 'G',
  };
  const col = colMap[field];
  if (!col) throw new Error(`Champ inconnu : ${field}`);

  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `'${TAB.ARCHIVES}'!${col}${archiveRow}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [[value]] },
  });
}

/**
 * Supprime DÉFINITIVEMENT une ligne d'ARCHIVES (poubelle).
 * Snapshot append-only avant la suppression pour pouvoir restaurer si l'utilisateur regrette.
 */
export async function deleteArchivedBDC(bdcId: string, archiveRow: number): Promise<void> {
  await invalidateBDCsCache();
  _clearFindRowCache();
  const sheets = getSheetsClient();

  // Snapshot AVANT suppression — capture la ligne ARCHIVES complète A:Y
  // (inclut le JSON BDC en col Y depuis v7.0.4) dans _BDC_BACKUPS_.
  try {
    await _ensureBackupsTab();
    const r = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `'${TAB.ARCHIVES}'!A${archiveRow}:Y${archiveRow}`,
      valueRenderOption: 'FORMATTED_VALUE',
    });
    const archiveLine = r.data.values?.[0] ?? [];
    const ts = new Date().toISOString().replace('T', ' ').substring(0, 19);
    await sheets.spreadsheets.values.append({
      spreadsheetId   : SHEET_IDS.INVENTAIRE,
      range           : `${TAB.BDC_BACKUPS}!A1`,
      valueInputOption: 'RAW',
      insertDataOption: 'INSERT_ROWS',
      requestBody     : {
        values: [[
          ts,
          'pre-delete-archive',
          bdcId,
          String(archiveLine[7] ?? ''),  // clientNom col H
          [archiveLine[8], archiveLine[9], archiveLine[10], archiveLine[11]].filter(Boolean).join(', '),
          '[]',                          // pas de bdc rows (déjà archivé)
          JSON.stringify(archiveLine),   // ligne ARCHIVES complète
          'suppression définitive depuis page Archives',
        ]],
      },
    });
  } catch (err: any) {
    console.warn(`[deleteArchivedBDC] snapshot ${bdcId} échoué :`, err?.message ?? err);
  }

  // Trouver le sheetId d'ARCHIVES
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const archSheet = meta.data.sheets?.find(s => s.properties?.title === TAB.ARCHIVES);
  const archSheetId = archSheet?.properties?.sheetId;
  if (archSheetId === undefined) throw new Error(`Onglet ${TAB.ARCHIVES} introuvable`);

  // Suppression de la ligne
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        deleteDimension: {
          range: {
            sheetId   : archSheetId,
            dimension : 'ROWS',
            startIndex: archiveRow - 1,
            endIndex  : archiveRow,
          },
        },
      }],
    },
  });

  // Retirer le bdcId de toutes les fiches CLIENTS qui le référencent
  // (sinon la fiche client garde une pill 'fantôme' orpheline).
  try {
    const { retirerBDCIdGlobal } = await import('./clients');
    await retirerBDCIdGlobal(bdcId);
  } catch (err: any) {
    console.warn(`[deleteArchivedBDC] retirerBDCIdGlobal ${bdcId} échoué :`, err?.message ?? err);
  }
}

/**
 * Supprime DÉFINITIVEMENT un BDC actif (pas encore archivé).
 * Opération destructive, multi-sheets :
 *   1. Snapshot pré-delete dans _BDC_BACKUPS_ (best-effort)
 *   2. Supprime les lignes BON→SEP du sheet BONS DE COMMANDES
 *   3. Supprime la ligne INVENTAIRE correspondante via deleteVelo()
 *   4. Retire le bdcId de la col I/J du client (via retirerBDCId)
 *
 * Utilisé quand un BDC actif doit disparaître complètement (ex. création
 * erronée, test). Pour archiver, utiliser archiverBDC() à la place.
 */
export async function deleteBDC(bdcId: string): Promise<void> {
  if (!bdcId) throw new Error('bdcId manquant');
  await invalidateBDCsCache();
  _clearFindRowCache();
  const { _clearFindVeloRowCache } = await import('./inventaire');
  _clearFindVeloRowCache();

  const sheets = getSheetsClient();

  // 1. Snapshot AVANT toute suppression (best-effort)
  await snapshotBDC(bdcId, 'pre-delete', 'suppression depuis modal client');

  // 2. Récupérer le BDC pour avoir _bonRow et clientNom
  const bdc = await getBDC(bdcId);
  const clientNom = bdc?.clientNom ?? '';

  // 3. Supprimer les lignes BON→SEP du sheet BONS DE COMMANDES
  if (bdc?._bonRow) {
    const sepRow = await _findSepRow(bdc._bonRow);
    if (sepRow > 0) {
      const bdcSheetId = await _getBDCSheetId(sheets);
      await sheets.spreadsheets.batchUpdate({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        requestBody  : {
          requests: [{
            deleteDimension: {
              range: {
                sheetId   : bdcSheetId,
                dimension : 'ROWS',
                startIndex: bdc._bonRow - 1,   // 0-indexed
                endIndex  : sepRow,            // exclusif, inclut la SEP
              },
            },
          }],
        },
      });
    } else {
      console.warn(`[deleteBDC] SEP introuvable pour ${bdcId} — lignes BDC non supprimées`);
    }
  } else {
    console.warn(`[deleteBDC] BDC ${bdcId} absent du sheet BONS DE COMMANDES`);
  }

  // 4. Supprimer la ligne INVENTAIRE (best-effort : noop si vélo absent)
  try {
    const { deleteVelo } = await import('./inventaire');
    await deleteVelo(bdcId);
  } catch (err: any) {
    console.warn(`[deleteBDC] deleteVelo ${bdcId} échoué :`, err?.message ?? err);
  }

  // 5. Retirer de la col I/J du client (best-effort)
  if (clientNom) {
    try {
      const { retirerBDCId } = await import('./clients');
      await retirerBDCId(clientNom, bdcId);
    } catch (err: any) {
      console.warn(`[deleteBDC] retirerBDCId ${bdcId} échoué :`, err?.message ?? err);
    }
  }
}

/**
 * Renomme l'ID d'un BDC archivé (col D dans ARCHIVES) + met à jour CLIENTS col I.
 */
export async function renameArchivedBDC(archiveRow: number, oldId: string, newId: string): Promise<void> {
  await invalidateBDCsCache();
  const sheets = getSheetsClient();

  // 1. Mettre à jour col D dans ARCHIVES
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `'${TAB.ARCHIVES}'!D${archiveRow}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [[newId]] },
  });

  // 2. Mettre à jour CLIENTS col I (remplacer oldId par newId)
  const clientsRes = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.CLIENTS,
    range            : `${TAB.CLIENTS_EXT}!I5:I`,
    valueRenderOption: 'FORMATTED_VALUE',
  });

  for (let idx = 0; idx < (clientsRes.data.values ?? []).length; idx++) {
    const cell = String(clientsRes.data.values![idx][0] ?? '');
    if (cell.includes(oldId)) {
      const updated = cell.split('\n').map(id => id.trim() === oldId ? newId : id).join('\n');
      await sheets.spreadsheets.values.update({
        spreadsheetId    : SHEET_IDS.CLIENTS,
        range            : `${TAB.CLIENTS_EXT}!I${idx + 5}`,
        valueInputOption : 'RAW',
        requestBody      : { values: [[updated]] },
      });
    }
  }
}

export async function desarchiverBDC(bdcId: string, archiveRow: number): Promise<void> {
  await invalidateBDCsCache();
  _clearFindRowCache();
  const { _clearFindVeloRowCache } = await import('./inventaire');
  _clearFindVeloRowCache();
  // Snapshot AVANT toute modification — capture l'état actuel (potentiellement
  // archivé) pour rollback si la restauration corrompt les données.
  await snapshotBDC(bdcId, 'desarchive');

  const sheets = getSheetsClient();

  // 0. ⚠ Garde anti-doublon : refuse si une ligne INVENTAIRE existe
  // déjà avec ce ID (cas : le BDT n'a pas été correctement supprimé
  // lors d'un précédent archivage, ou un cycle archive/désarchive a
  // laissé un fantôme). Sinon on se retrouve avec 2 vélos pour le
  // même ID — visible dans la fiche client en 2 statuts différents.
  //
  // V1.0 hardening (P0.6) : on ne swallow plus l'erreur du check.
  // Avant, `.catch(() => -1)` traitait toute panne quota comme « pas
  // d'existant » → désarchivage continuait → doublon dans INVENTAIRE.
  // Même pattern que P0.1 sur creerBon.
  const { findVeloRow } = await import('./inventaire');
  let existingInvRow: number;
  try {
    existingInvRow = await findVeloRow(bdcId);
  } catch (err: any) {
    const msg = err?.message ?? 'erreur Sheets';
    logError('bdc-desarchive-check-failed', { bdcId, error: msg });
    throw new Error(
      `Désarchivage BDT ${bdcId} bloqué : impossible de vérifier l'absence ` +
      `dans INVENTAIRE (${msg}). Réessaie dans 30 s — l'API Sheets est ` +
      `probablement saturée.`,
    );
  }
  if (existingInvRow > 0) {
    throw new Error(
      `Le BDT ${bdcId} existe déjà dans INVENTAIRE (ligne ${existingInvRow}). ` +
      `Le désarchivage est bloqué pour éviter un doublon. Supprime d'abord ` +
      `la ligne active via /parametres/admin → Supprimer un BDT.`
    );
  }

  // 1. Lire la ligne ARCHIVES complète. Range A:Y depuis v7.0.4 (col Y
  // contient le JSON des lignes BDC sauvegardées à l'archivage, déplacé
  // depuis X après l'ajout des notes EXT eval/facture en V/W/X).
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `'${TAB.ARCHIVES}'!A${archiveRow}:Y${archiveRow}`,
    valueRenderOption: 'FORMATTED_VALUE',
  });

  const rowData = res.data.values?.[0];
  if (!rowData) throw new Error(`Ligne ${archiveRow} introuvable dans ARCHIVES`);

  // 2. Insérer une ligne dans INVENTAIRE à la position INS_ROW
  const invMeta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const invSheet = invMeta.data.sheets?.find(s => s.properties?.title === TAB.INVENTAIRE);
  const invSheetId = invSheet?.properties?.sheetId;
  if (invSheetId === undefined) throw new Error('Onglet INVENTAIRE introuvable');

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        insertDimension: {
          range: {
            sheetId   : invSheetId,
            dimension : 'ROWS',
            startIndex: ROW.INS_ROW - 1,
            endIndex  : ROW.INS_ROW,
          },
          inheritFromBefore: true,
        },
      }],
    },
  });

  // 3. Écrire les données dans INVENTAIRE à la ligne INS_ROW
  //
  // ⚠ Remapping ARCHIVES → INVENTAIRE (v7.0.4 — décalage cols) :
  //   ARCHIVES :  N=eval O=meca P=ctrl Q=noteVélo R=svc text S=total$svc
  //               T=pce text U=total$pce V=notesInt W=noteEvalExt X=noteFactureExt Y=JSON
  //   INVENTAIRE: N=eval O=meca P=ctrl Q=noteVélo R=svc text
  //               S=pce text T=libre U=notesInt V=noteEvalExt W=noteFactureExt
  //
  // Sémantique du désarchivage = « réouvrir pour ré-évaluation » :
  //   - status remis à ÉVAL.
  //   - dates F (travaux) + G (sortie) effacées (la ré-éval relance le cycle)
  //   - notes (interne / eval / facture) préservées
  //   - les checkboxes du BON et le FAIT des items sont reset plus bas via 3c
  while (rowData.length < 25) rowData.push('');
  rowData[1] = false;          // col B — checkbox archive non cochée
  rowData[2] = 'ÉVAL.';        // col C — statut "ré-ouvert pour ré-éval"
  rowData[5] = '';             // col F — date travaux effacée
  rowData[6] = '';             // col G — date sortie effacée

  // Construire la ligne INVENTAIRE (23 cols, A..W) avec remapping
  const invRow: unknown[] = new Array(23).fill('');
  // A à Q (idx 0..16) — copie directe (status, ID, dates, client, vélo, mécanos, noteVélo)
  for (let i = 0; i <= 16; i++) invRow[i] = rowData[i] ?? '';
  invRow[17] = rowData[17] ?? ''; // R — services texte (était ARCHIVES.R aussi)
  invRow[18] = rowData[19] ?? ''; // S — pièces texte (était ARCHIVES.T, après ARCHIVES.S=total$svc)
  invRow[19] = '';                // T — libre (anciennement total $ svc dans ARCHIVES.S)
  invRow[20] = rowData[21] ?? ''; // U — notes internes (était ARCHIVES.V)
  invRow[21] = rowData[22] ?? ''; // V — note eval ext (était ARCHIVES.W)
  invRow[22] = rowData[23] ?? ''; // W — note facture ext (était ARCHIVES.X)

  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.INVENTAIRE}!A${ROW.INS_ROW}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [invRow] },
  });

  // 3b. Restaurer les lignes BDC dans BONS DE COMMANDES
  // Les lignes restaurées doivent refléter la sémantique « ré-éval » :
  //   - BON row col D (EVAL) = TRUE ; cols E (OK), F (BDS), G (OUT) = FALSE
  //   - chaque ITEM row col L (FAIT) = FALSE
  const colY = String(rowData[24] ?? '').trim();  // col Y = JSON des lignes BDC (était X avant v7.0.4)
  if (colY && colY.startsWith('[')) {
    try {
      const bdcLines = JSON.parse(colY) as unknown[][];
      if (bdcLines.length > 0) {
        // Reset checkboxes / FAIT pour la sémantique « réouverture »
        const resetLines = bdcLines.map(line => {
          if (!Array.isArray(line)) return line;
          const r = [...line];
          while (r.length < 12) r.push('');
          if (r[0] === 'BON') {
            r[3]  = true;   // col D — checkEval = TRUE
            r[4]  = false;  // col E — checkOk
            r[5]  = false;  // col F — checkBds
            r[6]  = false;  // col G — checkOut
          } else if (r[0] === 'ITEM') {
            r[11] = false;  // col L (SVC_CHK) — FAIT = false
          }
          return r;
        });
        await sheets.spreadsheets.values.append({
          spreadsheetId    : SHEET_IDS.INVENTAIRE,
          range            : `${TAB.BDC}!A${ROW.BDC_INS}`,
          valueInputOption : 'RAW',
          insertDataOption : 'INSERT_ROWS',
          requestBody      : { values: resetLines },
        });

        // ⚠ v6.5.1 — Plus de _incrementStock manuel ici. Le delta AB est
        // calculé par le snapshot before/after autour du désarchivage côté
        // route (POST /api/archives) via safeRecomputeStockState. L'invariant
        // basé sur engagement gère correctement les 2 cas (archive FACTURÉ
        // vs autre statut).
      }
    } catch { /* JSON invalide — fallback ci-dessous */ }
  } else {
    // Fallback : créer un BDC vide si pas de JSON sauvegardé.
    // Pas de ré-incrément stock ici — sans JSON on ne sait pas quelles
    // pièces avaient été décrémentées à l'archivage.
    const str = (i: number) => String(rowData[i] ?? '').trim();
    const clientNom = str(7);
    const veloDesc  = [str(8), str(9), str(10), str(11)].filter(Boolean).join(', ');
    await creerBon(bdcId, clientNom, veloDesc);
  }

  // 4. Supprimer la ligne ARCHIVES
  const archMeta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const archSheet = archMeta.data.sheets?.find(s => s.properties?.title === TAB.ARCHIVES);
  const archSheetId = archSheet?.properties?.sheetId;
  if (archSheetId === undefined) throw new Error('Onglet ARCHIVES introuvable');

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        deleteDimension: {
          range: {
            sheetId   : archSheetId,
            dimension : 'ROWS',
            startIndex: archiveRow - 1,
            endIndex  : archiveRow,
          },
        },
      }],
    },
  });
}

/**
 * Consolide les BDC "fantômes" (dans BONS DE COMMANDES mais absents d'INVENTAIRE et ARCHIVES)
 * en créant des entrées dans ARCHIVES 2026.
 * Retourne la liste des IDs consolidés.
 */
export async function consolidateGhostBDCs(): Promise<string[]> {
  await invalidateBDCsCache();
  const sheets = getSheetsClient();

  // 1. Lire toutes les sources en parallèle
  const [inventaireIds, archivedIds, bdcIds, clientsRes] = await Promise.all([
    _getInventaireIds(),
    _getArchiveIds(),
    _getBdcSheetIds(),
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.CLIENTS,
      range            : `${TAB.CLIENTS_EXT}!B5:J`,
      valueRenderOption: 'FORMATTED_VALUE',
    }),
  ]);

  // 2. Collecter tous les BDC IDs référencés par les clients
  //    avec le nom du client et la description vélo associée
  interface GhostInfo { id: string; client: string; velo: string }
  const ghosts: GhostInfo[] = [];
  const allKnownIds = new Set([...inventaireIds, ...archivedIds, ...bdcIds]);

  for (const r of (clientsRes.data.values ?? [])) {
    const s = (i: number) => String(r[i] ?? '').trim();
    const prenom = s(0);
    const nom    = s(1);
    const client = `${prenom} ${nom}`.trim();
    if (!client) continue;

    const idsRaw  = s(7);  // col I (index 7 depuis B) = BDC IDs
    const veloRaw = s(8);  // col J (index 8 depuis B) = Vélos
    const ids   = idsRaw  ? idsRaw.split('\n').map(v => v.trim()).filter(Boolean) : [];
    const velos = veloRaw ? veloRaw.split('\n').map(v => v.trim()).filter(Boolean) : [];

    for (let i = 0; i < ids.length; i++) {
      const bdcId = ids[i];
      if (!allKnownIds.has(bdcId)) {
        ghosts.push({ id: bdcId, client, velo: velos[i] || '' });
      }
    }
  }

  if (ghosts.length === 0) return [];

  // 3. Trouver le sheetId de ARCHIVES
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const archSheet = meta.data.sheets?.find(s => s.properties?.title === TAB.ARCHIVES);
  const archSheetId = archSheet?.properties?.sheetId;
  if (archSheetId === undefined) throw new Error('Onglet ARCHIVES introuvable');

  const consolidated: string[] = [];

  for (const ghost of ghosts) {
    const veloParts = ghost.velo.split(', ');

    const row = Array(23).fill('');
    row[1]  = false;                        // col B = checkbox FALSE
    row[2]  = 'ARCHIVÉ';                    // col C = Status
    row[3]  = ghost.id;                     // col D = ID
    row[7]  = ghost.client;                 // col H = Client
    row[8]  = veloParts[0] || '';            // col I = Marque
    row[9]  = veloParts[1] || '';            // col J = Modèle
    row[10] = veloParts[2] || '';            // col K = Couleur
    row[11] = veloParts[3] || '';            // col L = Taille

    // Insérer à la ligne 5 de ARCHIVES
    await sheets.spreadsheets.batchUpdate({
      spreadsheetId: SHEET_IDS.INVENTAIRE,
      requestBody  : {
        requests: [{
          insertDimension: {
            range: { sheetId: archSheetId, dimension: 'ROWS', startIndex: 4, endIndex: 5 },
            inheritFromBefore: true,
          },
        }],
      },
    });

    await sheets.spreadsheets.values.update({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `'${TAB.ARCHIVES}'!A5`,
      valueInputOption : 'RAW',
      requestBody      : { values: [row] },
    });

    consolidated.push(ghost.id);
  }

  return consolidated;
}

/** IDs dans BONS DE COMMANDES */
async function _getBdcSheetIds(): Promise<Set<string>> {
  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!A${ROW.BDC_INS}:B`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const ids = new Set<string>();
  for (const r of (res.data.values ?? [])) {
    if (String(r[0] ?? '').trim() === BDC_TAG.BON) {
      const id = String(r[1] ?? '').trim();
      if (id) ids.add(id);
    }
  }
  return ids;
}

/** IDs dans INVENTAIRE */
async function _getInventaireIds(): Promise<Set<string>> {
  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.INVENTAIRE}!D${ROW.INS_ROW}:D`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const ids = new Set<string>();
  for (const r of (res.data.values ?? [])) {
    const id = String(r[0] ?? '').trim();
    if (id) ids.add(id);
  }
  return ids;
}

/** IDs dans ARCHIVES */
async function _getArchiveIds(): Promise<Set<string>> {
  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `'${TAB.ARCHIVES}'!D5:D`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const ids = new Set<string>();
  for (const r of (res.data.values ?? [])) {
    const id = String(r[0] ?? '').trim();
    if (id) ids.add(id);
  }
  return ids;
}

// ── Patch item : PRIX / QTÉ ──────────────────────────────────────

/**
 * Met à jour le PRIX (et optionnellement QTÉ + S/TOTAL) d'une ligne ITEM.
 * - service : écrit col N (SVC_PX=14)
 * - piece   : écrit cols Q (PCE_PX=17), S (PCE_QTE=19), T (PCE_TOT=20)
 * Recalcule ensuite la ligne TOT du BDC.
 */
export async function patchBDCItemFields(
  bdcId  : string,
  row    : number,
  type   : 'service' | 'piece',
  fields : { nom?: string; prix?: number; qte?: number; sousTotal?: number; dureeOverride?: string; serviceId?: string },
): Promise<void> {
  await invalidateBDCsCache();
  const sheets = getSheetsClient();
  const data: { range: string; values: unknown[][] }[] = [];

  if (type === 'service') {
    if (fields.serviceId !== undefined) {
      data.push({ range: `${TAB.BDC}!${_colLetter(BDC_COL.SVC_ID)}${row}`, values: [[fields.serviceId]] });
    }
    if (fields.nom !== undefined) {
      data.push({ range: `${TAB.BDC}!${_colLetter(BDC_COL.SVC)}${row}`, values: [[fields.nom]] });
    }
    if (fields.prix !== undefined) {
      data.push({ range: `${TAB.BDC}!${_colLetter(BDC_COL.SVC_PX)}${row}`,  values: [[fields.prix]] });
    }
    // Override durée (ex. Services - Réhab éditables). Stocké dans SVC_TXT
    // (col M) comme string "h:mm". Chaîne vide = pas d'override (revient
    // sur la durée du catalogue).
    if (fields.dureeOverride !== undefined) {
      data.push({ range: `${TAB.BDC}!${_colLetter(BDC_COL.SVC_TXT)}${row}`, values: [[fields.dureeOverride]] });
    }
  } else {
    if (fields.nom      !== undefined) data.push({ range: `${TAB.BDC}!${_colLetter(BDC_COL.PCE)}${row}`,     values: [[fields.nom]]      });
    if (fields.prix     !== undefined) data.push({ range: `${TAB.BDC}!${_colLetter(BDC_COL.PCE_PX)}${row}`,  values: [[fields.prix]]     });
    if (fields.qte      !== undefined) data.push({ range: `${TAB.BDC}!${_colLetter(BDC_COL.PCE_QTE)}${row}`, values: [[fields.qte]]      });
    if (fields.sousTotal !== undefined) data.push({ range: `${TAB.BDC}!${_colLetter(BDC_COL.PCE_TOT)}${row}`, values: [[fields.sousTotal]] });
  }

  if (data.length === 0) return;

  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : { valueInputOption: 'RAW', data },
  });

  await _recalcTotaux(bdcId);
}

// ── Patch item (FAIT / CMD) ───────────────────────────────────────

/**
 * Met à jour les colonnes FAIT (SVC_CHK=L) et/ou CMD (PCE_CHK=R) d'une ligne ITEM.
 * Utilisé par les dropdowns FAIT / CMD dans BDCPanel.
 */
export async function patchBDCItem(
  row    : number,
  updates: { fait?: boolean; cmd?: string },
): Promise<void> {
  await invalidateBDCsCache();
  const data: { range: string; values: unknown[][] }[] = [];

  if (updates.fait !== undefined) {
    data.push({
      range : `${TAB.BDC}!${_colLetter(BDC_COL.SVC_CHK)}${row}`,
      values: [[updates.fait]],
    });
  }

  if (updates.cmd !== undefined) {
    data.push({
      range : `${TAB.BDC}!${_colLetter(BDC_COL.PCE_CHK)}${row}`,
      values: [[updates.cmd]],
    });
  }

  if (data.length === 0) return;

  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : { valueInputOption: 'RAW', data },
  });
}

/**
 * v1.0.7+ — Persiste les états des sous-items d'un forfait dans col J
 * (EVAL_ST inutilisée sur ligne ITEM service) sous forme JSON. Met à
 * jour aussi col L (SVC_CHK = fait) avec `allChecked`.
 *
 * Permet la persistance cross-device des cases à cocher individuelles
 * (avant v1.0.7 : localStorage par-browser → invisible chez le user
 * quand il rouvrait depuis un autre appareil).
 */
export async function patchBDCItemForfaitSubs(
  row     : number,
  subs    : boolean[],
  fait    : boolean,
): Promise<void> {
  await invalidateBDCsCache();
  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      valueInputOption: 'RAW',
      data: [
        {
          range : `${TAB.BDC}!${_colLetter(BDC_COL.EVAL_ST)}${row}`,
          values: [[JSON.stringify(subs)]],
        },
        {
          range : `${TAB.BDC}!${_colLetter(BDC_COL.SVC_CHK)}${row}`,
          values: [[fait]],
        },
      ],
    },
  });
}

/**
 * Persiste la note client de l'ÉVALUATION (INVENTAIRE col V) ou de la
 * FACTURE (INVENTAIRE col W) du vélo associé au BDC.
 *
 * v7.0.4 : ces notes vivent dans INVENTAIRE (cols V/W ajoutées avec le
 * décalage du sheet) et plus dans BDC/GAP (où les colonnes n'existent
 * pas — l'écriture en ${TAB.BDC}!W… était silencieusement perdue).
 */
export async function setBDCNoteClient(
  bdcId: string,
  note: string,
  mode: 'eval' | 'facture' = 'eval',
): Promise<void> {
  const { updateVelo } = await import('./inventaire');
  if (mode === 'facture') {
    await updateVelo(bdcId, { noteClientFacture: note });
  } else {
    await updateVelo(bdcId, { noteClientEval: note });
  }
}

/**
 * Supprime une ligne ITEM du BDC (service ou pièce) et recalcule les totaux.
 */
export async function deleteBDCItem(bdcId: string, row: number): Promise<void> {
  await invalidateBDCsCache();
  // Snapshot AVANT suppression pour pouvoir restaurer si l'utilisateur regrette
  await snapshotBDC(bdcId, 'pre-delete', `delete row ${row}`);

  const sheets  = getSheetsClient();
  const sheetId = await _getBDCSheetId(sheets);

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        deleteDimension: {
          range: {
            sheetId,
            dimension : 'ROWS',
            startIndex: row - 1, // 0-based
            endIndex  : row,
          },
        },
      }],
    },
  });

  await _recalcTotaux(bdcId);
}

/**
 * Persiste les remises services + pièces + avance d'un BDC sous forme
 * de JSON dans la col I (SVC_ID) de la ligne BON. Les lignes ITEM
 * utilisent aussi col I pour serviceId, mais le tag BON ne s'en sert
 * pas, donc pas de conflit.
 *
 * Utilise un read-modify-write : seuls les champs explicitement passés
 * dans `fields` sont modifiés ; les autres sont préservés. Pour effacer
 * un champ, passer `null` (ex. { remiseSvc: null }). undefined = no-op.
 */
export async function updateBDCBonJson(
  bdcId: string,
  fields: {
    remiseSvc?: { type: 'pct' | 'fixed'; value: number } | null;
    remisePce?: { type: 'pct' | 'fixed'; value: number } | null;
    /** v1.0.17+ : avance objet {montant, mode?, note?}. null/0 = effacer. */
    avance?: { montant: number; mode?: 'comptant' | 'interac' | 'cartes'; note?: string } | null;
  },
): Promise<void> {
  await invalidateBDCsCache();
  const bonRow = await _findBonRow(bdcId);
  if (bonRow < 0) throw new Error(`BDC ${bdcId} introuvable`);

  const sheets = getSheetsClient();

  // Read existing JSON pour merge
  const readRes = await sheets.spreadsheets.values.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    range        : `${TAB.BDC}!I${bonRow}`,
  });
  const raw = String(readRes.data.values?.[0]?.[0] ?? '').trim();
  let current: any = {};
  if (raw) {
    try { current = JSON.parse(raw) || {}; } catch { current = {}; }
  }

  // Merge ciblé : null = remove, undefined = keep, valeur = set
  if (fields.remiseSvc !== undefined) {
    if (fields.remiseSvc === null) delete current.svc;
    else current.svc = { type: fields.remiseSvc.type, value: fields.remiseSvc.value };
  }
  if (fields.remisePce !== undefined) {
    if (fields.remisePce === null) delete current.pce;
    else current.pce = { type: fields.remisePce.type, value: fields.remisePce.value };
  }
  if (fields.avance !== undefined) {
    if (fields.avance === null || !fields.avance.montant || fields.avance.montant <= 0) {
      delete current.avance;
    } else {
      const a: any = { montant: fields.avance.montant };
      if (fields.avance.mode) a.mode = fields.avance.mode;
      if (fields.avance.note) a.note = fields.avance.note;
      current.avance = a;
    }
  }

  const json = Object.keys(current).length ? JSON.stringify(current) : '';

  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!I${bonRow}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [[json]] },
  });
}

/**
 * @deprecated v1.0.15 — utiliser updateBDCBonJson({...}). Conservé pour
 * compat des callers existants : remplace svc + pce mais préserve avance.
 */
export async function updateBDCRemises(
  bdcId: string,
  remiseSvc?: { type: 'pct' | 'fixed'; value: number },
  remisePce?: { type: 'pct' | 'fixed'; value: number },
): Promise<void> {
  return updateBDCBonJson(bdcId, {
    remiseSvc: remiseSvc ?? null,
    remisePce: remisePce ?? null,
  });
}

/**
 * Persiste la note de commande fournisseur (col W de la ligne ITEM).
 */
export async function patchBDCItemNote(row: number, note: string): Promise<void> {
  await invalidateBDCsCache();
  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!W${row}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [[note]] },
  });
}

/** Convertit un index de colonne 1-based en lettre Sheets (ex. 12 → "L"). */
function _colLetter(n: number): string {
  let letter = '';
  while (n > 0) {
    const rem = (n - 1) % 26;
    letter = String.fromCharCode(65 + rem) + letter;
    n = Math.floor((n - 1) / 26);
  }
  return letter;
}

// ── Helpers privés ────────────────────────────────────────────────

/**
 * Cache mémoire (par-lambda, TTL 30s) pour _findBonRow et findVeloRow.
 * Réduit drastiquement les Sheets.values.get : pendant une session de
 * travail BDT (cascade de mutations), le rowNum reste stable. Sans
 * cache, chaque setCheckXXX/setEvalStatus déclenchait 1 read + 1 write
 * → quota Sheets API rapidement saturé.
 *
 * Invalidation : à l'archivage/désarchivage (rowNums décalés).
 */
const _findRowCache = new Map<string, { row: number; expiresAt: number }>();
const FIND_ROW_TTL_MS = 30_000;

export function _clearFindRowCache(id?: string): void {
  if (id) {
    _findRowCache.delete(`bon:${id}`);
    _findRowCache.delete(`velo:${id}`);
  } else {
    _findRowCache.clear();
  }
}

/** Trouve le numéro de ligne de la ligne BON pour un ID donné. */
async function _findBonRow(id: string): Promise<number> {
  const key = `bon:${id}`;
  const now = Date.now();
  const cached = _findRowCache.get(key);
  if (cached && cached.expiresAt > now) return cached.row;

  const sheets = getSheetsClient();
  const res    = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!A${ROW.BDC_INS}:B`,
    valueRenderOption: 'FORMATTED_VALUE',
  });

  const rows = res.data.values ?? [];
  for (let i = 0; i < rows.length; i++) {
    if (
      String(rows[i][0]).trim() === BDC_TAG.BON &&
      String(rows[i][1]).trim() === String(id).trim()
    ) {
      const row = i + ROW.BDC_INS;
      _findRowCache.set(key, { row, expiresAt: now + FIND_ROW_TTL_MS });
      return row;
    }
  }
  return -1;
}

/** Trouve la ligne SEP après une ligne BON. */
async function _findSepRow(bonRow: number): Promise<number> {
  const sheets = getSheetsClient();
  const res    = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!A${bonRow}:A${bonRow + 200}`,
    valueRenderOption: 'FORMATTED_VALUE',
  });

  const rows = res.data.values ?? [];
  for (let i = 1; i < rows.length; i++) { // commence à 1 pour sauter la ligne BON elle-même
    if (String(rows[i][0]).trim() === BDC_TAG.SEP) return bonRow + i;
  }
  return -1;
}

/**
 * Calcule la ligne d'insertion (après GAP + SEP0 éventuel).
 * Équivalent de _insertBoundaryApresGap() dans le GAS.
 */
function _insertBoundary(bdc: BDC): number {
  // La ligne d'insertion est après GAP (row BON + 1) et SEP0 (row BON + 2 si présent)
  // Comme on a dénormalisé, on insère avant les items existants
  // → bonRow + 3 (BON=+0, GAP=+1, SEP0=+2, insertion=+3)
  return bdc._bonRow + 3;
}

/** Cache du sheet ID de BDC pour batchUpdate. */
let _bdcSheetIdCache: number | null = null;
async function _getBDCSheetId(sheets: ReturnType<typeof getSheetsClient>): Promise<number> {
  if (_bdcSheetIdCache !== null) return _bdcSheetIdCache;

  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });

  const sh = meta.data.sheets?.find(
    (s: any) => s.properties?.title === TAB.BDC
  );
  _bdcSheetIdCache = sh?.properties?.sheetId ?? 0;
  return _bdcSheetIdCache;
}

/** Recalcule les totaux (ligne TOT) d'un BDC. */
/**
 * Force le recalcul des totaux d'un BDC (publique). Crée la ligne TOT si
 * absente. Utile pour réparer des BDT corrompus sans forcer l'utilisateur
 * à modifier un item pour déclencher la sync. Exposé via
 * /api/admin/repair-bdt/[id].
 */
export async function repairBdcTotaux(bdcId: string): Promise<void> {
  await _recalcTotaux(bdcId);
}

async function _recalcTotaux(bdcId: string): Promise<void> {
  // Appelé après une mutation — invalider le cache pour relire frais.
  await invalidateBDCsCache();
  const bdc = await getBDC(bdcId);
  if (!bdc) return;

  const sheets = getSheetsClient();
  // Trouve OU crée la ligne TOT (cas observé : certains BDT ont perdu leur
  // ligne TOT, ce qui rendait le PDF/total à 0 silencieusement).
  const totRow = await _ensureTotRow(bdcId);
  if (totRow < 0) return;

  const totalSvc = bdc.items.reduce((s, i) => s + (i.service?.prix ?? 0), 0);
  const totalPce = bdc.items.reduce((s, i) => s + (i.piece?.sousTotal ?? 0), 0);

  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      valueInputOption: 'RAW',
      data: [
        { range: `${TAB.BDC}!N${totRow}`, values: [[totalSvc]] },
        { range: `${TAB.BDC}!T${totRow}`, values: [[totalPce]] },
      ],
    },
  });

  // CRITIQUE : le cache a été peuplé AVANT l'écriture des totaux, il contient
  // donc les ANCIENS totalServices / totalPieces. On le re-invalide pour que
  // le prochain getBDC() (typiquement celui appelé par la route API après la
  // mutation) relise les nouveaux totaux depuis le sheet.
  await invalidateBDCsCache();
}

/**
 * Trouve la ligne TOT du BDT. Si absente (BDT corrompu / perte d'historique),
 * insère une nouvelle ligne TOT à l'intérieur du bloc du BDT courant
 * (entre BON{id} et BON suivant). Si introuvable, retourne -1.
 *
 * ⚠ Crucial : la col B ne contient l'ID QUE sur la ligne BON. On délimite
 * donc le bloc du BDT par : début = BON{id}, fin = ligne avant le PROCHAIN
 * BON (peu importe son id), ou fin du sheet. Avant ce fix, le scan trouvait
 * la SEP du BDT SUIVANT si le BDT courant n'avait pas de SEP, et insérait
 * la TOT dans le mauvais BDT.
 */
async function _ensureTotRow(bdcId: string): Promise<number> {
  const existing = await _findTotRow(bdcId);
  if (existing > 0) return existing;

  const bonRow = await _findBonRow(bdcId);
  if (bonRow < 0) return -1;

  const sheets = getSheetsClient();
  // Lire cols A et B sur 200 lignes après le BON, pour identifier la fin du bloc.
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!A${bonRow}:B${bonRow + 200}`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const rows = res.data.values ?? [];

  // 1. Borne du bloc : ligne avant le prochain BON (n'importe quel id)
  let blockEnd = rows.length;  // par défaut, jusqu'à la fin du range lu
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i]?.[0] ?? '').trim() === BDC_TAG.BON) {
      blockEnd = i;  // le BON suivant = exclusif
      break;
    }
  }

  // 2. Chercher SEP dans le bloc [1, blockEnd)
  let sepRow = -1;
  for (let i = 1; i < blockEnd; i++) {
    if (String(rows[i]?.[0] ?? '').trim() === BDC_TAG.SEP) {
      sepRow = bonRow + i;
      break;
    }
  }

  // 3. Si pas de SEP : insérer juste après le dernier ITEM du bloc (donc à
  // bonRow + blockEnd). C'est le comportement attendu pour les BDT
  // corrompus dont la ligne SEP a aussi disparu.
  if (sepRow < 0) {
    sepRow = bonRow + blockEnd;
    console.warn(`[bdc] BDT ${bdcId} sans ligne SEP — TOT insérée à la ligne ${sepRow} (juste après le dernier ITEM)`);
  }

  // Construire la ligne TOT (mêmes valeurs par défaut que creerBon)
  const tot = Array(BDC_COL.NB_COLS).fill('') as (string | number)[];
  tot[BDC_COL.TAG - 1]     = BDC_TAG.TOT;
  tot[BDC_COL.SVC - 1]     = '↑ Ajouter';
  tot[BDC_COL.SVC_CHK - 1] = 'total';
  tot[BDC_COL.SVC_PX - 1]  = 0;
  tot[BDC_COL.PCE - 1]     = '↑ Ajouter';
  tot[BDC_COL.PCE_CHK - 1] = 'total';
  tot[BDC_COL.PCE_TOT - 1] = 0;

  // Insérer une ligne vide juste avant SEP, puis écrire les valeurs
  const insertRow = sepRow;  // 1-based — la nouvelle ligne sera ici, SEP descend
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId : SHEET_IDS.INVENTAIRE,
    requestBody   : {
      requests: [{
        insertDimension: {
          range: {
            sheetId   : await _getBDCSheetId(sheets),
            dimension : 'ROWS',
            startIndex: insertRow - 1,
            endIndex  : insertRow,
          },
          inheritFromBefore: false,
        },
      }],
    },
  });
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!A${insertRow}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [tot] },
  });

  console.warn(`[bdc] Ligne TOT manquante pour ${bdcId} — recréée à la ligne ${insertRow}`);
  return insertRow;
}

async function _findTotRow(bdcId: string): Promise<number> {
  const bonRow = await _findBonRow(bdcId);
  if (bonRow < 0) return -1;

  const sheets = getSheetsClient();
  const res    = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!A${bonRow}:A${bonRow + 100}`,
    valueRenderOption: 'FORMATTED_VALUE',
  });

  const rows = res.data.values ?? [];
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i][0]).trim() === BDC_TAG.TOT) return bonRow + i;
  }
  return -1;
}
