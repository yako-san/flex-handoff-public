/**
 * Compteur d'ID vélo + compteur de facture vente.
 *
 * Stratégie de verrouillage à 2 niveaux (v1.1.3 — Item 3 audit) :
 *   • Mutex local (`async-mutex`) — sérialise les appels dans la MÊME lambda.
 *     Protège du burst quand un même handler est invoqué en parallèle.
 *   • Lock distribué (`@vercel/kv` SETNX) — sérialise CROSS-LAMBDA. Sans
 *     ça, 2 utilisateurs cliquant « Facturer » depuis 2 navigateurs peuvent
 *     atterrir sur 2 lambdas différents → lecture concurrente de B3 →
 *     2 factures avec le MÊME numéro (incident potentiel comptable).
 *
 * Le lock distribué a un TTL de 15s (failsafe si le caller crash) et un
 * timeout d'acquisition de 8s (l'opération Sheets read+write prend ~1-2s).
 *
 * Format retourné :
 *   - `prochainID`         → "0042" (4 chiffres, padding zéro)
 *   - `prochainFactureNumero` → "V0012"
 */
import { Mutex } from 'async-mutex';
import { getSheetsClient, SHEET_IDS, TAB, ROW } from './client';
import { padId } from '@/lib/utils/sheets';
import { withDistributedLock } from '@/lib/distributedLock';

const mutex         = new Mutex();
const factureMutex  = new Mutex();

const LOCK_TTL_SEC      = 15;
const LOCK_TIMEOUT_MS   = 8000;

export async function prochainID(): Promise<string> {
  return mutex.runExclusive(async () =>
    withDistributedLock('counter:velo', LOCK_TTL_SEC, async () => {
      const sheets = getSheetsClient();
      const range  = `${TAB.PARAMS}!B${ROW.COUNTER_ROW}`;

      const res = await sheets.spreadsheets.values.get({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        range,
        valueRenderOption: 'UNFORMATTED_VALUE',
      });

      const current = parseInt(String(res.data.values?.[0]?.[0] ?? '0'), 10);
      const next    = isNaN(current) || current < 0 ? 1 : current + 1;

      await sheets.spreadsheets.values.update({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        range,
        valueInputOption: 'RAW',
        requestBody: { values: [[next]] },
      });

      return padId(next);
    })
  );
}

/**
 * Compteur séquentiel pour les factures de ventes directes.
 * Stocké dans _PARAMÈTRES_!B3 (incrément global, pas de reset annuel).
 * Format retourné : "V0012" (V + séquentiel 4 chiffres). La date n'est
 * plus incluse dans le numéro lui-même — elle est stockée séparément en
 * col F du journal et col J de _VENTES_, et assemblée pour le filename
 * PDF (`facture-V0012-2026-04-29—Client.pdf`).
 * Anciens formats `V0012-2026-04-26` et `F2026-04-15-0001` lus par
 * parseFactureNumero pour rétrocompat.
 */
export async function prochainFactureNumero(): Promise<string> {
  return factureMutex.runExclusive(async () =>
    withDistributedLock('counter:facture', LOCK_TTL_SEC, async () => {
      const sheets = getSheetsClient();
      const range  = `${TAB.PARAMS}!B${ROW.FACTURE_COUNTER_ROW}`;

      const res = await sheets.spreadsheets.values.get({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        range,
        valueRenderOption: 'UNFORMATTED_VALUE',
      });

      const current = parseInt(String(res.data.values?.[0]?.[0] ?? '0'), 10);
      const next    = isNaN(current) || current < 0 ? 1 : current + 1;

      await sheets.spreadsheets.values.update({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        range,
        valueInputOption: 'RAW',
        requestBody: { values: [[next]] },
      });

      return `V${String(next).padStart(4, '0')}`;
    })
  );
}

// (LOCK_TIMEOUT_MS exposé pour de futurs tests / overrides)
export const _LOCK_TIMEOUT_MS = LOCK_TIMEOUT_MS;

/**
 * Extrait les composants d'un numéro de facture stocké.
 * Formats supportés (lecture) :
 *   - `V0012-2026-04-26`        (v6.3.2+ — actuel)
 *   - `F2026-04-15-0001`        (legacy — restera dans _VENTES_ pour les anciennes lignes)
 *   - `F2026-0001`              (très ancien, sans jour/mois)
 */
export function parseFactureNumero(s: string): { date: string; numero: string } | null {
  if (!s) return null;
  // Nouveau format : V + 4+ chiffres + - + date AAAA-MM-JJ
  const mV = s.match(/^V(\d{4,})-(\d{4}-\d{2}-\d{2})$/);
  if (mV) return { date: mV[2], numero: mV[1] };
  // Legacy : F + date AAAA-MM-JJ + - + 4+ chiffres
  const m1 = s.match(/^F(\d{4}-\d{2}-\d{2})-(\d{4,})$/);
  if (m1) return { date: m1[1], numero: m1[2] };
  // Très legacy : F + AAAA + - + 4+ chiffres
  const m2 = s.match(/^F(\d{4})-(\d{4,})$/);
  if (m2) return { date: m2[1], numero: m2[2] };
  return null;
}
