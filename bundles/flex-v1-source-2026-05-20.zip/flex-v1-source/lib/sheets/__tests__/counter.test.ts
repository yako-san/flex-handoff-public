import { describe, it, expect } from 'vitest';
import { parseFactureNumero } from '../counter';

describe('parseFactureNumero — parser 3 formats legacy', () => {
  describe('Format actuel V0012-2026-04-26', () => {
    it('parse un numéro standard', () => {
      expect(parseFactureNumero('V0012-2026-04-26')).toEqual({
        date: '2026-04-26',
        numero: '0012',
      });
    });

    it('accepte plus de 4 chiffres dans le séquentiel', () => {
      expect(parseFactureNumero('V12345-2027-12-31')).toEqual({
        date: '2027-12-31',
        numero: '12345',
      });
    });

    it('rejette format V sans date', () => {
      expect(parseFactureNumero('V0012')).toBeNull();
    });
  });

  describe('Format legacy F2026-04-15-0001', () => {
    it('parse un numéro standard', () => {
      expect(parseFactureNumero('F2026-04-15-0001')).toEqual({
        date: '2026-04-15',
        numero: '0001',
      });
    });

    it('accepte plus de 4 chiffres dans le séquentiel', () => {
      expect(parseFactureNumero('F2026-01-01-99999')).toEqual({
        date: '2026-01-01',
        numero: '99999',
      });
    });
  });

  describe('Format très legacy F2026-0001 (sans jour/mois)', () => {
    it('parse un numéro standard', () => {
      expect(parseFactureNumero('F2026-0001')).toEqual({
        date: '2026',
        numero: '0001',
      });
    });

    it('accepte plus de 4 chiffres', () => {
      expect(parseFactureNumero('F2025-12345')).toEqual({
        date: '2025',
        numero: '12345',
      });
    });
  });

  describe('Edge cases', () => {
    it('retourne null pour string vide', () => {
      expect(parseFactureNumero('')).toBeNull();
    });

    it('retourne null pour format inconnu', () => {
      expect(parseFactureNumero('XYZ-123')).toBeNull();
      expect(parseFactureNumero('0042')).toBeNull();
      expect(parseFactureNumero('FACTURE-2026')).toBeNull();
    });

    it('retourne null sur préfixe manquant', () => {
      expect(parseFactureNumero('0012-2026-04-26')).toBeNull();
      expect(parseFactureNumero('2026-04-15-0001')).toBeNull();
    });

    it('rejette caractères non-conformes (lettre dans séquentiel)', () => {
      expect(parseFactureNumero('V0A12-2026-04-26')).toBeNull();
      expect(parseFactureNumero('F2026-04-15-00A1')).toBeNull();
    });

    it('rejette format avec moins de 4 chiffres dans séquentiel', () => {
      expect(parseFactureNumero('V012-2026-04-26')).toBeNull();
      expect(parseFactureNumero('F2026-04-15-001')).toBeNull();
    });
  });
});
