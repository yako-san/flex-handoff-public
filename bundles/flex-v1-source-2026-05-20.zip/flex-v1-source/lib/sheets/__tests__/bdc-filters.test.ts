import { describe, it, expect } from 'vitest';
import { filterServiceItems } from '../bdc-filters';
import type { AddServiceInput } from '@/types/bdc';

const svc = (nom: string, prix = 25): AddServiceInput => ({ nom, prix });

describe('filterServiceItems — filet de sécurité forfaits/séparateurs', () => {
  it('happy path : items services valides passent tous', () => {
    const items = [
      svc('Mise au point complète'),
      svc('Réglage dérailleur'),
      svc('Changement chambre à air'),
    ];
    const out = filterServiceItems(items);
    expect(out).toHaveLength(3);
    expect(out).toEqual(items);
  });

  it('rejette les sous-items de forfait préfixés "- " (tiret + espace)', () => {
    const items = [
      svc('Forfait tune-up'),
      svc('- Nettoyage chaîne'),
      svc('- Réglage dérailleur'),
      svc('Service indépendant'),
    ];
    const out = filterServiceItems(items);
    expect(out.map(i => i.nom)).toEqual(['Forfait tune-up', 'Service indépendant']);
  });

  it('rejette les sous-items préfixés "—" (tiret cadratin, avec ou sans espace)', () => {
    const items = [
      svc('Forfait premium'),
      svc('— Nettoyage'),       // tiret cadratin + espace
      svc('—🧰 Ajust.'),         // tiret cadratin sans espace + emoji
      svc('—Inspection'),        // tiret cadratin sans espace
      svc('Service final'),
    ];
    const out = filterServiceItems(items);
    expect(out.map(i => i.nom)).toEqual(['Forfait premium', 'Service final']);
  });

  it('rejette les séparateurs purs "--" / "-" / "—"', () => {
    const items = [
      svc('Service A'),
      svc('--'),
      svc('-'),
      svc('—'),
      svc('Service B'),
    ];
    const out = filterServiceItems(items);
    expect(out.map(i => i.nom)).toEqual(['Service A', 'Service B']);
  });

  it('rejette nom vide ou whitespace pur', () => {
    const items = [
      svc(''),
      svc('   '),
      svc('\t\n'),
      svc('Service réel'),
    ];
    const out = filterServiceItems(items);
    expect(out.map(i => i.nom)).toEqual(['Service réel']);
  });

  it('trim implicite — un nom whitespace-only autour est rejeté', () => {
    const items = [svc('   '), svc('  Mise au point  ')];
    const out = filterServiceItems(items);
    // Le filtre n'altère pas le nom, il vérifie juste que trim() != ''.
    expect(out).toHaveLength(1);
    expect(out[0].nom).toBe('  Mise au point  ');
  });

  it('Edge : array vide retourne array vide', () => {
    expect(filterServiceItems([])).toEqual([]);
  });

  it('Edge : item null/undefined dans nom (cast safety)', () => {
    const items = [
      { nom: null as unknown as string, prix: 10 },
      { nom: undefined as unknown as string, prix: 10 },
      svc('OK'),
    ];
    const out = filterServiceItems(items);
    expect(out.map(i => i.nom)).toEqual(['OK']);
  });

  it('Edge : tiret simple suivi de mot SANS espace ("-Nettoyage") n\'est PAS filtré', () => {
    // Le filtre demande "- " (tiret + espace) explicitement. Les noms
    // catalogue avec un tiret accolé doivent pouvoir passer comme services
    // valides (cas rare mais possible : "non-démontage", etc.)
    const items = [svc('-Nettoyage'), svc('non-démontage')];
    const out = filterServiceItems(items);
    expect(out.map(i => i.nom)).toEqual(['-Nettoyage', 'non-démontage']);
  });
});
