import { describe, it, expect } from 'vitest';
import { _computeFromSource, type StockSourceData } from '../reservation';
import type { BDC } from '@/types/bdc';
import type { Velo, VeloStatus } from '@/types/velo';
import type { Vente } from '@/types/vente';

// Builders minimaux (juste les champs lus par _computeFromSource).
function bdc(id: string, items: { piece?: { nom: string; qte: number } }[]): BDC {
  return {
    id,
    dateIn: '2026-04-15',
    veloDesc: 'Test',
    clientNom: 'Test',
    noteClient: '',
    checkEval: false,
    checkOk: false,
    checkBds: false,
    checkOut: false,
    items: items.map((it, i) => ({
      _row: 100 + i,
      piece: it.piece
        ? { nom: it.piece.nom, prix: 10, cmd: '', qte: it.piece.qte, sousTotal: 0, flag: '', cmdNote: '' }
        : undefined,
    })),
    totalServices: 0,
    totalPieces: 0,
    _bonRow: 50,
  };
}

function velo(id: string, status: VeloStatus): Velo {
  return {
    _row: 10, id, status,
    date1: null, date2: null, date3: null,
    client: '', marque: '', modele: '', couleur: '', taille: '', serie: '',
    noteVelo: '', eval: '', meca: '', ctrl: '', services: '', pieces: '', notes: '',
  };
}

function vente(items: { nom: string; qte: number }[], facturee = false): Vente {
  return {
    date: '2026-04-29',
    client: 'Walk-in',
    items: items.map(it => ({
      pieceId: 'P00001', sku: 'SKU', nom: it.nom, qte: it.qte, prixUnit: 10, sousTotal: 10 * it.qte,
    })),
    total: 0,
    _rows: [200],
    venteId: 'V123',
    factureDate: facturee ? '2026-04-30' : undefined,
  };
}

function source(partial: Partial<StockSourceData>): StockSourceData {
  return {
    bdcs: [], velos: [], archivedBdcs: [], ventes: [],
    ...partial,
  };
}

describe('_computeFromSource — modèle stock invariant AB/AC', () => {
  it('happy path : BDT APPROUVÉ engage ET réserve les pièces', () => {
    const src = source({
      bdcs: [bdc('0001', [{ piece: { nom: 'Chaîne', qte: 2 } }])],
      velos: [velo('0001', 'APPROUVÉ')],
    });

    const { engaged, reserved } = _computeFromSource(src);

    expect(engaged.get('Chaîne')).toBe(2);
    expect(reserved.get('Chaîne')).toBe(2);
  });

  it('BDT FACTURÉ : engagé mais PLUS réservé (pièce sortie, vente confirmée)', () => {
    const src = source({
      bdcs: [bdc('0002', [{ piece: { nom: 'Pneu', qte: 1 } }])],
      velos: [velo('0002', 'FACTURÉ')],
    });

    const { engaged, reserved } = _computeFromSource(src);

    expect(engaged.get('Pneu')).toBe(1);
    expect(reserved.get('Pneu') ?? 0).toBe(0);
  });

  it('BDT REÇU/ÉVAL : ni engagé ni réservé (pas encore approuvé)', () => {
    const src = source({
      bdcs: [bdc('0003', [{ piece: { nom: 'Selle', qte: 1 } }])],
      velos: [velo('0003', 'ÉVAL.')],
    });

    const { engaged, reserved } = _computeFromSource(src);

    expect(engaged.get('Selle') ?? 0).toBe(0);
    expect(reserved.get('Selle') ?? 0).toBe(0);
  });

  it('Vente brouillon : engagée ET réservée', () => {
    const src = source({
      ventes: [vente([{ nom: 'Câble', qte: 3 }], false)],
    });

    const { engaged, reserved } = _computeFromSource(src);

    expect(engaged.get('Câble')).toBe(3);
    expect(reserved.get('Câble')).toBe(3);
  });

  it('Vente facturée : engagée mais PAS réservée', () => {
    const src = source({
      ventes: [vente([{ nom: 'Câble', qte: 3 }], true)],
    });

    const { engaged, reserved } = _computeFromSource(src);

    expect(engaged.get('Câble')).toBe(3);
    expect(reserved.get('Câble') ?? 0).toBe(0);
  });

  it('Archive FACTURÉ : engagée définitivement', () => {
    const archived: BDC = {
      ...bdc('0099', [{ piece: { nom: 'Frein', qte: 2 } }]),
      archiveStatus: 'FACTURÉ',
    };
    const src = source({ archivedBdcs: [archived] });

    const { engaged, reserved } = _computeFromSource(src);

    expect(engaged.get('Frein')).toBe(2);
    expect(reserved.get('Frein') ?? 0).toBe(0);
  });

  it('Archive REFUSÉ : ni engagé ni réservé (vélo sorti sans facturation)', () => {
    const archived: BDC = {
      ...bdc('0098', [{ piece: { nom: 'Frein', qte: 2 } }]),
      archiveStatus: 'REFUSÉ',
    };
    const src = source({ archivedBdcs: [archived] });

    const { engaged, reserved } = _computeFromSource(src);

    expect(engaged.get('Frein') ?? 0).toBe(0);
    expect(reserved.get('Frein') ?? 0).toBe(0);
  });

  it('Aggregation cross-source : un même nom de pièce somme les quantités', () => {
    const src = source({
      bdcs: [
        bdc('A', [{ piece: { nom: 'Chaîne', qte: 1 } }]),
        bdc('B', [{ piece: { nom: 'Chaîne', qte: 2 } }]),
      ],
      velos: [velo('A', 'ON BENCH'), velo('B', 'FINI')],
      ventes: [vente([{ nom: 'Chaîne', qte: 4 }], false)],
    });

    const { engaged, reserved } = _computeFromSource(src);

    expect(engaged.get('Chaîne')).toBe(7);
    expect(reserved.get('Chaîne')).toBe(7);
  });

  it('Edge : BDT sans vélo correspondant (orphelin) est ignoré', () => {
    const src = source({
      bdcs: [bdc('0050', [{ piece: { nom: 'Pédalier', qte: 1 } }])],
      velos: [], // pas de vélo 0050
    });

    const { engaged, reserved } = _computeFromSource(src);

    expect(engaged.size).toBe(0);
    expect(reserved.size).toBe(0);
  });

  it('Edge : trim sur les noms de pièces (whitespace)', () => {
    const src = source({
      bdcs: [bdc('0010', [{ piece: { nom: '  Roue  ', qte: 1 } }])],
      velos: [velo('0010', 'APPROUVÉ')],
      ventes: [vente([{ nom: 'Roue', qte: 1 }], false)],
    });

    const { engaged } = _computeFromSource(src);

    expect(engaged.get('Roue')).toBe(2);
    expect(engaged.has('  Roue  ')).toBe(false);
  });

  it('Edge : qte ≤ 0 est ignorée (pas d\'engagement négatif)', () => {
    const src = source({
      bdcs: [bdc('0011', [{ piece: { nom: 'Vis', qte: 0 } }, { piece: { nom: 'Boulon', qte: -1 } }])],
      velos: [velo('0011', 'APPROUVÉ')],
    });

    const { engaged } = _computeFromSource(src);

    expect(engaged.get('Vis') ?? 0).toBe(0);
    expect(engaged.get('Boulon') ?? 0).toBe(0);
  });
});
