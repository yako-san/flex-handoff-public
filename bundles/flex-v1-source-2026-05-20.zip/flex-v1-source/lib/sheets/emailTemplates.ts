/**
 * CRUD templates courriel (évaluation + facture).
 * Stockage : onglet _EMAIL_TEMPLATES_ du document INVENTAIRE.
 * Structure : col A = clé, col B = valeur (texte ou HTML).
 */
import { getSheetsClient, SHEET_IDS, TAB } from './client';
import cache, { CACHE_KEYS } from '@/lib/cache';
import { EMAIL_TEMPLATE_DEFAULTS as DEFAULTS } from '@/lib/emailTemplateDefaults';

export { DEFAULTS };

// ── Lecture ──────────────────────────────────────────────────────

/** Retourne tous les templates (Sheets override + defaults fallback). */
export async function getEmailTemplates(): Promise<Record<string, string>> {
  const cached = await cache.get<Record<string, string>>(CACHE_KEYS.EMAIL_TPL);
  if (cached) return cached;

  const merged = { ...DEFAULTS };

  try {
    const sheets = getSheetsClient();
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.EMAIL_TEMPLATES}!A:B`,
      valueRenderOption: 'FORMATTED_VALUE',
    });
    for (const r of (res.data.values ?? [])) {
      const key = String(r[0] ?? '').trim();
      const val = String(r[1] ?? '');
      if (key && val) merged[key] = val;
    }
  } catch {
    // Onglet absent → on utilise les defaults
  }

  await cache.set(CACHE_KEYS.EMAIL_TPL, merged);
  return merged;
}

// ── Écriture ────────────────────────────────────────────────────

// Cache du résultat de _ensureTab : une fois confirmé que l'onglet existe,
// inutile de refaire un round-trip Sheets.spreadsheets.get sur chaque save.
let _tabEnsured = false;

/** Sauvegarde un ou plusieurs templates dans l'onglet Sheets. */
export async function saveEmailTemplates(entries: Record<string, string>): Promise<void> {
  // Court-circuit : si rien à sauver, on évite tous les appels Sheets.
  const keys = Object.keys(entries);
  if (keys.length === 0) return;

  const sheets = getSheetsClient();

  // S'assurer que l'onglet existe (1× par instance — ensuite cached).
  if (!_tabEnsured) {
    await _ensureTab();
    _tabEnsured = true;
  }

  // Lire les clés existantes pour connaître les positions.
  // (Inévitable si on veut update by-key sans tout réécrire.)
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.EMAIL_TEMPLATES}!A:A`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const existingKeys = (res.data.values ?? []).map(r => String(r[0] ?? '').trim());

  const updates: { range: string; values: unknown[][] }[] = [];
  const appends: unknown[][] = [];

  for (const [key, value] of Object.entries(entries)) {
    const rowIdx = existingKeys.indexOf(key);
    if (rowIdx >= 0) {
      updates.push({
        range : `${TAB.EMAIL_TEMPLATES}!B${rowIdx + 1}`,
        values: [[value]],
      });
    } else {
      appends.push([key, value]);
    }
  }

  // Lance les 2 écritures en parallèle (avant : séquentielles)
  await Promise.all([
    updates.length > 0
      ? sheets.spreadsheets.values.batchUpdate({
          spreadsheetId: SHEET_IDS.INVENTAIRE,
          requestBody  : { valueInputOption: 'RAW', data: updates },
        })
      : Promise.resolve(),
    appends.length > 0
      ? sheets.spreadsheets.values.append({
          spreadsheetId   : SHEET_IDS.INVENTAIRE,
          range           : `${TAB.EMAIL_TEMPLATES}!A1`,
          valueInputOption: 'RAW',
          insertDataOption: 'INSERT_ROWS',
          requestBody     : { values: appends },
        })
      : Promise.resolve(),
  ]);

  await cache.del(CACHE_KEYS.EMAIL_TPL);
}

// ── Rendu ───────────────────────────────────────────────────────

/** Remplace les {{placeholders}} par les valeurs fournies. */
export function renderTemplate(
  template: string,
  vars: Record<string, string>,
): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => vars[key] ?? '');
}

// ── Helpers ─────────────────────────────────────────────────────

async function _ensureTab(): Promise<void> {
  const sheets = getSheetsClient();
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const exists = (meta.data.sheets ?? []).some(
    s => s.properties?.title === TAB.EMAIL_TEMPLATES,
  );
  if (exists) return;

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        addSheet: {
          properties: {
            title: TAB.EMAIL_TEMPLATES,
            gridProperties: { rowCount: 100, columnCount: 2 },
          },
        },
      }],
    },
  });

  // Seed avec les valeurs par défaut
  const rows = Object.entries(DEFAULTS).map(([k, v]) => [k, v]);
  await sheets.spreadsheets.values.update({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.EMAIL_TEMPLATES}!A1`,
    valueInputOption: 'RAW',
    requestBody     : { values: rows },
  });
}
