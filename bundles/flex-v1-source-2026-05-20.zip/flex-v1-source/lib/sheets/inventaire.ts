/**
 * CRUD vélos — onglet INVENTAIRE du document principal.
 * Équivalent des fonctions ajouterLigneVelo, _appliquerStatutLigne, etc.
 */
import { getSheetsClient, SHEET_IDS, TAB, COL, ROW } from './client';
import { todayStr } from '@/lib/utils/format';
import type { Velo, VeloStatus } from '@/types/velo';

const VELO_DEFAULTS = {
  eval    : 'Sélection →',
  meca    : 'Attente APPROBATION',
  ctrl    : 'Attente MÉCANIQUE',
  status  : 'REÇU' as VeloStatus,
};

/** Lit toutes les lignes INVENTAIRE (data dès ligne INS_ROW). */
export async function getVelos(): Promise<Velo[]> {
  // Validation schéma au premier appel (idempotente, n'attend pas le résultat)
  void import('./validate').then(m => m.validateSchemas()).catch(() => {});

  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.INVENTAIRE}!A${ROW.INS_ROW}:W`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });

  const rows = res.data.values ?? [];
  return rows
    .map((r, idx) => rowToVelo(r, idx + ROW.INS_ROW))
    .filter((v): v is Velo => v !== null);
}

/** Lit un vélo par son ID. */
export async function getVelo(id: string): Promise<Velo | null> {
  const velos = await getVelos();
  return velos.find(v => v.id === id) ?? null;
}

/**
 * Cache mémoire par-lambda (TTL 30s) pour findVeloRow. Pendant une
 * session de travail BDT (cascade de mutations sur la fiche vélo),
 * le rowNum reste stable — évite N reads inutiles vers le quota Sheets.
 */
const _findVeloRowCache = new Map<string, { row: number; expiresAt: number }>();
const FIND_VELO_TTL_MS = 30_000;

export function _clearFindVeloRowCache(id?: string): void {
  if (id) _findVeloRowCache.delete(id);
  else _findVeloRowCache.clear();
}

/** Trouve le numéro de ligne d'un vélo par son ID (retourne -1 si introuvable). */
export async function findVeloRow(id: string): Promise<number> {
  const now = Date.now();
  const cached = _findVeloRowCache.get(id);
  if (cached && cached.expiresAt > now) return cached.row;

  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.INVENTAIRE}!D${ROW.INS_ROW}:D`,
    valueRenderOption: 'FORMATTED_VALUE',
  });

  const rows = res.data.values ?? [];
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i][0]).trim() === id) {
      const row = i + ROW.INS_ROW;
      _findVeloRowCache.set(id, { row, expiresAt: now + FIND_VELO_TTL_MS });
      return row;
    }
  }
  return -1;
}

/**
 * Ajoute un nouveau vélo (append en bas + tri UI côté client).
 * Équivalent de ajouterLigneVelo() dans le GAS.
 */
export async function addVelo(
  idStr: string,
  fields: {
    client?: string;
    marque?: string;
    modele?: string;
    couleur?: string;
    taille?: string;
    serie?: string;
    /** Override du statut par défaut (REÇU). Ex. 'RV' pour pré-inscription Square. */
    status?: string;
    /** Override de la date de réception (ISO date ou string FR) — défaut : aujourd'hui. */
    date1?: string;
    /** Note interne (col U). Défaut : '...' */
    notes?: string;
  } = {}
): Promise<Velo> {
  const sheets   = getSheetsClient();
  const dateHeur = fields.date1 || todayStr();

  // 21 colonnes, offset depuis col A (col 1) jusqu'à col U (col 21)
  // Colonnes C(3)–U(21) = indices 2–20 dans ce tableau 0-based
  const rowData = Array(COL.NB_COLS).fill('');
  rowData[COL.STATUS   - 1] = fields.status || VELO_DEFAULTS.status;
  rowData[COL.ID       - 1] = idStr;
  rowData[COL.DATE1    - 1] = dateHeur;
  rowData[COL.CLIENT   - 1] = fields.client  ?? 'Sélection →';
  rowData[COL.MARQUE   - 1] = fields.marque  ?? 'Sélection →';
  rowData[COL.MODELE   - 1] = fields.modele  ?? '...';
  rowData[COL.COULEUR  - 1] = fields.couleur ?? '...';
  rowData[COL.TAILLE   - 1] = fields.taille  ?? '...';
  rowData[COL.SERIE    - 1] = fields.serie   ?? '...';
  rowData[COL.EVAL     - 1] = VELO_DEFAULTS.eval;
  rowData[COL.MECA     - 1] = VELO_DEFAULTS.meca;
  rowData[COL.CTRL     - 1] = VELO_DEFAULTS.ctrl;
  rowData[COL.NOTES    - 1] = fields.notes ?? '...';

  await sheets.spreadsheets.values.append({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.INVENTAIRE}!A${ROW.INS_ROW}`,
    valueInputOption : 'RAW',
    insertDataOption : 'INSERT_ROWS',
    requestBody      : { values: [rowData] },
  });

  // Nouvelle ligne insérée → invalider le cache de lookup (rowNums décalés)
  _clearFindVeloRowCache();

  // Relire pour obtenir la ligne réelle
  const newVelo = await getVelo(idStr);
  if (!newVelo) throw new Error(`Vélo ${idStr} introuvable après insertion`);
  return newVelo;
}

/**
 * Met à jour un ou plusieurs champs d'un vélo.
 * Utilise des updateCells ciblées pour minimiser les écritures.
 * Si `client` change, retire le bdcId de l'ancien client (col I/J de
 * CLIENTS) et l'ajoute au nouveau.
 */
export async function updateVelo(
  id: string,
  fields: Partial<Pick<Velo, 'status'|'client'|'marque'|'modele'|'couleur'|'taille'|'serie'|'noteVelo'|'eval'|'meca'|'ctrl'|'notes'|'services'|'pieces'|'date1'|'date2'|'date3'|'noteClientEval'|'noteClientFacture'>>
): Promise<Velo> {
  const sheets  = getSheetsClient();
  const rowNum  = await findVeloRow(id);
  if (rowNum < 0) throw new Error(`Vélo ${id} introuvable`);

  // Détecter un changement de client pour synchroniser CLIENTS (col I/J).
  let oldClient: string | null = null;
  if (fields.client !== undefined) {
    const current = await getVelo(id);
    const prev = current?.client?.trim() || '';
    const next = (fields.client ?? '').trim();
    if (prev && prev !== next && prev !== 'Sélection →') {
      oldClient = prev;
    }
  }

  const colMap: Record<string, number> = {
    status            : COL.STATUS,
    client            : COL.CLIENT,
    marque            : COL.MARQUE,
    modele            : COL.MODELE,
    couleur           : COL.COULEUR,
    taille            : COL.TAILLE,
    serie             : COL.SERIE,
    noteVelo          : COL.NOTE_VELO,
    eval              : COL.EVAL,
    meca              : COL.MECA,
    ctrl              : COL.CTRL,
    notes             : COL.NOTES,
    services          : COL.SERVICES,
    pieces            : COL.PIECES,
    date1             : COL.DATE1,
    date2             : COL.DATE2,
    date3             : COL.DATE3,
    noteClientEval    : COL.NOTE_EVAL,
    noteClientFacture : COL.NOTE_FACTURE,
  };

  const data: { range: string; values: unknown[][] }[] = [];
  for (const [key, val] of Object.entries(fields)) {
    const c = colMap[key];
    if (!c) continue;
    const colLetter = colToLetter(c);
    data.push({ range: `${TAB.INVENTAIRE}!${colLetter}${rowNum}`, values: [[val ?? '']] });
  }

  if (data.length === 0) return (await getVelo(id))!;

  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      valueInputOption: 'RAW',
      data,
    },
  });

  // Synchroniser la sheet CLIENTS si le client a changé (best-effort — ne
  // bloque jamais la mise à jour principale).
  if (fields.client !== undefined) {
    try {
      const { retirerBDCId, ajouterBDCId } = await import('./clients');
      const next = (fields.client ?? '').trim();
      if (oldClient) {
        await retirerBDCId(oldClient, id);
      }
      if (next && next !== 'Sélection →') {
        await ajouterBDCId(next, id);
      }
    } catch (err: any) {
      console.warn('[updateVelo] sync CLIENTS échoué :', err?.message ?? err);
    }
  }

  return (await getVelo(id))!;
}

/**
 * Supprime un vélo de l'INVENTAIRE par son ID.
 */
export async function deleteVelo(id: string): Promise<void> {
  const sheets  = getSheetsClient();
  const rowNum  = await findVeloRow(id);
  if (rowNum < 0) throw new Error(`Vélo ${id} introuvable`);
  // Lignes décalées par delete → invalider tout le cache de lookup
  _clearFindVeloRowCache();

  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const sheet   = meta.data.sheets?.find(s => s.properties?.title === TAB.INVENTAIRE);
  const sheetId = sheet?.properties?.sheetId;
  if (sheetId === undefined) throw new Error('Onglet INVENTAIRE introuvable');

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        deleteDimension: {
          range: {
            sheetId,
            dimension  : 'ROWS',
            startIndex : rowNum - 1,
            endIndex   : rowNum,
          },
        },
      }],
    },
  });
}

// ── Helpers ───────────────────────────────────────────────────────

function rowToVelo(r: unknown[], rowNum: number): Velo | null {
  const str = (i: number) => String(r[i] ?? '').trim();
  const id  = str(COL.ID - 1);
  if (!id) return null;

  return {
    _row    : rowNum,
    id,
    status  : str(COL.STATUS    - 1) as VeloStatus,
    date1   : str(COL.DATE1     - 1) || null,
    date2   : str(COL.DATE2     - 1) || null,
    date3   : str(COL.DATE3     - 1) || null,
    client  : str(COL.CLIENT    - 1),
    marque  : str(COL.MARQUE    - 1),
    modele  : str(COL.MODELE    - 1),
    couleur : str(COL.COULEUR   - 1),
    taille  : str(COL.TAILLE    - 1),
    serie   : str(COL.SERIE     - 1),
    noteVelo: str(COL.NOTE_VELO - 1),
    eval    : str(COL.EVAL      - 1),
    meca    : str(COL.MECA      - 1),
    ctrl    : str(COL.CTRL      - 1),
    services         : str(COL.SERVICES     - 1),
    pieces           : str(COL.PIECES       - 1),
    notes            : str(COL.NOTES        - 1),
    noteClientEval   : str(COL.NOTE_EVAL    - 1),
    noteClientFacture: str(COL.NOTE_FACTURE - 1),
  };
}

function colToLetter(n: number): string {
  let s = '';
  let num = n;
  while (num > 0) { num--; s = String.fromCharCode(65 + (num % 26)) + s; num = Math.floor(num / 26); }
  return s;
}
