/**
 * Stock physique (col AB) + stock réservé (col AC) — modèle invariant
 * basé sur l'engagement des pièces dans BDT et Ventes (v6.7.0).
 *
 * Définitions :
 *   ENGAGED = pièce dont la sortie du stock est commencée :
 *     - INVENTAIRE BDT statut ∈ {APPROUVÉ, ON BENCH, CTRL QLTÉ, FINI,
 *       LIVRÉ, FACTURER, FACTURÉ}
 *     - ARCHIVES BDT col C = FACTURÉ (vente définitive)
 *     - _VENTES_ : toute ligne (brouillon + facturée)
 *   RESERVED = sous-ensemble visible « réservation en cours » :
 *     - INVENTAIRE BDT statut ∈ {APPROUVÉ, ON BENCH, CTRL QLTÉ, FINI, LIVRÉ}
 *     - _VENTES_ brouillon (factureDate vide)
 *     (FACTURER/FACTURÉ + archives FACTURÉ + ventes facturées sont engaged
 *      mais plus reserved : la pièce est sortie du stock, vente confirmée.)
 *
 * Invariant maintenu :
 *   AB(after) = AB(before) - (engaged_after - engaged_before)
 *   AC(after) = reserved_after
 *
 * Optimisation v6.7.0 :
 *   `snapshotStock()` retourne `{ engaged, source }` — `source` contient
 *   la data brute déjà chargée. Le caller passe ça à `recomputeStockState`
 *   qui réutilise les sheets non-affectées par la mutation (scope), évitant
 *   1 à 3 reads Sheets par route → ~50% de gain quota.
 */
import { getSheetsClient, SHEET_IDS, TAB } from './client';
import { getBDCs, getArchivedBDCs } from './bdc';
import { getVelos } from './inventaire';
import { getVentes } from './ventes';
import cache, { CACHE_KEYS } from '@/lib/cache';
import { pieceKey } from '@/lib/utils/pieces';
import type { VeloStatus } from '@/types/velo';
import type { BDC } from '@/types/bdc';
import type { Velo } from '@/types/velo';
import type { Vente } from '@/types/vente';

export const ENGAGED_STATUSES: ReadonlySet<VeloStatus> = new Set<VeloStatus>([
  'APPROUVÉ', 'ON BENCH', 'CTRL QLTÉ', 'FINI', 'LIVRÉ', 'FACTURER', 'FACTURÉ',
]);

export const RESERVED_STATUSES: ReadonlySet<VeloStatus> = new Set<VeloStatus>([
  'APPROUVÉ', 'ON BENCH', 'CTRL QLTÉ', 'FINI', 'LIVRÉ',
]);

export type EngagedMap = Map<string, number>;

export interface StockSourceData {
  bdcs: BDC[];
  velos: Velo[];
  archivedBdcs: BDC[];
  ventes: Vente[];
}

export interface StockSnapshot {
  engaged : EngagedMap;
  reserved: EngagedMap;
  source  : StockSourceData;
}

/**
 * Type de mutation effectuée — guide la stratégie de re-read côté recompute.
 *   - 'BDT'    : mutation INVENTAIRE/BDC (status, items, archive…). Re-read
 *                bdcs + velos + archives, réutilise ventes du snapshot.
 *   - 'VENTE'  : mutation _VENTES_ (create, delete, item add/remove/qty).
 *                Re-read ventes, réutilise bdcs/velos/archives du snapshot.
 *   - 'ALL'    : mutation cross-cutting (admin, restore, désarchive…).
 *                Re-read tout.
 */
export type MutationScope = 'BDT' | 'VENTE' | 'ALL';

/**
 * Charge les 4 sheets de référence et calcule engaged/reserved.
 * Retourne aussi la data brute (pour réutilisation côté recompute).
 *
 * ⚠ Force un fresh read de BDC + VENTES en invalidant le cache local AVANT
 *    le read. Sinon, sur Vercel multi-instance, un lambda peut avoir un
 *    cache stale (mutation faite par un autre lambda) et calculer un
 *    engaged_before incohérent avec engaged_after → drift AB. Coûte 2-3
 *    reads de plus par snapshot mais garantit l'intégrité du modèle.
 */
export async function snapshotStock(): Promise<StockSnapshot> {
  // Force fresh des données mutables. INVENTAIRE (velos) et ARCHIVES ne
  // sont pas cachées en module, donc toujours fresh. Avec KV (v7.0.0+),
  // ce del se propage cross-lambda → garantit qu'aucun lambda ne lit
  // une version stale du cache pendant le snapshot.
  await cache.del(CACHE_KEYS.BDCS);
  await cache.del(CACHE_KEYS.VENTES);
  const [bdcs, velos, archivedBdcs, ventes] = await Promise.all([
    getBDCs(),
    getVelos(),
    getArchivedBDCs(),
    getVentes(),
  ]);
  const { engaged, reserved } = _computeFromSource({ bdcs, velos, archivedBdcs, ventes });
  return { engaged, reserved, source: { bdcs, velos, archivedBdcs, ventes } };
}

/** @deprecated Compat v6.4-v6.6 callers. Préférer `snapshotStock()`. */
export async function snapshotEngagedTotal(): Promise<EngagedMap> {
  const snap = await snapshotStock();
  return snap.engaged;
}

/**
 * Recalcule l'état stock complet (AB + AC) sur PIÈCES.
 *
 * @param before   Snapshot retourné par `snapshotStock()` AVANT la mutation.
 * @param scope    Type de mutation effectuée (détermine quels sheets re-read).
 *
 * Si `before` non fourni : seul AC est recalculé from scratch (AB inchangé).
 */
export async function recomputeStockState(
  before?: StockSnapshot,
  scope  : MutationScope = 'ALL',
): Promise<{
  abUpdates: { row: number; nom: string; before: number; after: number }[];
  acUpdates: { row: number; nom: string; before: number; after: number }[];
}> {
  // 1. Charger l'état APRÈS la mutation, en réutilisant la data du snapshot
  //    pour les sheets non-affectées par le scope. Économise 1 à 3 reads.
  const after = await _loadAfterState(before?.source, scope);

  // 2. Recalcul engaged/reserved sur l'état après.
  const { engaged: engagedAfter, reserved: reservedAfter } = _computeFromSource(after);

  // 3. Lire PIÈCES (1 read incompressible : on a besoin du nom→row + AB/AC actuels).
  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.PIECES,
    range            : `${TAB.PIECES_TAB}!A2:AC`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const pieceRows = res.data.values ?? [];

  interface PieceLookup { row: number; nom: string; pieceId: string; key: string; currentAB: number; currentAC: number }
  const lookupByKey = new Map<string, PieceLookup>();
  for (let i = 0; i < pieceRows.length; i++) {
    const r = pieceRows[i];
    const pieceId = String(r[0] ?? '').trim();  // col A — pieceId stable (v1.1.5+)
    const nom = String(r[3] ?? '').trim();
    if (!nom) continue;
    const currentAB = parseFloat(String(r[27] ?? '0')) || 0;  // col AB
    const currentAC = parseFloat(String(r[28] ?? '0')) || 0;  // col AC
    // Clé stable : symétrique à pieceKey(BDCPieceItem) côté consumers.
    const key = pieceKey({ pieceId, nom });
    lookupByKey.set(key, { row: i + 2, nom, pieceId, key, currentAB, currentAC });
  }

  // 4. Calculer + écrire les deltas. Une seule batchUpdate (1 write).
  const abUpdates: { row: number; nom: string; before: number; after: number }[] = [];
  const acUpdates: { row: number; nom: string; before: number; after: number }[] = [];
  const writes  : { range: string; values: unknown[][] }[] = [];

  for (const lookup of lookupByKey.values()) {
    // AC = reserved_after (computed pur, pas de delta).
    const newAC = reservedAfter.get(lookup.key) ?? 0;
    if (newAC !== lookup.currentAC) {
      acUpdates.push({ row: lookup.row, nom: lookup.nom, before: lookup.currentAC, after: newAC });
      writes.push({ range: `${TAB.PIECES_TAB}!AC${lookup.row}`, values: [[newAC]] });
    }

    // AB = AB(before) - delta engagement. Skip si pas de snapshot avant.
    if (before) {
      const engBefore = before.engaged.get(lookup.key) ?? 0;
      const engAfter  = engagedAfter.get(lookup.key) ?? 0;
      const delta     = engAfter - engBefore;
      if (delta !== 0) {
        const newAB = Math.max(0, lookup.currentAB - delta);
        abUpdates.push({ row: lookup.row, nom: lookup.nom, before: lookup.currentAB, after: newAB });
        writes.push({ range: `${TAB.PIECES_TAB}!AB${lookup.row}`, values: [[newAB]] });
      }
    }
  }

  if (writes.length > 0) {
    await sheets.spreadsheets.values.batchUpdate({
      spreadsheetId: SHEET_IDS.PIECES,
      requestBody  : { valueInputOption: 'RAW', data: writes },
    });
    await cache.del(CACHE_KEYS.PIECES);
  }

  return { abUpdates, acUpdates };
}

/**
 * Wrapper non-bloquant. Pattern type pour les routes :
 *   const before = await snapshotStock();
 *   // ... mutation ...
 *   await safeRecomputeStockState(before, 'VENTE');
 */
export async function safeRecomputeStockState(
  before?: StockSnapshot,
  scope  : MutationScope = 'ALL',
): Promise<void> {
  try {
    await recomputeStockState(before, scope);
  } catch (err: any) {
    console.warn('[reservation] recompute failed:', err?.message ?? err);
  }
}

// ── Compat v6.4-v6.6 callers ─────────────────────────────────────────
// L'ancienne signature acceptait un EngagedMap. On wrappe pour ne pas
// casser les hooks qui appellent encore l'ancien nom.
export async function safeRecomputeReservedStock(): Promise<void> {
  await safeRecomputeStockState(undefined, 'ALL');
}

export async function recomputeReservedStock(): Promise<void> {
  await recomputeStockState(undefined, 'ALL');
}

// ── Internes ─────────────────────────────────────────────────────────

async function _loadAfterState(
  beforeSource: StockSourceData | undefined,
  scope       : MutationScope,
): Promise<StockSourceData> {
  // Sans data préalable : load tout (cold path, équivalent au snapshot).
  if (!beforeSource) {
    const [bdcs, velos, archivedBdcs, ventes] = await Promise.all([
      getBDCs(), getVelos(), getArchivedBDCs(), getVentes(),
    ]);
    return { bdcs, velos, archivedBdcs, ventes };
  }

  // Avec scope BDT : re-read bdcs+velos+archives, ventes inchangées.
  if (scope === 'BDT') {
    const [bdcs, velos, archivedBdcs] = await Promise.all([
      getBDCs(), getVelos(), getArchivedBDCs(),
    ]);
    return { bdcs, velos, archivedBdcs, ventes: beforeSource.ventes };
  }

  // Avec scope VENTE : re-read ventes seulement, BDT inchangés.
  if (scope === 'VENTE') {
    const ventes = await getVentes();
    return {
      bdcs        : beforeSource.bdcs,
      velos       : beforeSource.velos,
      archivedBdcs: beforeSource.archivedBdcs,
      ventes,
    };
  }

  // ALL : tout re-read (par défaut, coût équivalent à pas de cache partagé).
  const [bdcs, velos, archivedBdcs, ventes] = await Promise.all([
    getBDCs(), getVelos(), getArchivedBDCs(), getVentes(),
  ]);
  return { bdcs, velos, archivedBdcs, ventes };
}

export function _computeFromSource(src: StockSourceData): { engaged: EngagedMap; reserved: EngagedMap } {
  const statusByBdcId = new Map<string, VeloStatus>();
  for (const v of src.velos) statusByBdcId.set(v.id, v.status);

  const engaged  = new Map<string, number>();
  const reserved = new Map<string, number>();
  const acc = (map: Map<string, number>, nom: string, qte: number) => {
    if (!nom || qte <= 0) return;
    map.set(nom, (map.get(nom) ?? 0) + qte);
  };

  for (const bdc of src.bdcs) {
    const status = statusByBdcId.get(bdc.id);
    if (!status) continue;
    const isEngaged  = ENGAGED_STATUSES.has(status);
    const isReserved = RESERVED_STATUSES.has(status);
    if (!isEngaged && !isReserved) continue;
    for (const item of bdc.items) {
      if (!item.piece) continue;
      // v1.1.5+ : clé stable (pieceId privilégié, fallback nom normalisé)
      // pour survivre aux renames de pièces catalogue.
      const k   = pieceKey(item.piece);
      const qte = item.piece.qte;
      if (isEngaged)  acc(engaged, k, qte);
      if (isReserved) acc(reserved, k, qte);
    }
  }

  for (const bdc of src.archivedBdcs) {
    if (bdc.archiveStatus !== 'FACTURÉ') continue;
    for (const item of bdc.items) {
      if (!item.piece) continue;
      acc(engaged, pieceKey(item.piece), item.piece.qte);
    }
  }

  for (const vente of src.ventes) {
    const isBrouillon = !vente.factureDate;
    for (const item of vente.items) {
      const k = pieceKey({ pieceId: item.pieceId, nom: item.nom });
      acc(engaged, k, item.qte);
      if (isBrouillon) acc(reserved, k, item.qte);
    }
  }

  return { engaged, reserved };
}
