/**
 * Singleton googleapis — authentifié via Service Account.
 * Utilisé par tous les modules lib/sheets/*.
 */
import { google } from 'googleapis';
import { GoogleAuth } from 'google-auth-library';
import { trackSheetsRetry } from '@/lib/log';

let sheetsInstance: ReturnType<typeof google.sheets> | null = null;
let authInstance: GoogleAuth | null = null;

export function getAuth(): GoogleAuth {
  if (authInstance) return authInstance;

  const email = process.env.GOOGLE_CLIENT_EMAIL;
  const key   = process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n');

  if (!email || !key) {
    throw new Error('Variables manquantes : GOOGLE_CLIENT_EMAIL et/ou GOOGLE_PRIVATE_KEY');
  }

  authInstance = new GoogleAuth({
    credentials: { client_email: email, private_key: key },
    scopes: [
      'https://www.googleapis.com/auth/spreadsheets',
      'https://www.googleapis.com/auth/drive',
    ],
  });
  return authInstance;
}

export function getSheetsClient() {
  if (sheetsInstance) return sheetsInstance;
  // retryConfig : retry auto sur 429 (Quota exceeded) et 5xx via gaxios.
  // Le quota Sheets API (60 reads/min/user) se reset chaque minute, donc
  // on retry pendant ~60s (8 retries, 500ms × 1.6^N + jitter) pour
  // absorber un cycle complet sans laisser le user voir l'erreur.
  // Total approx : 0.5 + 0.8 + 1.3 + 2.0 + 3.3 + 5.2 + 8.4 + 13.4 = ~35s
  // (avec jitter : peut atteindre 50-60s). Couvre toutes les routes API.
  sheetsInstance = google.sheets({
    version: 'v4',
    auth: getAuth() as any,
    retryConfig: {
      retry: 8,
      retryDelay: 500,
      retryDelayMultiplier: 1.6,
      statusCodesToRetry: [[429, 429], [500, 599]],
      httpMethodsToRetry: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
      onRetryAttempt: (err: any) => {
        const code    = err?.code ?? err?.response?.status ?? '?';
        const attempt = err?.config?.retryConfig?.currentRetryAttempt ?? 0;
        trackSheetsRetry(code, attempt);
      },
    },
  } as any);
  return sheetsInstance;
}

// IDs des 5 documents Sheets (depuis les vars d'env).
// v5.2 : documents renommés
//   - "ACHATS - FLEX-REV"            → "PIÈCES - FLEX-REV"
//   - "À LA CARTE et FORFAIT - FLEX-REV" → "SERVICES - FLEX-REV"
// Fallback sur les anciens noms d'env vars (SHEETS_ACHATS_ID / SHEETS_ALACARTE_ID)
// pour rester compatible avec Vercel tant que les nouveaux noms n'y sont pas
// déployés.
export const SHEET_IDS = {
  INVENTAIRE : process.env.SHEETS_INVENTAIRE_ID ?? '',
  PIECES     : process.env.SHEETS_PIECES_ID     ?? process.env.SHEETS_ACHATS_ID   ?? '',
  SERVICES   : process.env.SHEETS_SERVICES_ID   ?? process.env.SHEETS_ALACARTE_ID ?? '',
  FACTURES   : process.env.SHEETS_FACTURES_ID   ?? '',
  CLIENTS    : process.env.SHEETS_CLIENTS_ID    ?? '',
};

// IDs des dossiers Google Drive
export const DRIVE_FOLDER_IDS = {
  FACTURES: process.env.DRIVE_FACTURES_FOLDER_ID ?? '',
  CLIENTS : process.env.DRIVE_CLIENTS_FOLDER_ID  ?? '',
};

// Noms des onglets
export const TAB = {
  INVENTAIRE      : 'INVENTAIRE',
  BDC             : 'BONS DE COMMANDES',
  CLIENTS_MIROIR  : 'CLIENTS',
  PIECES_CACHE    : 'PIÈCES',
  PARAMS          : '_PARAMÈTRES_',
  DONNEES_EXT     : '_DONNÉES_EXT_',
  ARCHIVES        : 'ARCHIVES 2026',
  BDC_BACKUPS     : '_BDC_BACKUPS_',     // append-only — snapshots avant op destructive
  EQUIPE          : '_EQUIPE_',          // équipe atelier (mécaniciens) — fiche détaillée v7.0.18
  VENTES_ARCHIVES : '_VENTES_ARCHIVES_', // ventes archivées — pattern miroir d'ARCHIVES 2026 (v7.0.23)
  EMAIL_TEMPLATES : '_EMAIL_TEMPLATES_', // templates courriels éval/facture
  PO              : '_PO_',              // bons de commande fournisseurs
  VENTES          : '_VENTES_',           // ventes directes (sans BDT)
  DEPENSES        : '_DEPENSES_',         // v1.0.26+ : dépenses business (admin only, fiscalité TPS/TVQ)
  // docs externes — les NOMS des onglets restent inchangés ; seul le nom
  // du document (filename Drive) a changé en v5.2.
  CLIENTS_EXT     : 'CLIENTS',
  PIECES_TAB      : 'PIÈCES et COMPOSANTS',
  SERVICES_TAB    : 'À LA CARTE',
  FORFAITS_TAB    : 'FORFAITS',       // v5.7.5 : les forfaits et leurs sous-items ont migré
                                       //          de l'onglet "À LA CARTE" vers ce nouvel onglet
                                       //          dans "SERVICES - FLEX-REV".
  // Templates dans FACTURES-FLEX-REV
  FACTURES_BASE_YC      : 'BASE-YC',       // Template évaluation — lead yako.cyclo
  FACTURES_BASE_CF      : 'BASE-CF',       // Template évaluation — lead Cyclo Flex
  FACTURES_FACTURE_YC   : 'FACTURE-YC',    // Template facture    — lead yako.cyclo
  FACTURES_FACTURE_CF   : 'FACTURE-CF',    // Template facture    — lead Cyclo Flex
  FACTURES_LOG          : 'FACTURES',      // [legacy] journal mixte BDT+ventes — figé
  FACTURES_LOG_BDT      : 'ENCAISSE BDT',  // v7.0.13 — journal des factures BDT
  FACTURES_LOG_VENTES   : 'VENTES',        // v7.0.13 — journal des ventes directes
};

// Offsets de lignes
export const ROW = {
  INS_ROW             : 5,
  BDC_INS             : 6,
  COUNTER_ROW         : 2,
  COUNTER_COL         : 2,
  FACTURE_COUNTER_ROW : 3,   // _PARAMÈTRES_!B3 — compteur séquentiel factures ventes
  DEPENSE_COUNTER_ROW : 4,   // v1.0.26+ : _PARAMÈTRES_!B4 — compteur séquentiel dépenses (D0001, D0002, …)
  MARQUES_START       : 37,
  MARQUES_END         : 65,
};

// Index de colonnes INVENTAIRE (1-based) — refonte v7.0.4
//   I-M : Marque, Modèle, Couleur, Taille, Série
//   N   : ÉVALUATION (mécano)        ← était O
//   O   : MÉCANIQUE (mécano)         ← était P
//   P   : CONTRÔLE  (mécano)         ← était Q
//   Q   : NOTE_VELO                  ← était N (déplacée pour libérer N)
//   R   : SERVICES (texte)           ← était S
//   S   : PIÈCES   (texte)           ← était U
//   T   : (libre — anciennement Total $ services, calculé à la volée maintenant)
//   U   : NOTES INTERNES             ← était W
//   V   : NOTES EXT / ÉVALUATION     (NOUVEAU)
//   W   : NOTES EXT / FACTURATION    (NOUVEAU)
export const COL = {
  STATUS         :  3,
  ID             :  4,
  DATE1          :  5,
  DATE2          :  6,
  DATE3          :  7,
  CLIENT         :  8,
  MARQUE         :  9,
  MODELE         : 10,
  COULEUR        : 11,
  TAILLE         : 12,
  SERIE          : 13,
  EVAL           : 14, // col N (déplacé depuis O)
  MECA           : 15, // col O (déplacé depuis P)
  CTRL           : 16, // col P (déplacé depuis Q)
  NOTE_VELO      : 17, // col Q — note libre sur le vélo (déplacée depuis N)
  SERVICES       : 18, // col R (déplacé depuis S)
  PIECES         : 19, // col S (déplacé depuis U)
  NOTES          : 21, // col U — notes INTERNES (déplacé depuis W)
  NOTE_EVAL      : 22, // col V — note client EXT évaluation (NOUVEAU)
  NOTE_FACTURE   : 23, // col W — note client EXT facture    (NOUVEAU)
  NB_COLS        : 23,
};

// Index de colonnes BDC (1-based)
export const BDC_COL = {
  TAG     :  1,
  ID      :  2,
  IN      :  3,
  EVAL    :  4,
  OK      :  5,
  BDS     :  6,
  OUT     :  7,
  VELO    :  8,
  SVC_ID  :  9,   // col I — serviceId stable (S00001…)
  EVAL_ST : 10,   // col J ligne BON — evalStatus client (APPROUVE/REDUX/ATTENTE/REFUSE)
  SVC     : 11,
  SVC_CHK : 12,
  SVC_TXT : 13,
  SVC_PX  : 14,
  PCE_ID  : 15,   // col O — pieceId stable du catalogue (P00001…). Ajouté
                  //         2026-05-16 pour résoudre la perte de lien BDT↔
                  //         catalogue lors d'un rename de pièce. Header
                  //         `PCE_ID` écrit manuellement en O1. Col O était
                  //         un trou dans le schema (jamais utilisée auparavant),
                  //         donc AUCUN autre index n'a été bumpé.
                  //         Migration backfill : POST /api/admin/migrate-bdc-pceid
  PCE     : 16,
  PCE_PX  : 17,
  PCE_CHK : 18,
  PCE_QTE : 19,
  PCE_TOT : 20,
  PCE_FLAG  : 22,
  CMD_NOTE  : 23,  // col W — note de commande (texte libre sur ligne ITEM pièce)
  NB_COLS   : 22,  // nombre de colonnes pour la création d'une ligne (CMD_NOTE écrit séparément)
};

/**
 * Colonnes de la ligne GAP (client).
 * Col V (22) = note pour le client — partagée avec PCE_FLAG mais sur un tag différent.
 * Col W (23) = note client FACTURE — séparée de la note ÉVAL (col V) depuis v7.0.x.
 *              Permet d'avoir 2 messages distincts substitués dans les templates
 *              email correspondants.
 */
export const BDC_GAP_COL = {
  NOTE_CLIENT        : 22, // col V — note visible client pour l'ÉVALUATION
  NOTE_CLIENT_FACTURE: 23, // col W — note visible client pour la FACTURE
};

export const BDC_TAG = {
  BON  : 'BON',
  GAP  : 'GAP',
  SEP0 : 'SEP0',
  ITEM : 'ITEM',
  BTN  : 'BTN',
  TOT  : 'TOT',
  SEP  : 'SEP',
};
