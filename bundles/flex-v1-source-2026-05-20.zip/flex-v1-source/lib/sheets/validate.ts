/**
 * Validation de schéma au démarrage : vérifie que les en-têtes des onglets
 * critiques correspondent à ce que le code attend. Best-effort — ne bloque
 * jamais l'app, log seulement un warning si un mismatch est détecté.
 *
 * Lancé une seule fois par process serveur (cache mémoire), pour éviter de
 * spammer l'API Sheets à chaque requête.
 */
import { getSheetsClient, SHEET_IDS, TAB } from './client';

let _validated = false;

interface ExpectedHeader {
  sheetId : string;
  tab     : string;
  /** Range A1 des cellules d'en-tête à vérifier (ex. 'A2:U3') */
  range   : string;
  /** Map { 'colLetter': 'expected substring' } — case-insensitive contains */
  expects : Record<string, string>;
}

const SCHEMAS: ExpectedHeader[] = [
  {
    sheetId : SHEET_IDS.INVENTAIRE,
    tab     : TAB.INVENTAIRE,
    range   : 'A2:U3',
    expects : {
      // Row 2 (index 0)
      'C2' : 'projet',     // 🔢 PROJET (header de groupe)
      'E2' : 'in/out',     // 📆 IN/OUT
      'H2' : 'vélo',       // 🚲 VÉLO
      'O2' : 'séquence',   // 🧰 SÉQUENCE DE
      'S2' : 'services',
      'T2' : 'pièces',
      'U2' : 'notes',
      // Row 3 (index 1)
      'C3' : 'status',
      'D3' : 'id',
      'E3' : 'entrée',
      'F3' : 'travaux',
      'G3' : 'sortie',
      'H3' : 'client',
    },
  },
];

/**
 * Vérifie les en-têtes critiques. Logge des warnings si mismatch mais ne
 * throw jamais. À appeler une seule fois (idempotent par cache mémoire).
 */
export async function validateSchemas(): Promise<void> {
  if (_validated) return;
  _validated = true;

  const sheets = getSheetsClient();
  for (const schema of SCHEMAS) {
    try {
      const r = await sheets.spreadsheets.values.get({
        spreadsheetId    : schema.sheetId,
        range            : `${schema.tab}!${schema.range}`,
        valueRenderOption: 'FORMATTED_VALUE',
      });
      const rows = r.data.values ?? [];

      for (const [cell, expected] of Object.entries(schema.expects)) {
        // Parse 'A2' / 'B3' → row idx 0/1, col letter
        const m = cell.match(/^([A-Z]+)(\d+)$/);
        if (!m) continue;
        const colLetter = m[1];
        const rowAbs    = parseInt(m[2], 10);
        // schema.range commence à A2 → row 2 = index 0 dans `rows`
        const rangeStartRow = parseInt(schema.range.match(/(\d+)/)?.[1] ?? '1', 10);
        const rowIdx = rowAbs - rangeStartRow;
        const colIdx = colLetter.charCodeAt(0) - 'A'.charCodeAt(0);

        const actual = String(rows[rowIdx]?.[colIdx] ?? '').toLowerCase();
        if (!actual.includes(expected.toLowerCase())) {
          console.warn(
            `[schema] ${schema.tab}!${cell}: attendu "${expected}", trouvé "${actual.substring(0, 40)}"`,
          );
        }
      }
    } catch (err: any) {
      console.warn(`[schema] ${schema.tab} validation échouée :`, err?.message ?? err);
    }
  }
}
