/**
 * CRUD pour les dépenses business — onglet `_DEPENSES_` du doc INVENTAIRE.
 *
 * Pattern Sheets : 1 dépense = 1 ligne avec colonnes A à M (cf types/depense.ts
 * pour la sémantique exacte). Append-only (les suppressions = soft-delete via
 * col M `dateOut`).
 *
 * Accès : admin only — toutes les routes /api/depenses appellent requireAdmin().
 *
 * Cache : pas de cache KV ici (volume faible, plus simple sans).
 */
import { getSheetsClient, SHEET_IDS, TAB, ROW } from './client';
import type { Depense, DepenseInput } from '@/types/depense';

// Index de colonnes _DEPENSES_ (1-based)
const DEP_COL = {
  ID                : 1,   // A — D0001
  DATE              : 2,   // B — YYYY-MM-DD
  FOURNISSEUR       : 3,   // C
  CATEGORIE         : 4,   // D
  DESCRIPTION       : 5,   // E
  SOUS_TOTAL_HT     : 6,   // F
  TPS               : 7,   // G
  TVQ               : 8,   // H
  TOTAL_TTC         : 9,   // I
  MODE_PAIEMENT     : 10,  // J
  RECU_URL          : 11,  // K
  NOTES             : 12,  // L
  DATE_OUT          : 13,  // M
  // v1.0.30+ : champs fiscaux supplémentaires (anciennes lignes restent
  // valides, les nouvelles cellules N/O sont juste vides → defaults appliqués
  // par le parser : numeroEntreprise undefined, usagePct undefined ≈ 100 %).
  NUMERO_ENTREPRISE : 14,  // N — NE / GST / TPS fournisseur (texte libre)
  USAGE_PCT         : 15,  // O — pourcentage usage business (1-100)
  NB_COLS           : 15,
};

const DEP_INS_ROW = 2; // Insertion à la ligne 2 (après header). Pattern newest-first.

/**
 * Lit toutes les dépenses du sheet `_DEPENSES_`. Retourne les actives par
 * défaut (dateOut null/vide). Pour inclure les archivées (rare — surtout
 * pour rapports), passer `includeArchived: true`.
 */
export async function getDepenses(opts: { includeArchived?: boolean } = {}): Promise<Depense[]> {
  const sheets = getSheetsClient();
  try {
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.DEPENSES}!A2:M`,
      valueRenderOption: 'UNFORMATTED_VALUE',
    });
    const rows = res.data.values ?? [];
    const all = rows.map((r, idx) => _parseRow(r, idx + 2)).filter((d): d is Depense => d !== null);
    return opts.includeArchived ? all : all.filter(d => !d.dateOut);
  } catch (err: any) {
    // Onglet absent → retour liste vide (l'utilisateur n'a peut-être pas
    // encore créé l'onglet — le first POST le créera via _ensureTab).
    if (err?.code === 400 || /Unable to parse range/.test(err?.message ?? '')) return [];
    throw err;
  }
}

/** Crée une nouvelle dépense. L'ID est généré par `prochainDepenseId()`. */
export async function createDepense(input: DepenseInput, id: string): Promise<Depense> {
  const sheets = getSheetsClient();
  await _ensureTab();

  const totalTTC = round2(input.sousTotalHT + input.tps + input.tvq);

  const row = Array(DEP_COL.NB_COLS).fill('');
  row[DEP_COL.ID                - 1] = id;
  row[DEP_COL.DATE              - 1] = input.date;
  row[DEP_COL.FOURNISSEUR       - 1] = input.fournisseur;
  row[DEP_COL.CATEGORIE         - 1] = input.categorie;
  row[DEP_COL.DESCRIPTION       - 1] = input.description;
  row[DEP_COL.SOUS_TOTAL_HT     - 1] = input.sousTotalHT;
  row[DEP_COL.TPS               - 1] = input.tps;
  row[DEP_COL.TVQ               - 1] = input.tvq;
  row[DEP_COL.TOTAL_TTC         - 1] = totalTTC;
  row[DEP_COL.MODE_PAIEMENT     - 1] = input.modePaiement;
  row[DEP_COL.RECU_URL          - 1] = input.recuUrl ?? '';
  row[DEP_COL.NOTES             - 1] = input.notes ?? '';
  row[DEP_COL.DATE_OUT          - 1] = '';
  row[DEP_COL.NUMERO_ENTREPRISE - 1] = input.numeroEntreprise ?? '';
  row[DEP_COL.USAGE_PCT         - 1] = input.usagePct ?? '';

  // Insertion à la ligne 2 (newest-first). Pattern identique à factures.
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets(properties(sheetId,title))',
  });
  const sheetMeta = meta.data.sheets?.find(s => s.properties?.title === TAB.DEPENSES);
  if (!sheetMeta?.properties || (sheetMeta.properties.sheetId === undefined && sheetMeta.properties.sheetId !== 0)) {
    throw new Error(`Onglet '${TAB.DEPENSES}' introuvable`);
  }
  const sheetId = sheetMeta.properties.sheetId!;

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [
        {
          insertDimension: {
            range: {
              sheetId,
              dimension : 'ROWS',
              startIndex: DEP_INS_ROW - 1,
              endIndex  : DEP_INS_ROW,
            },
            inheritFromBefore: false,
          },
        },
      ],
    },
  });

  // v1.1.1+ : range dynamique sur NB_COLS (était hardcodé :M = 13 cols).
  // Quand on a étendu le schéma v1.0.30 (NB_COLS 13 → 15), ce range
  // n'avait pas été mis à jour → erreur 'tried writing to column N'.
  const lastCol = _colLetter(DEP_COL.NB_COLS);
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.DEPENSES}!A${DEP_INS_ROW}:${lastCol}${DEP_INS_ROW}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [row] },
  });

  return {
    _row: DEP_INS_ROW,
    id,
    date             : input.date,
    fournisseur      : input.fournisseur,
    categorie        : input.categorie,
    description      : input.description,
    sousTotalHT      : input.sousTotalHT,
    tps              : input.tps,
    tvq              : input.tvq,
    totalTTC,
    modePaiement     : input.modePaiement,
    recuUrl          : input.recuUrl,
    notes            : input.notes,
    dateOut          : null,
    numeroEntreprise : input.numeroEntreprise,
    usagePct         : input.usagePct,
  };
}

/** Patch ciblé d'une dépense par ID. Recalcule totalTTC. */
export async function updateDepense(id: string, patch: Partial<DepenseInput>): Promise<void> {
  // v1.1.1+ : appel _ensureTab pour garantir grille NB_COLS (migration auto
  // d'un onglet créé pré-v1.0.30 avec 13 cols). Sinon B:O échoue avec
  // 'tried writing to column N'.
  await _ensureTab();
  const all = await getDepenses({ includeArchived: true });
  const cur = all.find(d => d.id === id);
  if (!cur) throw new Error(`Dépense ${id} introuvable`);

  const merged = {
    date             : patch.date             ?? cur.date,
    fournisseur      : patch.fournisseur      ?? cur.fournisseur,
    categorie        : patch.categorie        ?? cur.categorie,
    description      : patch.description      ?? cur.description,
    sousTotalHT      : patch.sousTotalHT      ?? cur.sousTotalHT,
    tps              : patch.tps              ?? cur.tps,
    tvq              : patch.tvq              ?? cur.tvq,
    modePaiement     : patch.modePaiement     ?? cur.modePaiement,
    recuUrl          : patch.recuUrl          ?? cur.recuUrl ?? '',
    notes            : patch.notes            ?? cur.notes ?? '',
    numeroEntreprise : patch.numeroEntreprise ?? cur.numeroEntreprise ?? '',
    usagePct         : patch.usagePct         ?? cur.usagePct ?? '',
  };
  const totalTTC = round2(merged.sousTotalHT + merged.tps + merged.tvq);

  const sheets = getSheetsClient();
  // v1.1.1+ : range B:O dynamique sur NB_COLS pour rester en phase avec
  // une éventuelle future extension de schéma.
  const lastCol = _colLetter(DEP_COL.NB_COLS);
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.DEPENSES}!B${cur._row}:${lastCol}${cur._row}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [[
      merged.date,
      merged.fournisseur,
      merged.categorie,
      merged.description,
      merged.sousTotalHT,
      merged.tps,
      merged.tvq,
      totalTTC,
      merged.modePaiement,
      merged.recuUrl,
      merged.notes,
      cur.dateOut ?? '',
      merged.numeroEntreprise,
      merged.usagePct,
    ]] },
  });
}

/** Soft-delete une dépense en posant `dateOut` à aujourd'hui. */
export async function deleteDepense(id: string): Promise<void> {
  const all = await getDepenses({ includeArchived: true });
  const cur = all.find(d => d.id === id);
  if (!cur) throw new Error(`Dépense ${id} introuvable`);

  const today = new Date().toISOString().slice(0, 10);
  const sheets = getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.DEPENSES}!M${cur._row}`,
    valueInputOption : 'RAW',
    requestBody      : { values: [[today]] },
  });
}

// ── Helpers ──────────────────────────────────────────────────────

function _parseRow(r: unknown[], rowNum: number): Depense | null {
  const id  = String(r[DEP_COL.ID - 1] ?? '').trim();
  if (!id) return null;
  const num = (i: number) => parseFloat(String(r[i - 1] ?? '0')) || 0;
  const str = (i: number) => String(r[i - 1] ?? '').trim();

  const modePaiementRaw = str(DEP_COL.MODE_PAIEMENT).toLowerCase();
  const modePaiement = (['comptant', 'interac', 'cartes', 'virement'].includes(modePaiementRaw)
    ? modePaiementRaw
    : 'comptant') as Depense['modePaiement'];

  // v1.0.30+ : champs fiscaux additionnels
  const numeroEntreprise = str(DEP_COL.NUMERO_ENTREPRISE) || undefined;
  const rawUsage         = parseFloat(String(r[DEP_COL.USAGE_PCT - 1] ?? ''));
  const usagePct         = Number.isFinite(rawUsage) && rawUsage > 0 && rawUsage <= 100
    ? rawUsage
    : undefined;

  return {
    _row             : rowNum,
    id,
    date             : str(DEP_COL.DATE),
    fournisseur      : str(DEP_COL.FOURNISSEUR),
    categorie        : str(DEP_COL.CATEGORIE),
    description      : str(DEP_COL.DESCRIPTION),
    sousTotalHT      : num(DEP_COL.SOUS_TOTAL_HT),
    tps              : num(DEP_COL.TPS),
    tvq              : num(DEP_COL.TVQ),
    totalTTC         : num(DEP_COL.TOTAL_TTC),
    modePaiement,
    recuUrl          : str(DEP_COL.RECU_URL) || undefined,
    notes            : str(DEP_COL.NOTES)    || undefined,
    dateOut          : str(DEP_COL.DATE_OUT) || null,
    numeroEntreprise,
    usagePct,
  };
}

let _tabEnsured = false;

// v1.1.1+ : header canonique — utilisé pour création initiale ET migration
// de grille (cas onglet créé pré-v1.0.30 avec 13 cols → étendre à 15).
const DEP_HEADER = [
  'ID', 'Date', 'Fournisseur', 'Catégorie', 'Description',
  'Sous-total HT', 'TPS', 'TVQ', 'Total TTC',
  'Mode paiement', 'Reçu URL', 'Notes', 'Date archivage',
  'NE fournisseur', 'Usage %',
];

async function _ensureTab(): Promise<void> {
  if (_tabEnsured) return;
  const sheets = getSheetsClient();
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets(properties(sheetId,title,gridProperties))',
  });
  const sheetMeta = (meta.data.sheets ?? []).find(s => s.properties?.title === TAB.DEPENSES);

  if (!sheetMeta) {
    // Cas 1 : onglet absent → création complète
    await sheets.spreadsheets.batchUpdate({
      spreadsheetId: SHEET_IDS.INVENTAIRE,
      requestBody  : {
        requests: [{
          addSheet: {
            properties: {
              title: TAB.DEPENSES,
              gridProperties: { rowCount: 1000, columnCount: DEP_COL.NB_COLS },
            },
          },
        }],
      },
    });
    await sheets.spreadsheets.values.update({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.DEPENSES}!A1:${_colLetter(DEP_COL.NB_COLS)}1`,
      valueInputOption : 'RAW',
      requestBody      : { values: [DEP_HEADER] },
    });
  } else {
    // Cas 2 : onglet existe — migration si grille trop étroite
    // (ex. créé pré-v1.0.30 avec 13 cols, schéma actuel attend 15).
    const currentCols = sheetMeta.properties?.gridProperties?.columnCount ?? 0;
    if (currentCols < DEP_COL.NB_COLS) {
      const sheetId = sheetMeta.properties!.sheetId!;
      await sheets.spreadsheets.batchUpdate({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        requestBody  : {
          requests: [{
            appendDimension: {
              sheetId,
              dimension: 'COLUMNS',
              length   : DEP_COL.NB_COLS - currentCols,
            },
          }],
        },
      });
      // Re-écrit le header complet pour aligner sur le schéma courant
      await sheets.spreadsheets.values.update({
        spreadsheetId    : SHEET_IDS.INVENTAIRE,
        range            : `${TAB.DEPENSES}!A1:${_colLetter(DEP_COL.NB_COLS)}1`,
        valueInputOption : 'RAW',
        requestBody      : { values: [DEP_HEADER] },
      });
    }
  }

  _tabEnsured = true;
}

/** Compteur séquentiel D0001, D0002, … stocké en _PARAMÈTRES_!B4. */
export async function prochainDepenseId(): Promise<string> {
  const sheets = getSheetsClient();
  const range  = `${TAB.PARAMS}!B${ROW.DEPENSE_COUNTER_ROW}`;
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const current = parseInt(String(res.data.values?.[0]?.[0] ?? '0'), 10) || 0;
  const next    = current + 1;
  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range,
    valueInputOption : 'RAW',
    requestBody      : { values: [[next]] },
  });
  return `D${String(next).padStart(4, '0')}`;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/** Convertit index 1-based en lettre Sheets : 1→A, 13→M, 15→O, 27→AA, etc. */
function _colLetter(n: number): string {
  let letter = '';
  while (n > 0) {
    const rem = (n - 1) % 26;
    letter = String.fromCharCode(65 + rem) + letter;
    n = Math.floor((n - 1) / 26);
  }
  return letter;
}

// ── PO compilés en dépenses (v1.0.27+) ──────────────────────────

import { getPOs } from './po';

const TAUX_TPS_QC = 0.05;
const TAUX_TVQ_QC = 0.09975;

/**
 * v1.0.27+ : compile les PO finalisés/partiels en `Depense`-like virtuel
 * pour les inclure dans les totaux comptables (CTI/CTP). Convention :
 *
 *   - On considère les PO statut RECU ou PARTIEL avec dateReception non null
 *   - sousTotalHT = Σ(qteRecue × prixAchat)  → on assume prixAchat = HT
 *   - tps = sousTotalHT × 5%, tvq × 9,975%   → taux QC standard
 *
 * Limites volontaires :
 *   - Pas modifiable depuis /depenses (lecture seule, ID préfixé "PO-")
 *   - Pour modifier le HT d'un PO, passer par /catalogue/reception
 *   - Si TVH ou autre province : créer une dépense manuelle séparée pour
 *     l'écart, et ignorer le PO compilé via filtre (à venir si besoin)
 *
 * Performance : 1 read getPOs(). Pas de cache spécifique (volume PO < 1000
 * en pratique). Si volume gros, ajouter cache 5min.
 */
export async function getPOsAsDepenses(): Promise<Depense[]> {
  const pos = await getPOs();
  const compiled: Depense[] = [];
  for (const po of pos) {
    if (po.status !== 'RECU' && po.status !== 'PARTIEL') continue;
    if (!po.dateReception) continue;

    // HT = somme des qte RÉELLEMENT reçues × prix (les PARTIELS comptent
    // seulement ce qui est arrivé, pas le commandé)
    const sousTotalHT = round2(
      po.items.reduce((s, it) => s + (it.qteRecue || 0) * (it.prixAchat || 0), 0)
    );
    if (sousTotalHT <= 0) continue;

    const tps      = round2(sousTotalHT * TAUX_TPS_QC);
    const tvq      = round2(sousTotalHT * TAUX_TVQ_QC);
    const totalTTC = round2(sousTotalHT + tps + tvq);

    // Description courte = liste des noms d'items (tronquée 100 chars)
    const noms = po.items
      .filter(it => (it.qteRecue || 0) > 0)
      .map(it => it.nom)
      .filter(Boolean);
    const descFull = noms.join(' + ');
    const description = descFull.length > 100 ? descFull.slice(0, 97) + '…' : descFull;

    compiled.push({
      _row         : 0, // virtuel — ID préfixé "PO-" empêche tentative d'édition
      id           : `PO-${po.poNumber}`,
      date         : po.dateReception,
      fournisseur  : po.fournisseur,
      categorie    : 'Achats marchandises pour revente',
      description,
      sousTotalHT,
      tps,
      tvq,
      totalTTC,
      modePaiement : 'cartes',   // hypothèse — V1 PO ne stocke pas le mode
      recuUrl      : undefined,
      notes        : `PO #${po.poNumber} · ${po.status} · ${po.items.length} ligne${po.items.length > 1 ? 's' : ''} · réceptionné ${po.dateReception}`,
      dateOut      : null,
    });
  }
  return compiled;
}
