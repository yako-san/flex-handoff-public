/**
 * lib/sheets/factures.ts
 *
 * Génération d'une évaluation ou facture PDF via les templates du document FACTURES-FLEX-REV.
 *
 * Flux :
 *   1. Lire les onglets du document FACTURES pour trouver BASE-YC ou BASE-CF
 *   2. Copier l'onglet template dans un onglet temporaire
 *   3. Remplir les cellules dynamiques (client, BDC, items, totaux, note)
 *   4. Exporter l'onglet en PDF via l'URL d'export Google Sheets
 *   5. Supprimer l'onglet temporaire
 *   6. Créer un brouillon Gmail avec le PDF en pièce jointe
 *
 * ── Cellules du template (v1.1.17+ — fix layout col C/D) ───────────
 * Bloc client (col E) :
 *   E3 : DATE         → date d'émission
 *   E4 : ID           → numéro du BDC
 *   E5 : CLIENT       → nom complet du client
 *   E6 : CLIENT_EMAIL → courriel du client
 *   E7 : VÉLO         → description du vélo
 * Bloc employeur (col D, vis-à-vis du bloc client) :
 *   D5     : label « À l'attention de » (vide si pas d'employeur)
 *   D6:D7  : nom + adresse compagnie, align right (vide si pas d'employeur)
 * Items (rows 11+) :
 *   col C : description (inchangé par l'insertion de col D)
 *   col D : vide (spacer — col employeur au-dessus)
 *   col E : prix unitaire (anciennement col D)
 *   col F : quantité (anciennement col E)
 *   col G : total (anciennement col F)
 * Totaux :
 *   G38 : sous-total | G39 : remises | G43 : grand total (formule template)
 *   C38 : note pour le client (col C inchangée)
 * ────────────────────────────────────────────────────────────────────
 */
import { google }        from 'googleapis';
import { Readable }      from 'stream';
import { readFileSync }  from 'fs';
import { resolve }       from 'path';
import { getSheetsClient, getAuth, SHEET_IDS, DRIVE_FOLDER_IDS, TAB } from './client';
import { todayStr, nowDateHeure } from '@/lib/utils/format';
import { computeTaxes } from '@/lib/finances/taxes';
import { getServices }   from './catalogue';
import { translate }     from '@/lib/translate';
import type { BDC }      from '@/types/bdc';
import type { Client, Lang } from '@/types/client';
import type { Vente }    from '@/types/vente';

/**
 * Libellés d'en-tête du template PDF, par langue. Quand client.lang === 'EN',
 * on remplace la première ligne ("reçu de vente" / "bon de commande" / etc.)
 * lue depuis le template par la version anglaise correspondante.
 */
const HEADER_LABELS_EN: Record<string, string> = {
  'reçu de vente'    : 'sales receipt',
  'bon de commande'  : 'work order',
  'facture'          : 'invoice',
  'client'           : 'client',
  'contact'          : 'contact',
  'vélo'             : 'bike',
  'à l\'attention de': 'attention to',
};

function _translateHeaderLabel(frLabel: string, lang: Lang): string {
  if (lang !== 'EN') return frLabel;
  const key = frLabel.toLowerCase().trim();
  return HEADER_LABELS_EN[key] ?? frLabel;
}

/** Normalise un libellé de service pour matching tolérant aux préfixes
 *  emoji/ponctuation, espaces multiples et casse. */
function _normSvcKey(nom: string): string {
  return nom
    .replace(/^[^\p{L}\p{N}]+/u, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * v1.1.18+ : Plages Unicode NON couvertes par Roboto Regular (police
 * par défaut du template FACTURES-FLEX-REV). Pour les caractères dans
 * ces plages, on applique un `textFormatRun` avec une police fallback
 * (Noto Color Emoji) pour qu'ils rendent dans le PDF. Le reste du
 * texte garde Roboto — pas de changement de police global, le design
 * yako-cyclo reste intact.
 *
 * Note : ▸ (U+25B8, Geometric Shapes) EST couvert par Roboto → reste en
 * Roboto. Seuls ⚙ (U+2699), 🧰 (U+1F9F0), 🔧 (U+1F527), etc. basculent.
 */
function _needsEmojiFallback(cp: number): boolean {
  return (cp >= 0x2300 && cp <= 0x23FF)    // Misc Technical (⌚, ⌛, ⏱)
      || (cp >= 0x2600 && cp <= 0x26FF)    // Misc Symbols (⚙, ☀, ☑)
      || (cp >= 0x2700 && cp <= 0x27BF)    // Dingbats (✂, ✈, ✉)
      || (cp >= 0x1F300 && cp <= 0x1F9FF)  // Symbols, Pictographs, Emoji
      || (cp >= 0x1FA00 && cp <= 0x1FAFF); // Extended-A (objets, outils récents)
}

// v1.1.19+ : Noto Sans Symbols 2 (monochrome, design-friendly) au lieu de
// Noto Color Emoji (couleur). Couvre ⚙, ☀, ✂, ⌚, etc. dans les blocs
// Misc Symbols / Dingbats / Misc Technical. Pour rendre dans le PDF, cette
// police DOIT être activée dans le document FACTURES-FLEX-REV (Format →
// Police → Plus de polices → rechercher "Noto Sans Symbols 2" → OK).
const _EMOJI_FALLBACK_FONT = 'Noto Sans Symbols 2';

/**
 * v1.1.18+ : construit la liste des `textFormatRuns` à appliquer à une
 * cellule pour que les caractères hors Roboto soient rendus avec la
 * police fallback. Retourne `null` si le texte est intégralement
 * couvert par Roboto (pas de format runs à appliquer — économie d'API).
 *
 * `startIndex` est en unités UTF-16 (mêmes indices que `string.length` JS
 * et que l'API Sheets — code points hors BMP comptent comme 2). */
function _buildEmojiTextFormatRuns(text: string): Array<{
  startIndex: number;
  format: { fontFamily: string };
}> | null {
  if (!text) return null;
  const runs: Array<{ startIndex: number; format: { fontFamily: string } }> = [];
  let currentNeedsFallback: boolean | null = null;
  let i = 0;
  while (i < text.length) {
    const cp = text.codePointAt(i)!;
    const charLen = cp > 0xFFFF ? 2 : 1;
    const needs = _needsEmojiFallback(cp);
    if (needs !== currentNeedsFallback) {
      runs.push({
        startIndex: i,
        format: { fontFamily: needs ? _EMOJI_FALLBACK_FONT : 'Roboto' },
      });
      currentNeedsFallback = needs;
    }
    i += charLen;
  }
  // Si tout est en Roboto, pas de runs nécessaires
  if (runs.every(r => r.format.fontFamily === 'Roboto')) return null;
  return runs;
}

/** Dernier segment significatif d'un libellé, après ':', ' - ' ou ' — '.
 *  Permet de matcher deux libellés qui ne diffèrent que par leur préfixe. */
function _svcTailKey(nom: string): string {
  const parts = nom.split(/\s*[:–—-]\s*/).map(p => p.trim()).filter(Boolean);
  if (parts.length < 2) return '';
  const tail = parts[parts.length - 1];
  const k = tail.toLowerCase().replace(/\s+/g, ' ').trim();
  return k.length >= 5 ? k : '';
}

// ── Références cellules en-tête du template ──────────────────────────
// v1.1.17+ : correction du layout — l'insertion d'une nouvelle col D
// pour le bloc employeur a fait glisser SEULEMENT les colonnes à droite
// de l'insertion (anciennement D/E/F → maintenant E/F/G). L'ancien col C
// (description items) est resté à C, inchangé. La nouvelle col D sert
// uniquement au bloc employeur (rows 5-7) — pour les rows items, col D
// est un « spacer » vide.
//
// Bloc employeur (col D nouvelle) :
//   - D5 : label « À l'attention de » (vide si pas d'employeur)
//   - D6:D7 fusionné, align right : nom + adresse compagnie (multi-ligne),
//     placés en vis-à-vis du bloc client (rows 5-7)
//
// Bloc client (col E — anciennement col D) :
//   - E3 : date émission | E4 : n° | E5 : client | E6 : contact | E7 : vélo
//
// Items (rows 11+) :
//   - C : description (inchangé)
//   - D : (vide, spacer employeur au-dessus)
//   - E : prix unitaire (anciennement D)
//   - F : qté (anciennement E)
//   - G : total (anciennement F)
//
// Totaux : G38 (sous-total) | G39 (remises) | G43 (grand total — formule)
// Note client : C38 (inchangé)
const CELLS = {
  DATE_EVAL       : 'E3',   // Date d'émission       (label "reçu de vente")
  EVAL_NO         : 'E4',   // Numéro BDC            (label "bon de commande" / "facture")
  CLIENT_NOM      : 'E5',   // Nom complet du client  (label "client")
  CLIENT_EMAIL    : 'E6',   // Courriel du client     (label "contact")
  VELO_DESC       : 'E7',   // Description vélo       (label "vélo")
  EMPLOYER_LABEL  : 'D5',   // « À l'attention de » (label, ligne du CLIENT_NOM)
  EMPLOYER_VALEUR : 'D6',   // Ancre du merge D6:D7 — nom\nadresse align right
  ITEMS_START     : 11,     // Première ligne d'items → C11
  NOTE_CLIENT     : 'C38',  // Note pour le client (col C inchangé — pas de shift)
  SOUS_TOTAL      : 'G38',  // Sous-total (col shift F → G)
  REMISES         : 'G39',  // Remises (valeur POSITIVE — formule template = G38-G39)
  // TOTAL_GRAND G43 : calculé par formule template — ne pas écraser
} as const;

// ── Colonnes des lignes d'items (v1.1.17+) ───────────────────────────
// C = description (inchangé) | D = vide (spacer employeur) |
// E = prix unitaire | F = qté | G = total
const COL = { C: 'C', D: 'D', E: 'E', F: 'F', G: 'G' };

// ─────────────────────────────────────────────────────────────────────

export interface Remise { type: 'pct' | 'fixed'; value: number }

export interface EvaluationResult {
  draftId  : string;
  draftUrl : string;
  message  : string;
  /** webViewLink Drive du PDF sauvegardé (si upload Drive réussi) */
  pdfUrl?  : string;
  /** Numéro de facture séquentiel attribué (seulement pour docType='vente' si fourni) */
  factureNumero?: string;
}

function computeMontantRemise(total: number, remise: Remise): number {
  if (!remise || remise.value <= 0) return 0;
  if (remise.type === 'pct') return Math.round(total * remise.value) / 100;
  return Math.min(remise.value, total);
}

// ── Génère l'évaluation PDF + brouillon Gmail ─────────────────────────

export async function genererEvaluationEtDraft(
  bdc          : BDC,
  client       : Client,
  noteClient   : string,
  accessToken  : string,
  remiseSvc    : Remise = { type: 'pct', value: 0 },
  remisePce    : Remise = { type: 'pct', value: 0 },
  refreshToken?: string,
  docType      : 'evaluation' | 'facture' | 'vente' = 'evaluation',
  opts         : {
    hideVelo?: boolean;
    factureNumero?: string;
    modePaiement?: 'comptant' | 'interac' | 'cartes';
    // v1.0.25+ : statut initial du journal (default 'ÉMIS')
    statut?: 'ÉMIS' | 'PAYÉ' | 'ANNULÉ';
    /** v1.1.13+ : si true, n'écrit PAS de ligne dans le journal ENCAISSE BDT/
     *  VENTES. Utilisé par la route `regenerer-facture` qui re-produit le PDF
     *  + draft Gmail sans dupliquer la trace comptable. */
    skipJournalLog?: boolean;
  } = {},
): Promise<EvaluationResult> {
  const sheets = getSheetsClient();

  // 1. Template selon lead du client — BASE-YC/BASE-CF pour évaluation, facture et vente
  //    (pas d'onglets dédiés ; docType gère les différences dans le courriel)
  const isFacture   = docType === 'facture' || docType === 'vente';
  const isVente     = docType === 'vente';
  const templateTab = client.lead === 'yako.cyclo' ? TAB.FACTURES_BASE_YC : TAB.FACTURES_BASE_CF;

  // 2. Trouver le sheetId du template
  const spreadsheet = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.FACTURES,
    fields       : 'sheets.properties',
  });

  const templateSheet = spreadsheet.data.sheets?.find(
    s => s.properties?.title === templateTab
  );
  if (!templateSheet?.properties?.sheetId) {
    throw new Error(`Onglet template "${templateTab}" introuvable dans FACTURES.`);
  }
  const templateGid = templateSheet.properties.sheetId;

  // 3. Copier le template → onglet temporaire
  const copyRes = await sheets.spreadsheets.sheets.copyTo({
    spreadsheetId: SHEET_IDS.FACTURES,
    sheetId      : templateGid,
    requestBody  : { destinationSpreadsheetId: SHEET_IDS.FACTURES },
  });
  const tempGid   = copyRes.data.sheetId!;
  const tempTitle = copyRes.data.title!;  // ex. "Copie de BASE-YC"

  try {
    const today     = todayStr();
    // Évaluation : date + heure (utile pour traquer plusieurs éval sur un
    // même vélo dans une même journée). Facture/vente : date seule (document
    // officiel, l'heure alourdit inutilement).
    const dateHeure = isFacture ? today : nowDateHeure();

    // 4a. Lire les libellés existants des cellules d'en-tête (E3..E7) pour
    //     préserver la première ligne ("reçu de vente", "bon de commande",
    //     "client", "contact", "vélo") et ne remplacer que la 2e ligne.
    //     Le label employeur (D5) est en cellule séparée — pas besoin de
    //     parser une 1ʳᵉ ligne, le contenu de D5 EST le label.
    const headerCells = [
      CELLS.DATE_EVAL, CELLS.EVAL_NO, CELLS.CLIENT_NOM, CELLS.CLIENT_EMAIL,
      CELLS.VELO_DESC, CELLS.EMPLOYER_LABEL,
    ];
    const headerRead = await sheets.spreadsheets.values.batchGet({
      spreadsheetId: SHEET_IDS.FACTURES,
      ranges       : headerCells.map(c => `'${tempTitle}'!${c}`),
    });
    const labelFor = (idx: number, fallback: string): string => {
      const raw = String(headerRead.data.valueRanges?.[idx]?.values?.[0]?.[0] ?? '');
      const firstLine = raw.split('\n')[0].trim();
      return firstLine || fallback;
    };
    const lang: Lang = (client.lang as Lang) || 'FR';
    const labelDate     = _translateHeaderLabel(labelFor(0, 'reçu de vente'), lang);
    const labelBDC      = _translateHeaderLabel(labelFor(1, isFacture ? 'facture' : 'bon de commande'), lang);
    const labelClient   = _translateHeaderLabel(labelFor(2, 'client'), lang);
    const labelContact  = _translateHeaderLabel(labelFor(3, 'contact'), lang);
    const labelVelo     = _translateHeaderLabel(labelFor(4, 'vélo'), lang);
    const labelEmployer = _translateHeaderLabel(labelFor(5, "À l'attention de"), lang);

    // 4b. Cellules d'en-tête — on écrit "label\nvaleur" dans la cellule ancre.
    //     NOTE_CLIENT est écrite plus bas après traduction éventuelle.
    const batchData: { range: string; values: unknown[][] }[] = [
      { range: `'${tempTitle}'!${CELLS.DATE_EVAL}`,    values: [[`${labelDate}\n${dateHeure}`]] },
      { range: `'${tempTitle}'!${CELLS.EVAL_NO}`,      values: [[`${labelBDC}\n${bdc.id}`]] },
      { range: `'${tempTitle}'!${CELLS.CLIENT_NOM}`,   values: [[`${labelClient}\n${client.nomComplet}`]] },
      { range: `'${tempTitle}'!${CELLS.CLIENT_EMAIL}`, values: [[`${labelContact}\n${client.courriel}`]] },
      // Vente directe sans vélo : on vide la cellule plutôt que d'écrire "vélo\n"
      { range: `'${tempTitle}'!${CELLS.VELO_DESC}`,
        values: [[opts.hideVelo ? '' : `${labelVelo}\n${bdc.veloDesc}`]] },
    ];

    // v1.1.12+ : bloc employeur — refonte template. Le label « À l'attention de »
    // est en cellule séparée (D5, vis-à-vis du CLIENT_NOM en E5), et la valeur
    // dans D6:D7 fusionné (align right). Si pas d'employeur → vider les 2.
    const empName    = (client.entrepriseName    ?? '').trim();
    const empAdresse = (client.entrepriseAdresse ?? '').trim();
    if (empName) {
      const empValeur = empAdresse ? `${empName}\n${empAdresse}` : empName;
      batchData.push(
        { range: `'${tempTitle}'!${CELLS.EMPLOYER_LABEL}`,  values: [[labelEmployer]] },
        { range: `'${tempTitle}'!${CELLS.EMPLOYER_VALEUR}`, values: [[empValeur]] },
      );
    } else {
      batchData.push(
        { range: `'${tempTitle}'!${CELLS.EMPLOYER_LABEL}`,  values: [['']] },
        { range: `'${tempTitle}'!${CELLS.EMPLOYER_VALEUR}`, values: [['']] },
      );
    }

    // Remises + sous-total
    const montantSvc  = computeMontantRemise(bdc.totalServices, remiseSvc);
    const montantPce  = computeMontantRemise(bdc.totalPieces,   remisePce);
    const totalRemise = montantSvc + montantPce;
    const sousTotal   = bdc.totalServices + bdc.totalPieces;
    batchData.push(
      { range: `'${tempTitle}'!${CELLS.SOUS_TOTAL}`, values: [[sousTotal]]      },
      { range: `'${tempTitle}'!${CELLS.REMISES}`,    values: [[totalRemise]]    },
    );

    // 5. Lignes d'items
    // Structure : C=description | D=prix unitaire | E=quantité | F=total
    // v7.0.16 : forfait TOUJOURS en haut de la liste services (cohérent UI).
    const svcSortKey = (n: string) => {
      const s = (n ?? '').toLowerCase();
      if (s.includes('forfait'))   return 0;
      if (s.includes('rencontre')) return 1;
      return 2;
    };
    const services = bdc.items
      .filter(it => it.service)
      .slice()
      .sort((a, b) => svcSortKey(a.service!.nom) - svcSortKey(b.service!.nom));
    const pieces   = bdc.items.filter(it => it.piece);
    let   currentRow = CELLS.ITEMS_START;

    // 5a. Préparer une map prix depuis le catalogue services pour compléter
    //     les lignes dont le prix stocké dans le BDC est 0 (ex. services ajoutés
    //     avant que la durée par défaut ne soit renseignée).
    const svcPrixMap = new Map<string, number>();
    try {
      const catSvc = await getServices();
      for (const s of catSvc) {
        if (!s.prix) continue;
        svcPrixMap.set(s.label, s.prix);
        const nk = _normSvcKey(s.label);
        if (nk && !svcPrixMap.has(nk)) svcPrixMap.set(nk, s.prix);
        const tk = _svcTailKey(s.label);
        if (tk && !svcPrixMap.has(tk)) svcPrixMap.set(tk, s.prix);
      }
    } catch (err: any) {
      console.warn('[evaluation] getServices fallback failed:', err.message);
    }

    // 5b. Traduire en batch les noms d'items + note client si lang === 'EN'.
    //     DeepL préserve les préfixes emoji et la casse (preserve_formatting).
    const svcNames = services.map(it => it.service!.nom);
    const pceNames = pieces.map(it => it.piece!.nom);
    let   svcNamesT = svcNames;
    let   pceNamesT = pceNames;
    let   noteClientT = noteClient;
    if (lang === 'EN') {
      const allIn = [...svcNames, ...pceNames, noteClient];
      const allOut = await translate(allIn, 'EN', 'FR');
      svcNamesT  = allOut.slice(0, svcNames.length);
      pceNamesT  = allOut.slice(svcNames.length, svcNames.length + pceNames.length);
      noteClientT = allOut[allOut.length - 1] ?? noteClient;
    }

    // C38 (NOTE_CLIENT) : on ne touche plus à cette cellule. La valeur
    // par défaut du template (BASE-YC / BASE-CF) est conservée. La note
    // client éventuelle continue à être incluse dans le draft Gmail via
    // le placeholder {{noteClient}} du template courriel.

    // v1.1.18+ : on collecte les textes des descriptions au fil de l'écriture
    // pour appliquer ensuite les `textFormatRuns` (fallback police emoji)
    // sur les cellules contenant des caractères hors Roboto.
    const itemDescTexts: { row: number; text: string }[] = [];

    // ── Services ──
    for (let i = 0; i < services.length; i++) {
      const it  = services[i];
      const svc = it.service!;
      let prix = svc.prix;
      if (!prix || prix <= 0) {
        prix = svcPrixMap.get(svc.nom)
          ?? svcPrixMap.get(_normSvcKey(svc.nom))
          ?? svcPrixMap.get(_svcTailKey(svc.nom))
          ?? 0;
      }
      // v1.1.17+ : description en C, spacer vide en D, prix/qty/total en E/F/G
      const descText = `▸ ${svcNamesT[i] ?? svc.nom}`;
      batchData.push({
        range : `'${tempTitle}'!${COL.C}${currentRow}:${COL.G}${currentRow}`,
        values: [[descText, '', prix, 1, prix]],
      });
      itemDescTexts.push({ row: currentRow, text: descText });
      currentRow++;
    }

    // ── Séparateur + en-tête PIÈCES (si applicable) ──
    let piecesHeaderRow: number | null = null;
    if (pieces.length > 0) {
      currentRow++;                   // ligne vide de séparation
      piecesHeaderRow = currentRow;
      // v1.1.17+ : header section PIÈCES dans la col description (C)
      batchData.push({
        range : `'${tempTitle}'!${COL.C}${currentRow}`,
        values: [[lang === 'EN' ? 'PARTS' : 'PIÈCES']],
      });
      currentRow++;

      // ── Pièces ──
      for (let i = 0; i < pieces.length; i++) {
        const it  = pieces[i];
        const pce = it.piece!;
        // v1.1.17+ : pièce en C, spacer D, prix/qty/total en E/F/G
        const descText = `◆ ${pceNamesT[i] ?? pce.nom}`;
        batchData.push({
          range : `'${tempTitle}'!${COL.C}${currentRow}:${COL.G}${currentRow}`,
          values: [[descText, '', pce.prix, pce.qte, pce.sousTotal]],
        });
        itemDescTexts.push({ row: currentRow, text: descText });
        currentRow++;
      }
    }

    // Écriture des valeurs
    await sheets.spreadsheets.values.batchUpdate({
      spreadsheetId: SHEET_IDS.FACTURES,
      requestBody  : {
        valueInputOption: 'USER_ENTERED',
        data: batchData,
      },
    });

    // 5b. Mettre "PIÈCES" en gras + appliquer textFormatRuns aux descriptions
    //     pour rendre les emoji (⚙, 🧰, etc.) que Roboto ne couvre pas.
    const postWriteRequests: any[] = [];
    if (piecesHeaderRow !== null) {
      postWriteRequests.push({
        repeatCell: {
          range: {
            sheetId         : tempGid,
            startRowIndex   : piecesHeaderRow - 1,   // 0-based
            endRowIndex     : piecesHeaderRow,
            startColumnIndex: 2,                      // col C (0-based) — v1.1.17+
            endColumnIndex  : 7,                      // jusqu'à col G inclus
          },
          cell  : { userEnteredFormat: { textFormat: { bold: true } } },
          fields: 'userEnteredFormat.textFormat.bold',
        },
      });
    }
    // v1.1.18+ : textFormatRuns par description si elle contient des emoji.
    // L'API Sheets accepte des updateCells qui mélangent value + format mais
    // ici on ne touche QUE les runs (la valeur est déjà écrite via values.batchUpdate).
    for (const { row, text } of itemDescTexts) {
      const runs = _buildEmojiTextFormatRuns(text);
      if (!runs) continue;
      postWriteRequests.push({
        updateCells: {
          rows  : [{ values: [{ textFormatRuns: runs }] }],
          fields: 'textFormatRuns',
          range : {
            sheetId         : tempGid,
            startRowIndex   : row - 1,
            endRowIndex     : row,
            startColumnIndex: 2,   // col C
            endColumnIndex  : 3,
          },
        },
      });
    }
    if (postWriteRequests.length > 0) {
      await sheets.spreadsheets.batchUpdate({
        spreadsheetId: SHEET_IDS.FACTURES,
        requestBody  : { requests: postWriteRequests },
      });
    }

    // 6. Export PDF via Service Account
    const authClient = await getAuth().getClient() as any;
    const tokenRes   = await authClient.getAccessToken();
    const saToken    = tokenRes.token as string;

    const exportUrl = [
      `https://docs.google.com/spreadsheets/d/${SHEET_IDS.FACTURES}/export`,
      `?format=pdf`,
      `&gid=${tempGid}`,
      `&portrait=true`,
      `&fitw=true`,
      `&sheetnames=false`,
      `&pagenumbers=false`,
      `&gridlines=false`,
      `&printtitle=false`,
    ].join('');

    const pdfResponse = await fetch(exportUrl, {
      headers: { Authorization: `Bearer ${saToken}` },
    });

    if (!pdfResponse.ok) {
      throw new Error(`Export PDF échoué : ${pdfResponse.status} ${pdfResponse.statusText}`);
    }

    const pdfBuffer  = Buffer.from(await pdfResponse.arrayBuffer());
    const pdfBase64  = pdfBuffer.toString('base64');
    const typeLabel  = isFacture ? 'facture' : 'evaluation';
    // Sanitiser le nom du client : espaces → _, garder lettres/chiffres/tirets/accents
    const clientSlug = client.nomComplet
      .replace(/\s+/g, '_')
      .replace(/[^a-zA-ZÀ-ÿ0-9_\-]/g, '');
    // Pour les ventes : factureNumero = `V0007` (nouveau format, sans date).
    // Anciens formats avec date intégrée (`V0007-2026-04-23`,
    // `F2026-04-23-0007`) parsés via parseFactureNumero pour rétrocompat.
    // Le filename PDF assemble explicitement <numero>-<date>.
    let pdfId: string = bdc.id;
    if (isVente && (opts as any).factureNumero) {
      const raw = String((opts as any).factureNumero);
      if (/^V\d{4,}$/.test(raw)) {
        pdfId = raw;  // Nouveau format direct
      } else {
        const { parseFactureNumero } = await import('./counter');
        const parsed = parseFactureNumero(raw);
        pdfId = parsed ? `V${parsed.numero}` : raw;
      }
    }
    const pdfFilename = `${typeLabel}-${pdfId}-${today}—${clientSlug}.pdf`;

    // 7. Sauvegarde dans Google Drive (best-effort — ne bloque pas si échec).
    //    On capture le webViewLink pour l'exposer dans le résultat / la UI.
    const pdfUrl: string | null = await _sauvegarderPDFDrive(
      pdfBuffer, pdfFilename, accessToken, refreshToken,
    ).catch(err => {
      console.warn('[drive] sauvegarde échouée :', err.message);
      return null;
    });

    // 8. Brouillon Gmail — skipped si :
    //    - pas de courriel
    //    - courriel placeholder Walk-in (.local) : pas envoyer vers fausse adresse
    let draftResult: EvaluationResult;
    const isWalkin = client.courriel?.toLowerCase().endsWith('.local') === true;
    if (client.courriel && !isWalkin) {
      draftResult = await _creerBrouillonGmail({
        accessToken,
        refreshToken,
        docType,
        to          : client.courriel,
        clientPrenom: client.prenom,
        bdcId       : bdc.id,
        veloDesc    : bdc.veloDesc,
        dateStr     : today,
        noteClient  : noteClientT,
        pdfBase64,
        pdfFilename,
        templateLead: client.lead,
        lang,
        services    : services.map((it, i) => ({ nom: svcNamesT[i] ?? it.service!.nom, prix: it.service!.prix })),
        pieces      : pieces.map((it, i)   => ({ nom: pceNamesT[i] ?? it.piece!.nom,   prix: it.piece!.prix, qte: it.piece!.qte, sousTotal: it.piece!.sousTotal })),
      });
    } else {
      // Pas de courriel OU client Walk-in : PDF généré + sauvé Drive, mais
      // pas de brouillon Gmail (PDF s'ouvre dans nouvel onglet pour
      // impression au comptoir).
      draftResult = {
        draftId : '',
        draftUrl: '',
        message : isWalkin
          ? `PDF généré (Walk-in — pas de brouillon Gmail).`
          : `PDF généré et sauvegardé. Aucun courriel client — brouillon non créé.`,
      };
    }

    // Enrichit le résultat avec le lien Drive + numéro facture (pour les ventes)
    if (pdfUrl) draftResult.pdfUrl = pdfUrl;
    if (isVente && (opts as any).factureNumero) {
      draftResult.factureNumero = String((opts as any).factureNumero);
    }

    // Log dans l'onglet ENCAISSE BDT ou VENTES selon docType
    // (pas de log pour les évaluations).
    // v1.1.13+ : `skipJournalLog` permet de re-générer un PDF sans
    // dupliquer la ligne dans le journal (cas /regenerer-facture).
    if (isFacture && !opts.skipJournalLog) {
      const logType: 'facture' | 'vente' = isVente ? 'vente' : 'facture';
      const modePaiement = (opts.modePaiement ?? 'comptant') as 'comptant' | 'interac' | 'cartes';
      const statut       = (opts.statut ?? 'ÉMIS') as 'ÉMIS' | 'PAYÉ' | 'ANNULÉ';
      await _ecrireLogFacture(bdc, client, totalRemise, today, pdfUrl ?? '', draftResult.factureNumero ?? '', logType, modePaiement, statut).catch(err =>
        console.warn('[factures] log write failed:', err.message)
      );
    }

    return draftResult;

  } finally {
    // 8. Supprimer l'onglet temporaire (best-effort)
    try {
      await sheets.spreadsheets.batchUpdate({
        spreadsheetId: SHEET_IDS.FACTURES,
        requestBody  : { requests: [{ deleteSheet: { sheetId: tempGid } }] },
      });
    } catch { /* ne pas masquer l'erreur principale */ }
  }
}

// ── Update statut + mode paiement post-facturation (v1.0.15+) ────────

/**
 * v1.0.15+ — Met à jour le statut (ÉMIS/PAYÉ/ANNULÉ) et/ou le mode de
 * paiement d'une facture déjà émise dans le journal ENCAISSE BDT (BDT)
 * ou VENTES (vente directe).
 *
 * Cas d'usage : la facture a été générée avant que le paiement soit
 * reçu. Quand le client paye plus tard, l'utilisateur veut le marquer
 * directement depuis la fiche BDT (sans aller dans le sheet).
 *
 * Layout journal ENCAISSE BDT (A:P, 16 cols) :
 *   B Statut · C Facture # · D Vélo · E Client · F date · J HT ·
 *   K Taxes · L TTC · M Mode · N valid. · O TPS · P TVQ
 *
 * Layout journal VENTES (A:M, 13 cols) :
 *   B Statut · C Facture # · D Items · E Client · F date · G HT ·
 *   H Taxes · I TTC · J Mode · K valid. · L TPS · M TVQ
 *
 * Le match se fait sur col C (Facture #). Pour les BDT, c'est `bdc.id`
 * (ex. "0042"). Pour les ventes, c'est le `factureNumero` (ex. "V0012").
 */
export async function updateFactureLogStatus(
  factureRef  : string,
  docType     : 'facture' | 'vente',
  fields      : { statut?: 'ÉMIS' | 'PAYÉ' | 'ANNULÉ'; modePaiement?: 'comptant' | 'interac' | 'cartes' },
): Promise<{ updated: boolean; row?: number }> {
  if (!factureRef) throw new Error('factureRef requis');
  if (fields.statut === undefined && fields.modePaiement === undefined) {
    return { updated: false };
  }

  const sheets = getSheetsClient();
  const tabName = docType === 'vente' ? TAB.FACTURES_LOG_VENTES : TAB.FACTURES_LOG_BDT;

  // Lit le journal pour trouver la ligne par col C (Facture #)
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.FACTURES,
    range            : `${tabName}!A2:Z`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const rows = res.data.values ?? [];
  let matchedRow = 0;
  for (let i = 0; i < rows.length; i++) {
    const ref = String(rows[i]?.[2] ?? '').trim();  // col C = index 2
    if (ref === factureRef) { matchedRow = i + 2; break; }
  }
  if (!matchedRow) {
    throw new Error(`Facture ${factureRef} introuvable dans le journal ${tabName}`);
  }

  // Layout différent BDT vs VENTES pour col Mode
  //   BDT :    Mode = col M (13e)
  //   VENTES : Mode = col J (10e)
  const modeCol = docType === 'vente' ? 'J' : 'M';

  const data: { range: string; values: unknown[][] }[] = [];
  if (fields.statut !== undefined) {
    data.push({ range: `${tabName}!B${matchedRow}`, values: [[fields.statut]] });
  }
  if (fields.modePaiement !== undefined) {
    data.push({ range: `${tabName}!${modeCol}${matchedRow}`, values: [[fields.modePaiement]] });
  }
  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SHEET_IDS.FACTURES,
    requestBody  : { valueInputOption: 'RAW', data },
  });
  return { updated: true, row: matchedRow };
}

/**
 * v1.0.15+ — Lit le statut + mode de paiement d'une facture du journal.
 * Retourne null si introuvable.
 */
export async function getFactureLogStatus(
  factureRef: string,
  docType   : 'facture' | 'vente',
): Promise<{ statut: string; modePaiement: string; date: string } | null> {
  if (!factureRef) return null;
  const sheets = getSheetsClient();
  const tabName = docType === 'vente' ? TAB.FACTURES_LOG_VENTES : TAB.FACTURES_LOG_BDT;
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.FACTURES,
    range            : `${tabName}!A2:Z`,
    valueRenderOption: 'FORMATTED_VALUE',
  });
  const rows = res.data.values ?? [];
  for (const r of rows) {
    const ref = String(r?.[2] ?? '').trim();
    if (ref !== factureRef) continue;
    // BDT col M = index 12 ; vente col J = index 9
    const modeIdx = docType === 'vente' ? 9 : 12;
    return {
      statut       : String(r?.[1] ?? '').trim(),
      modePaiement : String(r?.[modeIdx] ?? '').trim(),
      date         : String(r?.[5] ?? '').trim(),
    };
  }
  return null;
}

/**
 * v1.0.32+ : compile les TPS et TVQ PERÇUES sur la période donnée (depuis
 * les onglets `ENCAISSE BDT` et `VENTES` du doc FACTURES-FLEX-REV).
 *
 * Sert au calcul du solde TPS/TVQ trimestriel pour le FPZ-500 :
 *
 *   solde TPS  = TPS perçue (ligne 105) − CTI (ligne 108) = ligne 109
 *   solde TVQ  = TVQ perçue              − CTP             = à remettre
 *
 * Filtre :
 *   - statut ≠ 'ANNULÉ' (les factures annulées ne sont pas comptabilisées)
 *   - date dans [startDate, endDate] inclus (YYYY-MM-DD)
 *
 * Layout des sheets :
 *   - BDT (ENCAISSE BDT) 16 cols A-P : statut=B(idx1), date=F(idx5), TPS=O(14), TVQ=P(15)
 *   - VENTES 13 cols A-M : statut=B(idx1), date=F(idx5), TPS=L(11), TVQ=M(12)
 *
 * Retour : `{ tpsPercue, tvqPercue, count, parSource: { bdt, vente } }`.
 */
export async function getTaxesPercuesByPeriode(
  startDate: string,  // YYYY-MM-DD inclusif
  endDate  : string,  // YYYY-MM-DD inclusif
): Promise<{
  tpsPercue : number;
  tvqPercue : number;
  count     : number;
  parSource : {
    bdt   : { tpsPercue: number; tvqPercue: number; count: number };
    vente : { tpsPercue: number; tvqPercue: number; count: number };
  };
}> {
  const sheets = getSheetsClient();

  // Lecture parallèle des 2 onglets
  const [bdtRes, venteRes] = await Promise.all([
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.FACTURES,
      range            : `${TAB.FACTURES_LOG_BDT}!A2:Z`,
      valueRenderOption: 'UNFORMATTED_VALUE',
    }).catch(() => ({ data: { values: [] } } as any)),
    sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.FACTURES,
      range            : `${TAB.FACTURES_LOG_VENTES}!A2:Z`,
      valueRenderOption: 'UNFORMATTED_VALUE',
    }).catch(() => ({ data: { values: [] } } as any)),
  ]);

  const round2 = (n: number) => Math.round(n * 100) / 100;

  function _inPeriode(rawDate: any): boolean {
    const s = String(rawDate ?? '').trim();
    if (!s) return false;
    // Format attendu YYYY-MM-DD (string ISO) ou serial Excel (number ou string num)
    let iso = s;
    if (/^\d{4,5}$/.test(s)) {
      // serial Excel
      const days = parseInt(s, 10);
      if (Number.isFinite(days)) {
        // Excel epoch = 1899-12-30
        const ms = (days - 25569) * 86400 * 1000;
        const d  = new Date(ms);
        if (!isNaN(d.getTime())) iso = d.toISOString().slice(0, 10);
      }
    }
    if (!/^\d{4}-\d{2}-\d{2}/.test(iso)) return false;
    return iso >= startDate && iso <= endDate;
  }

  function _parseNum(v: any): number {
    const n = parseFloat(String(v ?? '0').replace(',', '.'));
    return Number.isFinite(n) ? n : 0;
  }

  // BDT — TPS col O (idx 14), TVQ col P (idx 15)
  let bdtTps = 0, bdtTvq = 0, bdtCount = 0;
  for (const r of (bdtRes.data?.values ?? [])) {
    const statut = String(r?.[1] ?? '').trim().toUpperCase();
    if (statut === 'ANNULÉ' || statut === 'ANNULE') continue;
    if (!_inPeriode(r?.[5])) continue;
    bdtTps   += _parseNum(r?.[14]);
    bdtTvq   += _parseNum(r?.[15]);
    bdtCount += 1;
  }

  // VENTES — TPS col L (idx 11), TVQ col M (idx 12)
  let venteTps = 0, venteTvq = 0, venteCount = 0;
  for (const r of (venteRes.data?.values ?? [])) {
    const statut = String(r?.[1] ?? '').trim().toUpperCase();
    if (statut === 'ANNULÉ' || statut === 'ANNULE') continue;
    if (!_inPeriode(r?.[5])) continue;
    venteTps   += _parseNum(r?.[11]);
    venteTvq   += _parseNum(r?.[12]);
    venteCount += 1;
  }

  return {
    tpsPercue : round2(bdtTps + venteTps),
    tvqPercue : round2(bdtTvq + venteTvq),
    count     : bdtCount + venteCount,
    parSource : {
      bdt   : { tpsPercue: round2(bdtTps),   tvqPercue: round2(bdtTvq),   count: bdtCount },
      vente : { tpsPercue: round2(venteTps), tvqPercue: round2(venteTvq), count: venteCount },
    },
  };
}

// ── Génère la facture PDF + brouillon Gmail ───────────────────────────

export async function genererFactureEtDraft(
  bdc          : BDC,
  client       : Client,
  noteClient   : string,
  accessToken  : string,
  remiseSvc    : Remise = { type: 'pct', value: 0 },
  remisePce    : Remise = { type: 'pct', value: 0 },
  refreshToken?: string,
  opts         : { skipJournalLog?: boolean } = {},
): Promise<EvaluationResult> {
  return genererEvaluationEtDraft(
    bdc, client, noteClient, accessToken, remiseSvc, remisePce, refreshToken, 'facture',
    { skipJournalLog: opts.skipJournalLog },
  );
}

// ── Facture pour vente directe (sans BDC/vélo) ────────────────────

/**
 * Génère une facture PDF pour une vente directe (pièces vendues hors BDC).
 * Construit un BDC-shaped depuis la Vente et réutilise le pipeline standard
 * avec hideVelo=true (la cellule D7 reste vide, pas de ligne "vélo").
 */
export async function genererFactureVente(
  vente         : Vente,
  client        : Client,
  noteClient    : string,
  accessToken   : string,
  remisePce     : Remise = { type: 'pct', value: 0 },
  refreshToken? : string,
  factureNumero?: string,
  modePaiement  : 'comptant' | 'interac' | 'cartes' = 'comptant',
  // v1.0.25+ : statut initial — 'PAYÉ' direct si payeMaintenant=true côté UI
  statut        : 'ÉMIS' | 'PAYÉ' | 'ANNULÉ' = 'ÉMIS',
  // v1.1.16+ : si true, skip _ecrireLogFacture (re-génération sans dupliquer
  // la ligne dans le journal VENTES).
  skipJournalLog: boolean = false,
): Promise<EvaluationResult> {
  const bdcLike = _bdcLikeFromVente(vente, client);
  return genererEvaluationEtDraft(
    bdcLike,
    client,
    noteClient,
    accessToken,
    { type: 'pct', value: 0 },   // pas de remise services (UI vente n'en propose pas)
    remisePce,
    refreshToken,
    'vente',
    { hideVelo: true, factureNumero, modePaiement, statut, skipJournalLog },
  );
}

/**
 * v1.0.24+ : Construit un BDC synthétique depuis une Vente, en séparant
 * les services et les pièces. Les `VenteItem.pieceId` commençant par 'S'
 * sont des services du catalogue À LA CARTE (S00088 = Flat, etc.) et
 * doivent apparaître dans la section Services de la facture. Les autres
 * (préfixe 'P' ou pas de préfixe stable) vont en pièces.
 *
 * Pour qté décimale (cf v1.0.23, ex. 1,5h mécanicien volant) : on injecte
 * `(×1,5)` dans le nom du service et on met `prix = sousTotal` (déjà
 * multiplié) puisque BDCServiceItem n'a pas de champ `qte` (un service
 * en BDC = quantité 1 implicite).
 */
function _bdcLikeFromVente(vente: Vente, client: Client): BDC {
  const isService = (it: { pieceId: string }) => (it.pieceId || '').startsWith('S');
  const servicesArr = vente.items.filter(isService);
  const piecesArr   = vente.items.filter(it => !isService(it));
  const totalServices = servicesArr.reduce((s, it) => s + it.sousTotal, 0);
  const totalPieces   = piecesArr.reduce((s, it) => s + it.sousTotal, 0);

  let row = 0;
  const items = [
    ...servicesArr.map(it => ({
      _row: row++,
      service: {
        serviceId: it.pieceId,
        // Si qté ≠ 1, l'inclure dans le nom (format fr-CA : virgule décimale).
        nom: it.qte !== 1
          ? `${it.nom} (×${String(it.qte).replace('.', ',')})`
          : it.nom,
        fait : false,
        status: '',
        prix : it.sousTotal,   // pré-multiplié (BDCServiceItem.prix = total ligne)
      },
    })),
    ...piecesArr.map(it => ({
      _row: row++,
      piece: {
        nom      : it.nom,
        prix     : it.prixUnit,
        cmd      : '',
        qte      : it.qte,
        sousTotal: it.sousTotal,
        flag     : '',
        cmdNote  : '',
      },
    })),
  ];

  return {
    id            : vente.venteId,
    dateIn        : vente.date,
    veloDesc      : '',
    clientNom     : client.nomComplet,
    noteClient    : '',
    checkEval     : false,
    checkOk       : false,
    checkBds      : false,
    checkOut      : false,
    totalServices,
    totalPieces,
    _bonRow       : 0,
    items,
  };
}

/**
 * Comptabilise une vente SANS générer de PDF ni de draft Gmail.
 * Cas walk-in où l'utilisateur a décoché « Générer un reçu PDF ».
 * La transaction est juste loggée dans le journal VENTES (pour TPS/TVQ).
 */
export async function comptabiliserVenteSansPdf(
  vente         : Vente,
  client        : Client,
  remisePce     : Remise = { type: 'pct', value: 0 },
  factureNumero : string,
  modePaiement  : 'comptant' | 'interac' | 'cartes' = 'comptant',
  // v1.0.25+ : statut initial (default ÉMIS, peut être PAYÉ si walk-in cash)
  statut        : 'ÉMIS' | 'PAYÉ' | 'ANNULÉ' = 'ÉMIS',
): Promise<{ factureNumero: string; message: string }> {
  // v1.0.24+ : utilise le helper qui sépare services/pièces pour que le
  // journal _ecrireLogFacture distingue correctement les totaux H (services)
  // et I (pièces) dans la colonne du sheet.
  const bdcLike = _bdcLikeFromVente(vente, client);
  const today = todayStr();
  // Calcul de la remise comme dans genererEvaluationEtDraft
  const montantPce  = computeMontantRemise(bdcLike.totalPieces, remisePce);
  const totalRemise = montantPce;
  await _ecrireLogFacture(bdcLike, client, totalRemise, today, '', factureNumero, 'vente', modePaiement, statut);
  return {
    factureNumero,
    message: 'Vente comptabilisée — pas de PDF (walk-in opt-out).',
  };
}

// ── Journal des factures ──────────────────────────────────────────

/**
 * Ajoute une ligne dans le journal des factures (sheet FACTURES-FLEX-REV).
 *
 * v7.0.13 — Routage selon docType :
 *  - 'facture' (BDT facturé)  → onglet 'ENCAISSE BDT'
 *  - 'vente'   (vente directe) → onglet 'VENTES'
 *
 * Colonnes (mappées sur la structure user existante) :
 *   A (vide) | B Statut | C Facture # | D Vélo | E Clients | F date
 *   G (vide) | H Services | I Pièces | J Total HT | K taxes | L total TTC
 *   M (vide) | N valid.
 *
 * Notes :
 * - Statut (B) : 'ÉMIS' par défaut. À updater manuellement en 'PAYÉ' /
 *   'ANNULÉ' / etc. (ou via futur endpoint).
 * - Facture # (C) : factureNumero pour ventes (V0042-…) ou bdc.id pour
 *   BDT facturés (ex. 0042).
 * - taxes (K) : total TPS + TVQ (déjà arrondi par taxe). Toujours calculé,
 *   indépendamment du mode de paiement (LTA art. 165 + LTVQ art. 16).
 * - total TTC (L) : J + K.
 * - valid. (N) : checkbox/statut de validation comptable manuelle.
 * - TPS (O) : 5 % du HT, arrondi cent.
 * - TVQ (P) : 9,975 % du HT, arrondi cent.
 *
 * Suggestions formules en haut du sheet :
 *   Total mois (HT)  : =SUMIFS(J:J, F:F, ">="&DATE(YEAR(TODAY()),MONTH(TODAY()),1))
 *   Total mois (TTC) : =SUMIFS(L:L, F:F, ">="&DATE(YEAR(TODAY()),MONTH(TODAY()),1))
 *   Total taxes mois : =SUMIFS(K:K, F:F, ">="&DATE(YEAR(TODAY()),MONTH(TODAY()),1))
 */
async function _ecrireLogFacture(
  bdc           : BDC,
  client        : Client,
  remise        : number,
  dateStr       : string,
  pdfUrl        : string = '',
  factureNumero : string = '',
  docType       : 'facture' | 'vente' = 'facture',
  modePaiement  : 'comptant' | 'interac' | 'cartes' = 'comptant',
  // v1.0.25+ : statut initial. Avant : toujours 'ÉMIS'. Maintenant
  // 'PAYÉ' possible si le client paie immédiatement (walk-in, etc.).
  statut        : 'ÉMIS' | 'PAYÉ' | 'ANNULÉ' = 'ÉMIS',
): Promise<void> {
  const sheets     = getSheetsClient();
  const sousTotal  = bdc.totalServices + bdc.totalPieces - remise;
  const { tps, tvq, taxes, grandTotal } = computeTaxes(sousTotal);

  const tabName = docType === 'vente'
    ? TAB.FACTURES_LOG_VENTES
    : TAB.FACTURES_LOG_BDT;

  // Ventes : factureNumero (V0042-…). BDT : bdc.id (ex. '0042') car pas
  // de compteur séparé pour les BDT (cf Q1 audit facturation).
  const factRef = factureNumero || bdc.id;

  // Layout différencié BDT vs vente directe :
  //  - BDT (A:P, 16 cols) : Statut, Facture#, Vélo, Client, date, Services,
  //    Pièces, HT, Taxes, TTC, Mode, valid., TPS, TVQ
  //  - VENTES (A:M, 13 cols) : Statut, Facture#, Items, Client, date, HT,
  //    Taxes, TTC, Mode, valid., TPS, TVQ (pas de Vélo, Services, Pièces —
  //    sans objet pour ventes directes)
  const isVente = docType === 'vente';

  // Pour VENTES : construire un résumé Items (col D) à partir des items
  // du bdc synthétique. Concat des noms, tronqué à ~100 chars.
  let itemsResume = '';
  if (isVente && bdc.items?.length) {
    const noms = bdc.items
      .map(it => it.service?.nom ?? it.piece?.nom ?? '')
      .filter(Boolean);
    const full = noms.join(' + ');
    itemsResume = full.length > 100 ? full.slice(0, 97) + '…' : full;
  }

  const values = isVente
    ? [
        '',                            // A (vide)
        statut,                        // B Statut (v1.0.25+ : peut être PAYÉ direct)
        factRef,                       // C Facture #
        itemsResume,                   // D Items (résumé)
        client.nomComplet,             // E Clients
        dateStr,                       // F date
        sousTotal,                     // G Total HT
        taxes,                         // H Taxes (TPS+TVQ)
        grandTotal,                    // I Total TTC
        modePaiement,                  // J Mode paiement
        '',                            // K valid.
        tps,                           // L TPS (5 %)
        tvq,                           // M TVQ (9,975 %)
      ]
    : [
        '',                            // A (vide)
        statut,                        // B Statut (v1.0.25+ : peut être PAYÉ direct)
        factRef,                       // C Facture #
        bdc.veloDesc,                  // D Vélo
        client.nomComplet,             // E Clients
        dateStr,                       // F date
        '',                            // G (vide)
        bdc.totalServices || '',       // H Services
        bdc.totalPieces,               // I Pièces
        sousTotal,                     // J Total HT
        taxes,                         // K Taxes (TPS+TVQ)
        grandTotal,                    // L Total TTC
        modePaiement,                  // M Mode paiement
        '',                            // N valid.
        tps,                           // O TPS (5 %)
        tvq,                           // P TVQ (9,975 %)
      ];

  // Insertion à la ligne 4 (en haut de la zone data) avec décalage des
  // anciennes lignes vers le bas — pattern « newest first ».
  // 2 API calls : insertDimension (crée la ligne vide) + update (écrit les
  // valeurs). Si insertDimension échoue, on fallback vers values.append.
  const meta = await sheets.spreadsheets.get({
    spreadsheetId : SHEET_IDS.FACTURES,
    fields        : 'sheets(properties(sheetId,title))',
  });
  const sheetMeta = meta.data.sheets?.find(s => s.properties?.title === tabName);
  if (!sheetMeta?.properties?.sheetId && sheetMeta?.properties?.sheetId !== 0) {
    throw new Error(`Onglet '${tabName}' introuvable dans FACTURES`);
  }
  const sheetId = sheetMeta.properties.sheetId!;

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId : SHEET_IDS.FACTURES,
    requestBody   : {
      requests: [{
        insertDimension: {
          range: { sheetId, dimension: 'ROWS', startIndex: 3, endIndex: 4 },
          inheritFromBefore: false,
        },
      }],
    },
  });

  await sheets.spreadsheets.values.update({
    spreadsheetId    : SHEET_IDS.FACTURES,
    range            : `'${tabName}'!A4`,
    valueInputOption : 'USER_ENTERED',
    requestBody      : { values: [values] },
  });
}

// ── Google Drive — sauvegarde PDF ─────────────────────────────────────

/**
 * Sauvegarde le PDF dans le dossier FACTURES de Google Drive.
 * Utilise le service account (auth serveur).
 * Si DRIVE_FACTURES_FOLDER_ID est vide, skip silencieusement.
 */
async function _sauvegarderPDFDrive(
  pdfBuffer   : Buffer,
  filename    : string,
  accessToken : string,
  refreshToken?: string,
): Promise<string | null> {
  const folderId = DRIVE_FOLDER_IDS.FACTURES;
  if (!folderId) {
    console.warn('[drive] DRIVE_FACTURES_FOLDER_ID non configuré — sauvegarde Drive ignorée');
    return null;
  }

  // Utiliser le OAuth de l'utilisateur (pas le service account qui n'a pas de quota storage)
  const oauth2Client = new google.auth.OAuth2(
    process.env.AUTH_GOOGLE_ID,
    process.env.AUTH_GOOGLE_SECRET,
  );
  oauth2Client.setCredentials({
    access_token  : accessToken,
    refresh_token : refreshToken ?? null,
  });
  const drive = google.drive({ version: 'v3', auth: oauth2Client });

  // Supprimer l'ancien fichier avec le même nom dans le dossier (pour remplacement)
  const searchRes = await drive.files.list({
    q     : `name='${filename.replace(/'/g, "\\'")}' and '${folderId}' in parents and trashed=false`,
    fields: 'files(id,name)',
    spaces: 'drive',
  }).catch(() => ({ data: { files: [] } }));

  for (const f of (searchRes.data.files ?? [])) {
    await drive.files.delete({ fileId: f.id! }).catch((err: Error) =>
      console.warn(`[drive] impossible de supprimer ${f.id} :`, err.message)
    );
  }

  const stream = Readable.from(pdfBuffer);

  const res = await drive.files.create({
    requestBody: {
      name    : filename,
      mimeType: 'application/pdf',
      parents : [folderId],
    },
    media: {
      mimeType: 'application/pdf',
      body    : stream,
    },
    fields: 'id,webViewLink',
  });

  const fileId  = res.data.id   ?? null;
  const fileUrl = res.data.webViewLink ?? null;
  console.log(`[drive] PDF sauvegardé : ${filename} (id=${fileId})`);
  return fileUrl;
}

// ── Gmail ─────────────────────────────────────────────────────────────

interface DraftParams {
  accessToken  : string;
  refreshToken?: string;
  docType      : 'evaluation' | 'facture' | 'vente';
  to           : string;
  clientPrenom : string;
  bdcId        : string;
  veloDesc     : string;
  dateStr      : string;
  noteClient   : string;
  pdfBase64    : string;
  pdfFilename  : string;
  templateLead : string;
  lang         : Lang;
  /** Liste des services pour le placeholder {{services}} */
  services    ?: { nom: string; prix: number }[];
  /** Liste des pièces pour le placeholder {{pieces}} */
  pieces      ?: { nom: string; prix: number; qte: number; sousTotal: number }[];
}

// Signature HTML yako.cyclo
const SIGNATURE_YAKO = `
<div style="margin-top:16px;font-family:Helvetica Neue,Helvetica,Arial,sans-serif;font-size:14px;color:#222;line-height:1.6;">
  <p style="margin:0 0 8px 0;color:#999;">—</p>
  <p style="margin:0;"><a href="https://www.instagram.com/yako.foto/" style="color:#1a0dab;font-weight:bold;">yako.cyclo</a> <strong>@ Cyclo Flex</strong></p>
  <p style="margin:0;">Ostéo d'vélo et réhabilitation de vélos urbains</p>
  <p style="margin:0;">4109, St-Denis, Montréal</p>
  <p style="margin:0 0 12px 0;"><a href="mailto:yako.cyclo@gmail.com" style="color:#1a0dab;">yako.cyclo@gmail.com</a>, 514 995-3445</p>
  <p style="margin:0;">Jean-Christophe Yacono (yako)</p>
  <p style="margin:0;">Mécaniciens certifiés AEP</p>
  <p style="margin:0 0 12px 0;"><a href="https://www.instagram.com/yako.foto/" style="color:#1a0dab;">yako.cyclo</a> et <a href="https://cycloflex.ca/" style="color:#1a0dab;">Cyclo Flex</a></p>
  <p style="margin:0;"><img src="cid:yako-logo" alt="YAKO.CYCLO — entretien et réhabilitation de vélos urbains" width="130" style="border:4px solid #FFD600;"></p>
</div>`;

// Signature HTML Cyclo Flex
const SIGNATURE_CF = `
<table style="margin-top:16px;border-top:1px solid #e0e0e0;padding-top:12px;font-family:Helvetica Neue,Helvetica,Arial,sans-serif;font-size:13px;color:#555;">
  <tr>
    <td>
      <strong style="color:#000;">Cyclo Flex Montréal</strong><br>
      Atelier de réparation vélo<br>
      <a href="mailto:cycloflex.mtl@gmail.com" style="color:#555;">cycloflex.mtl@gmail.com</a>
    </td>
  </tr>
</table>`;

async function _creerBrouillonGmail(p: DraftParams): Promise<EvaluationResult> {
  const oauth2Client = new google.auth.OAuth2(
    process.env.AUTH_GOOGLE_ID,
    process.env.AUTH_GOOGLE_SECRET,
  );
  oauth2Client.setCredentials({
    access_token  : p.accessToken,
    refresh_token : p.refreshToken ?? null,
  });

  const gmail       = google.gmail({ version: 'v1', auth: oauth2Client });
  const isYako      = p.templateLead === 'yako.cyclo';
  const isEval      = p.docType === 'evaluation';
  const isVente     = p.docType === 'vente';
  const isEN        = p.lang === 'EN';
  const fromEmail   = isYako ? 'yako.cyclo@gmail.com' : 'cycloflex.mtl@gmail.com';

  // ── Templates éditables ────────────────────────────────────────────
  const { getEmailTemplates, renderTemplate, DEFAULTS: TPL_DEFAULTS } = await import('./emailTemplates');
  const tpl   = await getEmailTemplates();
  const lang  = isEN ? 'en' : 'fr';
  const dtype = isEval ? 'eval' : isVente ? 'vente' : 'facture';
  const vars  = {
    prenom    : p.clientPrenom,
    clientNom : p.clientPrenom,
    veloDesc  : p.veloDesc,
    id        : p.bdcId,
    date      : p.dateStr,
    noteClient: p.noteClient || '',
  };
  const t = (key: string) => renderTemplate(tpl[key] || TPL_DEFAULTS[key] || '', vars);

  // ── Sujet ─────────────────────────────────────────────────────────
  const subject  = t(`${dtype}_subject_${lang}`);
  const filename = p.pdfFilename;

  // ── Supprimer brouillons existants avec le même BDC (remplacement) ──
  const existingDrafts = await gmail.users.drafts.list({
    userId: 'me',
    q     : `subject:"#${p.bdcId}"`,
  }).catch(() => ({ data: { drafts: [] } }));

  for (const d of (existingDrafts.data.drafts ?? [])) {
    await gmail.users.drafts.delete({ userId: 'me', id: d.id! }).catch((err: Error) =>
      console.warn('[gmail] suppression brouillon échouée :', err.message)
    );
  }

  // ── Corps du courriel ─────────────────────────────────────────────

  // Marqueurs pour {{services}} et {{pieces}} — remplacés AVANT renderTemplate
  // pour ne pas être vidés, puis substitués APRÈS wrap <p>…</p> pour éviter
  // un <p><ul>…</ul></p> invalide.
  const MK_SVC = '__FLEX_SVC_MARKER__';
  const MK_PCE = '__FLEX_PCE_MARKER__';
  const rawTemplate = (tpl[`${dtype}_message_${lang}`] || TPL_DEFAULTS[`${dtype}_message_${lang}`] || '')
    .replace(/\{\{services\}\}/g, MK_SVC)
    .replace(/\{\{pieces\}\}/g,   MK_PCE);
  let messageRaw = renderTemplate(rawTemplate, vars);

  // Si pas de note client, retirer la ligne "Note : " (et la ligne vide qui suit)
  if (!p.noteClient) {
    messageRaw = messageRaw.replace(/\n*Note\s*:\s*\{\{noteClient\}\}\n*/gi, '\n');
    messageRaw = messageRaw.replace(/\n*Note\s*:\s*\n*/gi, '\n');
  }

  // Listes HTML pour {{services}} et {{pieces}}
  const servicesHtml = p.services && p.services.length > 0
    ? `<ul style="margin:8px 0 0 0;padding-left:20px;">${
        p.services.map(s => `<li style="margin-bottom:4px;">${s.nom}</li>`).join('')
      }</ul>`
    : '';
  const piecesHtml = p.pieces && p.pieces.length > 0
    ? `<ul style="margin:8px 0 0 0;padding-left:20px;">${
        p.pieces.map(pc => `<li style="margin-bottom:4px;">${pc.nom}${pc.qte > 1 ? ` × ${pc.qte}` : ''}</li>`).join('')
      }</ul>`
    : '';

  let messageHtml = messageRaw
    .split('\n')
    .map((l: string) => l.trim() ? `<p>${l}</p>` : '')
    .join('\n');

  // Remplacer les paragraphes ne contenant QUE le marqueur par le HTML brut
  messageHtml = messageHtml
    .replace(new RegExp(`<p>\\s*${MK_SVC}\\s*</p>`, 'g'), servicesHtml)
    .replace(new RegExp(`<p>\\s*${MK_PCE}\\s*</p>`, 'g'), piecesHtml)
    // Marqueur inline dans un paragraphe
    .replace(new RegExp(MK_SVC, 'g'), servicesHtml)
    .replace(new RegExp(MK_PCE, 'g'), piecesHtml);

  // Signature : v7.0.30 — supprimée de TOUS les drafts Gmail (BDT, ventes,
  // évaluations). La signature Gmail native (configurée par l'utilisateur
  // dans Gmail → Settings → Signature) sera ajoutée automatiquement par
  // Gmail au moment de l'envoi du draft. Évite la double signature et
  // permet à chaque membre de l'équipe d'avoir SA signature.
  const signature = '';

  const htmlBody = `
<div style="font-family:Helvetica Neue,Helvetica,Arial,sans-serif;font-size:15px;color:#222;line-height:1.6;">
  ${messageHtml}
  ${signature}
</div>`.trim();

  // ── Construction du message MIME ───────────────────────────────────
  // v7.0.31 : logo Yako (`logo-yako-cyclo.png`) supprimé du draft. Il
  // n'était utile que pour la signature HTML (cid:yako-logo), elle-même
  // retirée en v7.0.30. La signature Gmail native sera ajoutée à l'envoi.
  // Structure :
  //   multipart/mixed
  //   ├── text/html                  ← message
  //   └── application/pdf            ← facture en pièce jointe
  const mixedB = `mixed_flex_rev_${Date.now()}`;

  const subjectEncoded = `=?UTF-8?B?${Buffer.from(subject).toString('base64')}?=`;

  // CC : aucun. yako-san a retiré info@cycloflex.ca (2026-05-16) — pas
  // de copie automatique à la compta CycloFlex sur les factures envoyées.
  const ccAddresses: string[] = [];

  const rawParts: string[] = [
    `From: ${fromEmail}`,
    `To: ${p.to}`,
    ...(ccAddresses.length > 0 ? [`Cc: ${ccAddresses.join(', ')}`] : []),
    `Subject: ${subjectEncoded}`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/mixed; boundary="${mixedB}"`,
    '',
    // ── Partie 1 : HTML ──
    `--${mixedB}`,
    'Content-Type: text/html; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    ...(Buffer.from(htmlBody, 'utf-8').toString('base64').match(/.{1,76}/g) ?? []),
    '',
    // ── Partie 2 : PDF attachment ──
    `--${mixedB}`,
    `Content-Type: application/pdf; name="${filename}"`,
    `Content-Disposition: attachment; filename="${filename}"`,
    'Content-Transfer-Encoding: base64',
    '',
    ...(p.pdfBase64.match(/.{1,76}/g) ?? [p.pdfBase64]),
    '',
    `--${mixedB}--`,
  ];

  const rawMessage = rawParts.join('\r\n');
  const encodedRaw = Buffer.from(rawMessage).toString('base64url');

  const draft = await gmail.users.drafts.create({
    userId     : 'me',
    requestBody: { message: { raw: encodedRaw } },
  });

  return {
    draftId : draft.data.id ?? '',
    draftUrl: 'https://mail.google.com/mail/u/0/#drafts',
    message : `Brouillon créé pour ${p.to}`,
  };
}
