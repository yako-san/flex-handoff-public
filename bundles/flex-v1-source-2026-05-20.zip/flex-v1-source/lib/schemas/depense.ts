/**
 * Schémas zod pour les routes /api/depenses — v1.1.7 / Item 4 audit.
 *
 * Couvre POST (création) et PATCH (mise à jour partielle).
 * Aligné sur `_validateInput` de l'ancienne route — comportement
 * strictement identique pour préserver le contrat UI.
 */
import { z } from 'zod';
import { DEPENSE_CATEGORIES } from '../depenses-categories';
import {
  zDateISO,
  zDecimal,
  zDecimalPositive,
  zModePaiement,
  zTrimOptional,
} from './common';

export const DepenseCategorieEnum = z.enum(
  DEPENSE_CATEGORIES as unknown as readonly [string, ...string[]],
);

/** Body POST /api/depenses — création. */
export const DepenseCreateSchema = z.object({
  date         : zDateISO,
  fournisseur  : z.string().trim().min(1, 'Fournisseur requis'),
  categorie    : DepenseCategorieEnum,
  description  : z.string().trim().default(''),
  sousTotalHT  : zDecimalPositive.default(0),
  tps          : zDecimalPositive.default(0),
  tvq          : zDecimalPositive.default(0),
  modePaiement : zModePaiement.default('comptant'),
  recuUrl      : zTrimOptional,
  notes        : zTrimOptional,
  numeroEntreprise: zTrimOptional,
  usagePct     : z
    .union([z.number(), z.string(), z.null()])
    .optional()
    .transform(v => {
      if (v === null || v === undefined || v === '') return undefined;
      const n = parseFloat(String(v).replace(',', '.'));
      return Number.isFinite(n) ? n : undefined;
    })
    .refine(n => n === undefined || (n > 0 && n <= 100), {
      message: 'Usage % doit être entre 1 et 100',
    }),
});

export type DepenseCreateInput = z.infer<typeof DepenseCreateSchema>;

/** Body PATCH /api/depenses/[id] — patch ciblé.
 *  Tous les champs sont optionnels mais doivent respecter leur contrainte
 *  si présents. */
export const DepenseUpdateSchema = z.object({
  date         : zDateISO.optional(),
  fournisseur  : z.string().trim().min(1).optional(),
  categorie    : DepenseCategorieEnum.optional(),
  description  : z.string().optional(),
  sousTotalHT  : zDecimal.optional(),
  tps          : zDecimal.optional(),
  tvq          : zDecimal.optional(),
  modePaiement : zModePaiement.optional(),
  recuUrl      : z.string().optional(),
  notes        : z.string().optional(),
  numeroEntreprise: z.string().optional(),
  usagePct     : z
    .union([z.number(), z.string(), z.null()])
    .optional()
    .transform(v => {
      if (v === null || v === undefined || v === '') return undefined;
      const n = parseFloat(String(v).replace(',', '.'));
      return Number.isFinite(n) ? n : undefined;
    })
    .refine(n => n === undefined || (n > 0 && n <= 100), {
      message: 'Usage % doit être entre 1 et 100',
    }),
});

export type DepenseUpdateInput = z.infer<typeof DepenseUpdateSchema>;
