/**
 * Schémas zod pour les routes /api/admin/* — v1.1.7 / Item 4.
 *
 * Endpoints maintenant gardés par `requireAdmin()` (v1.1.2), mais ça
 * n'empêche pas un admin de poster un body malformé. Le `safeParse`
 * retourne 400 INVALID_BODY plutôt que de planter à la première
 * propriété manquante.
 */
import { z } from 'zod';
import { zSheetRow } from './common';

export const CleanupVenteNumbersSchema = z.object({
  nextNumber: z.number().int().positive('nextNumber doit être un entier >= 1'),
  dryRun    : z.boolean().optional(),
});

export const RestoreBdcSchema = z.object({
  id            : z.string().trim().min(1, 'id requis'),
  backupRow     : zSheetRow,
  overrideClient: z.string().trim().optional(),
});

export const SnapshotSchema = z.object({
  id  : z.string().trim().min(1, 'id requis'),
  note: z.string().trim().optional(),
});

export const TestCycleSchema = z.object({
  id: z.string().trim().min(1).optional(),
});

export const CleanupTestVentesSchema = z.object({
  dryRun: z.boolean().optional(),
});
