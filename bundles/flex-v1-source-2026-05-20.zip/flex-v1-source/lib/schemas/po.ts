/**
 * Schémas zod pour les routes /api/po/* — v1.1.7 / Item 4.
 */
import { z } from 'zod';
import { zDateISO, zDecimal, zDecimalPositive, zSheetRow } from './common';

const POLineItemSchema = z.object({
  nom         : z.string().trim().min(1, 'Nom requis'),
  sku         : z.string().trim().default(''),
  qteCommandee: zDecimalPositive.default(0),
  prixAchat   : zDecimalPositive.default(0),
  pieceRow    : z.number().int().default(-1),
  pieceId     : z.string().trim().default(''),
  notes       : z.string().trim().default(''),
  categorie   : z.string().trim().optional(),
});

export const POCreateSchema = z.object({
  poNumber    : z.string().trim().min(1, 'poNumber requis'),
  fournisseur : z.string().trim().min(1, 'fournisseur requis'),
  dateCommande: zDateISO,
  items       : z.array(POLineItemSchema).min(1, 'Au moins 1 item requis'),
});

/** POST /api/po/[poNumber] : ajout de lignes à un PO existant. */
export const POAddLinesSchema = z.object({
  items: z.array(POLineItemSchema).min(1, 'Au moins 1 item requis'),
});

/** PATCH /api/po/[poNumber] : update ligne OU action reopen. */
export const POPatchSchema = z.union([
  z.object({
    action: z.literal('reopen'),
  }),
  z.object({
    sheetRow    : zSheetRow,
    qteCommandee: zDecimal.optional(),
    qteRecue    : zDecimal.optional(),
    recu        : z.boolean().optional(),
    notes       : z.string().optional(),
    categorie   : z.string().optional(),
  }),
]);

/** DELETE /api/po/[poNumber] : supprime une ligne par sheetRow. */
export const PODeleteLineSchema = z.object({
  sheetRow: zSheetRow,
});

/** POST /api/po/[poNumber]/sync-stock — Item 2 v1.1.3 idempotence. */
export const POSyncStockSchema = z.object({
  force: z.boolean().optional(),
});

export const POAdhocReceiveSchema = z.object({
  fournisseur: z.string().trim().min(1, 'fournisseur requis'),
  pieceId    : z.string().trim().optional(),
  sku        : z.string().trim().default(''),
  nom        : z.string().trim().min(1, 'nom requis'),
  qte        : zDecimalPositive.refine(n => n > 0, 'qte doit être > 0'),
  prixAchat  : zDecimalPositive.default(0),
  notes      : z.string().trim().optional(),
});
