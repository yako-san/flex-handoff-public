/**
 * Primitives zod partagées entre les schémas de route — v1.1.7 / Item 4.
 *
 * Centraliser les regexes / contraintes courantes évite les drifts
 * (ex: une route accepte les dates avec slash, une autre seulement
 * avec dash). Si un format évolue, on touche un seul endroit.
 */
import { z } from 'zod';

/** Date au format YYYY-MM-DD (ISO court, sans heure). */
export const zDateISO = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, 'Date attendue au format YYYY-MM-DD');

/** Nombre dans une string (chiffre virgule ou point) → number ≥ 0. */
export const zDecimal = z
  .union([z.number(), z.string()])
  .transform(v => {
    if (typeof v === 'number') return v;
    const n = parseFloat(String(v).replace(',', '.'));
    return Number.isFinite(n) ? n : 0;
  });

/** Idem mais doit rester ≥ 0 après transform. */
export const zDecimalPositive = zDecimal.refine(n => n >= 0, {
  message: 'Doit être ≥ 0',
});

/** Numéro de ligne sheet — entier ≥ 1. */
export const zSheetRow = z
  .union([z.number(), z.string()])
  .transform(v => parseInt(String(v), 10))
  .refine(n => Number.isInteger(n) && n >= 1, {
    message: 'Numéro de ligne invalide',
  });

/** Mode de paiement dépense / vente. */
export const zModePaiement = z.enum(['comptant', 'interac', 'cartes', 'virement']);

/** Mode de paiement étendu — utilisé sur BDT/factures (peut inclure « cheque »). */
export const zModePaiementBDT = z.enum(['comptant', 'interac', 'cartes', 'virement', 'cheque']);

/** Booléen permissif (string "true"/"false", 0/1, ou boolean). */
export const zBoolish = z
  .union([z.boolean(), z.string(), z.number()])
  .transform(v => {
    if (typeof v === 'boolean') return v;
    if (typeof v === 'number') return v !== 0;
    return String(v).toLowerCase() === 'true' || v === '1';
  });

/** String trimée, vide → undefined. Pratique pour les champs optionnels. */
export const zTrimOptional = z
  .string()
  .optional()
  .transform(v => {
    const t = String(v ?? '').trim();
    return t || undefined;
  });
