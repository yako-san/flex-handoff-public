/**
 * Schémas zod pour les routes /api/ventes/* — v1.1.7 / Item 4.
 */
import { z } from 'zod';
import { zDateISO, zDecimal, zDecimalPositive, zModePaiementBDT } from './common';

const VenteItemSchema = z.object({
  pieceId : z.string().trim().min(1, 'pieceId requis'),
  sku     : z.string().trim().default(''),
  nom     : z.string().trim().min(1, 'nom requis'),
  qte     : zDecimalPositive,
  prixUnit: zDecimalPositive,
});

export const VenteCreateSchema = z.object({
  date  : zDateISO,
  client: z.string().trim().default(''),
  items : z.array(VenteItemSchema).min(1, 'Au moins 1 item requis'),
  modePaiement: zModePaiementBDT.optional(),
  payerMaintenant: z.boolean().optional(),
});

export const VenteAppendItemsSchema = z.object({
  items: z.array(VenteItemSchema).min(1),
});

export const VenteItemPatchSchema = z.object({
  qte: zDecimalPositive,
});

export const VenteFactureSchema = z.object({
  modePaiement: zModePaiementBDT.optional(),
});

export const VenteArchiveDeleteSchema = z.object({
  venteId: z.string().trim().min(1),
});

export const VenteArchivePostSchema = z.object({
  venteId: z.string().trim().min(1),
});
