/**
 * Schémas zod pour les routes /api/archives — v1.1.7 / Item 4.
 */
import { z } from 'zod';
import { zSheetRow } from './common';

export const ArchivePatchSchema = z.object({
  archiveRow: zSheetRow,
  field     : z.enum(['dateIn', 'dateOut']),
  value     : z.string().optional(),
});

export const ArchiveDeleteSchema = z.object({
  bdcId     : z.string().trim().min(1, 'bdcId requis'),
  archiveRow: zSheetRow,
});

/** Désarchive OU consolide-ghosts OU rename. */
export const ArchivePostSchema = z.union([
  z.object({
    action    : z.literal('consolidate'),
  }),
  z.object({
    action    : z.literal('rename'),
    archiveRow: zSheetRow,
    oldId     : z.string().trim().min(1),
    newId     : z.string().trim().min(1),
  }),
  z.object({
    bdcId     : z.string().trim().min(1),
    archiveRow: zSheetRow,
  }),
]);
