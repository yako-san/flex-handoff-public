/**
 * Cache 2 niveaux (L1 in-memory + L2 Vercel KV cross-lambda).
 *
 * L1 = node-cache, par-lambda, TTL 30s. Réduit les round-trips KV pour
 *      les hot reads dans une même requête.
 * L2 = Vercel KV (Upstash Redis), partagée entre lambdas, TTL 5 min.
 *      Garantit qu'une invalidation faite par un lambda est vue par les
 *      autres → élimine le drift cache stale cross-lambda.
 *
 * Fallback : si KV_REST_API_URL n'est pas dans l'env (dev local sans
 * Vercel link, tests unitaires), L2 est désactivée et seul L1 fonctionne.
 * Le code se comporte comme l'ancien cache v6.x (mais TTL court).
 *
 * API : asynchrone. Tous les call sites doivent `await` get/set/del.
 */
import NodeCache from 'node-cache';
import { kv } from '@vercel/kv';

const useKV = !!process.env.KV_REST_API_URL;
const L1_TTL_SEC = 30;   // burst protection within a request
const L2_TTL_SEC = 300;  // 5 min cross-lambda

const l1 = new NodeCache({ stdTTL: L1_TTL_SEC, checkperiod: 60 });

export const CACHE_KEYS = {
  CLIENTS    : 'clients',
  BDCS       : 'bdcs',
  PIECES     : 'catalogue:pieces',
  EMAIL_TPL  : 'email:templates',
  POS        : 'po:list',
  VENTES         : 'ventes:list',
  VENTES_ARCHIVES: 'ventes:archives',
  SERVICES   : 'catalogue:services',
  MARQUES    : 'catalogue:marques',
  CATEGORIES : 'catalogue:categories',
};

async function get<T>(key: string): Promise<T | undefined> {
  const local = l1.get<T>(key);
  if (local !== undefined) return local;

  if (useKV) {
    try {
      const remote = await kv.get<T>(key);
      if (remote !== null && remote !== undefined) {
        l1.set(key, remote);
        return remote;
      }
    } catch (err: any) {
      console.warn('[cache] KV get failed:', key, err?.message);
    }
  }
  return undefined;
}

async function set<T>(key: string, value: T, ttlSec?: number): Promise<void> {
  if (ttlSec !== undefined) l1.set(key, value, ttlSec);
  else l1.set(key, value);
  if (useKV) {
    try {
      await kv.set(key, value, { ex: ttlSec ?? L2_TTL_SEC });
    } catch (err: any) {
      console.warn('[cache] KV set failed:', key, err?.message);
    }
  }
}

async function del(key: string): Promise<void> {
  l1.del(key);
  if (useKV) {
    try {
      await kv.del(key);
    } catch (err: any) {
      console.warn('[cache] KV del failed:', key, err?.message);
    }
  }
}

const cache = { get, set, del };
export default cache;
