/**
 * Helpers purs pour les calculs BDT — v1.1.9 / Item 5 audit.
 *
 * Extraits de `components/bdc/BDCPanel.tsx` (1555 LOC) pour réduire la
 * surface du monolithe et permettre du test unitaire. Aucun de ces
 * helpers ne touche React, ne fait d'I/O, n'a d'effet de bord :
 *   - `parseSvcTemps`  — extrait "(45 min)" d'un nom de service
 *   - `normSvcKey`     — normalise pour matching tolérant emoji/casse
 *   - `svcTailKey`     — extrait la "queue" après ':' / '—' / '-'
 *   - `svcLabel`       — décompose nom → { display, temps }
 *   - `pceLabel`       — préfixe ⚙️ pour affichage
 *   - `computeMontant` — calcule un montant de remise (pct ou flat)
 *   - `parseDureeToMinutes` — parse "1:45" ou "45 min" → minutes
 *   - `computeTotalDuree`   — somme des durées d'une liste de services
 *
 * Conservés dans BDCPanel via import + re-déclaration locale (alias)
 * pour préserver les call-sites — refactor cosmétique seulement.
 */
import type { BDCItem } from '@/types/bdc';
import type { Remise } from '@/components/bdc/BDCHeader';

/** Extrait la durée entre parenthèses d'un nom de service. */
export function parseSvcTemps(nom: string): { label: string; temps: string } {
  const m = nom.match(/\s*(\(\d[\d\s]*(?:min(?:utes?)?|h(?:eures?)?)\))$/i);
  if (m) return { label: nom.slice(0, nom.length - m[0].length).trim(), temps: m[1] };
  return { label: nom, temps: '' };
}

/** Normalise un nom de service pour matching tolérant aux préfixes
 *  emoji/ponctuation, espaces multiples et casse. */
export function normSvcKey(nom: string): string {
  return nom
    .replace(/^[^\p{L}\p{N}]+/u, '')   // strip leading non-letter/digit
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

/** Extrait la "queue" significative d'un nom de service : le dernier segment
 *  après ':', ' - ' ou ' — '. Permet de matcher des libellés dont seul le
 *  préfixe diffère (ex. "🧰 Remplac. : 4 câbles…" vs
 *  "🧰 Remplac. et ajust. - 4 câbles…"). Retourne '' si la queue est trop
 *  courte pour être discriminante. */
export function svcTailKey(nom: string): string {
  const parts = nom.split(/\s*[:–—-]\s*/).map(p => p.trim()).filter(Boolean);
  if (parts.length < 2) return '';
  const tail = parts[parts.length - 1];
  const k = tail.toLowerCase().replace(/\s+/g, ' ').trim();
  return k.length >= 5 ? k : '';
}

export function svcLabel(nom: string): { display: string; temps: string } {
  const { label, temps } = parseSvcTemps(nom);
  return { display: label, temps };
}

export function pceLabel(nom: string): string {
  return '⚙️ : ' + nom;
}

export function computeMontant(total: number, remise: Remise): number {
  if (remise.value <= 0) return 0;
  if (remise.type === 'pct') return Math.round(total * remise.value) / 100;
  return Math.min(remise.value, total);
}

/** Parse une durée au format "1:45" ou "45 min" ou "2h" en minutes totales. */
export function parseDureeToMinutes(d: string): number {
  if (!d) return 0;
  const colonMatch = d.match(/^(\d+):(\d+)$/);
  if (colonMatch) return parseInt(colonMatch[1]) * 60 + parseInt(colonMatch[2]);
  const minMatch = d.match(/(\d+)\s*min/i);
  if (minMatch) return parseInt(minMatch[1]);
  const hMatch = d.match(/(\d+)\s*h/i);
  if (hMatch) return parseInt(hMatch[1]) * 60;
  return 0;
}

/** Calcule la durée totale de tous les services au format "h:mm".
 *  Si l'item a un override (stocké dans service.status), il prime sur
 *  la valeur du catalogue. */
export function computeTotalDuree(
  services: BDCItem[],
  dureeMap: Map<string, string>,
): string {
  const totalMin = services.reduce((sum, item) => {
    const nom = item.service!.nom;
    const override = String(item.service?.status ?? '').trim();
    const d = (override && override !== '...')
      ? override
      : (dureeMap.get(nom)
        || dureeMap.get(normSvcKey(nom))
        || dureeMap.get(svcTailKey(nom))
        || parseSvcTemps(nom).temps);
    return sum + parseDureeToMinutes(d);
  }, 0);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  return `${h}:${m.toString().padStart(2, '0')}`;
}
