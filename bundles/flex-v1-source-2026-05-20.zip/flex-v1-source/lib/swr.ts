/**
 * Fetcher SWR partagé.
 *
 * v1.1.5 — Item 7 audit : avant cette consolidation, 14 hooks/components
 * dupliquaient une variante de `(url) => fetch(url).then(r => r.json())`.
 * Chaque modif du comportement réseau (timeout, headers, parsing d'erreur)
 * exigeait de toucher 14 fichiers en parallèle → bugs silencieux garantis.
 *
 * Deux variantes :
 *
 *   - `jsonFetcher` (plain) — retourne le body JSON quel que soit le
 *     status HTTP. SWR garde la donnée même sur 4xx/5xx (le composant
 *     gère l'erreur via la forme du payload). C'est le comportement
 *     historique de 12 des 14 hooks. À utiliser quand l'API renvoie
 *     `{ data, error }` plutôt que des codes HTTP discriminants.
 *
 *   - `jsonFetcherStrict` — lève `Error(payload.error)` si `!response.ok`,
 *     pour que SWR remplisse son champ `error` (et que `data` reste
 *     `undefined`). Comportement historique de `useBDC` et `useDepenses`.
 *     À utiliser quand l'UI doit distinguer « pas encore chargé » de
 *     « erreur serveur ».
 */

export const jsonFetcher = (url: string): Promise<any> =>
  fetch(url).then(r => r.json());

export const jsonFetcherStrict = (url: string): Promise<any> =>
  fetch(url).then(async r => {
    if (!r.ok) {
      const payload = await r.json().catch(() => ({}));
      throw new Error(payload?.error ?? `HTTP ${r.status}`);
    }
    return r.json();
  });
