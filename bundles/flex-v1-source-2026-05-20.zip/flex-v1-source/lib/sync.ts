/**
 * Sync intelligent — compare les timestamps de modification des documents
 * Google Sheets (via Drive API) et invalide uniquement les caches des
 * documents qui ont changé depuis le dernier sync.
 */
import { google } from 'googleapis';
import { getAuth, SHEET_IDS } from './sheets/client';
import cache, { CACHE_KEYS } from './cache';

/** Mapping document → clés de cache associées. */
const DOC_CACHE_MAP: Record<string, string[]> = {
  INVENTAIRE: [CACHE_KEYS.CLIENTS, CACHE_KEYS.BDCS, CACHE_KEYS.MARQUES, CACHE_KEYS.CATEGORIES, CACHE_KEYS.EMAIL_TPL],
  PIECES:     [CACHE_KEYS.PIECES, CACHE_KEYS.CATEGORIES],
  SERVICES:   [CACHE_KEYS.SERVICES],
  CLIENTS:    [CACHE_KEYS.CLIENTS],
};

/** Dernier timestamp connu par document. */
const lastModified = new Map<string, string>();

export interface SyncResult {
  changed: string[];       // noms des documents modifiés
  invalidated: string[];   // clés de cache invalidées
  unchanged: string[];     // noms des documents inchangés
}

/**
 * Vérifie les timestamps de modification de chaque document Sheets,
 * invalide les caches serveur des documents modifiés, et retourne
 * quels documents ont changé.
 */
export async function smartSync(): Promise<SyncResult> {
  const drive = google.drive({ version: 'v3', auth: getAuth() as any });

  const docs = Object.entries(SHEET_IDS).filter(([, id]) => id);
  const changed: string[] = [];
  const unchanged: string[] = [];
  const invalidated = new Set<string>();

  // Vérifier les timestamps en parallèle
  const checks = await Promise.all(
    docs.map(async ([name, fileId]) => {
      try {
        const res = await drive.files.get({
          fileId,
          fields: 'modifiedTime',
        });
        return { name, modifiedTime: res.data.modifiedTime ?? '' };
      } catch {
        // Si erreur Drive (permissions, etc.), on force l'invalidation
        return { name, modifiedTime: '__unknown__' };
      }
    }),
  );

  for (const { name, modifiedTime } of checks) {
    const prev = lastModified.get(name);
    if (prev === modifiedTime && modifiedTime !== '__unknown__') {
      unchanged.push(name);
      continue;
    }
    // Document modifié — invalider ses caches
    changed.push(name);
    lastModified.set(name, modifiedTime);
    const keys = DOC_CACHE_MAP[name] ?? [];
    for (const key of keys) {
      cache.del(key);
      invalidated.add(key);
    }
  }

  return { changed, invalidated: [...invalidated], unchanged };
}

/**
 * Force l'invalidation de TOUS les caches (utilisé en fallback).
 */
export function invalidateAllCaches(): string[] {
  const allKeys = Object.values(CACHE_KEYS);
  for (const key of allKeys) cache.del(key);
  lastModified.clear();
  return allKeys;
}
