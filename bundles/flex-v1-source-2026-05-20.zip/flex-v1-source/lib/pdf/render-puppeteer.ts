/**
 * Renderer PDF via Puppeteer + @sparticuz/chromium — v1.3.0+.
 *
 * Architecture :
 *   1. Reçoit `FactureHtmlData` + une string HTML (rendue par
 *      `lib/pdf/templates/facture-html.ts`).
 *   2. Boote un Chromium headless via `@sparticuz/chromium`
 *      (lightweight Chrome binary pour Lambda/Vercel).
 *   3. Charge le HTML via `page.setContent` avec `waitUntil: 'networkidle0'`
 *      (attend Google Fonts + assets).
 *   4. Exporte en PDF A4 portrait via `page.pdf` → Buffer.
 *   5. Ferme le browser → libère la mémoire.
 *
 * Contraintes Vercel Hobby :
 *   - Memory function : 1024 MB max (Chromium peak ~600-800 MB)
 *   - Timeout : 10s default, jusqu'à 60s avec maxDuration
 *   - Le cold start prend ~3-5s, calls suivants ~1-2s
 *
 * En dev local, Puppeteer utilise le Chrome système si disponible
 * (variable PUPPETEER_EXECUTABLE_PATH) sinon @sparticuz/chromium aussi.
 */
import puppeteer, { type Browser } from 'puppeteer-core';
import chromium from '@sparticuz/chromium';

/** Cache singleton du browser pour réutiliser entre cold starts adjacents.
 *  Vercel garde la fonction « warm » quelques minutes — on amortit le
 *  coût de boot Chromium. */
let cachedBrowser: Browser | null = null;
let cachedBrowserPromise: Promise<Browser> | null = null;

async function _getBrowser(): Promise<Browser> {
  if (cachedBrowser && cachedBrowser.connected) return cachedBrowser;
  if (cachedBrowserPromise) return cachedBrowserPromise;

  cachedBrowserPromise = (async () => {
    // En dev local (NODE_ENV !== production), permet d'utiliser un Chrome
    // système si CHROME_EXECUTABLE_PATH est défini — évite de télécharger
    // Chromium pour les tests rapides.
    const executablePath = process.env.CHROME_EXECUTABLE_PATH
                        || await chromium.executablePath();

    const browser = await puppeteer.launch({
      args         : chromium.args,
      defaultViewport: (chromium as any).defaultViewport,
      executablePath,
      headless     : true,
    });
    cachedBrowser = browser;
    return browser;
  })();

  try {
    return await cachedBrowserPromise;
  } finally {
    cachedBrowserPromise = null;
  }
}

/**
 * Rend un HTML en PDF Buffer via Chromium headless.
 *
 * @param html string HTML autonome (CSS inline dans <style>)
 * @returns Buffer PDF binaire
 */
export async function renderHtmlToPdfBuffer(html: string): Promise<Buffer> {
  const browser = await _getBrowser();
  const page = await browser.newPage();
  try {
    // setContent attend que les ressources externes (Google Fonts) soient
    // chargées. 'networkidle0' = 0 connection active depuis 500ms.
    await page.setContent(html, {
      // 'networkidle0' n'est pas exposé dans les types puppeteer-core
      // récents — cast pour rester compatible avec les anciens runtime
      // qui le reconnaissent. Sinon fallback 'load' suffit dans la prod.
      waitUntil: 'load',
      timeout  : 15000,
    });

    // Force le rendu d'au moins une « tick » React/CSS (font swap)
    await page.evaluateHandle('document.fonts.ready');

    const pdfBuffer = await page.pdf({
      format         : 'A4',
      printBackground: true,    // respecte les backgrounds CSS (zebra, etc.)
      margin         : {
        top   : '18mm',
        bottom: '32mm',          // place pour le footer fixe
        left  : '18mm',
        right : '18mm',
      },
      preferCSSPageSize: true,   // @page CSS prime sur format A4
    });

    return Buffer.from(pdfBuffer);
  } finally {
    await page.close().catch(() => { /* best-effort */ });
  }
}
