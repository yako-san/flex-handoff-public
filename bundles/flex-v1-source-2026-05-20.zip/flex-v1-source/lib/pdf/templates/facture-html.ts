/**
 * Template HTML pour la facture PDF — v1.3.0+ pipeline Puppeteer.
 *
 * Produit une string HTML autonome (un seul fichier, CSS inline dans
 * <style>), que `lib/pdf/render-puppeteer.ts` charge dans Chromium
 * headless puis exporte en PDF.
 *
 * Design fidèle au PDF de référence Sheets BASE-YC/BASE-CF, avec
 * ajustements demandés par yako-san (v1.3.0-preview) :
 *   1. Footer en bas de page absolu (toujours visible, même si la
 *      facture déborde sur plusieurs pages)
 *   2. Lignes items en zebra full-width (description → total) au-delà
 *      de 2 items
 *   3. Identité fiscale workshop (NEQ/TPS/TVQ) dans le footer
 *
 * Portabilité V1 ↔ V2 : la fonction `renderFactureHtml(data)` ne dépend
 * d'aucune API. V2 (Postgres) lui passe le même `FactureHtmlData` shape.
 */

export type FactureDocType = 'evaluation' | 'facture' | 'vente';

export interface FactureHtmlData {
  docType    : FactureDocType;
  lang       : 'FR' | 'EN';
  // Identité workshop (depuis _EMAIL_TEMPLATES_)
  workshop   : {
    nom         : string;   // « yako.cyclo » ou « Cyclo Flex Montréal »
    courriel    : string;
    telephone  ?: string;
    adresse    ?: string;
    neq        ?: string;
    tpsNumero  ?: string;
    tvqNumero  ?: string;
  };
  // En-tête doc
  numero      : string;   // "0042" ou "V0012"
  date        : string;   // YYYY-MM-DD (ou avec heure pour évaluation)
  // Client
  client      : {
    nomComplet       : string;
    courriel         : string;
    adressePostale  ?: string;
    entrepriseName  ?: string;
    entrepriseAdresse?: string;
  };
  veloDesc?   : string;   // Omis pour vente directe
  // Items
  services    : { nom: string; prix: number }[];
  pieces      : { nom: string; prix: number; qte: number; sousTotal: number }[];
  // Totaux
  sousTotal   : number;
  totalRemise : number;   // POSITIF — affiché en négatif sur le PDF
  tps         : number;
  tvq         : number;
  totalTTC    : number;
  // Note client (zone bilan en bas de la zone items)
  noteClient  : string;
  // Optionnel : URL absolu du logo (sinon /logo-yako-cyclo.svg)
  logoUrl    ?: string;
}

// ── Libellés FR / EN ─────────────────────────────────────────────────

const LBL = {
  FR: {
    facture     : 'FACTURE',
    evaluation  : 'ÉVALUATION',
    recuVente   : 'REÇU DE VENTE',
    no          : 'N°',
    date        : 'Date',
    client      : 'Client',
    contact     : 'Contact',
    velo        : 'Vélo',
    attention   : 'À l\'attention de',
    services    : 'SERVICES',
    pieces      : 'PIÈCES',
    item        : 'item',
    unitaire    : 'unitaire',
    qte         : 'qté',
    prix        : 'prix',
    sousTotal   : 'Sous-total',
    remise      : 'Remises',
    tps         : 'T.P.S (5 %)',
    tvq         : 'T.V.Q (9,975 %)',
    totalTaxes  : 'Total des taxes',
    total       : 'Total',
    retoursTitre: 'Politique de retour',
    retoursText : `Les retours considérés dans les trente jours suivant l'achat. Retours pour crédit seulement. Les articles retournés seront crédités moyennant des frais de 15 % de remise en stock. Les items ouverts ou utilisés ne peuvent être retournés. Les articles soldés ne peuvent être retournés. Le prix des articles en commande spéciale est sujet à changer entre la date de la commande et de la réception de l'article et sera facturé au prix le plus récent.`,
    paiementTitre: 'Modes de paiement',
    paiementText : `Le paiement se fera lors du retrait ou avant, par Interac* au {{tel}}. merci 🙏`,
    paiementNote : `* (comptant ou Interac) sont les deux seules méthodes pour éviter les frais de service. Les pourboires sont acceptés.`,
  },
  EN: {
    facture     : 'INVOICE',
    evaluation  : 'ESTIMATE',
    recuVente   : 'SALES RECEIPT',
    no          : '#',
    date        : 'Date',
    client      : 'Client',
    contact     : 'Contact',
    velo        : 'Bike',
    attention   : 'Attention to',
    services    : 'SERVICES',
    pieces      : 'PARTS',
    item        : 'item',
    unitaire    : 'unit',
    qte         : 'qty',
    prix        : 'amount',
    sousTotal   : 'Subtotal',
    remise      : 'Discount',
    tps         : 'GST (5%)',
    tvq         : 'QST (9.975%)',
    totalTaxes  : 'Total taxes',
    total       : 'Total',
    retoursTitre: 'Return policy',
    retoursText : `Returns must be made within thirty days of purchase. Returns are accepted for store credit only. Returned items will be credited minus a 15% restocking fee. Opened or used items cannot be returned. Sale items cannot be returned. The price of special-order items is subject to change between the date of order and the date of receipt, and will be billed at the most recent price.`,
    paiementTitre: 'Payment methods',
    paiementText : `Payment is made on pickup or before, by Interac* at {{tel}}. thank you 🙏`,
    paiementNote : `* (cash or Interac) are the two methods to avoid service fees. Tips welcome.`,
  },
};

// ── Helpers ──────────────────────────────────────────────────────────

function frPrix(n: number, lang: 'FR' | 'EN'): string {
  const s = n.toFixed(2);
  if (lang === 'EN') return `$ ${s}`;
  return `${s.replace('.', ',')} $`;
}

function escapeHtml(s: string): string {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Préserve les sauts de ligne dans une string multi-ligne (ex. adresse) */
function nl2br(s: string): string {
  return escapeHtml(s).replace(/\n/g, '<br>');
}

// ── Render principal ─────────────────────────────────────────────────

export function renderFactureHtml(data: FactureHtmlData): string {
  const t       = LBL[data.lang];
  const docLabel =
    data.docType === 'evaluation' ? t.evaluation
  : data.docType === 'vente'      ? t.recuVente
  :                                  t.facture;

  const showVelo     = !!data.veloDesc?.trim();
  const showEmployer = !!data.client.entrepriseName?.trim();
  const showRemise   = data.totalRemise > 0.005;

  const totalServices = data.services.reduce((s, it) => s + it.prix, 0);
  const totalPieces   = data.pieces.reduce((s, it) => s + it.sousTotal, 0);

  // Zebra : appliquée toujours, mais l'utilisateur la « voit » surtout
  // à partir de 3+ items. CSS gère via nth-child sans condition côté JS.
  const itemsHtml = (rows: string[]) => rows.join('\n');

  const servicesRows = data.services.map((svc, i) => `
    <tr class="item-row">
      <td class="col-desc">${escapeHtml(svc.nom)}</td>
      <td class="col-unit">${frPrix(svc.prix, data.lang)}</td>
      <td class="col-qty">1</td>
      <td class="col-total">${frPrix(svc.prix, data.lang)}</td>
    </tr>
  `);

  const piecesRows = data.pieces.map((pce, i) => `
    <tr class="item-row">
      <td class="col-desc">${escapeHtml(pce.nom)}</td>
      <td class="col-unit">${frPrix(pce.prix, data.lang)}</td>
      <td class="col-qty">${pce.qte}</td>
      <td class="col-total">${frPrix(pce.sousTotal, data.lang)}</td>
    </tr>
  `);

  const logoUrl  = data.logoUrl ?? '/logo-yako-cyclo.svg';
  const phoneStr = data.workshop.telephone ?? '(514) 995-3445';
  const paiementText = t.paiementText.replace('{{tel}}', phoneStr);

  // Footer fiscal — n'affiche que les champs renseignés
  const fiscalParts: string[] = [];
  if (data.workshop.neq)       fiscalParts.push(`NEQ ${escapeHtml(data.workshop.neq)}`);
  if (data.workshop.tpsNumero) fiscalParts.push(`T.P.S ${escapeHtml(data.workshop.tpsNumero)}`);
  if (data.workshop.tvqNumero) fiscalParts.push(`T.V.Q ${escapeHtml(data.workshop.tvqNumero)}`);
  const fiscalLine = fiscalParts.join(' · ');

  return `<!DOCTYPE html>
<html lang="${data.lang.toLowerCase()}">
<head>
<meta charset="UTF-8">
<title>${escapeHtml(docLabel)} ${escapeHtml(data.numero)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
<style>
  /* ── Reset basique ──────────────────────────────────────────── */
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body {
    font-family: 'Roboto', Arial, sans-serif;
    font-size: 11px;
    line-height: 1.4;
    color: #1a1a1a;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }
  /* ── Page A4 + marges + footer fixe ─────────────────────────── */
  @page {
    size: A4;
    margin: 18mm 18mm 32mm 18mm;
  }
  .pdf-footer {
    position: fixed;
    bottom: -22mm;
    left: 0;
    right: 0;
    padding-top: 6px;
    border-top: 0.5px solid rgba(0,0,0,0.2);
    font-size: 8.5px;
    color: rgba(0,0,0,0.55);
  }
  /* ── En-tête : logo + branding + type doc ───────────────────── */
  .header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 18px;
  }
  .header-left { display: flex; align-items: center; gap: 14px; }
  .header-logo { width: 70px; height: 70px; }
  .brand-name { font-size: 18px; font-weight: 700; letter-spacing: -0.3px; }
  .brand-sub  { font-size: 10px; color: rgba(0,0,0,0.55); margin-top: 2px; }
  .header-right { text-align: right; }
  .doc-type { font-size: 16px; font-weight: 700; letter-spacing: 1.4px; }
  .doc-meta { font-size: 9.5px; color: rgba(0,0,0,0.6); margin-top: 4px; line-height: 1.5; }
  /* ── Bloc client + employeur ────────────────────────────────── */
  .info-grid {
    display: flex;
    justify-content: space-between;
    gap: 24px;
    margin: 22px 0 18px;
    padding-bottom: 14px;
    border-bottom: 1px solid rgba(0,0,0,0.12);
  }
  .info-block { flex: 1; min-width: 0; }
  .info-block-right { text-align: right; }
  .info-label {
    font-size: 8.5px;
    color: rgba(0,0,0,0.45);
    text-transform: uppercase;
    letter-spacing: 0.6px;
    margin-bottom: 2px;
  }
  .info-value { font-size: 11.5px; font-weight: 700; }
  .info-sub   { font-size: 10px; color: rgba(0,0,0,0.6); margin-top: 1px; }
  /* ── Table items ────────────────────────────────────────────── */
  .section-title {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.4px;
    margin-top: 16px;
    margin-bottom: 6px;
    padding-bottom: 3px;
    border-bottom: 1.5px solid #1a1a1a;
  }
  table.items-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 10px;
  }
  table.items-table th {
    font-size: 8.5px;
    font-weight: 400;
    color: rgba(0,0,0,0.45);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-align: left;
    padding: 4px 6px;
    border-bottom: 0.5px solid rgba(0,0,0,0.15);
  }
  table.items-table th.col-unit  { text-align: right; width: 70px; }
  table.items-table th.col-qty   { text-align: center; width: 40px; }
  table.items-table th.col-total { text-align: right; width: 80px; }
  table.items-table tr.item-row td {
    padding: 6px;
    font-size: 11px;
    border-bottom: 0.5px solid rgba(0,0,0,0.08);
  }
  table.items-table tr.item-row td.col-desc { color: #1a1a1a; }
  table.items-table tr.item-row td.col-unit  { text-align: right; color: rgba(0,0,0,0.65); }
  table.items-table tr.item-row td.col-qty   { text-align: center; color: rgba(0,0,0,0.65); }
  table.items-table tr.item-row td.col-total { text-align: right; font-weight: 500; }
  /* v1.3.0+ : zebra full-width (toutes colonnes incluses) */
  table.items-table tr.item-row:nth-child(even) td {
    background-color: rgba(0,0,0,0.025);
  }
  /* ── Totaux ────────────────────────────────────────────────── */
  .totals {
    margin-top: 14px;
    margin-left: auto;
    width: 280px;
  }
  .totals-row {
    display: flex;
    justify-content: space-between;
    padding: 3px 8px;
    font-size: 10.5px;
    color: rgba(0,0,0,0.65);
  }
  .totals-row.totals-grand {
    border-top: 1.5px solid #1a1a1a;
    padding-top: 8px;
    margin-top: 6px;
    font-size: 13px;
    font-weight: 700;
    color: #1a1a1a;
    text-transform: uppercase;
    letter-spacing: 1px;
  }
  /* ── Note client ───────────────────────────────────────────── */
  .note-client {
    margin-top: 22px;
    padding: 12px 14px;
    background: #f7f7f5;
    border-left: 3px solid #fff056;
    font-size: 10px;
    color: rgba(0,0,0,0.65);
    font-style: italic;
  }
  /* ── Footer : politique + paiement + fiscal ────────────────── */
  .policy {
    margin-top: 18px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
    font-size: 8.5px;
    color: rgba(0,0,0,0.55);
    line-height: 1.5;
  }
  .policy h4 {
    font-size: 9px;
    font-weight: 700;
    color: rgba(0,0,0,0.7);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin: 0 0 4px 0;
  }
  .footer-fiscal { text-align: center; font-size: 8.5px; color: rgba(0,0,0,0.55); padding-top: 4px; }
  .footer-paiement { text-align: center; font-size: 9px; color: rgba(0,0,0,0.65); margin-top: 4px; }
  .footer-paiement-note { text-align: center; font-size: 8px; color: rgba(0,0,0,0.45); margin-top: 1px; }
</style>
</head>
<body>

<!-- ── Header ──────────────────────────────────────── -->
<div class="header">
  <div class="header-left">
    <img class="header-logo" src="${escapeHtml(logoUrl)}" alt="logo">
    <div>
      <div class="brand-name">${escapeHtml(data.workshop.nom)}</div>
      <div class="brand-sub">${escapeHtml(data.workshop.courriel)}${
        data.workshop.telephone ? ' · ' + escapeHtml(data.workshop.telephone) : ''
      }</div>
      ${data.workshop.adresse ? `<div class="brand-sub">${escapeHtml(data.workshop.adresse)}</div>` : ''}
    </div>
  </div>
  <div class="header-right">
    <div class="doc-type">${escapeHtml(docLabel)}</div>
    <div class="doc-meta">
      ${escapeHtml(t.no)} ${escapeHtml(data.numero)}<br>
      ${escapeHtml(t.date)} : ${escapeHtml(data.date)}
    </div>
  </div>
</div>

<!-- ── Bloc client + employeur ────────────────────── -->
<div class="info-grid">
  <div class="info-block">
    ${showEmployer ? `
      <div class="info-label">${escapeHtml(t.attention)}</div>
      <div class="info-value">${escapeHtml(data.client.entrepriseName!)}</div>
      ${data.client.entrepriseAdresse ? `<div class="info-sub">${nl2br(data.client.entrepriseAdresse)}</div>` : ''}
    ` : ''}
  </div>
  <div class="info-block info-block-right">
    <div class="info-label">${escapeHtml(t.client)}</div>
    <div class="info-value">${escapeHtml(data.client.nomComplet)}</div>
    ${data.client.adressePostale ? `<div class="info-sub">${nl2br(data.client.adressePostale)}</div>` : ''}
    ${data.client.courriel ? `<div class="info-sub">${escapeHtml(data.client.courriel)}</div>` : ''}
    ${showVelo ? `
      <div class="info-label" style="margin-top:8px">${escapeHtml(t.velo)}</div>
      <div class="info-sub">${escapeHtml(data.veloDesc!)}</div>
    ` : ''}
  </div>
</div>

<!-- ── Services ───────────────────────────────────── -->
${data.services.length > 0 ? `
<div class="section-title">${escapeHtml(t.services)}</div>
<table class="items-table">
  <thead>
    <tr>
      <th class="col-desc">${escapeHtml(t.item)}</th>
      <th class="col-unit">${escapeHtml(t.unitaire)}</th>
      <th class="col-qty">${escapeHtml(t.qte)}</th>
      <th class="col-total">${escapeHtml(t.prix)}</th>
    </tr>
  </thead>
  <tbody>
    ${itemsHtml(servicesRows)}
  </tbody>
</table>
` : ''}

<!-- ── Pièces ─────────────────────────────────────── -->
${data.pieces.length > 0 ? `
<div class="section-title">${escapeHtml(t.pieces)}</div>
<table class="items-table">
  <thead>
    <tr>
      <th class="col-desc">${escapeHtml(t.item)}</th>
      <th class="col-unit">${escapeHtml(t.unitaire)}</th>
      <th class="col-qty">${escapeHtml(t.qte)}</th>
      <th class="col-total">${escapeHtml(t.prix)}</th>
    </tr>
  </thead>
  <tbody>
    ${itemsHtml(piecesRows)}
  </tbody>
</table>
` : ''}

<!-- ── Totaux ────────────────────────────────────── -->
<div class="totals">
  <div class="totals-row">
    <span>${escapeHtml(t.sousTotal)}</span>
    <span>${frPrix(data.sousTotal, data.lang)}</span>
  </div>
  ${showRemise ? `
  <div class="totals-row">
    <span>${escapeHtml(t.remise)}</span>
    <span>− ${frPrix(data.totalRemise, data.lang)}</span>
  </div>
  ` : ''}
  <div class="totals-row">
    <span>${escapeHtml(t.tps)}</span>
    <span>${frPrix(data.tps, data.lang)}</span>
  </div>
  <div class="totals-row">
    <span>${escapeHtml(t.tvq)}</span>
    <span>${frPrix(data.tvq, data.lang)}</span>
  </div>
  <div class="totals-row totals-grand">
    <span>${escapeHtml(t.total)}</span>
    <span>${frPrix(data.totalTTC, data.lang)}</span>
  </div>
</div>

<!-- ── Note client (si présente) ─────────────────── -->
${data.noteClient?.trim() ? `
<div class="note-client">${nl2br(data.noteClient)}</div>
` : ''}

<!-- ── Politique retour + paiement ──────────────── -->
<div class="policy">
  <div>
    <h4>${escapeHtml(t.retoursTitre)}</h4>
    <p>${escapeHtml(t.retoursText)}</p>
  </div>
  <div>
    <h4>${escapeHtml(t.paiementTitre)}</h4>
    <p>${escapeHtml(paiementText)}</p>
    <p style="margin-top:6px;font-size:8px;color:rgba(0,0,0,0.45)">${escapeHtml(t.paiementNote)}</p>
  </div>
</div>

<!-- ── Footer fixe (bas de page absolu, toutes pages) ─── -->
<div class="pdf-footer">
  ${fiscalLine ? `<div class="footer-fiscal">${fiscalLine}</div>` : ''}
</div>

</body>
</html>`;
}
