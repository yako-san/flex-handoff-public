/**
 * Traduction via l'API DeepL (free tier).
 *
 * - Endpoint : https://api-free.deepl.com/v2/translate
 * - Clé API  : env var DEEPL_API_KEY (sans elle, la fonction renvoie le
 *   texte original inchangé — jamais d'erreur en production)
 * - Cache    : NodeCache partagé (lib/cache.ts), TTL 24h
 * - Batch    : DeepL accepte plusieurs segments `text=` par requête ; on
 *   pousse tout en une seule requête par appel.
 *
 * Langues supportées par ce wrapper : 'FR' et 'EN' (source + cible).
 */
import cache from '@/lib/cache';

type Lang = 'FR' | 'EN';

const DEEPL_URL   = 'https://api-free.deepl.com/v2/translate';
const CACHE_TTL_S = 24 * 60 * 60;  // 24 heures

function _cacheKey(src: Lang, tgt: Lang, text: string): string {
  return `translate:${src}:${tgt}:${text}`;
}

/**
 * Traduit un ou plusieurs textes. Retourne un tableau dans le même ordre
 * que l'entrée. Les textes déjà en cache ne sont pas renvoyés à DeepL.
 * Si la clé API est absente ou si l'API échoue, retourne le texte
 * original (best-effort, jamais throw).
 */
export async function translate(
  texts: string[],
  targetLang: Lang,
  sourceLang: Lang = 'FR',
): Promise<string[]> {
  if (!texts.length) return [];
  if (sourceLang === targetLang) return [...texts];

  const apiKey = process.env.DEEPL_API_KEY;
  if (!apiKey) {
    // Pas de clé configurée → fallback silencieux sur le texte original.
    return [...texts];
  }

  // Vérifier le cache pour chaque entrée ; ne garder que celles à traduire.
  const result: (string | null)[] = new Array(texts.length).fill(null);
  const toFetch: { idx: number; text: string }[] = [];

  for (let i = 0; i < texts.length; i++) {
    const t = texts[i] ?? '';
    if (!t.trim()) { result[i] = t; continue; }
    const cached = await cache.get<string>(_cacheKey(sourceLang, targetLang, t));
    if (cached !== undefined) {
      result[i] = cached;
    } else {
      toFetch.push({ idx: i, text: t });
    }
  }

  if (toFetch.length === 0) {
    return result as string[];
  }

  try {
    const params = new URLSearchParams();
    params.set('auth_key', apiKey);
    params.set('source_lang', sourceLang);
    params.set('target_lang', targetLang);
    // preserve_formatting=1 conserve ponctuation/majuscules des noms propres.
    params.set('preserve_formatting', '1');
    for (const { text } of toFetch) {
      params.append('text', text);
    }

    const res = await fetch(DEEPL_URL, {
      method : 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body   : params.toString(),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => '');
      console.warn(`[translate] DeepL ${res.status} — fallback texte original :`, body.slice(0, 200));
      // Remplir les trous avec le texte original
      for (const { idx, text } of toFetch) result[idx] = text;
      return result as string[];
    }

    const data = await res.json() as { translations?: Array<{ text: string }> };
    const translations = data.translations ?? [];

    for (let i = 0; i < toFetch.length; i++) {
      const { idx, text } = toFetch[i];
      const translated    = translations[i]?.text ?? text;
      result[idx]         = translated;
      await cache.set(_cacheKey(sourceLang, targetLang, text), translated, CACHE_TTL_S);
    }

    return result as string[];
  } catch (err: any) {
    console.warn('[translate] erreur réseau DeepL — fallback :', err?.message ?? err);
    for (const { idx, text } of toFetch) result[idx] = text;
    return result as string[];
  }
}

/**
 * Helper : traduit un seul texte (wrapper autour de translate()).
 */
export async function translateOne(
  text: string,
  targetLang: Lang,
  sourceLang: Lang = 'FR',
): Promise<string> {
  if (!text) return text;
  const [out] = await translate([text], targetLang, sourceLang);
  return out;
}
