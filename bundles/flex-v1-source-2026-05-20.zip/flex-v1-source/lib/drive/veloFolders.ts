/**
 * Helpers Drive pour gérer les dossiers photos PAR VÉLO (BDT).
 *
 * Structure cible (v1.0.10+) :
 *   DRIVE_CLIENTS_FOLDER_ID (root)
 *   ├── Nathalie Therrien/
 *   │   ├── BDT-0112/         ← sous-dossier vélo
 *   │   │   ├── IMG_7184.jpg
 *   │   │   └── …
 *   │   └── BDT-0113/         ← autre vélo du même client
 *   │       └── …
 *   └── …
 *
 * Avantages vs photos par client (architecture précédente) :
 *  - Photos liées au vélo, pas au client → exact pour archivage et historique
 *    quand un même client revient avec un autre vélo.
 *  - Permet de retrouver les photos d'un BDT archivé via son bdcId.
 *  - Conserve la regroupement par client (un dossier client contient les
 *    sous-dossiers de tous ses BDT).
 *
 * Compat ascendante : les anciennes photos déposées directement dans
 * `Nathalie Therrien/` (sans sous-dossier BDT) restent accessibles via
 * `lib/drive/clientFolders.ts` — pas de migration automatique.
 */
import { google } from 'googleapis';
import { Readable } from 'stream';
import { DRIVE_FOLDER_IDS } from '../sheets/client';
import { withTokenRetry } from '../google/withTokenRetry';
import { getOrCreateClientFolder } from './clientFolders';

function getDrive(accessToken: string, refreshToken?: string) {
  const oauth2Client = new google.auth.OAuth2(
    process.env.AUTH_GOOGLE_ID,
    process.env.AUTH_GOOGLE_SECRET,
  );
  oauth2Client.setCredentials({
    access_token : accessToken,
    refresh_token: refreshToken ?? null,
  });
  return google.drive({ version: 'v3', auth: oauth2Client });
}

/**
 * Trouve (ou crée) le sous-dossier `BDT-<bdcId>` dans le dossier client.
 * Retourne l'id Drive du sous-dossier.
 */
export async function getOrCreateVeloFolder(
  clientNom    : string,
  bdcId        : string,
  accessToken  : string,
  refreshToken?: string,
): Promise<string> {
  if (!bdcId) throw new Error('bdcId requis');

  const clientFolderId = await getOrCreateClientFolder(clientNom, accessToken, refreshToken);
  const drive = getDrive(accessToken, refreshToken);
  const subName = `BDT-${bdcId}`;

  // Cherche le sous-dossier
  const q =
    `'${clientFolderId}' in parents ` +
    `and mimeType = 'application/vnd.google-apps.folder' ` +
    `and name = '${subName.replace(/'/g, "\\'")}' ` +
    `and trashed = false`;
  const res = await drive.files.list({
    q, fields: 'files(id,name)', pageSize: 5,
  });
  const existing = res.data.files?.[0];
  if (existing?.id) return existing.id;

  // Crée le sous-dossier
  const created = await drive.files.create({
    requestBody: {
      name      : subName,
      mimeType  : 'application/vnd.google-apps.folder',
      parents   : [clientFolderId],
    },
    fields: 'id',
  });
  if (!created.data.id) throw new Error('Création sous-dossier vélo Drive échouée');
  return created.data.id;
}

/** Liste les fichiers (photos) du sous-dossier BDT. */
export async function listVeloPhotos(
  clientNom    : string,
  bdcId        : string,
  accessToken  : string,
  refreshToken?: string,
): Promise<Array<{
  id: string; name: string; webViewLink?: string; thumbnailLink?: string; mimeType: string; createdTime?: string;
}>> {
  if (!DRIVE_FOLDER_IDS.CLIENTS) return [];
  return withTokenRetry(async (token) => {
    const folderId = await getOrCreateVeloFolder(clientNom, bdcId, token, refreshToken);
    const drive    = getDrive(token, refreshToken);
    const res = await drive.files.list({
      q     : `'${folderId}' in parents and trashed = false`,
      fields: 'files(id,name,webViewLink,thumbnailLink,mimeType,createdTime)',
      orderBy: 'createdTime desc',
      pageSize: 100,
    });
    return (res.data.files ?? []).map(f => ({
      id           : f.id!,
      name         : f.name ?? '',
      webViewLink  : f.webViewLink ?? undefined,
      thumbnailLink: f.thumbnailLink ?? undefined,
      mimeType     : f.mimeType ?? 'application/octet-stream',
      createdTime  : f.createdTime ?? undefined,
    }));
  }, accessToken, refreshToken);
}

/** Upload un fichier dans le sous-dossier BDT. */
export async function uploadVeloPhoto(
  clientNom    : string,
  bdcId        : string,
  file         : { name: string; mimeType: string; buffer: Buffer },
  accessToken  : string,
  refreshToken?: string,
): Promise<{ id: string; name: string; webViewLink?: string }> {
  return withTokenRetry(async (token) => {
    const folderId = await getOrCreateVeloFolder(clientNom, bdcId, token, refreshToken);
    const drive    = getDrive(token, refreshToken);
    const res = await drive.files.create({
      requestBody: { name: file.name, parents: [folderId], mimeType: file.mimeType },
      media      : { mimeType: file.mimeType, body: Readable.from(file.buffer) },
      fields     : 'id,name,webViewLink',
    });
    return {
      id         : res.data.id ?? '',
      name       : res.data.name ?? file.name,
      webViewLink: res.data.webViewLink ?? undefined,
    };
  }, accessToken, refreshToken);
}
