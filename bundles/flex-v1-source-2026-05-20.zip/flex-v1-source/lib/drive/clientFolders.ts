/**
 * Helpers Drive pour gérer les dossiers photos clients.
 *
 * Utilise le OAuth de l'utilisateur connecté (pas le service account —
 * les SA n'ont pas de quota storage sur My Drive). L'utilisateur doit
 * avoir accès en écriture au dossier CLIENTS racine.
 *
 * Structure :
 *   DRIVE_CLIENTS_FOLDER_ID (root)
 *   ├── Nathalie Therrien/
 *   │   ├── IMG_7184.jpg
 *   │   └── …
 *   └── …
 */
import { google } from 'googleapis';
import { Readable } from 'stream';
import { DRIVE_FOLDER_IDS } from '../sheets/client';
import { withTokenRetry } from '../google/withTokenRetry';

function getDrive(accessToken: string, refreshToken?: string) {
  const oauth2Client = new google.auth.OAuth2(
    process.env.AUTH_GOOGLE_ID,
    process.env.AUTH_GOOGLE_SECRET,
  );
  oauth2Client.setCredentials({
    access_token : accessToken,
    refresh_token: refreshToken ?? null,
  });
  return google.drive({ version: 'v3', auth: oauth2Client });
}

/** Slug léger : trim, normalise espaces. Le nom est utilisé tel quel par
 *  Drive (accents OK). On évite juste les caractères qui cassent le path. */
function slugName(nom: string): string {
  return nom.trim().replace(/\s+/g, ' ').replace(/[/\\]/g, '-');
}

/** Trouve le dossier du client (ou le crée s'il n'existe pas) et retourne son id. */
export async function getOrCreateClientFolder(
  clientNom: string,
  accessToken: string,
  refreshToken?: string,
): Promise<string> {
  if (!DRIVE_FOLDER_IDS.CLIENTS) {
    throw new Error('DRIVE_CLIENTS_FOLDER_ID non configuré');
  }
  const drive = getDrive(accessToken, refreshToken);
  const name  = slugName(clientNom);
  if (!name) throw new Error('Nom de client vide');

  // Cherche un dossier du même nom directement sous CLIENTS root
  const q =
    `'${DRIVE_FOLDER_IDS.CLIENTS}' in parents ` +
    `and mimeType = 'application/vnd.google-apps.folder' ` +
    `and name = '${name.replace(/'/g, "\\'")}' ` +
    `and trashed = false`;
  const res = await drive.files.list({
    q, fields: 'files(id,name)', pageSize: 5,
  });
  const existing = res.data.files?.[0];
  if (existing?.id) return existing.id;

  // Sinon, crée le dossier
  const created = await drive.files.create({
    requestBody: {
      name,
      mimeType: 'application/vnd.google-apps.folder',
      parents : [DRIVE_FOLDER_IDS.CLIENTS],
    },
    fields: 'id',
  });
  if (!created.data.id) throw new Error('Création dossier client Drive échouée');
  return created.data.id;
}

/** Liste les fichiers (photos) dans le dossier client. */
export async function listClientPhotos(
  clientNom: string,
  accessToken: string,
  refreshToken?: string,
): Promise<Array<{
  id: string; name: string; webViewLink?: string; thumbnailLink?: string; mimeType: string; createdTime?: string;
}>> {
  if (!DRIVE_FOLDER_IDS.CLIENTS) return [];
  // Ne swallow plus les erreurs : throw pour que la route remonte le 401
  // au client (bannière/toast "Session expirée"). Le withTokenRetry gère
  // le refresh automatique en amont.
  return withTokenRetry(async (token) => {
    const folderId = await getOrCreateClientFolder(clientNom, token, refreshToken);
    const drive    = getDrive(token, refreshToken);
    const res = await drive.files.list({
      q     : `'${folderId}' in parents and trashed = false`,
      fields: 'files(id,name,webViewLink,thumbnailLink,mimeType,createdTime)',
      orderBy: 'createdTime desc',
      pageSize: 100,
    });
    return (res.data.files ?? []).map(f => ({
      id           : f.id!,
      name         : f.name ?? '',
      webViewLink  : f.webViewLink ?? undefined,
      thumbnailLink: f.thumbnailLink ?? undefined,
      mimeType     : f.mimeType ?? 'application/octet-stream',
      createdTime  : f.createdTime ?? undefined,
    }));
  }, accessToken, refreshToken);
}

/** Upload un fichier dans le dossier du client. */
export async function uploadClientPhoto(
  clientNom: string,
  file: { name: string; mimeType: string; buffer: Buffer },
  accessToken: string,
  refreshToken?: string,
): Promise<{ id: string; name: string; webViewLink?: string }> {
  return withTokenRetry(async (token) => {
    const folderId = await getOrCreateClientFolder(clientNom, token, refreshToken);
    const drive    = getDrive(token, refreshToken);
    const res = await drive.files.create({
      requestBody: { name: file.name, parents: [folderId], mimeType: file.mimeType },
      media      : { mimeType: file.mimeType, body: Readable.from(file.buffer) },
      fields     : 'id,name,webViewLink',
    });
    return {
      id         : res.data.id ?? '',
      name       : res.data.name ?? file.name,
      webViewLink: res.data.webViewLink ?? undefined,
    };
  }, accessToken, refreshToken);
}

/** Supprime un fichier Drive (photo client) par id. */
export async function deleteClientPhoto(
  fileId: string,
  accessToken: string,
  refreshToken?: string,
): Promise<void> {
  await withTokenRetry(async (token) => {
    const drive = getDrive(token, refreshToken);
    await drive.files.delete({ fileId });
  }, accessToken, refreshToken);
}
