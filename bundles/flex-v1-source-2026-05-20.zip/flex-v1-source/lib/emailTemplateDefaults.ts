/**
 * Valeurs par défaut des templates courriels.
 * Fichier séparé de lib/sheets/emailTemplates.ts pour pouvoir être importé
 * côté client sans entraîner googleapis / Node.js deps.
 *
 * Chaque type (eval/facture) × chaque langue (fr/en) a :
 *   - subject : sujet du courriel
 *   - message : corps complet (salutation + intro + note + CTA + conclusion)
 *
 * Placeholders : {{prenom}}, {{clientNom}}, {{veloDesc}}, {{id}}, {{date}}, {{noteClient}}
 */

export const EMAIL_TEMPLATE_DEFAULTS: Record<string, string> = {
  // ── Évaluation FR ─────────────────────────────────────────────
  eval_subject_fr: 'Évaluation #{{id}} - {{date}}',
  eval_message_fr: `Bonjour {{prenom}},

Veuillez trouver ci-joint l'évaluation des travaux à faire sur votre <strong>{{veloDesc}}</strong>.

Note : {{noteClient}}

Travaux à faire :
{{services}}

Pièces requises :
{{pieces}}

Merci de commenter ou d'approuver ce courriel afin que nous puissions commencer le travail.

N'hésitez pas à nous contacter pour toute question.

Cordialement,`,

  // ── Évaluation EN ─────────────────────────────────────────────
  eval_subject_en: 'Evaluation #{{id}} - {{date}}',
  eval_message_en: `Hello {{prenom}},

Please find attached the evaluation of the work to be done on your <strong>{{veloDesc}}</strong>.

Note: {{noteClient}}

Work to do:
{{services}}

Parts required:
{{pieces}}

Please comment on or approve this email so we can begin the work.

Please don't hesitate to contact us with any questions.

Best regards,`,

  // ── Facture FR ────────────────────────────────────────────────
  facture_subject_fr: 'Facture #{{id}} - {{date}}',
  facture_message_fr: `Bonjour {{prenom}},

Le travail sur votre <strong>{{veloDesc}}</strong> est terminé et vous pouvez prendre <a href="https://squ.re/4vTvxH7">rendez-vous pour le récupérer</a>.

Veuillez trouver ci-joint la facture des travaux effectués. Le paiement se fera lors du retrait (liquide ou Interac)*.

Note : {{noteClient}}

Merci de votre confiance et bonne route,

* <i>ce sont les deux seules méthodes pour éviter les frais de service</i>.`,

  // ── Facture EN ────────────────────────────────────────────────
  facture_subject_en: 'Invoice #{{id}} - {{date}}',
  facture_message_en: `Hello {{prenom}},

Please find attached the invoice for the work completed on your <strong>{{veloDesc}}</strong>.

Note: {{noteClient}}

Work completed:
{{services}}

Parts:
{{pieces}}

<a href="https://www.google.com/search?q=yako.cyclo">Please leave a rating</a> ⭐️ and <a href="https://www.google.com/search?q=yako.cyclo">a review</a> 👍🏻 if you think the work was done well and the service was courteous.

Please don't hesitate to contact us with any questions.

Best regards,`,

  // ── Vente directe FR ──────────────────────────────────────────
  vente_subject_fr: 'Facture de vente #{{id}} - {{date}}',
  vente_message_fr: `Bonjour {{prenom}},

Veuillez trouver ci-joint la facture pour votre achat.

Note : {{noteClient}}

Pièces :
{{pieces}}

Merci pour votre confiance !`,

  // ── Vente directe EN ──────────────────────────────────────────
  vente_subject_en: 'Sales invoice #{{id}} - {{date}}',
  vente_message_en: `Hello {{prenom}},

Please find attached the invoice for your purchase.

Note: {{noteClient}}

Parts:
{{pieces}}

Thank you for your business!`,

  // ── Signatures HTML ───────────────────────────────────────────
  signature_yako: `<div style="margin-top:16px;font-family:Helvetica Neue,Helvetica,Arial,sans-serif;font-size:14px;color:#222;line-height:1.6;">
  <p style="margin:0 0 8px 0;color:#999;">—</p>
  <p style="margin:0;"><a href="https://www.instagram.com/yako.foto/" style="color:#1a0dab;font-weight:bold;">yako.cyclo</a> <strong>@ Cyclo Flex</strong></p>
  <p style="margin:0;">Ostéo d'vélo et réhabilitation de vélos urbains</p>
  <p style="margin:0;">4109, St-Denis, Montréal</p>
  <p style="margin:0 0 12px 0;"><a href="mailto:yako.cyclo@gmail.com" style="color:#1a0dab;">yako.cyclo@gmail.com</a>, 514 995-3445</p>
  <p style="margin:0;">Jean-Christophe Yacono (yako)</p>
  <p style="margin:0;">Mécaniciens certifiés AEP</p>
  <p style="margin:0 0 12px 0;"><a href="https://www.instagram.com/yako.foto/" style="color:#1a0dab;">yako.cyclo</a> et <a href="https://cycloflex.ca/" style="color:#1a0dab;">Cyclo Flex</a></p>
  <p style="margin:0;"><img src="/logo-yako-cyclo.png" alt="YAKO.CYCLO — entretien et réhabilitation de vélos urbains" width="130" style="border:4px solid #FFD600;"></p>
</div>`,
  signature_cf: `<table style="margin-top:16px;border-top:1px solid #e0e0e0;padding-top:12px;font-family:Helvetica Neue,Helvetica,Arial,sans-serif;font-size:13px;color:#555;">
  <tr><td>
    <strong style="color:#000;">Cyclo Flex Montréal</strong><br>
    Atelier de réparation vélo<br>
    <a href="mailto:cycloflex.mtl@gmail.com" style="color:#555;">cycloflex.mtl@gmail.com</a>
  </td></tr>
</table>`,

  // ── SMS rappel "vélo prêt à ramasser" ─────────────────────────
  // Placeholders : {{prenom}} {{veloDesc}} {{id}} {{montantFacture}}
  // Utilisés par buildReminderUrl — FR/EN selon client.lang.
  sms_rappel_fr: `Bonjour {{prenom}},

un petit rappel pour te dire que ton {{veloDesc}} est prêt à être ramassé chez Cyclo Flex.

Si tu préfères le laisser encore à la boutique, puis-je te demander un règlement via Interac ? {{montantFacture}} au 514 995-3445

Merci et bonne journée`,
  sms_rappel_en: `Hi {{prenom}},

a quick reminder that your {{veloDesc}} is ready to be picked up at Cyclo Flex.

If you'd rather leave it at the shop a bit longer, could I ask you to settle the invoice via Interac ? {{montantFacture}} at 514 995-3445

Thanks and have a great day`,

  // ── Courriel suivi 2 jours après archivage (brouillon Gmail) ──
  // Placeholders : {{prenom}} {{nom}} {{veloDesc}} {{id}}
  courriel_suivi_subject_fr: `Suivi — Cyclo Flex (BDT {{id}})`,
  courriel_suivi_subject_en: `Follow-up — Cyclo Flex (BDT {{id}})`,
  courriel_suivi_fr: `Bonjour {{prenom}},

Je viens aux nouvelles des travaux réalisés sur ton vélo. Tout fonctionne comme tu le souhaitais ?

N'hésite pas à me contacter si jamais tu as des questions ou besoin d'un ajustement.

Si tu veux m'aider à faire connaître notre service et que tu as deux minutes, laisser un commentaire ou une note sur Google ou sur Instagram serait très apprécié.

Merci !
Cyclo Flex`,
  courriel_suivi_en: `Hi {{prenom}},

Just checking in about the recent work done on your bike. Everything running smoothly?

Let me know if you have any questions or need any adjustments.

If you want to help us spread the word and have a couple of minutes, a rating or a short review on Google or Instagram would mean a lot.

Thanks!
Cyclo Flex`,

  // Legacy (conservés pour rétrocompat — l'UI Paramètres les lit en
  // fallback si courriel_suivi_* est vide) :
  sms_suivi_fr: `Bonjour {{prenom}}, je viens aux nouvelles des réparations sur ton vélo. Tout va bien ?`,
  sms_suivi_en: `Hi {{prenom}}, just checking in about the recent work done on your bike. All going well?`,

  // ── Équipe atelier (JSON array de noms) ──────────────────────
  // Ex. ["François","Jean-François","yako"]
  // La chaîne vide "" (non assigné) est toujours présente en tête.
  equipe_list: `["François","Jean-François","yako"]`,

  // Nom court de l'équipe (affiché en en-tête de page Équipe).
  // Ex. « Flex » pour Cyclo Flex.
  equipe_nom         : 'Flex',
  // Localisation de l'atelier (ville). Affichée à droite du nom équipe.
  equipe_localisation: 'Montréal',

  // ── Infos atelier (utilisées signatures, SMS, PDFs) ─────────
  atelier_nom      : 'Cyclo Flex',
  atelier_adresse  : '4109, St-Denis, Montréal',
  atelier_tel      : '514 995-3445',
  atelier_email    : 'yako.cyclo@gmail.com',
  atelier_reviews  : 'https://www.google.com/search?q=yako.cyclo',
  atelier_instagram: 'https://www.instagram.com/yako.foto/',

  // ── Préférences par défaut nouveaux clients ─────────────────
  client_default_commpref: 'Courriel,Texto',
  client_default_lang    : 'FR',

  // ── Sécurité : emails admin (accès /parametres/*) ───────────
  // JSON array. Les utilisateurs dont session.user.email matche une
  // entrée (insensible à la casse) peuvent ouvrir les Paramètres.
  // Toujours inclure yako.cyclo@gmail.com en fallback pour ne jamais
  // perdre l'accès (hardcodé dans useIsAdmin par sécurité).
  admin_emails: `["yako.cyclo@gmail.com"]`,

  // ── Tailles de vélo (éditable via /parametres/catalogue) ────
  velo_tailles: `["XXL","XL","L","M","S","XS","XSS","24","26"]`,

  // ── Seuil alerte stock (valeur minimale souhaitée) ──────────
  // Une pièce avec stock <= ce seuil (et stock > 0, ie. pas encore
  // rupture totale) apparaît dans la section "Stock bas" du Dashboard.
  // 0 = feature désactivée (on ne signale que les qteACommander > 0).
  stock_min_default: '2',

  // ── v1.3.0+ : identité fiscale workshop (footer PDF) ────────
  // Affichés en bas de page de la facture si remplis. Vides = ligne
  // omise. Format conseillé :
  //   workshop_tps : "123456789 RT 0001"
  //   workshop_tvq : "1234567890 TQ 0001"
  //   workshop_neq : "2275992768"
  // Différents par lead (yc = yako.cyclo TA, cf = Cyclo Flex corp).
  workshop_neq_yc : '',          // À remplir si applicable
  workshop_tps_yc : '',          // À remplir quand reçu de l'ARC
  workshop_tvq_yc : '',          // À remplir quand reçu de Revenu Québec
  workshop_neq_cf : '2275992768',
  workshop_tps_cf : '',          // À remplir quand reçu
  workshop_tvq_cf : '',          // À remplir quand reçu
};
