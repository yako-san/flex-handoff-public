/**
 * Catégories comptables pour les dépenses business — inspirées du formulaire
 * T2125 Revenu Canada (États des résultats d'une entreprise). Adaptées au
 * contexte atelier vélo (yako-cyclo / Cyclo Flex).
 *
 * v1.0.26+ : hard-codé dans le code. Si besoin futur d'éditer sans déploiement,
 * migrer vers une clé `depenses_categories` dans le Sheet `_EMAIL_TEMPLATES_`
 * (pattern admin_emails déjà en place).
 */
export const DEPENSE_CATEGORIES = [
  'Achats marchandises pour revente',
  'Transport (taxi, Uber, essence, stationnement)',
  'Repas et représentation',           // 50 % déductible — note dans UI
  'Fournitures de bureau',
  'Outils et petit équipement',
  'Logiciels et abonnements',
  'Téléphone / Internet',
  'Loyer / Local',
  'Publicité et marketing',
  'Honoraires professionnels',         // compta, légal, design, etc.
  'Frais bancaires',
  'Assurances',
  'Formations / Conférences',
  'Entretien et réparations',
  'Autres',
] as const;

export type DepenseCategorie = typeof DEPENSE_CATEGORIES[number];

/** Note d'aide pour certaines catégories (affichée dans l'UI au moment du
 *  choix). Le user voit un petit ⓘ qui explique les particularités fiscales. */
export const DEPENSE_CATEGORIE_HINTS: Partial<Record<string, string>> = {
  'Repas et représentation': '50 % déductible (LTA art. 67.1 + LTVQ art. 421.1). HT et CTI/CTP réduits automatiquement.',
  'Achats marchandises pour revente': 'Pour les achats hors-PO. Les PO formels sont déjà tracés dans /catalogue/reception.',
};

/**
 * v1.0.30+ : Pourcentage déductible par catégorie (LTA art. 67.1 + LTVQ
 * art. 421.1 — règle des 50 % pour repas/représentation).
 *
 * Catégories absentes de cette map = 100 % déductible (défaut).
 *
 * Le calcul effectif d'une dépense applique ce taux AU MULTIPLIE par
 * usagePct/100 :
 *
 *   factor = (CATEGORIE_DEDUCTIBLE_PCT[cat] / 100) × (usagePct / 100)
 *   htDeductible = sousTotalHT × factor
 *   tpsCti       = tps × factor
 *   tvqCtp       = tvq × factor
 *
 * Le sheet conserve toujours les montants PAYÉS bruts (HT, TPS, TVQ tels
 * qu'inscrits sur le reçu). C'est seulement à l'affichage / export /
 * impression que les valeurs effectives sont calculées.
 */
export const CATEGORIE_DEDUCTIBLE_PCT: Record<string, number> = {
  'Repas et représentation': 50,
};

/** Helper : facteur effectif (combinaison catégorie × usage). Retourne
 *  une valeur entre 0 et 1. */
export function deductibleFactor(categorie: string, usagePct?: number | null): number {
  const catPct  = CATEGORIE_DEDUCTIBLE_PCT[categorie] ?? 100;
  const usePct  = (usagePct !== undefined && usagePct !== null && Number.isFinite(usagePct))
    ? Math.max(0, Math.min(100, usagePct))
    : 100;
  return (catPct / 100) * (usePct / 100);
}

/**
 * v1.0.31+ : Mapping catégorie → ligne T2125 (États des résultats des
 * activités d'une entreprise — ARC). Référence : formulaire T2125, partie 5
 * « Dépenses d'entreprise » (lignes 8300 à 9270).
 *
 * Utilisé pour l'export CSV / impression : ajoute une colonne « T2125 ligne »
 * qui permet au comptable de reporter chaque dépense au bon poste sans
 * re-catégoriser à la main.
 *
 * Sources :
 *   - https://www.canada.ca/fr/agence-revenu/services/formulaires-publications/formulaires/t2125.html
 *   - Guide T4002 « Revenus d'entreprise »
 */
export const CATEGORIE_T2125: Record<string, { ligne: string; libelle: string }> = {
  'Achats marchandises pour revente'                   : { ligne: '8320', libelle: 'Achats nets de marchandises destinées à la revente' },
  'Transport (taxi, Uber, essence, stationnement)'     : { ligne: '9281', libelle: 'Frais de véhicule à moteur (sauf DPA)' },
  'Repas et représentation'                            : { ligne: '8523', libelle: 'Repas et frais de représentation' },
  'Fournitures de bureau'                              : { ligne: '8810', libelle: 'Fournitures de bureau' },
  'Outils et petit équipement'                         : { ligne: '8910', libelle: 'Petits outils (< 500 $) — sinon DPA cat. 8' },
  'Logiciels et abonnements'                           : { ligne: '8760', libelle: 'Frais de bureau (incl. logiciels SaaS)' },
  'Téléphone / Internet'                               : { ligne: '9220', libelle: 'Services publics — téléphone, internet, etc.' },
  'Loyer / Local'                                      : { ligne: '8910', libelle: 'Loyer (local commercial)' },
  'Publicité et marketing'                             : { ligne: '8521', libelle: 'Publicité' },
  'Honoraires professionnels'                          : { ligne: '8860', libelle: 'Honoraires professionnels (compta, légal, etc.)' },
  'Frais bancaires'                                    : { ligne: '8710', libelle: 'Intérêts et frais bancaires' },
  'Assurances'                                         : { ligne: '8690', libelle: 'Assurances' },
  'Formations / Conférences'                           : { ligne: '8760', libelle: 'Frais de bureau (formations incluses)' },
  'Entretien et réparations'                           : { ligne: '8960', libelle: 'Entretien et réparations' },
  'Autres'                                             : { ligne: '9270', libelle: 'Autres dépenses' },
};

/** Retourne la ligne T2125 pour une catégorie. '9270' (Autres) en fallback. */
export function t2125LineFor(categorie: string): { ligne: string; libelle: string } {
  return CATEGORIE_T2125[categorie] ?? { ligne: '9270', libelle: 'Autres dépenses' };
}
