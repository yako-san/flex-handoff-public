/**
 * Mini-rendu markdown vers HTML, juste suffisant pour les tutoriels
 * (`docs/tutoriels/*.md`). Pas de dépendance externe : on traite uniquement
 * la grammaire utilisée dans les tutoriels (titres, listes, gras/italique,
 * tableaux, code blocs, séparateurs `---` pour slides).
 *
 * Sortie : { slides: string[] } — un tableau de fragments HTML, un par slide.
 * Le séparateur `---` (sur une ligne seule) découpe en slides.
 */

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/** Inline : gras, italique, code, liens (basique). */
function renderInline(s: string): string {
  let out = escapeHtml(s);
  // Inline code `xxx`
  out = out.replace(/`([^`]+)`/g, '<code>$1</code>');
  // Bold **xxx**
  out = out.replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
  // Italic *xxx* (single star, not at start of line bullet)
  out = out.replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<i>$2</i>');
  // Links [text](url)
  out = out.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" style="color:#0066cc;text-decoration:underline">$1</a>');
  return out;
}

function renderTable(rows: string[]): string {
  // rows[0] = header, rows[1] = ---|---, rows[2..] = body
  if (rows.length < 2) return '';
  const splitRow = (r: string) => r.replace(/^\||\|$/g, '').split('|').map(c => c.trim());
  const header = splitRow(rows[0]);
  const body = rows.slice(2).map(splitRow);
  let html = '<table style="width:100%;border-collapse:collapse;margin:12px 0;font-size:14px"><thead><tr>';
  for (const h of header) {
    html += `<th style="text-align:left;padding:8px 10px;border-bottom:2px solid rgba(0,0,0,0.15);font-weight:700">${renderInline(h)}</th>`;
  }
  html += '</tr></thead><tbody>';
  for (const r of body) {
    html += '<tr>';
    for (const c of r) {
      html += `<td style="padding:8px 10px;border-bottom:1px solid rgba(0,0,0,0.08);vertical-align:top">${renderInline(c)}</td>`;
    }
    html += '</tr>';
  }
  html += '</tbody></table>';
  return html;
}

/** Convertit une slide (markdown brut) en fragment HTML. */
function renderSlide(md: string): string {
  const lines = md.split('\n');
  let html = '';
  let i = 0;
  let inList: 'ul' | 'ol' | null = null;
  let inCode = false;
  let codeBuf: string[] = [];
  let tableBuf: string[] = [];

  const closeList = () => {
    if (inList) {
      html += `</${inList}>`;
      inList = null;
    }
  };
  const flushTable = () => {
    if (tableBuf.length) {
      html += renderTable(tableBuf);
      tableBuf = [];
    }
  };

  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();

    // Code block fence
    if (trimmed.startsWith('```')) {
      closeList();
      flushTable();
      if (!inCode) {
        inCode = true;
        codeBuf = [];
      } else {
        inCode = false;
        html += `<pre style="background:rgba(0,0,0,0.05);padding:12px 14px;border-radius:10px;overflow-x:auto;margin:10px 0;font-size:12px;line-height:1.5"><code>${escapeHtml(codeBuf.join('\n'))}</code></pre>`;
        codeBuf = [];
      }
      i++;
      continue;
    }
    if (inCode) {
      codeBuf.push(line);
      i++;
      continue;
    }

    // Tables
    if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
      closeList();
      tableBuf.push(trimmed);
      i++;
      continue;
    } else {
      flushTable();
    }

    // Empty line
    if (trimmed === '') {
      closeList();
      i++;
      continue;
    }

    // Headings
    const h = /^(#{1,6})\s+(.*)$/.exec(trimmed);
    if (h) {
      closeList();
      const lvl = h[1].length;
      const sizes: Record<number, string> = { 1: '24px', 2: '20px', 3: '17px', 4: '15px', 5: '14px', 6: '13px' };
      const margins: Record<number, string> = { 1: '0 0 12px', 2: '14px 0 8px', 3: '12px 0 6px', 4: '10px 0 4px', 5: '8px 0 4px', 6: '6px 0 4px' };
      html += `<h${lvl} style="font-size:${sizes[lvl]};font-weight:700;margin:${margins[lvl]};color:rgba(0,0,0,0.85)">${renderInline(h[2])}</h${lvl}>`;
      i++;
      continue;
    }

    // Blockquote
    if (trimmed.startsWith('> ')) {
      closeList();
      html += `<blockquote style="border-left:4px solid #fff056;padding:6px 14px;margin:10px 0;color:rgba(0,0,0,0.65);font-style:italic;background:rgba(255,240,86,0.1)">${renderInline(trimmed.slice(2))}</blockquote>`;
      i++;
      continue;
    }

    // Ordered list
    const ol = /^(\d+)\.\s+(.*)$/.exec(trimmed);
    if (ol) {
      if (inList !== 'ol') {
        closeList();
        html += '<ol style="margin:8px 0;padding-left:24px;line-height:1.55">';
        inList = 'ol';
      }
      html += `<li style="margin:4px 0">${renderInline(ol[2])}</li>`;
      i++;
      continue;
    }

    // Unordered list
    if (/^[-*+]\s+/.test(trimmed)) {
      const txt = trimmed.replace(/^[-*+]\s+/, '');
      if (inList !== 'ul') {
        closeList();
        html += '<ul style="margin:8px 0;padding-left:24px;line-height:1.55">';
        inList = 'ul';
      }
      html += `<li style="margin:4px 0">${renderInline(txt)}</li>`;
      i++;
      continue;
    }

    // Paragraph
    closeList();
    html += `<p style="margin:8px 0;line-height:1.55">${renderInline(line)}</p>`;
    i++;
  }
  closeList();
  flushTable();
  if (inCode && codeBuf.length) {
    html += `<pre style="background:rgba(0,0,0,0.05);padding:12px 14px;border-radius:10px;overflow-x:auto"><code>${escapeHtml(codeBuf.join('\n'))}</code></pre>`;
  }
  return html;
}

export function renderTutorialMarkdown(md: string): { slides: string[] } {
  // Découpe sur `---` (ligne seule). Ignore le 1er segment vide possible.
  const parts = md.split(/^\s*---\s*$/m).map(s => s.trim()).filter(Boolean);
  const slides = parts.map(renderSlide);
  return { slides };
}
