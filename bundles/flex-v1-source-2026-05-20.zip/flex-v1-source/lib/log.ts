/**
 * Helper de logs structurés (JSON-line vers stdout/stderr).
 *
 * Format : `{ ts, level, event, ...fields }` — Vercel Logs supporte le
 * filtrage par champ JSON, donc on peut isoler les `event:"sheets-retry"`
 * ou `event:"bdc-create-aborted"` dans le dashboard.
 *
 * Pourquoi pas Pino : sur-dimensionné pour v1 figé. Helper minimal sans
 * dépendance, portable tel quel vers v2 (où on passera à Pino + Axiom/
 * Logtail).
 *
 * Usage :
 *   logInfo('bdc-created', { id: '0042', durationMs: 230 });
 *   logWarn('sheets-retry', { code: 429, attempt: 3 });
 *   logError('bdc-create-aborted', { id: '0042', reason: 'check-failed' });
 */
export type LogLevel = 'info' | 'warn' | 'error';

export interface LogFields {
  [key: string]: unknown;
}

export function log(level: LogLevel, event: string, fields: LogFields = {}): void {
  const line = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    event,
    ...fields,
  });
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);
}

export const logInfo  = (event: string, fields?: LogFields) => log('info',  event, fields);
export const logWarn  = (event: string, fields?: LogFields) => log('warn',  event, fields);
export const logError = (event: string, fields?: LogFields) => log('error', event, fields);

/**
 * Compteur in-memory des retries Sheets API par minute. Reset auto à chaque
 * fenêtre. Permet de mesurer la pression quota sans externe (Sentry/etc.).
 * Lecture via /api/health/google ou logs grep `sheets-retry-window`.
 */
let _retryCount = 0;
let _retryWindow = Math.floor(Date.now() / 60_000);

export function trackSheetsRetry(code: number | string, attempt: number): void {
  const now = Math.floor(Date.now() / 60_000);
  if (now !== _retryWindow) {
    if (_retryCount > 0) {
      logWarn('sheets-retry-window', {
        windowStartedAt: new Date(_retryWindow * 60_000).toISOString(),
        retries        : _retryCount,
      });
    }
    _retryWindow = now;
    _retryCount  = 0;
  }
  _retryCount++;
  logWarn('sheets-retry', { code, attempt, retriesThisWindow: _retryCount });
}

export function getSheetsRetryStats(): { window: number; retries: number } {
  return { window: _retryWindow, retries: _retryCount };
}
