/**
 * Helper de validation zod pour les routes API — v1.1.7 / Item 4 audit.
 *
 * Usage canonique :
 *
 *   import { z } from 'zod';
 *   import { parseBody } from '@/lib/validate';
 *
 *   const BodySchema = z.object({
 *     row    : z.number().int().positive(),
 *     fields : z.record(z.any()).optional(),
 *   });
 *
 *   export async function POST(req: NextRequest) {
 *     const parsed = await parseBody(req, BodySchema);
 *     if (!parsed.ok) return parsed.response;   // 400 structuré
 *     const { row, fields } = parsed.data;     // typé
 *     // ...
 *   }
 *
 * Avant cette consolidation, chaque route validait manuellement avec une
 * cascade de `if (!body.x) throw new Error(...)`. Maintenance pénible,
 * messages d'erreur incohérents, types `any` partout côté handler.
 *
 * Avec zod : 1) parsing typé, 2) erreurs structurées via le code
 * `INVALID_BODY` + tableau `issues` (path + message), 3) refactor V2
 * facilité (les mêmes schémas seront réutilisés côté Next.js 15).
 */
import { NextResponse } from 'next/server';
import type { z } from 'zod';

export type ParseResult<T> =
  | { ok: true;  data: T }
  | { ok: false; response: NextResponse };

/**
 * Parse + valide le body JSON d'une requête contre un schéma zod.
 * Retourne `{ ok: true, data }` ou `{ ok: false, response }` (400 structuré).
 *
 * Le body est lu avec `req.json()` — si le JSON est invalide, on renvoie
 * 400 INVALID_JSON. Sinon on délègue à `schema.safeParse`.
 */
export async function parseBody<S extends z.ZodTypeAny>(
  req: Request,
  schema: S,
): Promise<ParseResult<z.infer<S>>> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return {
      ok: false,
      response: NextResponse.json(
        { error: 'Body JSON invalide', code: 'INVALID_JSON' },
        { status: 400 },
      ),
    };
  }

  const result = schema.safeParse(body);
  if (!result.success) {
    const issues = result.error.issues.map(i => ({
      path   : i.path.join('.') || '(root)',
      message: i.message,
      code   : i.code,
    }));
    return {
      ok: false,
      response: NextResponse.json(
        {
          error : `Validation échouée : ${issues[0]?.path} — ${issues[0]?.message}`,
          code  : 'INVALID_BODY',
          issues,
        },
        { status: 400 },
      ),
    };
  }
  return { ok: true, data: result.data };
}

/**
 * Helper pour parser searchParams via zod (queries GET).
 *
 *   const QuerySchema = z.object({ periode: z.string().min(1) });
 *   const parsed = parseQuery(req.nextUrl.searchParams, QuerySchema);
 */
export function parseQuery<S extends z.ZodTypeAny>(
  params: URLSearchParams,
  schema: S,
): ParseResult<z.infer<S>> {
  const obj: Record<string, string> = {};
  params.forEach((v, k) => { obj[k] = v; });
  const result = schema.safeParse(obj);
  if (!result.success) {
    const issues = result.error.issues.map(i => ({
      path   : i.path.join('.') || '(root)',
      message: i.message,
    }));
    return {
      ok: false,
      response: NextResponse.json(
        {
          error : `Query invalide : ${issues[0]?.path} — ${issues[0]?.message}`,
          code  : 'INVALID_QUERY',
          issues,
        },
        { status: 400 },
      ),
    };
  }
  return { ok: true, data: result.data };
}
