/**
 * Compression client-side d'une image avant upload.
 *
 * Usage : `const compressed = await compressImage(file);`
 * - Redimensionne jusqu'à `maxWidth` px (proportionnel, jamais agrandi)
 * - Encode en JPEG avec qualité adaptative (0.9 → 0.5) jusqu'à passer
 *   sous `maxBytes` (défaut : 3.5 MB, marge sur la limite Vercel 4.5 MB)
 * - Si le décodage échoue (ex. HEIC sur Chrome/Firefox — Safari iOS OK),
 *   retourne le fichier original sans toucher.
 * - Si après compression max, le fichier dépasse toujours `maxBytes`,
 *   retourne quand même le meilleur blob produit (l'appelant peut alors
 *   afficher une erreur de taille).
 */

export interface CompressOptions {
  maxWidth?: number;      // px, défaut 2000
  maxBytes?: number;      // bytes, défaut 3.5 MB
  qualitySteps?: number[]; // qualités JPEG à essayer dans l'ordre
}

const DEFAULT_STEPS = [0.9, 0.82, 0.72, 0.6, 0.5];

/**
 * Lit un File → HTMLImageElement (via ObjectURL). Rejette si le navigateur
 * ne sait pas décoder le format (cas HEIC sur Chrome/Firefox).
 */
function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload  = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('decode-failed')); };
    img.src     = url;
  });
}

/** canvas.toBlob en promesse. */
function canvasToBlob(canvas: HTMLCanvasElement, mime: string, quality: number): Promise<Blob | null> {
  return new Promise(resolve => canvas.toBlob(resolve, mime, quality));
}

/** Remplace l'extension d'un nom de fichier (ex. "IMG.heic" → "IMG.jpg"). */
function withJpgExt(name: string): string {
  const dot = name.lastIndexOf('.');
  return (dot > 0 ? name.slice(0, dot) : name) + '.jpg';
}

export async function compressImage(
  file: File,
  opts: CompressOptions = {},
): Promise<File> {
  // Ne compresse pas les non-images
  if (!file.type.startsWith('image/')) return file;

  const maxWidth     = opts.maxWidth     ?? 2000;
  const maxBytes     = opts.maxBytes     ?? 3.5 * 1024 * 1024;
  const qualitySteps = opts.qualitySteps ?? DEFAULT_STEPS;

  // Si le fichier est déjà sous la limite ET qu'il est probablement déjà
  // optimisé (JPEG/WebP < maxBytes), on peut le skipper pour garder la
  // qualité max. On compresse quand même les HEIC pour les transformer en
  // JPEG (meilleure compatibilité Drive thumbnails / browsers).
  const isHeic = /heic|heif/i.test(file.type) || /\.heic$/i.test(file.name);
  if (file.size <= maxBytes && !isHeic) return file;

  let img: HTMLImageElement;
  try {
    img = await loadImage(file);
  } catch {
    // Decode failed (ex. HEIC sur Chrome/Firefox). On retourne l'original —
    // l'appelant affichera l'erreur de taille si besoin.
    return file;
  }

  // Calcul des dimensions cibles (proportionnel, jamais agrandi)
  const ratio = img.width > maxWidth ? maxWidth / img.width : 1;
  const w = Math.round(img.width  * ratio);
  const h = Math.round(img.height * ratio);

  const canvas = document.createElement('canvas');
  canvas.width  = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) return file;
  ctx.drawImage(img, 0, 0, w, h);

  // Essaie les qualités décroissantes jusqu'à passer sous maxBytes
  let best: Blob | null = null;
  for (const q of qualitySteps) {
    const blob = await canvasToBlob(canvas, 'image/jpeg', q);
    if (!blob) continue;
    best = blob;
    if (blob.size <= maxBytes) break;
  }
  if (!best) return file;

  return new File([best], withJpgExt(file.name), {
    type        : 'image/jpeg',
    lastModified: file.lastModified,
  });
}
