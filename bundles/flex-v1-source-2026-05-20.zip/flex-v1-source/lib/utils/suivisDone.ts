/**
 * Stockage localStorage des BDT dont le "suivi post-archivage" est fait.
 *
 * Clé unique : flex-rev-suivis-done
 * Valeur : { [bdcId]: timestamp ISO }
 *
 * TTL de 60 jours : un suivi > 60j est auto-purgé pour éviter que le
 * storage grossisse indéfiniment. Au-delà, un suivi archivé depuis si
 * longtemps est de toute façon hors du scope Dashboard (2-4j).
 */

const KEY     = 'flex-rev-suivis-done';
const TTL_MS  = 60 * 24 * 60 * 60 * 1000; // 60 jours

function read(): Record<string, string> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return {};
    const obj = JSON.parse(raw);
    if (!obj || typeof obj !== 'object') return {};
    // Purge les entrées expirées au passage
    const now   = Date.now();
    const clean: Record<string, string> = {};
    for (const [k, v] of Object.entries(obj)) {
      if (typeof v !== 'string') continue;
      const t = Date.parse(v);
      if (isNaN(t)) continue;
      if (now - t <= TTL_MS) clean[k] = v;
    }
    return clean;
  } catch { return {}; }
}

function write(data: Record<string, string>) {
  if (typeof window === 'undefined') return;
  try { localStorage.setItem(KEY, JSON.stringify(data)); } catch { /* quota */ }
}

/** Marque un BDT comme "suivi fait" (timestamp = maintenant). */
export function markSuiviDone(bdcId: string): void {
  const d = read();
  d[bdcId] = new Date().toISOString();
  write(d);
}

/** Retire le flag "suivi fait" sur un BDT (retour à "à faire"). */
export function unmarkSuiviDone(bdcId: string): void {
  const d = read();
  delete d[bdcId];
  write(d);
}

/** True si le BDT a été marqué comme suivi fait (et pas expiré). */
export function isSuiviDone(bdcId: string): boolean {
  return bdcId in read();
}

/** Retourne tous les IDs marqués comme done (purge TTL déjà appliquée). */
export function getSuivisDone(): string[] {
  return Object.keys(read());
}
