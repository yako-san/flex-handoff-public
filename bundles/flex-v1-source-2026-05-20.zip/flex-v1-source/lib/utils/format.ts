// ── Texte ─────────────────────────────────────────────────────────

/**
 * Strip le format Markdown que Google Sheets injecte dans `FORMATTED_VALUE`
 * pour les hyperliens : `[texte](url)` → `texte` (ou l'URL si le texte est
 * vide/manquant). Robuste : si pas de match, retourne la string trim().
 *
 * Cas typiques :
 *   "[a@yako.ca](mailto:a@yako.ca)" → "a@yako.ca"
 *   "[Site](https://exemple.com)"   → "Site"
 *   "user@example.com"              → "user@example.com" (inchangé)
 */
export function stripMarkdownLink(s: string): string {
  const v = (s ?? '').trim();
  const m = v.match(/^\[([^\]]*)\]\((?:mailto:)?([^)]+)\)$/);
  if (!m) return v;
  return (m[1] || m[2] || '').trim();
}

// ── Dates ─────────────────────────────────────────────────────────

/**
 * Convertit un numéro de série Google Sheets en date lisible.
 * Google Sheets stocke les dates comme jours depuis le 30 déc 1899.
 * Ex. : 46109.549... → "2026-03-28"
 */
export function sheetsSerialToDateStr(serial: number | string): string {
  if (!serial && serial !== 0) return '';
  const n = typeof serial === 'string' ? parseFloat(serial) : serial;
  if (isNaN(n) || n === 0) return '';
  // offset entre epoch Sheets (1899-12-30) et Unix (1970-01-01) = 25569 jours
  const date = new Date((n - 25569) * 86400 * 1000);
  return date.toLocaleDateString('fr-CA', {
    year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'America/Toronto',
  });
}

/**
 * Retourne une date lisible depuis une valeur Sheets (serial ou string yyyy-MM-dd).
 */
export function parseSheetsDate(val: unknown): string | null {
  if (val === null || val === undefined || val === '') return null;
  if (typeof val === 'number') return sheetsSerialToDateStr(val) || null;
  const s = String(val).split('\n')[0].trim();
  if (!s) return null;
  // Si c'est un numéro de série en string
  if (/^\d{4,6}(\.\d+)?$/.test(s)) return sheetsSerialToDateStr(parseFloat(s)) || null;
  return s;
}

/**
 * Formate un prix en français canadien (ex. 12,50 $).
 * Équivalent de _frPrix() dans le GAS.
 */
export function frPrix(val: number | string | null | undefined): string {
  if (val === null || val === undefined || val === '') return '';
  const num = typeof val === 'number' ? val : parseFloat(String(val).replace(',', '.'));
  if (isNaN(num)) return String(val);
  return new Intl.NumberFormat('fr-CA', {
    style: 'currency', currency: 'CAD', minimumFractionDigits: 2,
  }).format(num);
}

/**
 * Affichage court d'une date (supprime l'heure si présente).
 */
export function frDate(dateStr: string | null | undefined): string {
  if (!dateStr) return '';
  return dateStr.split('\n')[0];
}

/**
 * Retourne "yyyy-MM-dd\nHH:mm HAE" si l'heure est présente, sinon juste
 * la date. Utilisé dans Inventaire pour afficher date + heure du RDV /
 * de réception sur deux lignes (nécessite whiteSpace: 'pre-line' UI).
 * Tolère aussi une ISO UTC : la convertit en heure locale d'abord.
 * L'acronyme HAE / HNE est calculé dynamiquement selon la date
 * (DST respecté).
 */
export function frDateHeure(dateStr: string | null | undefined): string {
  if (!dateStr) return '';
  const s = String(dateStr).trim();
  // Normaliser au format "yyyy-MM-dd\nHH:mm"
  let normalized = s;
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(s)) {
    normalized = isoToMontrealDateHeure(s) || s;
  }
  // Ajouter l'acronyme de fuseau si on a bien date + heure
  const [datePart, timePart] = normalized.split('\n');
  if (datePart && timePart && /^\d{2}:\d{2}/.test(timePart.trim())) {
    // Sonde = midi UTC sur la date ; on récupère le label fuseau à ce
    // moment dans America/Toronto (robuste peu importe le TZ du client)
    const probe = new Date(`${datePart}T12:00:00Z`);
    const tz = estTzLabel(probe);
    const hhmm = timePart.trim().slice(0, 5);
    if (tz && !timePart.includes(tz)) {
      return `${datePart}\n${hhmm} ${tz}`;
    }
    return `${datePart}\n${hhmm}`;
  }
  return normalized;
}

/**
 * Date + heure actuelles au format Sheets : "yyyy-MM-dd\nHH:mm"
 */
export function nowDateHeure(): string {
  const now = new Date();
  const date = now.toLocaleDateString('fr-CA', {
    year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'America/Toronto',
  });
  const time = now.toLocaleTimeString('fr-CA', {
    hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'America/Toronto',
  });
  return `${date}\n${time}`;
}

/**
 * Convertit une chaîne ISO (UTC) en "yyyy-MM-dd\nHH:mm" en heure de l'Est
 * (America/Toronto). Utilisé pour les RDV Square qui arrivent en UTC.
 * Retourne '' si le parse échoue.
 * Note : pas de suffixe HAE/HNE ici (on le stocke pas dans la sheet pour
 * éviter un acronyme figé entre été/hiver) — c'est frDateHeure() qui
 * l'ajoute dynamiquement au rendu.
 */
export function isoToMontrealDateHeure(iso: string | null | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  const date = d.toLocaleDateString('fr-CA', {
    year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'America/Toronto',
  });
  const time = d.toLocaleTimeString('fr-CA', {
    hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'America/Toronto',
  });
  return `${date}\n${time}`;
}

/**
 * v1.0.20+ : variante inline de `isoToMontrealDateHeure` qui retourne
 * `YYYY-MM-DD, HH h MM` (virgule + espace au lieu de retour à la ligne).
 * Utile pour les notes textuelles d'une seule ligne (ex. en-tête de note
 * interne BDT, brouillons emails, etc.).
 */
export function isoToMontrealDateHeureInline(iso: string | null | undefined): string {
  const both = isoToMontrealDateHeure(iso);
  return both ? both.replace('\n', ', ') : '';
}

/**
 * Retourne l'acronyme de l'heure de l'Est pour une date donnée :
 * "HAE" (été, UTC-4) ou "HNE" (hiver, UTC-5), selon l'observation DST
 * pour America/Toronto au moment donné. Retourne '' si la date est
 * invalide.
 */
export function estTzLabel(date: Date): string {
  if (isNaN(date.getTime())) return '';
  const parts = new Intl.DateTimeFormat('fr-CA', {
    hour: '2-digit', minute: '2-digit', hour12: false,
    timeZone: 'America/Toronto', timeZoneName: 'short',
  }).formatToParts(date);
  return parts.find(p => p.type === 'timeZoneName')?.value ?? '';
}

/**
 * Retourne "yyyy-MM-dd" aujourd'hui.
 */
export function todayStr(): string {
  return new Date().toLocaleDateString('fr-CA', {
    year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'America/Toronto',
  });
}

/**
 * Normalise une chaîne pour une recherche accent-insensitive et
 * case-insensitive (ex. "câble" → "cable", "Éval." → "eval.").
 * À utiliser des deux côtés (aiguille et meule de foin) avant includes().
 */
export function normSearch(s: string | null | undefined): string {
  return (s ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

/**
 * Formate un numéro de téléphone en "(000) 000-0000" (NANP 10 digits).
 * Retourne la valeur d'origine (trim) si pas exactement 10 chiffres.
 */
export function formatTel(raw: string | null | undefined): string {
  const s = (raw ?? '').trim();
  if (!s) return '';
  const d = s.replace(/\D/g, '');
  if (d.length === 10) return `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`;
  if (d.length === 11 && d.startsWith('1')) return `(${d.slice(1, 4)}) ${d.slice(4, 7)}-${d.slice(7)}`;
  return s;
}

/** Retourne juste les chiffres d'un numéro (pour tel:/sms:). */
export function telDigits(raw: string | null | undefined): string {
  return (raw ?? '').replace(/\D/g, '');
}

/**
 * Retourne le numéro au format E.164 (+CCCXXXXXXXXXX) pour les liens
 * sms:/tel:. iOS Messages.app refuse les SMS vers numéros sans country
 * code (« Not Delivered »).
 *
 * @param raw       Numéro tapé par l'utilisateur (avec ou sans formatage)
 * @param indicatif Code pays explicite (ex. '+1', '+33'). Default '+1'.
 *                  Ignoré si `raw` commence déjà par '+' (l'utilisateur
 *                  a tapé un E.164 complet — on respecte tel quel).
 *
 * Cas gérés :
 *  - raw commence par '+'         → garde le + et nettoie les non-chiffres
 *  - raw == 11 chiffres et `1`    → +1XXXXXXXXXX (legacy NA avec 1 préfixe)
 *  - raw vide                      → ''
 *  - autres                        → indicatif + chiffres locaux
 */
export function telE164(
  raw: string | null | undefined,
  indicatif: string | null | undefined = '+1',
): string {
  const s = (raw ?? '').trim();
  if (!s) return '';
  // Si l'utilisateur a tapé un + en début, on respecte tel quel
  if (s.startsWith('+')) {
    const d = s.slice(1).replace(/\D/g, '');
    return d ? `+${d}` : '';
  }
  const d = s.replace(/\D/g, '');
  if (!d) return '';
  // Cas legacy NANP : 11 chiffres commençant par 1 → +1XXXXXXXXXX
  if (d.length === 11 && d.startsWith('1')) return `+${d}`;
  const cc = (indicatif || '+1').trim();
  const ccClean = cc.startsWith('+') ? cc : `+${cc.replace(/\D/g, '')}`;
  return `${ccClean}${d}`;
}

/**
 * Pick la meilleure catégorie pour un nom d'item, en comparant les stems
 * (5 premiers caractères) des mots du nom vs les mots de chaque catégorie.
 * Ex. « Lubrifiant céramique sec » → « 6. Produit d'entretien / Lubrification »
 *      (stem « lubri » partagé entre lubrifiant et lubrification).
 * Retourne une string vide si aucun score > 0.
 */
export function autoPickCategorie(itemNom: string, categories: string[]): string {
  if (!itemNom || categories.length === 0) return '';
  const itemWords = normSearch(itemNom)
    .split(/\s+/)
    .filter(w => w.length >= 4);
  if (itemWords.length === 0) return '';

  const STEM_LEN = 5;
  let best = { cat: '', score: 0 };
  for (const cat of categories) {
    const catWords = normSearch(cat)
      .split(/[\s,/\-.]+/)
      .filter(w => w.length >= 4);
    let score = 0;
    for (const iw of itemWords) {
      for (const cw of catWords) {
        const n = Math.min(iw.length, cw.length, STEM_LEN);
        if (n >= 4 && iw.slice(0, n) === cw.slice(0, n)) {
          score += n;
          break; // un seul match par mot d'item
        }
      }
    }
    if (score > best.score) best = { cat, score };
  }
  return best.cat;
}
