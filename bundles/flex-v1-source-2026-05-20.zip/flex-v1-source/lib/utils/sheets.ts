/**
 * Convertit un index de colonne (1-based) en lettre(s) Sheets (A, B, ..., Z, AA, ...).
 * Équivalent de _col(n) dans le GAS.
 */
export function col(n: number): string {
  let s = '';
  let num = n;
  while (num > 0) {
    num--;
    s = String.fromCharCode(65 + (num % 26)) + s;
    num = Math.floor(num / 26);
  }
  return s;
}

/**
 * Construit un range Sheets (ex. "INVENTAIRE!C5:U").
 */
export function range(sheet: string, rowStart: number, colStart: number, rowEnd?: number, colEnd?: number): string {
  const c1 = col(colStart);
  const r1 = rowStart;
  if (rowEnd !== undefined && colEnd !== undefined) {
    return `${sheet}!${c1}${r1}:${col(colEnd)}${rowEnd}`;
  }
  return `${sheet}!${c1}${r1}`;
}

/**
 * Formate un ID vélo sur 4 chiffres (ex. 42 → "0042").
 */
export function padId(n: number): string {
  return String(n).padStart(4, '0');
}
