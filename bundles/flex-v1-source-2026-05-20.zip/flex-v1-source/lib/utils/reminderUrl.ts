import { telE164, frPrix } from './format';
import type { Client } from '@/types/client';

export type ReminderKind = 'sms' | 'email' | 'tel';

export interface Reminder {
  url: string;
  kind: ReminderKind;
  label: string;
}

/**
 * Contexte optionnel pour personnaliser le template SMS rappel.
 * Tous les champs sont optionnels — les placeholders manquants sont
 * remplacés par une chaîne vide.
 */
export interface ReminderContext {
  /** Template SMS FR (raw avec placeholders {{prenom}}, {{veloDesc}}, {{id}}, {{montantFacture}}) */
  smsTemplateFr?: string;
  /** Template SMS EN (mêmes placeholders) */
  smsTemplateEn?: string;
  /** Description du vélo (ex. "Picnica, Pliable, Blanc, S") */
  veloDesc?: string;
  /** Montant facture déjà formaté (ex. "125,00 $") ou 0 pour omettre */
  montantFacture?: number | string;
}

function renderSmsTemplate(
  template: string,
  vars: { prenom: string; veloDesc: string; id: string; montantFacture: string },
): string {
  return template
    .replace(/\{\{\s*prenom\s*\}\}/g, vars.prenom)
    .replace(/\{\{\s*veloDesc\s*\}\}/g, vars.veloDesc || 'vélo')
    .replace(/\{\{\s*id\s*\}\}/g, vars.id)
    .replace(/\{\{\s*montantFacture\s*\}\}/g, vars.montantFacture);
}

/**
 * Construit un lien SMS de **suivi post-archivage** (appel 2 jours après
 * qu'un BDT est archivé). Utilise un template séparé des rappels "vélo
 * prêt" (celui-ci est plus conversationnel, sans montant).
 *
 * Retourne null si le client n'a pas de téléphone.
 */
export function buildFollowupSmsUrl(
  client: Client | undefined,
  bdcId: string,
  ctx: { smsTemplateFr?: string; smsTemplateEn?: string; veloDesc?: string } = {},
): Reminder | null {
  if (!client) return null;
  const tel = telE164(client.tel, client.indicatif);
  if (!tel) return null; // SMS uniquement

  const lang   = client.lang === 'EN' ? 'EN' : 'FR';
  const prenom = client.prenom || '';
  const fallbackFr = `Bonjour ${prenom}, je viens aux nouvelles des réparations sur ton vélo. Tout va bien ?`;
  const fallbackEn = `Hi ${prenom}, just checking in about the recent work done on your bike. All going well?`;
  const template = lang === 'EN' ? (ctx.smsTemplateEn || fallbackEn) : (ctx.smsTemplateFr || fallbackFr);
  const body = renderSmsTemplate(template, {
    prenom,
    veloDesc      : ctx.veloDesc ?? '',
    id            : bdcId,
    montantFacture: '',
  });
  return {
    url  : `sms:${tel}?&body=${encodeURIComponent(body)}`,
    kind : 'sms',
    label: 'SMS suivi',
  };
}

/**
 * Construit l'URL de rappel (SMS / mailto / tel) pour un client donné,
 * avec un message "vélo prêt" pré-rempli en FR ou EN selon client.lang.
 *
 * Priorité imposée (peu importe l'ordre stocké dans commPref) :
 *   Texto > Courriel > Téléphone — le SMS est plus direct pour un
 *   rappel "vélo prêt à ramasser".
 * Fallback (si aucune pref matchée) : SMS > Email > Tel (peu importe prefs).
 *
 * Retourne `null` si le client est introuvable ou sans aucun contact.
 */
export function buildReminderUrl(
  client: Client | undefined,
  bdcId: string,
  ctx: ReminderContext = {},
): Reminder | null {
  if (!client) return null;
  const lang   = client.lang === 'EN' ? 'EN' : 'FR';
  const prenom = client.prenom || '';
  const tel    = telE164(client.tel, client.indicatif);
  const mail   = (client.courriel || '').trim();

  // Montant facture formaté si fourni
  const montantStr = typeof ctx.montantFacture === 'number'
    ? frPrix(ctx.montantFacture)
    : (ctx.montantFacture ?? '');

  // SMS : template customisable depuis Paramètres, fallback aux textes
  // historiques si aucun template fourni.
  const fallbackSmsFr = `Bonjour ${prenom}, votre vélo (BDT ${bdcId}) est prêt à être ramassé chez Cyclo Flex.`;
  const fallbackSmsEn = `Hi ${prenom}, your bike (ID ${bdcId}) is ready for pickup at Cyclo Flex.`;
  const templateFr    = ctx.smsTemplateFr || fallbackSmsFr;
  const templateEn    = ctx.smsTemplateEn || fallbackSmsEn;
  const smsBody       = renderSmsTemplate(
    lang === 'EN' ? templateEn : templateFr,
    {
      prenom,
      veloDesc      : ctx.veloDesc ?? '',
      id            : bdcId,
      montantFacture: montantStr,
    },
  );
  const mailSubject = lang === 'EN' ? 'Your bike is ready — Cyclo Flex' : 'Votre vélo est prêt — Cyclo Flex';
  const mailBody = lang === 'EN'
    ? `Hi ${prenom},\n\nYour bike (ID ${bdcId}) is ready for pickup at Cyclo Flex. Please let us know when you'd like to come by.\n\nThanks,\nCyclo Flex`
    : `Bonjour ${prenom},\n\nVotre vélo (BDT ${bdcId}) est prêt à être ramassé chez Cyclo Flex. Fais-nous savoir quand tu veux passer.\n\nMerci,\nCyclo Flex`;

  const smsUrl  = tel  ? `sms:${tel}?&body=${encodeURIComponent(smsBody)}`                                      : null;
  const mailUrl = mail ? `mailto:${mail}?subject=${encodeURIComponent(mailSubject)}&body=${encodeURIComponent(mailBody)}` : null;
  const telUrl  = tel  ? `tel:${tel}`                                                                            : null;

  const prefs = (client.commPref || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
  const hasTexto    = prefs.some(p => /texto/.test(p));
  const hasCourriel = prefs.some(p => /courriel|email/.test(p));
  const hasPhone    = prefs.some(p => /téléphone|telephone|phone/.test(p));
  if (hasTexto    && smsUrl)  return { url: smsUrl,  kind: 'sms',   label: 'SMS' };
  if (hasCourriel && mailUrl) return { url: mailUrl, kind: 'email', label: 'Courriel' };
  if (hasPhone    && telUrl)  return { url: telUrl,  kind: 'tel',   label: 'Téléphone' };
  // Fallback : n'importe quel moyen dispo
  if (smsUrl)  return { url: smsUrl,  kind: 'sms',   label: 'SMS' };
  if (mailUrl) return { url: mailUrl, kind: 'email', label: 'Courriel' };
  if (telUrl)  return { url: telUrl,  kind: 'tel',   label: 'Téléphone' };
  return null;
}
