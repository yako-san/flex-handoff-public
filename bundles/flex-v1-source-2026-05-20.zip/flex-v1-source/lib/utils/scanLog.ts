/**
 * Log local (localStorage) des codes-barres scannés, pour récupération si
 * la persistance serveur foire (ex. route PATCH qui ignore un champ, token
 * expiré, rate-limit Google Sheets…).
 *
 * Chaque entrée contient :
 *  - timestamp (ISO)
 *  - code : le code-barre brut
 *  - action : ce qui a été fait côté UI
 *  - pieceId + pieceName si associé à une pièce du catalogue
 *  - note libre éventuelle
 *
 * Garde les 200 dernières entrées (FIFO). Ne quitte jamais le navigateur
 * — log purement côté client pour diagnostic / rattrapage manuel.
 */

const KEY     = 'flex-rev-scan-log';
const MAX     = 200;

export type ScanAction =
  | 'matched-barcode'   // match par codeBarre existant
  | 'matched-sku'       // match par SKU (fallback)
  | 'mapped-existing'   // code inconnu → associé à une pièce existante
  | 'created-new'       // code inconnu → nouvelle pièce créée
  | 'unknown-cancelled' // code inconnu → modal fermé sans action
  | 'unknown';          // code inconnu (état transitoire avant décision)

export interface ScanLogEntry {
  timestamp: string;     // ISO
  code     : string;     // code scanné brut (EAN/UPC/SKU…)
  action   : ScanAction;
  pieceId? : string;     // si associé
  pieceName?: string;
  note?    : string;
}

function read(): ScanLogEntry[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch { return []; }
}

function write(entries: ScanLogEntry[]) {
  if (typeof window === 'undefined') return;
  try {
    const trimmed = entries.slice(-MAX);
    localStorage.setItem(KEY, JSON.stringify(trimmed));
  } catch { /* quota exceeded : ignore */ }
}

/** Ajoute une entrée au log (garde les 200 dernières). */
export function logScan(entry: Omit<ScanLogEntry, 'timestamp'>): void {
  const full: ScanLogEntry = { ...entry, timestamp: new Date().toISOString() };
  const current = read();
  current.push(full);
  write(current);
}

/** Retourne le log, plus récent en premier. */
export function getScanLog(): ScanLogEntry[] {
  return read().slice().reverse();
}

/** Efface tout le log. */
export function clearScanLog(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(KEY);
}

/**
 * Met à jour la DERNIÈRE entrée avec un code donné (utile pour passer de
 * 'unknown' → 'mapped-existing' / 'created-new' sans dupliquer le scan).
 */
export function updateLastScanAction(
  code: string,
  patch: Partial<Omit<ScanLogEntry, 'timestamp' | 'code'>>,
): void {
  const current = read();
  for (let i = current.length - 1; i >= 0; i--) {
    if (current[i].code === code) {
      current[i] = { ...current[i], ...patch };
      write(current);
      return;
    }
  }
}

/** Exporte le log en CSV (pour backup / partage). UTF-8 BOM + RFC 4180. */
export function scanLogToCsv(): string {
  const entries = read();
  const esc = (v: string | undefined): string => {
    const s = v ?? '';
    if (s.includes(',') || s.includes('"') || s.includes('\n')) {
      return `"${s.replace(/"/g, '""')}"`;
    }
    return s;
  };
  const header = 'timestamp,code,action,pieceId,pieceName,note';
  const lines  = entries.map(e =>
    [esc(e.timestamp), esc(e.code), esc(e.action), esc(e.pieceId), esc(e.pieceName), esc(e.note)].join(',')
  );
  return '\uFEFF' + header + '\n' + lines.join('\n') + '\n';
}
