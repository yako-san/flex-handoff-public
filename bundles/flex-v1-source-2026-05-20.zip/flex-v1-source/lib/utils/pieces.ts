/**
 * Nettoie le nom d'une pièce : retire "(Stock X)" et les lignes secondaires.
 * Équivalent de _pceNomClean() dans le GAS.
 */
export function pceNomClean(raw: string): string {
  return String(raw).split('\n')[0].replace(/\s*\(Stock\s*[\d,.]+\).*$/i, '').trim();
}

/**
 * Retire les préfixes décoratifs (emojis, symboles, ":", "◆", "⚙️", etc.)
 * au début du nom d'une pièce. Permet le matching avec le nom canonique
 * stocké dans le catalogue PIÈCES qui n'a pas ces préfixes.
 *
 * Ex. "⚙️ : Babac, Poteau de selle..." → "Babac, Poteau de selle..."
 *     "◆ Kenda, 26''..."              → "Kenda, 26''..."
 */
export function stripIconPrefix(raw: string): string {
  // Retire tout ce qui n'est pas une lettre ASCII / chiffre / accent au début.
  return String(raw).replace(/^[^a-zA-Z0-9À-ÿ]+/, '').trim();
}

/**
 * Formate le nom d'affichage d'une pièce avec son stock.
 * Retourne { label, stockInfo } pour un rendu <span> séparé.
 * stockInfo est toujours renvoyé (même si stock = 0).
 */
export function pceNomAvecStock(nom: string, stock: number): { label: string; stockInfo: string } {
  const label = pceNomClean(nom);
  const stockInfo = `(stock ${stock ?? 0})`;
  return { label, stockInfo };
}

/**
 * v1.1.5+ — Nom normalisé pour matching catalogue/BDT (fallback quand
 * pieceId n'est pas disponible). Retire stock affiché, préfixes décoratifs,
 * minuscules, multi-espaces.
 */
export function normalizePieceName(raw: string): string {
  return stripIconPrefix(pceNomClean(raw))
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * v1.1.5+ — Clé stable pour indexer une pièce dans une Map, qu'elle
 * vienne d'un BDC item ou du catalogue. Privilégie le pieceId (col O
 * pour BDT, col A pour catalogue) car il survit aux renames de nom.
 * Tombe sur le nom normalisé si pieceId absent (items BDT pré-migration
 * ou non matchés à la migration). Format : `id:P00042` ou `nom:xxx…`.
 *
 * Producer ET consumer doivent appeler cette fonction sur leur source
 * pour que le matching soit symétrique (pieceId↔pieceId, nom↔nom).
 */
export function pieceKey(piece: { pieceId?: string; nom: string }): string {
  if (piece.pieceId && piece.pieceId.trim() !== '') {
    return `id:${piece.pieceId.trim()}`;
  }
  return `nom:${normalizePieceName(piece.nom)}`;
}
