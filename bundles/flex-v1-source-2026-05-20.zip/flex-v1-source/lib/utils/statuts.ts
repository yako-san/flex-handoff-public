import type { VeloStatus } from '@/types/velo';

export const STATUTS: Record<string, { bg: string; fg: string }> = {
  'RV'           : { bg: '#fff056', fg: '#000000' }, // même couleur que REÇU, pré-inscription Square
  'REÇU'         : { bg: '#fff056', fg: '#000000' },
  'ÉVAL.'        : { bg: '#fff056', fg: '#000000' }, // jaune — groupé avec RV/REÇU en tête d'inventaire (2026-05-16)
  'EN ATTENTE'   : { bg: '#fb923c', fg: '#000000' }, // orange — attente décision client
  'ON BENCH'     : { bg: '#5cd62b', fg: '#000000' },
  'CTRL QLTÉ' : { bg: '#2e7d32', fg: '#ffffff' },
  'FINI'         : { bg: '#fce4ec', fg: '#c62828' },
  'LIVRÉ'        : { bg: '#e0e0e0', fg: '#333333' },
  'FACTURER'     : { bg: '#e53935', fg: '#ffffff' },
  'FACTURÉ'      : { bg: '#ffcdd2', fg: '#b71c1c' },
  'APPROUVÉ'     : { bg: '#62e335', fg: '#000000' },
  // v1.0.20+ : REFUSÉ (archiveStatus pour BDT éval refusée) — rouge franc
  // pour ressortir clairement vs FACTURER (rouge similar) et FACTURÉ (rose).
  'REFUSÉ'       : { bg: '#d92020', fg: '#ffffff' },
};

/** Options affichées dans le dropdown statut (workflow normal). */
export const DROPDOWN_STATUTS: VeloStatus[] = [
  'REÇU', 'ÉVAL.', 'EN ATTENTE', 'APPROUVÉ', 'ON BENCH', 'CTRL QLTÉ', 'FACTURÉ', 'LIVRÉ',
];

/** Ordre complet du workflow (pour le tri des BDC). */
export const STATUTS_ORDER: VeloStatus[] = [
  'RV', 'REÇU', 'ÉVAL.', 'EN ATTENTE', 'APPROUVÉ', 'ON BENCH', 'CTRL QLTÉ', 'FINI', 'FACTURER', 'FACTURÉ', 'LIVRÉ',
];

export function getStatutStyle(statut: string): { backgroundColor: string; color: string } {
  const s = STATUTS[statut];
  if (!s) return { backgroundColor: '#f5f5f5', color: '#000000' };
  return { backgroundColor: s.bg, color: s.fg };
}

/**
 * v1.1.4 — Item 6 audit : helper unifié pour l'affichage statut d'un BDT
 * archivé (page /archives + modal ArchiveDetailModal). Auparavant 2 copies
 * locales d'une fonction `statutColors` (drift garanti à long terme).
 *
 *   - REFUSÉ / REFUSE → rouge franc `#d92020`, label "REFUSÉ"
 *   - Autres          → gris neutre, label "Archivé"
 */
export function getArchiveStatutDisplay(
  status: string | undefined,
): { bg: string; fg: string; label: string } {
  const s = (status ?? '').trim().toUpperCase();
  if (s === 'REFUSÉ' || s === 'REFUSE') {
    return { bg: STATUTS['REFUSÉ'].bg, fg: STATUTS['REFUSÉ'].fg, label: 'REFUSÉ' };
  }
  return { bg: '#e0e0e0', fg: 'rgba(0,0,0,0.5)', label: 'Archivé' };
}

/**
 * v1.1.4 — Item 6 audit : style des pills statut d'un Purchase Order
 * (page /catalogue/reception). Extrait du STATUS_STYLE local pour
 * centraliser le vocabulaire couleur (cohérent avec le reste de l'app).
 *
 * Les clés correspondent au champ `PO.status` (sans accent). Le label
 * accentué est exposé séparément via `PO_STATUS_LABEL`.
 */
export const PO_STATUS_STYLE: Record<string, { bg: string; fg: string }> = {
  'EN ATTENTE': { bg: '#fff9c4', fg: '#f9a825' },
  'PARTIEL'   : { bg: '#ffcdd2', fg: '#c62828' },
  'RECU'      : { bg: '#c8e6c9', fg: '#2e7d32' },
  'ANNULE'    : { bg: '#ffcdd2', fg: '#c62828' },
};

export const PO_STATUS_LABEL: Record<string, string> = {
  'EN ATTENTE': 'EN ATTENTE',
  'PARTIEL'   : 'PARTIEL',
  'RECU'      : 'REÇU',
  'ANNULE'    : 'ANNULÉ',
};

// ── Statuts pièces/CMD ──────────────────────────────────────────────
// Légende (du plus prioritaire au moins prioritaire) :
//   √  Pièce à commander   ← priorité 1
//   $  Pièce en commande   ← priorité 2
//   $$ Pièce reçue         ← priorité 3
//   —  Pièce estimée       ← priorité 4
//   ...Pièce listée        ← priorité 5

export const CMD_OPTIONS = ['...', '—', '√', '$', '#', '@'] as const;
export type  CmdFlag     = typeof CMD_OPTIONS[number];

export const CMD_STYLE: Record<string, { bg: string; fg: string; label: string }> = {
  '...' : { bg: '#ffffff', fg: '#000000', label: 'Pièce listée'      },
  '—'   : { bg: '#ffcfc9', fg: '#b10202', label: 'Pièce estimée'     },
  '√'   : { bg: '#d4edbc', fg: '#11734b', label: 'Pièce à commander' },
  '$'   : { bg: '#ffff00', fg: '#473821', label: 'Pièce en commande'  },
  '#'   : { bg: '#ffe0b2', fg: '#e65100', label: 'Réception partielle' },
  '@'   : { bg: '#00ff00', fg: '#000000', label: 'Pièce reçue'       },
};

/** Texte du tooltip à placer sur tous les <select> de statut pièce */
export const CMD_TOOLTIP =
  '... Pièce listée\n' +
  '—   Pièce estimée\n' +
  '√   Pièce à commander ← priorité 1\n' +
  '$   Pièce en commande  ← priorité 2\n' +
  '#   Réception partielle ← priorité 3\n' +
  '@   Pièce reçue        ← priorité 4';

/** Couleurs fixes des colonnes responsables (éval/méca/ctrl) */
export const OPQ_COLORS = {
  eval: { bg: '#d9ead3', fg: '#38761d' },
  meca: { bg: '#b6d7a8', fg: '#38761d' },
  ctrl: { bg: '#93c47d', fg: '#274e13' },
};

/**
 * Calcule la transition de statut quand un mécanicien est assigné à
 * une étape (eval/meca/ctrl). Renvoie le nouveau statut, ou null si pas
 * de transition (mécano vidé, statut déjà plus avancé, etc.).
 *
 * Règles :
 *  - Assigner un mécano à éval : RV/REÇU → ÉVAL.
 *  - Assigner un mécano à méca : RV/REÇU/ÉVAL./APPROUVÉ → ON BENCH
 *  - Assigner un mécano à ctrl : ON BENCH → CTRL QLTÉ
 */
export function nextStatusOnAssign(
  field: 'eval' | 'meca' | 'ctrl',
  newMecano: string,
  currentStatus: string,
): VeloStatus | null {
  if (!newMecano) return null; // assignation vidée → pas de progression
  const cur = STATUTS_ORDER.indexOf(currentStatus as VeloStatus);
  const evalIdx = STATUTS_ORDER.indexOf('ÉVAL.');

  if (field === 'eval') {
    // Tout statut antérieur à ÉVAL. (ou inconnu) → ÉVAL.
    if (cur < 0 || cur < evalIdx) return 'ÉVAL.';
  } else if (field === 'meca') {
    if (currentStatus === 'RV' || currentStatus === 'REÇU' || currentStatus === 'ÉVAL.' || currentStatus === 'APPROUVÉ') return 'ON BENCH';
  } else if (field === 'ctrl') {
    if (currentStatus === 'ON BENCH') return 'CTRL QLTÉ';
  }
  return null;
}
