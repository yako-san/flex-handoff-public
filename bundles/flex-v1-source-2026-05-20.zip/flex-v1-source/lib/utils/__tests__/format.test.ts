import { describe, it, expect } from 'vitest';
import { stripMarkdownLink } from '../format';

describe('stripMarkdownLink — strip format hyperlink Sheets', () => {
  it('extrait l\'email d\'un mailto Markdown', () => {
    expect(stripMarkdownLink('[a@yako.ca](mailto:a@yako.ca)')).toBe('a@yako.ca');
  });

  it('extrait le label d\'un lien web Markdown (et non l\'URL)', () => {
    expect(stripMarkdownLink('[Site](https://exemple.com)')).toBe('Site');
  });

  it('utilise l\'URL si le label est vide', () => {
    expect(stripMarkdownLink('[](mailto:a@b.ca)')).toBe('a@b.ca');
  });

  it('retourne tel quel si pas de Markdown', () => {
    expect(stripMarkdownLink('user@example.com')).toBe('user@example.com');
  });

  it('trim les espaces', () => {
    expect(stripMarkdownLink('  user@example.com  ')).toBe('user@example.com');
    expect(stripMarkdownLink('  [a@b.ca](mailto:a@b.ca)  ')).toBe('a@b.ca');
  });

  it('Edge : string vide retourne string vide', () => {
    expect(stripMarkdownLink('')).toBe('');
    expect(stripMarkdownLink('   ')).toBe('');
  });

  it('Edge : Markdown malformé (pas de fermeture) → tel quel', () => {
    expect(stripMarkdownLink('[user@example.com')).toBe('[user@example.com');
    expect(stripMarkdownLink('[user@example.com](mailto:')).toBe('[user@example.com](mailto:');
  });

  it('Edge : Markdown imbriqué inattendu → safe fallback', () => {
    // Le regex demande exact match du début à la fin → tout Markdown malformé
    // ou imbriqué retourne le texte original.
    expect(stripMarkdownLink('prefix [a@b.ca](mailto:a@b.ca) suffix'))
      .toBe('prefix [a@b.ca](mailto:a@b.ca) suffix');
  });
});
