import type { Velo, VeloStatus } from './velo';
import type { BDC } from './bdc';
import type { Client, ClientsGrouped } from './client';
import type { Piece, Service, Marque } from './catalogue';

// ── Inventaire ────────────────────────────────────────────────────

export interface PostVeloBody {
  client?: string;
  marque?: string;
  modele?: string;
  couleur?: string;
  taille?: string;
  serie?: string;
}

export interface PostVeloResponse {
  id: string;
  velo: Velo;
}

export interface PatchVeloBody {
  status?: VeloStatus;
  client?: string;
  marque?: string;
  modele?: string;
  couleur?: string;
  taille?: string;
  serie?: string;
  noteVelo?: string;
  eval?: string;
  meca?: string;
  ctrl?: string;
  notes?: string;
}

// ── BDC ───────────────────────────────────────────────────────────

export type BDCAction = 'approuver' | 'bon-de-sortie' | 'reset-eval' | 'reset-facture' | 'reset-archive' | 'set-eval-status';

export interface PatchBDCBody {
  action: BDCAction;
  /** Pour action 'set-eval-status' : '' | APPROUVE | REDUX | ATTENTE | REFUSE */
  evalStatus?: '' | 'APPROUVE' | 'REDUX' | 'ATTENTE' | 'REFUSE';
}

// ── Clients ───────────────────────────────────────────────────────

export interface GetClientsResponse extends ClientsGrouped {}

// ── Catalogue ─────────────────────────────────────────────────────

export interface GetPiecesResponse { pieces: Piece[] }
export interface GetServicesResponse { services: Service[] }
export interface GetMarquesResponse { marques: Marque[] }

// ── Generic ───────────────────────────────────────────────────────

export interface ApiError {
  error: string;
  detail?: string;
}

export interface StubResponse {
  status: 'stub';
  message: string;
}
