/**
 * Dépense business — pour compilation TPS/TVQ trimestrielle + déclaration
 * fin d'année (T2125 Revenu Canada).
 *
 * Source : onglet `_DEPENSES_` du doc INVENTAIRE-FLEX-REV.
 * Accès : admin only (requireAdmin côté serveur + filter LOGO_MENU côté UI).
 */

export type ModePaiementDepense = 'comptant' | 'interac' | 'cartes' | 'virement';

export interface Depense {
  /** Numéro de ligne dans Sheets (pour PATCH/DELETE ciblé). */
  _row: number;
  /** ID stable séquentiel, ex. 'D0042'. */
  id: string;
  /** Date du reçu (ISO YYYY-MM-DD). */
  date: string;
  /** Fournisseur / commerçant. Texte libre. */
  fournisseur: string;
  /** Catégorie comptable (cf DEPENSE_CATEGORIES dans lib/depenses-categories.ts). */
  categorie: string;
  /** Description libre — « café meeting client », « pneus Canadian Tire », etc. */
  description: string;
  /** Sous-total avant taxes. */
  sousTotalHT: number;
  /** TPS payée (5 % typique au Québec). Éditable manuellement pour cas TVH /
   *  taxes non standard (autres provinces, reçus parsés différemment). */
  tps: number;
  /** TVQ payée (9,975 % typique). Idem éditable. */
  tvq: number;
  /** Total TTC = sousTotalHT + tps + tvq. */
  totalTTC: number;
  /** Mode de paiement. */
  modePaiement: ModePaiementDepense;
  /** URL du reçu (Drive, Dropbox, etc.). Optionnel — certains achats n'ont
   *  pas de reçu papier (abonnements web par exemple). */
  recuUrl?: string;
  /** Note interne libre. */
  notes?: string;
  /** Date de soft-delete (archivage). null = active. */
  dateOut: string | null;
  /** v1.0.30+ : numéro d'entreprise du fournisseur (NE / GST / TPS). Optionnel
   *  pour facture < 30 $ HT ; obligatoire au-delà pour pouvoir réclamer le
   *  CTI/CTP au QC sans risque sur audit Revenu Québec (LTA art. 169(4),
   *  LTVQ art. 201, Règl. LTA art. 3). Format libre — le user saisit tel que
   *  sur le reçu. */
  numeroEntreprise?: string;
  /** v1.0.30+ : pourcentage d'usage business (1-100). Défaut 100. Utilisé
   *  pour les dépenses mixtes perso/business (téléphone, internet, loyer
   *  résidentiel, transport). T2125 partie 7. Le HT déductible et le CTI/CTP
   *  réclamables sont multipliés par ce ratio. */
  usagePct?: number;
}

export interface DepenseInput {
  date: string;
  fournisseur: string;
  categorie: string;
  description: string;
  sousTotalHT: number;
  tps: number;
  tvq: number;
  modePaiement: ModePaiementDepense;
  recuUrl?: string;
  notes?: string;
  /** v1.0.30+ */
  numeroEntreprise?: string;
  /** v1.0.30+ */
  usagePct?: number;
}
