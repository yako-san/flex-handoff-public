export interface EquipeMember {
  /** Ligne réelle dans le sheet _EQUIPE_ (pour patch ciblé). */
  _row: number;
  /** Prénom — col B (renommé depuis « Nom » legacy en v7.0.20). */
  prenom: string;
  /** Nom de famille — col K (NOUVEAU v7.0.20, fin de ligne pour ne pas
   *  casser les lignes existantes). */
  nom: string;
  /** Surnom court (ex. « yako » pour Jean-Christophe Yacono). Affiché
   *  dans le menu de gauche à la place du courriel quand le user
   *  connecté correspond à ce membre (lookup par courriel). */
  surnom: string;
  courriel: string;
  tel: string;
  /** Indicatif pays E.164 (ex. '+1', '+33'). Default '+1'. */
  indicatif: string;
  lang: 'FR' | 'EN';
  /** Rôle libre (ex. « Mécanicien », « Gérant », « Apprenti »). */
  role: string;
  /** Si false, le membre n'apparaît pas dans les dropdowns BDT. */
  active: boolean;
  notes: string;
}

export type EquipeMemberFormData = Omit<EquipeMember, '_row'>;
