export interface POLineItem {
  nom: string;
  sku: string;
  qteCommandee: number;
  qteRecue: number;
  prixAchat: number;
  recu: boolean;
  /** Numéro de ligne dans le sheet PIÈCES (pour mise à jour stock). -1 si non trouvé. */
  pieceRow: number;
  /** ID stable de la pièce (col A du sheet PIÈCES). Prioritaire sur pieceRow. */
  pieceId: string;
  notes: string;
  /** Catégorie catalogue utilisée lors de l'auto-création (ex. « 6. Produit
   *  d'entretien / Lubrification »). Vide jusqu'à ce que l'utilisateur la
   *  sélectionne dans le dropdown de Réception. Persistée en col O de _PO_. */
  categorie?: string;
}

export interface PO {
  poNumber: string;
  fournisseur: string;
  dateCommande: string;
  dateReception: string | null;
  status: 'EN ATTENTE' | 'PARTIEL' | 'RECU' | 'ANNULE';
  /** v1.1.3 — Item 2 idempotence : ISO timestamp du sync-stock initial.
   *  `null` tant que `syncStockForPO` n'a jamais été appelée pour ce PO.
   *  Persistée en col P de la 1ʳᵉ ligne du PO. */
  stockSyncedAt: string | null;
  items: POLineItem[];
  /** Lignes Sheet (1-based) occupées par ce PO dans l'onglet _PO_ */
  _rows: number[];
}

export type POStatus = PO['status'];
