export interface VenteItem {
  /** ID stable de la pièce (col A du sheet PIÈCES) */
  pieceId: string;
  sku: string;
  nom: string;
  qte: number;
  prixUnit: number;
  /** qte * prixUnit */
  sousTotal: number;
}

export interface Vente {
  /** Date ISO (YYYY-MM-DD) */
  date: string;
  client: string;
  items: VenteItem[];
  total: number;
  /** Lignes occupées dans le sheet _VENTES_ */
  _rows: number[];
  /** ID unique de la vente (timestamp) */
  venteId: string;
  /** Numéro de facture séquentiel (F2026-0001) — absent tant que pas facturée */
  factureNumero?: string;
  /** Date de facturation (ISO YYYY-MM-DD) */
  factureDate?: string;
  /** webViewLink Drive du PDF de facture */
  factureUrl?: string;
  /** true si les prix COST ont été utilisés à la création (col L _VENTES_) */
  cost?: boolean;
  /** Type de la remise appliquée à la facture (col M _VENTES_) */
  remiseType?: 'pct' | 'fixed';
  /** Valeur de la remise (col N _VENTES_) : % si type=pct, $ si type=fixed */
  remiseValue?: number;
  /** v7.0.22+ : mode de paiement persisté à la facturation (col O _VENTES_). */
  modePaiement?: 'comptant' | 'interac' | 'cartes';
  /** v1.1.5+ (cluster 4 item m) : statut paiement (col P _VENTES_).
   *  Vide tant que vente non payée. 'payé' une fois encaissé.
   *  Une vente n'est archivable que si payeStatus === 'payé'. */
  payeStatus?: 'payé' | '';
}
