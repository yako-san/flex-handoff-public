export type CommPref = 'Téléphone' | 'Texto' | 'Courriel';
export type Lead = 'Cyclo Flex' | 'yako.cyclo';
export type Lang = 'FR' | 'EN';

export interface Client {
  _row: number;
  prenom: string;
  nom: string;
  nomComplet: string; // `${prenom} ${nom}`
  tel: string;
  /** Indicatif pays E.164 (ex. '+1', '+33'). Default '+1' si vide. Col P. */
  indicatif?: string;
  courriel: string;
  commPref: CommPref | string;
  bdcIds: string[];    // col I — multi-ligne split \n
  velos: string[];     // col J — multi-ligne split \n
  dateIn: string;
  dateOut: string | null; // null = actif
  lead: Lead | string;
  notes: string;
  lang: Lang;          // col N — préférence de langue pour communications
  /** % de remise par défaut à appliquer aux prochaines factures du client
   *  (0, 10, 15, 25, 50). 0 = pas de remise. Col O. */
  remise?: number;
  /** Adresse postale (livraison/ramassage). Col Q. Texte libre multi-ligne. */
  adressePostale?: string;
  /** v1.1.11+ : facturation employeur (rare — cas corporatif). Si rempli,
   *  ajouté sur le PDF facture sous la mention « À l'attention de ». Col R. */
  entrepriseName?: string;
  /** v1.1.11+ : adresse de l'employeur. Col S. Texte libre multi-ligne. */
  entrepriseAdresse?: string;
  googleResourceName?: string; // col H — ID du contact Google (people/c…) pour sync
}

export interface ClientFormData {
  prenom: string;
  nom: string;
  tel: string;
  indicatif?: string;
  courriel: string;
  commPref: CommPref;
  lead: Lead;
  notes?: string;
  lang: Lang;
  remise?: number;
  /** Adresse postale (livraison/ramassage). Texte libre multi-ligne. */
  adressePostale?: string;
  /** v1.1.11+ : facturation employeur (cas corporatif). */
  entrepriseName?: string;
  entrepriseAdresse?: string;
}

export interface ClientsGrouped {
  recents: Client[];
  actifs: Client[];
  autres: Client[];
}
