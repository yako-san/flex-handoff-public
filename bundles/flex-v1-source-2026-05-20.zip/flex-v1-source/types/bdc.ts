export type BDCTag = 'BON' | 'GAP' | 'SEP0' | 'ITEM' | 'BTN' | 'TOT' | 'SEP';

export interface BDCServiceItem {
  serviceId?: string;  // col I — ID stable du service catalogue (S00001…)
  nom: string;
  fait: boolean;
  status: string;
  prix: number;
  /** v1.0.7+ : pour les services forfait, état persisté de chaque sous-item
   *  (cross-device). Stocké en col J (EVAL_ST inutilisée sur ligne ITEM
   *  service) sous forme JSON `[true, false, ...]`. Aligné sur l'ordre
   *  des sous-items du catalogue. undefined si pas encore initialisé. */
  subStates?: boolean[];
}

export interface BDCPieceItem {
  /** v1.1.5+ : pieceId stable du catalogue (P00001…) — col O. Permet de
   *  retrouver la pièce malgré un rename de nom. Optionnel pour rétrocompat
   *  (items BDT existants pré-migration). Tous les nouveaux items écrivent
   *  ce champ ; la migration `/api/admin/migrate-bdc-pceid` le backfille
   *  sur les items historiques. */
  pieceId?: string;
  nom: string;
  prix: number;
  cmd: string;       // —/√/$/$$ — statut de la commande
  qte: number;
  sousTotal: number;
  flag: string;
  cmdNote: string;   // col W — note libre de commande fournisseur
}

export interface BDCItem {
  service?: BDCServiceItem;
  piece?: BDCPieceItem;
  /** Numéro de ligne Sheets de cet ITEM (pour PATCH ciblé) */
  _row: number;
}

/** Statut d'évaluation côté client — 4 états mutuellement exclusifs.
 *  '' = pas encore décidé. Stocké en col J de la ligne BON.
 *  Backwards compat : si vide ET checkOk=true → APPROUVE. */
export type EvalStatus = '' | 'APPROUVE' | 'REDUX' | 'ATTENTE' | 'REFUSE';

export interface BDC {
  id: string;
  dateIn: string;
  /** Date d'archivage — col BDS ou OUT dans Sheets (optionnel) */
  dateOut?: string;
  veloDesc: string;
  clientNom: string;
  /** Note visible par le client pour l'ÉVALUATION (col V ligne GAP) */
  noteClient: string;
  /** Note visible par le client pour la FACTURE (col W ligne GAP) */
  noteClientFacture?: string;
  checkEval: boolean;
  checkOk: boolean;
  checkBds: boolean;
  checkOut: boolean;
  /** Statut éval client (col J ligne BON) — Approuvée/Redux/En attente/Refusée. */
  evalStatus?: EvalStatus;
  items: BDCItem[];
  totalServices: number;
  totalPieces: number;
  /** Numéro de ligne Sheets de la ligne BON */
  _bonRow: number;
  /** Statut lu depuis ARCHIVES col C (uniquement pour les BDC archivés).
   *  Vaut 'REFUSÉ' pour les évaluations refusées, sinon 'LIVRÉ'/'FACTURÉ' etc. */
  archiveStatus?: string;
  /** Note libre sur le vélo (col N de INVENTAIRE, copiée dans ARCHIVES). */
  noteVelo?: string;
  /** Mécanicien évaluation (col O de ARCHIVES / INVENTAIRE). */
  evalMecano?: string;
  /** Mécanicien mécanique (col P de ARCHIVES / INVENTAIRE). */
  mecaMecano?: string;
  /** Mécanicien ctrl. qlté (col Q de ARCHIVES / INVENTAIRE). */
  ctrlMecano?: string;
  /** Note interne (col W de ARCHIVES). */
  noteInterne?: string;
  /** Remise services persistée (col I de la ligne BON, JSON). */
  remiseSvc?: { type: 'pct' | 'fixed'; value: number };
  /** Remise pièces persistée (col I de la ligne BON, JSON). */
  remisePce?: { type: 'pct' | 'fixed'; value: number };
  /** v1.0.15+ : avance (acompte) versée par le client.
   *  Réduit le « reste à payer » sans toucher aux taxes (qui restent
   *  calculées sur le total HT complet). Persistée en col I (JSON).
   *
   *  v1.0.17+ : devient un objet {montant, mode, note}. Le parser
   *  accepte aussi l'ancien format `number` et le promeut en
   *  `{montant: n}` (back compat). */
  avance?: {
    montant: number;
    mode?: 'comptant' | 'interac' | 'cartes';
    note?: string;
  };
}

export interface AddItemsPayload {
  bdcId: string;
  type: 'service' | 'piece';
  items: AddServiceInput[] | AddPieceInput[];
}

export interface AddServiceInput {
  serviceId?: string;
  nom: string;
  prix: number;
}

export interface AddPieceInput {
  /** v1.1.5+ : pieceId stable du catalogue (P00001…). Écrit en col O
   *  de BONS DE COMMANDES. Optionnel pour rétrocompat (anciens callers). */
  pieceId?: string;
  nom: string;
  prix: number;
  qte: number;
  flag?: string;
}
