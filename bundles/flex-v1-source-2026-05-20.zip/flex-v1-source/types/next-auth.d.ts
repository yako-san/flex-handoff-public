/**
 * Module augmentation NextAuth — v1.1.8 / Item 11 audit.
 *
 * Auparavant : 33 occurrences de `(session as any).googleAccessToken` dans
 * le repo. Avec ce fichier, TypeScript connaît les champs custom du Session
 * et du JWT → plus besoin du cast.
 *
 * Référence : https://authjs.dev/getting-started/typescript#module-augmentation
 */
import type { DefaultSession } from 'next-auth';

declare module 'next-auth' {
  /** Session retournée par `auth()` côté serveur ET par `useSession()` côté client. */
  interface Session {
    googleAccessToken ?: string;
    googleRefreshToken?: string;
    user: {
      id?: string;
    } & DefaultSession['user'];
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    googleAccessToken ?: string;
    googleRefreshToken?: string;
    googleTokenExpiry ?: number;
  }
}
