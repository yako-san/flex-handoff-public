export type VeloStatus =
  | 'RV'
  | 'REÇU'
  | 'ÉVAL.'
  | 'EN ATTENTE'
  | 'APPROUVÉ'
  | 'ON BENCH'
  | 'CTRL QLTÉ'
  | 'FINI'
  | 'LIVRÉ'
  | 'FACTURER'
  | 'FACTURÉ';

export interface Velo {
  /** Numéro de ligne dans Sheets (pour PATCH ciblé) */
  _row: number;
  id: string;          // "0042"
  status: VeloStatus;
  date1: string | null; // réception  yyyy-MM-dd\nHH:mm
  date2: string | null; // approbation
  date3: string | null; // livraison
  client: string;
  marque: string;
  modele: string;
  couleur: string;
  taille: string;
  serie: string;
  /** Note libre sur le vélo (col N) — visible partout où le vélo apparaît. */
  noteVelo: string;
  eval: string;
  meca: string;
  ctrl: string;
  services: string;
  pieces: string;
  notes: string;
  /** Note client EXT évaluation (col V INVENTAIRE) — visible dans le PDF/email d'éval. */
  noteClientEval?: string;
  /** Note client EXT facturation (col W INVENTAIRE) — visible dans le PDF/email facture. */
  noteClientFacture?: string;
}

export interface VeloFormData {
  client: string;
  marque: string;
  modele: string;
  couleur: string;
  taille: string;
  serie: string;
}
