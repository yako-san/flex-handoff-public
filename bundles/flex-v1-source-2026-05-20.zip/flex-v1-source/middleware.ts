import { auth } from '@/lib/auth';
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export default auth((req: NextRequest & { auth: any }) => {
  const isLoggedIn  = !!req.auth;
  const pathname    = req.nextUrl.pathname;

  // Routes publiques (pas besoin de session) :
  //  - /login, /api/auth/* : NextAuth
  //  - /api/square/webhook : Square POST signe avec HMAC, vérifié dans le handler
  //  - /api/square/sync    : cron Vercel + bouton manuel (auth via CRON_SECRET)
  //
  // v1.1.2 — /api/admin/repair-bdt RETIRÉ de cette liste (Item 8 audit sécurité).
  // L'endpoint exigeait juste le n° du BDT, donc n'importe qui pouvait recalculer
  // les totaux d'un BDT en prod. Maintenant requireAdmin() côté handler.
  const publicPaths = ['/login', '/api/auth', '/api/square/webhook', '/api/square/sync'];
  // Bypass auth pour endpoints admin/test — activable via ENABLE_DEV_ENDPOINTS=1
  // (v1.1.2 — Item 15 : on remplace NODE_ENV !== 'production' par une env var
  // explicite, plus difficile à activer en prod par accident).
  const devEndpointsEnabled = process.env.ENABLE_DEV_ENDPOINTS === '1';
  const isDevTest   = devEndpointsEnabled
                   && (pathname.startsWith('/api/admin/test-cycle')
                       || pathname.startsWith('/api/admin/restore-bdc')
                       || pathname.startsWith('/api/admin/snapshot')
                       || pathname.startsWith('/api/archives'));
  const isPublic    = publicPaths.some(p => pathname.startsWith(p)) || isDevTest;

  if (!isLoggedIn && !isPublic) {
    // Routes API : retourner 401 JSON au lieu d'un redirect. Sinon le
    // navigateur suit le 307 vers /login en gardant la méthode (PUT/POST/
    // DELETE) et /login répond 405 « Method Not Allowed ».
    // Cache-Control no-store sinon Vercel CDN cache l'erreur (cf incident
    // 405 servi en HIT pendant 53s après fix).
    if (pathname.startsWith('/api/')) {
      return NextResponse.json(
        { error: 'Session expirée — reconnecte-toi', code: 'UNAUTHENTICATED' },
        { status: 401, headers: { 'Cache-Control': 'no-store, no-cache, must-revalidate' } },
      );
    }
    return NextResponse.redirect(new URL('/login', req.url));
  }

  return NextResponse.next();
});

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)'],
};
