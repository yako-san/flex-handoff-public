import type { Metadata } from 'next';
import './globals.css';
import Providers from './providers';

export const metadata: Metadata = {
  title       : 'FLEX-REV — Inventaire vélos',
  description : 'Gestion d\'atelier vélo — Cyclo FLEX, Montréal',
  // Next.js détecte automatiquement app/icon.svg et app/apple-icon.svg
  // pour les balises <link rel="icon"> + <link rel="apple-touch-icon">.
  // Le manifest.ts gère le PWA Add to Home Screen iOS / Android.
  appleWebApp : {
    capable  : true,
    statusBarStyle: 'default',
    title    : 'FLEX-REV',
  },
  themeColor  : '#fff056',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
