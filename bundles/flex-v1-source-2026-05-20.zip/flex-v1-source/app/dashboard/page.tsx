'use client';
import { useMemo, useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';
import GoogleHealthPills from '@/components/layout/GoogleHealthPills';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { useVentes } from '@/hooks/useVentes';
import { useArchives } from '@/hooks/useArchives';
import { useInventaire } from '@/hooks/useInventaire';
import { usePieces } from '@/hooks/useCatalogue';
import { useClients } from '@/hooks/useClients';
import { frPrix, telDigits, estTzLabel } from '@/lib/utils/format';
import { buildReminderUrl } from '@/lib/utils/reminderUrl';
import { useEmailTemplates } from '@/hooks/useEmailTemplates';
import { getSuivisDone, markSuiviDone, unmarkSuiviDone } from '@/lib/utils/suivisDone';
import { useSquareBookings } from '@/hooks/useSquareBookings';
import { useNewBookings } from '@/hooks/useNewBookings';
import { CalendarDaysIcon, PlusIcon, CheckIcon, TrashIcon, LinkIcon } from '@heroicons/react/24/outline';
import Modal from '@/components/ui/Modal';
import { isRetraitEssayage } from '@/lib/square/bookings';
import { toast } from '@/components/ui/Toast';
import { mutate as swrMutate } from 'swr';
import { STATUTS } from '@/lib/utils/statuts';
import type { Client } from '@/types/client';
import {
  BanknotesIcon,
  WrenchScrewdriverIcon,
  ExclamationTriangleIcon,
  ClipboardDocumentCheckIcon,
  ChatBubbleLeftRightIcon,
  EnvelopeIcon,
  PhoneIcon,
  CubeIcon,
  DocumentTextIcon,
} from '@heroicons/react/24/outline';
import { StarIcon } from '@heroicons/react/24/solid';

/** Statuts BDT qui comptent comme « actifs » (non archivés). */
const ACTIVE_STATUSES = ['RV', 'REÇU', 'ÉVAL.', 'APPROUVÉ', 'ON BENCH', 'CTRL QLTÉ', 'FINI', 'FACTURER'] as const;

/** Est-ce que la date (ISO yyyy-MM-dd ou yyyy-MM-dd\nHH:mm) est dans le mois courant ? */
function isThisMonth(dateStr: string | null | undefined): boolean {
  if (!dateStr) return false;
  const s = dateStr.split('\n')[0].trim();
  if (!/^\d{4}-\d{2}-\d{2}/.test(s)) return false;
  const now = new Date();
  const curYM = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  return s.slice(0, 7) === curYM;
}

/** Nombre de jours entiers entre une date ISO (ou yyyy-MM-dd\nHH:mm) et aujourd'hui. */
function daysSince(dateStr: string | null | undefined): number {
  if (!dateStr) return 0;
  const s = dateStr.split('\n')[0].trim();
  if (!/^\d{4}-\d{2}-\d{2}/.test(s)) return 0;
  const then = new Date(s + 'T00:00:00');
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.round((now.getTime() - then.getTime()) / (1000 * 60 * 60 * 24));
}


const MOIS_NAMES = ['janv.', 'févr.', 'mars', 'avril', 'mai', 'juin', 'juill.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];

export default function DashboardPage() {
  // v1.0.6+ : redirect mobile → /catalogue/ventes RETIRÉ.
  // Avant : forçait `/catalogue/ventes` sur mobile (avant le big menu).
  // Maintenant : /menu est la home iOS, et l'utilisateur qui clique
  // explicitement "Dashboard" dans le big menu doit voir le dashboard
  // (responsive). Le router import reste pour les autres usages.
  const router = useRouter();

  const { ventes, isLoading: ventesLoading } = useVentes();
  const { bdcs: archives, isLoading: archLoading } = useArchives();
  const { velos, isLoading: invLoading } = useInventaire();
  const { pieces, isLoading: piecesLoading } = usePieces();
  const { grouped } = useClients();
  const { tpl } = useEmailTemplates();
  const { bookings: squareBookingsRaw, configMissing: squareConfigMissing, squareError } = useSquareBookings(14);
  const [squareBusy, setSquareBusy] = useState<string | null>(null);
  // v1.0.22+ : modal de liaison d'un RV retrait/essayage à un BDT existant.
  // Stocke le bookingId courant ; la modal liste les BDT actifs du client.
  const [linkBookingId, setLinkBookingId] = useState<string | null>(null);
  const [linkBusy,      setLinkBusy]      = useState<string | null>(null);

  // ── RDV Square annulés masqués (poubelle) ──
  // Stockés en localStorage pour persistance entre sessions. Le user clique
  // la poubelle → l'ID est ajouté à la liste, le RDV disparaît du dashboard.
  const DISMISS_KEY = 'square_dismissed_bookings_v1';
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(() => {
    if (typeof window === 'undefined') return new Set();
    try {
      const raw = window.localStorage.getItem(DISMISS_KEY);
      return new Set(raw ? JSON.parse(raw) : []);
    } catch { return new Set(); }
  });
  function dismissBooking(id: string) {
    setDismissedIds(prev => {
      const next = new Set(prev);
      next.add(id);
      try { window.localStorage.setItem(DISMISS_KEY, JSON.stringify([...next])); } catch {}
      return next;
    });
  }
  // Filtre les RDV masqués (poubelle)
  const squareBookings = squareBookingsRaw.filter(b => !dismissedIds.has(b.id));
  // Pour le badge NEW, on ignore les RDV déjà synchronisés (cron les a
  // traités en arrière-plan, inutile de les flagger comme "nouveau")
  const { newIds: newBookingIds, markSeen: markBookingSeen, markAllSeen: markAllBookingsSeen } =
    useNewBookings(squareBookings.filter(b => !b.syncedVeloId).map(b => b.id));

  // À l'entrée du Dashboard, déclencher un sync Square silencieux pour
  // attraper les nouveaux RDV entre les cron (cron = 1 fois/jour sur
  // Vercel Hobby). Best-effort, on ignore les erreurs.
  useEffect(() => {
    const controller = new AbortController();
    (async () => {
      try {
        const res = await fetch('/api/square/sync', {
          signal: controller.signal,
          cache : 'no-store',
        });
        if (res.ok) {
          const data = await res.json().catch(() => ({}));
          if (Array.isArray(data.created) && data.created.length > 0) {
            toast(`${data.created.length} RDV Square sync(s)`);
            // Refresh les SWR affectés
            swrMutate('/api/inventaire');
            swrMutate('/api/clients');
            swrMutate('/api/square/bookings?days=14');
          }
        }
      } catch { /* abort / network → silent */ }
    })();
    return () => controller.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleCreateBdtFromBooking(bookingId: string) {
    // Pré-check : est-ce que le client Square a déjà un BDT actif en
    // inventaire ? (Match par nom complet — simple, pas d'appel API.)
    const booking = squareBookings.find(b => b.id === bookingId);
    if (booking?.customer) {
      const sqName = `${booking.customer.prenom} ${booking.customer.nom}`.trim().toLowerCase();
      const ACTIVE_SET = new Set(['RV', 'REÇU', 'ÉVAL.', 'APPROUVÉ', 'ON BENCH', 'CTRL QLTÉ', 'FINI', 'FACTURER']);
      const existingBdt = velos.find(v =>
        ACTIVE_SET.has(v.status) &&
        v.client.trim().toLowerCase() === sqName
      );
      if (existingBdt) {
        const msg = `⚠ ${booking.customer.prenom} a déjà un BDT actif #${existingBdt.id} (${existingBdt.status}).\n\nOK = Créer un nouveau BDT (RDV distinct)\nAnnuler = Ouvrir le BDT existant`;
        if (!confirm(msg)) {
          // Ouvrir le BDT existant à la place
          window.location.href = `/inventaire/${existingBdt.id}`;
          return;
        }
      }
    }

    setSquareBusy(bookingId);
    try {
      const res  = await fetch('/api/square/create-bdt', {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ squareBookingId: bookingId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erreur');
      if (data.alreadySynced) {
        toast(`BDT #${data.veloId} déjà créé pour ce RDV`);
      } else {
        const baseMsg = `BDT #${data.veloId} créé${data.clientCreated ? ' + nouveau client' : ''}`;
        if (data.calendarEventId) {
          toast(`${baseMsg} + Calendar`, 'success');
        } else if (data.calendarError) {
          // Calendar a échoué → on prévient explicitement le user. Cas le
          // plus fréquent : scope manquant après upgrade des permissions.
          toast(`${baseMsg} (Calendar échoué : ${data.calendarError})`, 'error');
        } else {
          toast(baseMsg);
        }
      }
      // Refresh inventaire + clients SWR pour voir le nouveau BDT
      swrMutate('/api/inventaire');
      swrMutate('/api/clients');
      // Marquer le RDV comme vu (retire le badge NEW)
      markBookingSeen(bookingId);
    } catch (err: any) {
      toast(err.message || 'Erreur création BDT', 'error');
    } finally {
      setSquareBusy(null);
    }
  }

  /** v1.0.22+ : lie un RV retrait/essayage à un BDT existant du même client.
   *  Workflow :
   *    1. Ouvre la modal avec la liste des BDT actifs du client
   *    2. Au clic sur un BDT → POST /api/square/link-to-bdc
   *    3. Refresh SWR (inventaire, bookings)
   *    4. Toast confirmation
   */
  async function handleLinkToBdc(bookingId: string, bdcId: string) {
    setLinkBusy(bdcId);
    try {
      const res  = await fetch('/api/square/link-to-bdc', {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ squareBookingId: bookingId, bdcId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erreur');
      toast(data.alreadyLinked
        ? `RV déjà lié au BDT ${bdcId}`
        : `RV lié au BDT ${bdcId} (en tête de la note interne)`);
      // Refresh inventaire (note interne modifiée) + bookings (syncedVeloId)
      swrMutate('/api/inventaire');
      swrMutate('/api/square/bookings?days=14');
      markBookingSeen(bookingId);
      setLinkBookingId(null);
    } catch (err: any) {
      toast(err.message || 'Erreur liaison', 'error');
    } finally {
      setLinkBusy(null);
    }
  }

  // Lookup client par nomComplet pour récupérer commPref/tel/courriel/lang
  const clientByName = useMemo(() => {
    const m = new Map<string, Client>();
    const all = [...(grouped?.recents ?? []), ...(grouped?.actifs ?? []), ...(grouped?.autres ?? [])];
    for (const c of all) if (!m.has(c.nomComplet)) m.set(c.nomComplet, c);
    return m;
  }, [grouped]);

  const now = new Date();
  const moisLabel = `${MOIS_NAMES[now.getMonth()]} ${now.getFullYear()}`;

  // 1. Revenus du mois = ventes facturées ce mois + BDT archivés ce mois (hors REFUSÉ)
  const revenusMois = useMemo(() => {
    const ventesMois = ventes
      .filter(v => isThisMonth(v.factureDate))
      .reduce((s, v) => s + (v.total || 0), 0);
    const bdtMois = archives
      .filter(b => isThisMonth(b.dateOut) && b.archiveStatus !== 'REFUSÉ')
      .reduce((s, b) => s + (b.totalServices || 0) + (b.totalPieces || 0), 0);
    return { ventes: ventesMois, bdt: bdtMois, total: ventesMois + bdtMois };
  }, [ventes, archives]);

  // 2. BDT actifs par statut
  const bdtByStatus = useMemo(() => {
    const map: Record<string, number> = {};
    for (const s of ACTIVE_STATUSES) map[s] = 0;
    for (const v of velos) {
      if (ACTIVE_STATUSES.includes(v.status as any)) {
        map[v.status] = (map[v.status] || 0) + 1;
      }
    }
    const total = Object.values(map).reduce((s, n) => s + n, 0);
    return { map, total };
  }, [velos]);

  // 3. Stock bas : pièces déjà flaggées à commander OU dont le stock
  //    passe sous le seuil d'alerte configuré (sans être à zéro — les
  //    ruptures totales sont probablement voulues / OOS).
  const stockMin = useMemo(() => {
    const raw = parseFloat(tpl('stock_min_default'));
    return isFinite(raw) && raw > 0 ? raw : 0;
  }, [tpl]);
  const stockBas = useMemo(() => {
    return pieces.filter(p => {
      if (!p.nom || p.nom === 'Nom ITEM' || p.nom.startsWith('FIN DE')) return false;
      if ((p.qteACommander || 0) > 0) return true;
      if (stockMin > 0 && (p.stock ?? 0) > 0 && (p.stock ?? 0) <= stockMin && !p.oos) return true;
      return false;
    });
  }, [pieces, stockMin]);

  // 4. Factures dues = ventes pas encore facturées
  const venteNonFact = useMemo(() =>
    ventes.filter(v => !v.factureDate),
    [ventes]);
  const venteNonFactTotal = useMemo(() =>
    venteNonFact.reduce((s, v) => s + (v.total || 0), 0),
    [venteNonFact]);

  // Section : BDT à facturer (status FACTURER)
  const bdtAFacturer = useMemo(() =>
    velos.filter(v => v.status === 'FACTURER'),
    [velos]);

  // Section : BDT prêts à ramasser — FINI / FACTURER / FACTURÉ.
  // L'âge est calculé depuis date1 (réception) ; pas parfait mais seule date
  // dispo. Tri par âge décroissant (plus ancien en tête).
  const bdtARamasser = useMemo(() => {
    const readyStatuses = new Set(['FINI', 'FACTURER', 'FACTURÉ']);
    return velos
      .filter(v => readyStatuses.has(v.status))
      .map(v => ({
        velo: v,
        ageDays: v.date1 ? daysSince(v.date1) : 0,
      }))
      .sort((a, b) => b.ageDays - a.ageDays);
  }, [velos]);

  // Section : Dernières ventes (5 plus récentes)
  const dernieresVentes = useMemo(() => {
    return [...ventes]
      .sort((a, b) => (b.date || '').localeCompare(a.date || ''))
      .slice(0, 5);
  }, [ventes]);

  // Section : Dernières factures (BDT archivés avec dateOut, 5 plus récentes)
  const dernieresFactures = useMemo(() => {
    return [...archives]
      .filter(a => a.dateOut)
      .sort((a, b) => (b.dateOut || '').localeCompare(a.dateOut || ''))
      .slice(0, 5);
  }, [archives]);

  // Suivis marqués "fait" — sources fusionnées :
  //   1. Serveur : clés `suivi_done_<bdcId>` dans _EMAIL_TEMPLATES_
  //      (settées automatiquement quand l'API suivi-courriel a réussi).
  //      Sync entre tous les navigateurs et domaines.
  //   2. localStorage : legacy fallback pour les anciens marquages.
  // Bump this state quand on (dé)marque pour forcer le recalcul.
  const { templates: tplAll, mutate: mutateTpl } = useEmailTemplates();
  const [suivisDoneTick, setSuivisDoneTick] = useState(0);
  const suivisDoneSet = useMemo<Set<string>>(() => {
    const s = new Set<string>(getSuivisDone());
    for (const k of Object.keys(tplAll)) {
      if (k.startsWith('suivi_done_') && tplAll[k]) {
        s.add(k.replace(/^suivi_done_/, ''));
      }
    }
    return s;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tplAll, suivisDoneTick]);

  function toggleSuiviDone(bdcId: string) {
    if (suivisDoneSet.has(bdcId)) unmarkSuiviDone(bdcId);
    else markSuiviDone(bdcId);
    setSuivisDoneTick(t => t + 1);
  }

  // Section : Suivi post-archivage — BDT archivés il y a 2-4 jours.
  // Fenêtre élargie à 2-4j pour capturer les cas où tu ouvres le dashboard
  // que le lundi alors qu'un BDT a été archivé le vendredi. Tri par plus
  // récent en premier. Exclut ceux marqués "fait" via l'étoile.
  const suiviPostArchive = useMemo(() => {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    return archives
      .map(bdc => {
        if (!bdc.dateOut) return null;
        if (suivisDoneSet.has(bdc.id)) return null;
        const d = new Date(bdc.dateOut); d.setHours(0, 0, 0, 0);
        const diff = Math.floor((today.getTime() - d.getTime()) / 86400000);
        if (diff < 2 || diff > 4) return null;
        return { bdc, ageDays: diff };
      })
      .filter(Boolean)
      .sort((a, b) => (a!.ageDays - b!.ageDays)) as { bdc: typeof archives[0]; ageDays: number }[];
  }, [archives, suivisDoneSet]);

  const isLoading = ventesLoading || archLoading || invLoading || piecesLoading;

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader
          subtitle={moisLabel}
          title="Dashboard"
          helpTopic="04-dashboard"
          helpTitle="Dashboard"
          helpHint="Vue d'ensemble de la journée : RDV Square, suivis, BDT à sortir, factures, ventes. 3 colonnes pour scanner ton atelier en un coup d'œil."
        >
          <GoogleHealthPills />
        </PageHeader>

        {isLoading && <LoadingSpinner className="py-20" />}

        {!isLoading && (
          <div className="flex flex-col" style={{ gap: '20px' }}>
            {/* KPI cards — Revenus du mois à droite */}
            <div className="grid" style={{ gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: '16px' }}>
              <KpiCard
                href="/inventaire"
                icon={<WrenchScrewdriverIcon style={{ width: '28px', height: '28px' }} />}
                label="BDT actifs"
                value={String(bdtByStatus.total)}
                subtitle={
                  <div className="flex items-center flex-wrap" style={{ gap: '4px', marginTop: '4px' }}>
                    {ACTIVE_STATUSES.filter(s => bdtByStatus.map[s] > 0).map(s => {
                      const st = STATUTS[s];
                      return (
                        <span
                          key={s}
                          style={{
                            backgroundColor: st?.bg ?? '#e0e0e0',
                            color: st?.fg ?? '#333',
                            padding: '1px 6px',
                            borderRadius: '999px',
                            fontSize: '10px',
                            fontWeight: 700,
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {bdtByStatus.map[s]} {s}
                        </span>
                      );
                    })}
                  </div>
                }
                accent="#fff056"
              />
              <KpiCard
                href="/catalogue/commande"
                icon={<ExclamationTriangleIcon style={{ width: '28px', height: '28px' }} />}
                label="Stock à commander"
                value={String(stockBas.length)}
                subtitle={stockBas.length > 0 ? `${stockBas.reduce((s, p) => s + (p.qteACommander || 0), 0)} unités au total` : 'aucune pièce à commander'}
                accent="#ffcdd2"
              />
              <KpiCard
                href="/archives"
                icon={<StarIcon style={{ width: '28px', height: '28px' }} />}
                label="Suivis"
                value={String(suiviPostArchive.length)}
                subtitle={suiviPostArchive.length > 0
                  ? `${suiviPostArchive.length} BDT archivé${suiviPostArchive.length > 1 ? 's' : ''} à rappeler`
                  : 'aucun rappel à faire'}
                accent="#f59e0b"
              />
              <KpiCard
                href="/archives"
                icon={<BanknotesIcon style={{ width: '28px', height: '28px' }} />}
                label="Revenus du mois"
                value={frPrix(revenusMois.total)}
                subtitle={`${frPrix(revenusMois.bdt)} BDT · ${frPrix(revenusMois.ventes)} ventes`}
                accent="#88fa4e"
              />
            </div>

            {/* Sections */}
            <div className="grid" style={{ gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: '16px', alignItems: 'start' }}>
              {/* Col 1 : Rendez-vous (Square) + Suivi + À sortir */}
              <div className="flex flex-col" style={{ gap: '16px' }}>
                {/* Section Rendez-vous — déplacée ici, ex "RV à venir" */}
                <Section
                  title="Rendez-vous"
                  count={squareBookings.length}
                  emptyText={squareConfigMissing
                    ? 'Square non configuré (voir Paramètres)'
                    : squareError
                      ? `Erreur : ${squareError}`
                      : 'Aucun RDV à venir (14 j)'}
                  minHeight={160}
                  icon={<CalendarDaysIcon style={{ width: '18px', height: '18px', color: '#2563eb' }} />}
                >
                  {newBookingIds.size > 0 && (
                    <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '0 4px 4px' }}>
                      <button
                        type="button"
                        onClick={markAllBookingsSeen}
                        style={{
                          fontSize: '10px', fontWeight: 600, color: 'rgba(0,0,0,0.5)',
                          background: 'none', border: 'none', cursor: 'pointer', padding: 0,
                          textDecoration: 'underline',
                        }}
                      >
                        Tout vu ({newBookingIds.size})
                      </button>
                    </div>
                  )}
                  {squareBookings.slice(0, 8).map(b => {
                    const d = new Date(b.startAt);
                    const date = d.toLocaleDateString('fr-CA', { weekday: 'short', day: '2-digit', month: 'short', timeZone: 'America/Toronto' });
                    const hhmm = d.toLocaleTimeString('fr-CA', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'America/Toronto' });
                    const tz   = estTzLabel(d);
                    const time = tz ? `${hhmm} ${tz}` : hhmm;
                    const cname = b.customer ? `${b.customer.prenom} ${b.customer.nom}`.trim() : '(client inconnu)';
                    const isNew = newBookingIds.has(b.id);
                    return (
                      <div
                        key={b.id}
                        className="flex items-center gap-2"
                        style={{
                          padding: '6px 8px',
                          borderRadius: '8px',
                          backgroundColor: isNew ? 'rgba(245, 158, 11, 0.08)' : 'transparent',
                        }}
                      >
                        <span style={{ display: 'flex', flexDirection: 'column', minWidth: '80px', lineHeight: 1.1 }}>
                          <span style={{ fontSize: '11px', fontWeight: 700, color: 'rgba(0,0,0,0.6)' }}>
                            {date}
                          </span>
                          <span style={{ fontSize: '12px', fontFamily: 'monospace', color: 'rgba(0,0,0,0.55)' }}>
                            {time}
                          </span>
                        </span>
                        <span style={{ flex: 1, fontSize: '12px', color: 'rgba(0,0,0,0.8)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {isNew && (
                            <span
                              title="Nouveau RDV — pas encore vu"
                              style={{
                                display: 'inline-block', marginRight: '6px', padding: '1px 6px', borderRadius: '999px',
                                backgroundColor: '#f59e0b', color: '#fff', fontSize: '9px', fontWeight: 700,
                                letterSpacing: '0.04em', verticalAlign: 'middle',
                              }}
                            >NEW</span>
                          )}
                          <strong>{cname}</strong>
                          {b.services && <> · <span style={{ color: 'rgba(0,0,0,0.55)' }}>{b.services}</span></>}
                        </span>
                        {b.status && b.status !== 'ACCEPTED' && (
                          <span style={{ padding: '1px 6px', borderRadius: '999px', backgroundColor: 'rgba(0,0,0,0.1)', color: 'rgba(0,0,0,0.6)', fontSize: '9px', fontWeight: 700, textTransform: 'uppercase' }}>
                            {b.status}
                          </span>
                        )}
                        {b.syncedVeloId ? (
                          <Link
                            href={`/inventaire/${b.syncedVeloId}`}
                            title={`BDT #${b.syncedVeloId} déjà créé — cliquer pour ouvrir`}
                            className="flex items-center justify-center shrink-0 transition-colors hover:bg-green-100"
                            style={{
                              width: '28px', height: '28px', borderRadius: '50%',
                              backgroundColor: 'rgba(34,197,94,0.15)', color: '#15803d',
                              textDecoration: 'none',
                            }}
                          >
                            <CheckIcon style={{ width: '14px', height: '14px' }} />
                          </Link>
                        ) : b.status?.startsWith('CANCELLED') ? (
                          /* RDV annulé : poubelle (le retire du dashboard, ne touche pas Square) */
                          <button
                            type="button"
                            onClick={() => dismissBooking(b.id)}
                            title="RDV annulé — masquer du tableau de bord"
                            className="flex items-center justify-center shrink-0 transition-colors hover:bg-red-100"
                            style={{
                              width: '28px', height: '28px', borderRadius: '50%',
                              backgroundColor: 'rgba(239,68,68,0.10)', color: '#b91c1c',
                              border: 'none', cursor: 'pointer', padding: 0,
                            }}
                          >
                            <TrashIcon style={{ width: '14px', height: '14px' }} />
                          </button>
                        ) : isRetraitEssayage(b.services) ? (
                          /* v1.0.22+ : RV retrait/essayage → bouton 🔗 Lier
                              au BDT (pas de création BDT auto, cf sync.ts) */
                          <button
                            type="button"
                            onClick={() => setLinkBookingId(b.id)}
                            title="RV retrait/essayage — lier à un BDT existant du client"
                            className="flex items-center justify-center shrink-0 transition-colors hover:bg-blue-100"
                            style={{
                              width: '28px', height: '28px', borderRadius: '50%',
                              backgroundColor: 'rgba(37,99,235,0.10)', color: '#2563eb',
                              border: 'none', cursor: 'pointer', padding: 0,
                            }}
                          >
                            <LinkIcon style={{ width: '14px', height: '14px' }} />
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleCreateBdtFromBooking(b.id)}
                            disabled={squareBusy === b.id}
                            title="Créer un BDT à partir de ce RDV (client créé si nécessaire)"
                            className="flex items-center justify-center shrink-0 transition-colors hover:bg-yellow-200"
                            style={{
                              width: '28px', height: '28px', borderRadius: '50%',
                              backgroundColor: 'rgba(0,0,0,0.06)', color: 'rgba(0,0,0,0.6)',
                              border: 'none', cursor: squareBusy === b.id ? 'wait' : 'pointer', padding: 0,
                            }}
                          >
                            {squareBusy === b.id
                              ? <span style={{ fontSize: '10px' }}>…</span>
                              : <PlusIcon style={{ width: '14px', height: '14px' }} />}
                          </button>
                        )}
                      </div>
                    );
                  })}
                  {squareBookings.length > 8 && (
                    <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)', textAlign: 'center', padding: '6px' }}>
                      + {squareBookings.length - 8} autre(s)
                    </div>
                  )}
                </Section>

                {/* BDT - Terminés — BDT prêts à ramasser (FINI / FACTURER / FACTURÉ)
                    → rappel au client (SMS/Courriel/Tél selon prefs). */}
                <Section
                  title="BDT - Terminés"
                  href="/inventaire"
                  count={bdtARamasser.length}
                  emptyText="Aucun BDT en attente de ramassage"
                  icon={<WrenchScrewdriverIcon style={{ width: '18px', height: '18px', color: '#1f8f1f' }} />}
                >
                  {bdtARamasser.map(({ velo, ageDays }) => {
                    // Couleur de l'âge : < 7j gris, 7-13j orange, ≥ 14j rouge
                    const ageColor = ageDays >= 14 ? '#c62828'
                      : ageDays >= 7 ? '#e65100'
                      : 'rgba(0,0,0,0.5)';
                    const ageBg = ageDays >= 14 ? '#ffcdd2'
                      : ageDays >= 7 ? '#ffe0b2'
                      : 'rgba(0,0,0,0.06)';
                    const st = STATUTS[velo.status];
                    const veloDesc = [velo.marque, velo.modele, velo.couleur, velo.taille].filter(Boolean).join(', ');
                    const reminder = buildReminderUrl(clientByName.get(velo.client), velo.id, {
                      smsTemplateFr: tpl('sms_rappel_fr'),
                      smsTemplateEn: tpl('sms_rappel_en'),
                      veloDesc,
                    });
                    const RemIcon = reminder?.kind === 'email' ? EnvelopeIcon
                      : reminder?.kind === 'tel' ? PhoneIcon
                      : ChatBubbleLeftRightIcon;
                    return (
                      <div
                        key={velo._row}
                        className="flex items-center hover:bg-yellow-50 transition-colors"
                        style={{ padding: '4px 6px', borderRadius: '8px', gap: '6px' }}
                      >
                        <Link
                          href={`/inventaire/${velo.id}`}
                          className="flex items-center flex-1"
                          style={{ gap: '8px', textDecoration: 'none', color: 'inherit', minWidth: 0, padding: '4px 4px' }}
                        >
                          <span style={{ fontFamily: 'monospace', fontWeight: 700, color: 'rgba(0,0,0,0.55)', fontSize: '12px', minWidth: '44px' }}>
                            {velo.id}
                          </span>
                          <span
                            style={{
                              backgroundColor: st?.bg ?? '#e0e0e0',
                              color: st?.fg ?? '#333',
                              padding: '2px 6px',
                              borderRadius: '999px',
                              fontSize: '10px',
                              fontWeight: 700,
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {velo.status}
                          </span>
                          <span style={{ flex: 1, fontSize: '12px', color: 'rgba(0,0,0,0.75)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {(() => {
                              const veloDesc = [velo.marque, velo.modele, velo.couleur, velo.taille].filter(Boolean).join(', ');
                              if (veloDesc && velo.client) return `${veloDesc} | ${velo.client}`;
                              return veloDesc || velo.client || '—';
                            })()}
                          </span>
                          <span
                            style={{
                              backgroundColor: ageBg,
                              color: ageColor,
                              padding: '2px 8px',
                              borderRadius: '999px',
                              fontSize: '10px',
                              fontWeight: 700,
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {ageDays}j
                          </span>
                        </Link>
                        {reminder ? (
                          <a
                            href={reminder.url}
                            title={`Envoyer rappel (${reminder.label})`}
                            onClick={e => e.stopPropagation()}
                            className="flex items-center justify-center shrink-0 transition-colors hover:bg-yellow-200"
                            style={{
                              width: '28px',
                              height: '28px',
                              borderRadius: '50%',
                              backgroundColor: 'rgba(0,0,0,0.06)',
                              color: 'rgba(0,0,0,0.6)',
                              textDecoration: 'none',
                            }}
                          >
                            <RemIcon style={{ width: '14px', height: '14px' }} />
                          </a>
                        ) : (
                          <span
                            title="Aucun moyen de contact (pas de tél/courriel sur la fiche client)"
                            className="flex items-center justify-center shrink-0"
                            style={{
                              width: '28px',
                              height: '28px',
                              borderRadius: '50%',
                              backgroundColor: 'rgba(0,0,0,0.03)',
                              color: 'rgba(0,0,0,0.25)',
                            }}
                          >
                            <ChatBubbleLeftRightIcon style={{ width: '14px', height: '14px' }} />
                          </span>
                        )}
                      </div>
                    );
                  })}
                </Section>

                {/* BDT - Suivi — BDT archivés 2-4j, brouillon Gmail de suivi */}
                <Section
                  title="BDT - Suivi"
                  href="/archives"
                  count={suiviPostArchive.length}
                  emptyText="Aucun BDT archivé à suivre"
                  minHeight={100}
                  icon={<StarIcon style={{ width: '18px', height: '18px', color: '#f59e0b' }} />}
                >
                  {suiviPostArchive.map(({ bdc, ageDays }) => {
                    const client = clientByName.get(bdc.clientNom);
                    const veloDesc = bdc.veloDesc || '';
                    const hasEmail = !!client?.courriel;
                    return (
                      <div
                        key={bdc.id}
                        className="flex items-center gap-2 hover:bg-yellow-50 transition-colors"
                        style={{ padding: '6px 8px', borderRadius: '8px' }}
                      >
                        <span style={{ fontFamily: 'monospace', fontWeight: 700, color: 'rgba(0,0,0,0.5)', fontSize: '12px', minWidth: '44px' }}>
                          {bdc.id}
                        </span>
                        <span style={{ flex: 1, fontSize: '12px', color: 'rgba(0,0,0,0.75)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {veloDesc ? `${veloDesc} | ${bdc.clientNom}` : bdc.clientNom}
                        </span>
                        <span
                          style={{
                            padding: '2px 8px',
                            borderRadius: '999px',
                            backgroundColor: 'rgba(0,0,0,0.06)',
                            color: 'rgba(0,0,0,0.55)',
                            fontSize: '10px',
                            fontWeight: 700,
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {ageDays}j
                        </span>
                        {/* Étoile = brouillon Gmail de suivi + marque fait. */}
                        <button
                          type="button"
                          onClick={async (e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            if (hasEmail) {
                              try {
                                const res = await fetch(`/api/bdc/${bdc.id}/suivi-courriel`, { method: 'POST' });
                                const data = await res.json().catch(() => ({}));
                                if (!res.ok) throw new Error(data.error || `${res.status}`);
                                toast(`Brouillon créé pour ${data.to}`);
                                window.open(data.draftUrl || 'https://mail.google.com/mail/u/0/#drafts', '_blank');
                                // L'API a déjà marqué `suivi_done_<id>` côté
                                // serveur (clé _EMAIL_TEMPLATES_). On force un
                                // refresh SWR pour que tplAll voie la clé
                                // immédiatement → le BDT disparaît de la liste.
                                await mutateTpl();
                              } catch (err: any) {
                                toast(err.message || 'Erreur création brouillon', 'error');
                                return;
                              }
                            }
                            // Toujours MARQUER (pas toggle) après cette action
                            // pour qu'un re-clic accidentel ne dé-marque pas.
                            markSuiviDone(bdc.id);
                            setSuivisDoneTick(t => t + 1);
                          }}
                          title={hasEmail ? 'Générer brouillon Courriel suivi + marquer comme fait' : 'Marquer comme fait (pas de courriel client)'}
                          className="flex items-center justify-center shrink-0 transition-colors hover:bg-yellow-200"
                          style={{
                            width: '28px', height: '28px', borderRadius: '50%',
                            backgroundColor: 'rgba(245, 158, 11, 0.15)',
                            border: 'none', cursor: 'pointer', padding: 0,
                          }}
                        >
                          <StarIcon style={{ width: '16px', height: '16px', color: '#f59e0b' }} />
                        </button>
                      </div>
                    );
                  })}
                </Section>

              </div>

              {/* Col 2 : Pièces - à commander */}
              <div className="flex flex-col" style={{ gap: '16px' }}>
                <Section
                  title="Pièces - à commander"
                  href="/catalogue/commande"
                  count={stockBas.length}
                  emptyText="Aucune pièce à commander"
                  icon={<CubeIcon style={{ width: '18px', height: '18px', color: '#c62828' }} />}
                >
                {stockBas.slice(0, 10).map(p => (
                  <Link
                    key={p._row}
                    href="/catalogue/commande"
                    className="flex items-center justify-between hover:bg-yellow-50 transition-colors"
                    style={{
                      padding: '8px 12px',
                      borderRadius: '8px',
                      textDecoration: 'none',
                      color: 'inherit',
                      gap: '8px',
                    }}
                  >
                    <span style={{ flex: 1, fontSize: '13px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {p.nom}
                    </span>
                    <span
                      style={{
                        backgroundColor: '#ffcdd2',
                        color: '#c62828',
                        padding: '2px 8px',
                        borderRadius: '999px',
                        fontSize: '11px',
                        fontWeight: 700,
                        minWidth: '32px',
                        textAlign: 'center',
                      }}
                    >
                      {p.qteACommander}
                    </span>
                  </Link>
                ))}
                {stockBas.length > 10 && (
                  <Link
                    href="/catalogue/commande"
                    className="block text-center py-2 hover:bg-yellow-50 transition-colors"
                    style={{
                      fontSize: '12px',
                      fontWeight: 700,
                      color: 'rgba(0,0,0,0.5)',
                      borderRadius: '8px',
                      textDecoration: 'none',
                    }}
                  >
                    + {stockBas.length - 10} autres →
                  </Link>
                )}
                </Section>
              </div>

              {/* Col 3 : Dernières factures (haut) + Dernières ventes (bas) */}
              <div className="flex flex-col" style={{ gap: '16px' }}>
                <Section
                  title="Dernières factures"
                  href="/archives"
                  count={dernieresFactures.length}
                  emptyText="Aucune facture récente"
                  icon={<DocumentTextIcon style={{ width: '18px', height: '18px', color: '#1f8f1f' }} />}
                >
                  {dernieresFactures.map(a => {
                    const total = (a.totalServices || 0) + (a.totalPieces || 0);
                    return (
                      <Link
                        key={a.id}
                        href="/archives"
                        className="flex items-center justify-between hover:bg-yellow-50 transition-colors"
                        style={{
                          padding: '8px 12px',
                          borderRadius: '8px',
                          textDecoration: 'none',
                          color: 'inherit',
                          gap: '8px',
                        }}
                      >
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: '13px', fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            #{a.id} · {a.clientNom || '—'}
                          </div>
                          <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)' }}>
                            {a.dateOut ?? '—'}
                          </div>
                        </div>
                        <span style={{ fontSize: '13px', fontWeight: 700, whiteSpace: 'nowrap' }}>
                          {frPrix(total)}
                        </span>
                      </Link>
                    );
                  })}
                </Section>

                <Section
                  title="Dernières ventes"
                  href="/catalogue/ventes"
                  count={ventes.length}
                  emptyText="Aucune vente"
                  icon={<BanknotesIcon style={{ width: '18px', height: '18px', color: '#1f8f1f' }} />}
                >
                  {dernieresVentes.map(v => {
                    const itemsResume = v.items
                      .map(it => it.nom)
                      .filter(Boolean)
                      .join(' + ');
                    return (
                    <Link
                      key={v.venteId}
                      href="/catalogue/ventes"
                      className="flex items-center justify-between hover:bg-yellow-50 transition-colors"
                      style={{
                        padding: '8px 12px',
                        borderRadius: '8px',
                        textDecoration: 'none',
                        color: 'inherit',
                        gap: '8px',
                      }}
                    >
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: '13px', fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {v.client || '—'}
                        </div>
                        {itemsResume && (
                          <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.6)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={itemsResume}>
                            {itemsResume}
                          </div>
                        )}
                        <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)' }}>
                          {v.date}
                          {!v.factureDate && <span style={{ marginLeft: '6px', color: '#e53935', fontWeight: 700 }}>à facturer</span>}
                        </div>
                      </div>
                      <span style={{ fontSize: '13px', fontWeight: 700, whiteSpace: 'nowrap' }}>
                        {frPrix(v.total)}
                      </span>
                    </Link>
                    );
                  })}
                </Section>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* v1.0.22+ : Modal de liaison RV retrait/essayage → BDT existant.
          Liste les BDT actifs du client (status ∈ ACTIVE_STATUSES). Au clic
          sur un BDT → POST /api/square/link-to-bdc qui inscrit l'en-tête
          du RV en tête de la note interne du BDT et marque sq_<bookingId>. */}
      {(() => {
        const linkBooking = linkBookingId ? squareBookings.find(b => b.id === linkBookingId) : null;
        if (!linkBooking) return null;
        const sqName = linkBooking.customer
          ? `${linkBooking.customer.prenom} ${linkBooking.customer.nom}`.trim().toLowerCase()
          : '';
        // BDT actifs du client (match nom complet case-insensitive). On
        // inclut aussi FACTURÉ / LIVRÉ archivés ? Non — on reste sur les
        // statuts actifs (vélo encore en atelier). L'utilisateur peut lier
        // un retrait/essayage à un BDT en cours de travail OU déjà facturé
        // mais pas encore livré (= encore visible dans /inventaire).
        const FACT_VISIBLE = new Set(['APPROUVÉ', 'ON BENCH', 'CTRL QLTÉ', 'FINI', 'FACTURER', 'FACTURÉ']);
        const candidateBdts = velos.filter(v =>
          FACT_VISIBLE.has(v.status) &&
          v.client.trim().toLowerCase() === sqName
        );
        return (
          <Modal
            open={!!linkBookingId}
            onClose={() => { if (!linkBusy) setLinkBookingId(null); }}
            title={`Lier au BDT — ${linkBooking.customer ? `${linkBooking.customer.prenom} ${linkBooking.customer.nom}` : '(client inconnu)'}`}
            size="md"
          >
            <div className="flex flex-col" style={{ gap: '14px' }}>
              <div style={{ fontSize: '13px', color: 'rgba(0,0,0,0.65)' }}>
                <strong>RV :</strong> {linkBooking.services || '(services non précisés)'}<br />
                <strong>Date :</strong> {new Date(linkBooking.startAt).toLocaleString('fr-CA', { dateStyle: 'long', timeStyle: 'short', timeZone: 'America/Toronto' })}
              </div>

              {candidateBdts.length === 0 ? (
                <div style={{ padding: '14px 16px', borderRadius: '12px', backgroundColor: 'rgba(245,158,11,0.10)', color: '#92400e', fontSize: '13px' }}>
                  Aucun BDT actif trouvé pour <strong>{sqName ? linkBooking.customer?.prenom + ' ' + linkBooking.customer?.nom : 'ce client'}</strong>.<br />
                  Vérifier le nom dans Square ou créer un BDT pour ce client d'abord.
                </div>
              ) : (
                <div className="overflow-y-auto" style={{
                  maxHeight: '50vh',
                  border: '1.5px solid rgba(0,0,0,0.15)',
                  borderRadius: '12px',
                  backgroundColor: '#fff',
                }}>
                  {candidateBdts.map(v => {
                    const st = STATUTS[v.status];
                    const veloDesc = [v.marque, v.modele, v.couleur, v.taille].filter(Boolean).join(', ');
                    return (
                      <button
                        key={v.id}
                        type="button"
                        onClick={() => handleLinkToBdc(linkBooking.id, v.id)}
                        disabled={linkBusy !== null}
                        className="w-full text-left flex items-center hover:bg-yellow-50 disabled:opacity-40"
                        style={{ padding: '10px 14px', borderBottom: '1px solid rgba(0,0,0,0.06)', fontSize: '13px' }}
                      >
                        <span style={{ fontFamily: 'monospace', fontWeight: 700, color: 'rgba(0,0,0,0.7)', minWidth: '52px' }}>
                          #{v.id}
                        </span>
                        <span
                          className="inline-block text-xs font-bold px-2 py-0.5 rounded"
                          style={{
                            backgroundColor: st?.bg || '#f5f5f5',
                            color: st?.fg || '#000',
                            marginLeft: '8px',
                          }}
                        >
                          {v.status}
                        </span>
                        <span style={{ flex: 1, marginLeft: '12px', color: 'rgba(0,0,0,0.8)' }}>
                          {veloDesc || '(vélo non décrit)'}
                        </span>
                        {linkBusy === v.id && (
                          <span style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)' }}>liaison…</span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}

              <p className="text-xs" style={{ color: 'rgba(0,0,0,0.5)' }}>
                Cliquer un BDT inscrit le RV en tête de la note interne (date · services) puis marque le booking comme lié.
              </p>
            </div>
          </Modal>
        );
      })()}
    </AppShell>
  );
}

// ─── Sub-components ────────────────────────────────────────────

interface KpiCardProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  subtitle?: React.ReactNode;
  /** Couleur d'accent — utilisée pour le cercle autour de l'icône et la bordure gauche. */
  accent?: string;
  /** Lien de navigation quand on clique sur la carte. */
  href?: string;
}

function KpiCard({ icon, label, value, subtitle, accent = '#fff056', href }: KpiCardProps) {
  const content = (
    <div
      className="flex flex-col transition-transform"
      style={{
        backgroundColor: 'rgba(0,0,0,0.20)',
        borderRadius: '24px',
        padding: '20px 24px',
        gap: '6px',
        borderLeft: `4px solid ${accent}`,
        cursor: href ? 'pointer' : 'default',
        height: '100%',
      }}
      onMouseEnter={e => { if (href) e.currentTarget.style.transform = 'translateY(-2px)'; }}
      onMouseLeave={e => { if (href) e.currentTarget.style.transform = 'translateY(0)'; }}
    >
      <div className="flex items-center" style={{ gap: '10px' }}>
        <span
          className="flex items-center justify-center shrink-0"
          style={{
            width: '48px',
            height: '48px',
            borderRadius: '50%',
            backgroundColor: accent,
            color: 'rgba(0,0,0,0.5)',
          }}
        >
          {icon}
        </span>
        <span style={{ fontSize: '14px', fontWeight: 700, letterSpacing: '0.06em', color: 'rgba(255,255,255,0.85)' }}>
          {label.toUpperCase()}
        </span>
      </div>
      <div style={{ color: '#fff056', fontSize: '32px', fontWeight: 300, lineHeight: 1.1, marginTop: '4px' }}>
        {value}
      </div>
      {subtitle && (
        <div style={{ color: 'rgba(255,255,255,0.75)', fontSize: '12px', fontWeight: 500 }}>
          {subtitle}
        </div>
      )}
    </div>
  );

  if (href) {
    return (
      <Link href={href} style={{ textDecoration: 'none', color: 'inherit' }}>
        {content}
      </Link>
    );
  }
  return content;
}

interface SectionProps {
  title: string;
  count: number;
  emptyText: string;
  children: React.ReactNode;
  /** Lien de navigation depuis l'entête de la section. */
  href?: string;
  /** Hauteur minimale en px (défaut 200). */
  minHeight?: number;
  /** Icône optionnelle affichée avant le titre (ex. rappel / étoile). */
  icon?: React.ReactNode;
}

function Section({ title, count, emptyText, children, href, minHeight = 200, icon }: SectionProps) {
  // Détection robuste de "vide" : on déballe les arrays/fragments et on
  // vérifie qu'aucun child n'est rendu réellement (false, null, '',
  // arrays vides comptent comme vides). Sinon les blocs avec plusieurs
  // children conditionnels n'affichaient jamais le texte emptyText.
  const hasVisibleChild = (node: React.ReactNode): boolean => {
    if (node === null || node === undefined || node === false || node === true) return false;
    if (typeof node === 'string') return node.trim().length > 0;
    if (typeof node === 'number') return true;
    if (Array.isArray(node)) return node.some(hasVisibleChild);
    return true;
  };
  const isEmpty = !hasVisibleChild(children) && count === 0;
  const header = (
    <div
      className="flex items-center justify-between"
      style={{
        paddingBottom: '8px',
        borderBottom: '1px solid rgba(0,0,0,0.08)',
        cursor: href ? 'pointer' : 'default',
        gap: '8px',
      }}
    >
      <span className="flex items-center" style={{ gap: '8px', fontSize: '18px', fontWeight: 700, color: 'rgba(0,0,0,0.8)', letterSpacing: '0.02em' }}>
        {icon}
        {title}
      </span>
      <span style={{ fontSize: '14px', fontWeight: 700, color: 'rgba(0,0,0,0.4)' }}>
        {count}
      </span>
    </div>
  );
  return (
    <div
      className="flex flex-col"
      style={{
        backgroundColor: 'rgba(255,255,255,0.9)',
        borderRadius: '24px',
        padding: '16px 18px',
        gap: '6px',
        minHeight: `${minHeight}px`,
      }}
    >
      {href ? (
        <Link href={href} style={{ textDecoration: 'none', color: 'inherit' }}>
          {header}
        </Link>
      ) : header}
      {isEmpty ? (
        <div style={{ padding: '20px', textAlign: 'center', color: 'rgba(0,0,0,0.4)', fontSize: '12px', fontStyle: 'italic' }}>
          {emptyText}
        </div>
      ) : (
        <div className="flex flex-col" style={{ gap: '2px' }}>
          {children}
        </div>
      )}
    </div>
  );
}
