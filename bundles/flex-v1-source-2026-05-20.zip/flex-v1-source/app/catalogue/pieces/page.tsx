'use client';
import React, { useState, useMemo } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock, SearchInput, AddButton } from '@/components/layout/PageHeader';
import MultiSelectCat from '@/components/ui/MultiSelectCat';
import PiecesTabs from '@/components/catalogue/PiecesTabs';
import NotesCell from '@/components/catalogue/NotesCell';
import PieceForm from '@/components/catalogue/PieceForm';
import BromptonImportModal from '@/components/catalogue/BromptonImportModal';
import { usePieces } from '@/hooks/useCatalogue';
import { frPrix } from '@/lib/utils/format';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import DragTh from '@/components/ui/DragTh';
import { useColOrder } from '@/hooks/useColOrder';
import { PlusIcon, CubeIcon, ArrowDownTrayIcon, TagIcon, ClockIcon } from '@heroicons/react/24/outline';
import ScanLogModal from '@/components/ui/ScanLogModal';
import type { CatalogueAnchor } from '@/components/catalogue/PiecesTabs';
import { toast } from '@/components/ui/Toast';
import type { Piece } from '@/types/catalogue';

import { CMD_OPTIONS as FLAG_OPTIONS, CMD_STYLE as FLAG_STYLE, CMD_TOOLTIP } from '@/lib/utils/statuts';

// Colonnes — width vide = auto (s'élargit), sinon fixe
const COLS = [
  { id: 'acmd',        header: 'statut',       width: '70px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'nom',         header: 'item',         width: '33%',    hCls: 'px-4 py-2',              cCls: 'px-4 py-2 text-gray-800 font-medium whitespace-nowrap overflow-hidden text-ellipsis' },
  { id: 'notes',       header: 'notes',        width: '',       hCls: 'px-3 py-2',              cCls: 'px-2 py-1' },
  { id: 'sku',         header: 'sku',          width: '90px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'oos',         header: 'oos',          width: '48px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'stock',       header: 'stock',        width: '48px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'prix',        header: 'prix cost',    width: '80px',   hCls: 'px-3 py-2 text-right',  cCls: 'px-3 py-1.5 text-right text-gray-700 font-medium' },
  { id: 'prixVente',   header: 'prix vente',   width: '90px',   hCls: 'px-3 py-2 text-right',  cCls: 'px-3 py-1.5 text-right text-gray-700 font-medium' },
  { id: 'qte',         header: 'qté',          width: '50px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'categorie',   header: 'catégories',   width: '220px',  hCls: 'px-3 py-2',              cCls: 'px-3 py-1.5' },
  { id: 'fournisseur', header: 'fournisseur',  width: '130px',  hCls: 'px-3 py-2',              cCls: 'px-3 py-1.5' },
] as const;

type ColId = typeof COLS[number]['id'];

/** Slugifie une catégorie principale pour en faire un id d'anchor (v5.3.1). */
function catSlug(main: string): string {
  return 'cat-' + main
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function isExcluded(nom: string): boolean {
  if (!nom || nom.trim() === '') return true;
  const n = nom.trim().toLowerCase();
  if (n === 'nom item' || n === 'item') return true;
  if (nom.includes('FIN DE →')) return true;
  if (nom.startsWith('FIN DE')) return true;
  return false;
}



export default function PiecesPage() {
  const { pieces, isLoading, patchPiece, mutate: mutatePieces } = usePieces();
  const [search, setSearch] = useState('');
  const [busy,   setBusy]   = useState<Set<number>>(new Set());

  // Popup Nouvelle pièce — l'ancien formulaire inline a été remplacé
  // par un composant Modal partagé (PieceForm).
  const [showAdd,     setShowAdd]     = useState(false);
  const [showBromp,   setShowBromp]   = useState(false);
  const [showScanLog, setShowScanLog] = useState(false);
  const [addInitCat, setAddInitCat] = useState<string | undefined>(undefined);

  function openAddPiece(initCat?: string) {
    setAddInitCat(initCat);
    setShowAdd(true);
  }

  const { orderedCols, dragProps, dragOverId } = useColOrder('pieces', COLS as any);

  const filtered = useMemo(() =>
    pieces.filter(p => {
      if (isExcluded(p.nom)) return false;
      if (!search) return true;
      const q = search.toLowerCase();
      return (
        p.nom.toLowerCase().includes(q) ||
        p.categorie.toLowerCase().includes(q) ||
        p.fournisseur.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q)
      );
    }),
  [pieces, search]);

  const categories = useMemo(() =>
    [...new Set(pieces.filter(p => !isExcluded(p.nom)).map(p => p.categorie).filter(Boolean))].sort(),
  [pieces]);

  const fournisseurs = useMemo(() =>
    [...new Set(
      pieces
        .filter(p => !isExcluded(p.nom))
        .map(p => p.fournisseur)
        .filter(f => !!f && f.toLowerCase() !== 'fournisseur'),
    )].sort(),
  [pieces]);

  // Parse la catégorie complète d'une pièce pour en extraire la catégorie
  // principale (ex. "1. Direction") et la sous-catégorie (ex. "Guidons").
  // Format attendu dans le sheet : "1. Direction, Guidons" ou juste "Autre".
  function splitCat(raw: string | undefined): { main: string; sub: string } {
    const s = (raw ?? '').trim();
    if (!s) return { main: 'Autre', sub: '' };
    const idx = s.indexOf(',');
    if (idx < 0) return { main: s, sub: '' };
    return { main: s.slice(0, idx).trim(), sub: s.slice(idx + 1).trim() };
  }

  /** Structure : Map<mainCat, Map<subCat, Piece[]>> — double niveau de groupement. */
  const grouped = useMemo(() => {
    const byMain = new Map<string, Map<string, Piece[]>>();
    filtered.forEach(p => {
      const { main, sub } = splitCat(p.categorie);
      if (!byMain.has(main)) byMain.set(main, new Map());
      const bySub = byMain.get(main)!;
      if (!bySub.has(sub)) bySub.set(sub, []);
      bySub.get(sub)!.push(p);
    });
    // Trier les mains alphabétiquement (les "1. Direction" passent en tête
    // naturellement grâce au préfixe numérique).
    return new Map([...byMain.entries()].sort((a, b) => a[0].localeCompare(b[0], 'fr')));
  }, [filtered]);

  // v5.3.1 — anchors pour le dropdown catalogue
  const catAnchors: CatalogueAnchor[] = useMemo(
    () => [...grouped.keys()].map(main => ({ id: catSlug(main), label: main })),
    [grouped],
  );

  async function save(row: number, fields: Parameters<typeof patchPiece>[1]) {
    setBusy(prev => new Set(prev).add(row));
    try { await patchPiece(row, fields); }
    catch (err: any) { toast(err.message, 'error'); }
    finally { setBusy(prev => { const s = new Set(prev); s.delete(row); return s; }); }
  }

  function renderCell(id: ColId, p: Piece) {
    const isBusy = busy.has(p._row);
    const style  = FLAG_STYLE[p.flag] ?? FLAG_STYLE['...'];

    switch (id) {
      case 'acmd':
        return (
          <select
            value={FLAG_OPTIONS.includes(p.flag as any) ? p.flag : '...'}
            onChange={e => save(p._row, { flag: e.target.value })}
            disabled={isBusy}
            title={CMD_TOOLTIP}
            className="text-xs border rounded px-1 py-0.5 font-bold w-full focus:outline-none focus:ring-1 focus:ring-yellow-400"
            style={{ backgroundColor: style.bg, color: style.fg }}
          >
            {FLAG_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
          </select>
        );
      case 'nom':
        return p.skuUrl
          ? <a href={p.skuUrl} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()}
               className="hover:underline" style={{ color: 'inherit' }} title={p.skuUrl}>{p.nom}</a>
          : <span title={p.nom}>{p.nom}</span>;
      case 'notes':
        return (
          <NotesCell
            value={p.notes}
            disabled={isBusy}
            onSave={val => save(p._row, { notes: val })}
          />
        );
      case 'qte':
        return (
          <span className={`text-xs font-semibold ${p.qteACommander > 0 ? 'text-blue-600' : 'text-gray-400'}`}>
            {p.qteACommander}
          </span>
        );
      case 'categorie':
        return (
          <MultiSelectCat
            value={p.categorie}
            options={categories}
            disabled={isBusy}
            onSave={val => save(p._row, { categorie: val })}
          />
        );
      case 'prix':
        return frPrix(p.prixCost);
      case 'prixVente':
        return frPrix(p.prixBDC);
      case 'stock':
        return (
          <span className={`text-xs font-semibold tabular-nums ${p.stock > 0 ? 'text-green-600' : 'text-gray-400'}`}>
            {p.stock}
          </span>
        );
      case 'fournisseur':
        return (
          <select
            value={p.fournisseur}
            onChange={e => save(p._row, { fournisseur: e.target.value })}
            disabled={isBusy}
            className="w-full text-xs border rounded px-1 py-0.5 bg-white focus:outline-none focus:ring-1 focus:ring-yellow-400 text-gray-600"
          >
            <option value="">—</option>
            {fournisseurs.map(f => <option key={f} value={f}>{f}</option>)}
            {p.fournisseur && !fournisseurs.includes(p.fournisseur) && (
              <option value={p.fournisseur}>{p.fournisseur}</option>
            )}
          </select>
        );
      case 'sku':
        return p.skuUrl ? (
          <a href={p.skuUrl} target="_blank" rel="noopener noreferrer"
            className="text-xs font-mono text-blue-500 hover:underline truncate block text-center" title={p.skuUrl}>
            {p.sku || p.skuUrl}
          </a>
        ) : (
          <span className="text-xs font-mono text-gray-500 truncate block text-center" title={p.sku}>
            {p.sku || '—'}
          </span>
        );
      case 'oos':
        return p.oos ? (
          <span className="text-xs font-bold text-red-600">OOS</span>
        ) : null;
    }
  }

  // Colgroup + thead partagés — assure l'alignement entre les blocs
  function TableColgroup() {
    return (
      <colgroup>
        {orderedCols.map(col => (
          <col key={col.id} style={{ width: (col as any).width || undefined }} />
        ))}
      </colgroup>
    );
  }

  function TableHead() {
    return (
      <thead>
        <tr className="list-header">
          {orderedCols.map(col => (
            <DragTh key={col.id} className={col.hCls} isDragOver={dragOverId === col.id} {...dragProps(col.id)}>
              {col.header}
            </DragTh>
          ))}
        </tr>
      </thead>
    );
  }

  const OOS_RED_COLS = ['oos', 'stock', 'prix', 'prixVente', 'qte'];

  function PieceRow({ p, idx }: { p: Piece; idx: number }) {
    const isOos = !!p.oos;
    const baseBg = idx % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)';
    const oosPresent = orderedCols
      .map(c => c.id)
      .filter(id => OOS_RED_COLS.includes(id));
    const oosFirst = oosPresent[0];
    const oosLast  = oosPresent[oosPresent.length - 1];
    return (
      <tr className={`text-sm ${busy.has(p._row) ? 'opacity-60' : ''}`}>
        {orderedCols.map(col => {
          const inPill = isOos && OOS_RED_COLS.includes(col.id);
          if (inPill) {
            const isFirst = col.id === oosFirst;
            const isLast  = col.id === oosLast;
            const radius = isFirst && isLast ? '20px'
              : isFirst ? '20px 0 0 20px'
              : isLast  ? '0 20px 20px 0'
              : undefined;
            return (
              <td
                key={col.id}
                style={{
                  padding: 0,
                  paddingTop: '2pt',
                  paddingBottom: '2pt',
                  paddingRight: 0,
                  verticalAlign: 'middle',
                  backgroundColor: baseBg,
                }}
              >
                <div
                  className={col.cCls}
                  style={{
                    backgroundColor: 'rgba(239,68,68,0.3)',
                    color: '#7f1d1d',
                    borderRadius: radius,
                    whiteSpace: 'nowrap',
                    height: '36px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxSizing: 'border-box',
                  }}
                >
                  {renderCell(col.id as ColId, p)}
                </div>
              </td>
            );
          }
          return (
            <td key={col.id} className={col.cCls} style={{ backgroundColor: baseBg }}>
              {renderCell(col.id as ColId, p)}
            </td>
          );
        })}
      </tr>
    );
  }

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">

        <PageHeader
          subtitle="catalogue achats"
          title="Pièces"
          titleSuffix=": catalogue"
          helpTopic="10-scanner-codebarre"
          helpTitle="Catalogue pièces"
          helpHint="Catalogue des pièces avec stock, SKU, fournisseur. Scan code-barre disponible (📷). Voir le tutoriel scanner."
        >
          <ToolbarBlock>
            <SearchInput value={search} onChange={setSearch} />
            <PiecesTabs anchors={catAnchors} />
          </ToolbarBlock>
          <button
            type="button"
            onClick={() => setShowBromp(true)}
            title="Importer un catalogue Brompton (xlsx Square POS)"
            className="flex items-center justify-center transition-colors shrink-0"
            style={{
              width: '37px', height: '37px',
              borderRadius: '50%',
              backgroundColor: 'transparent',
              color: '#fff056',
              border: '2px solid #fff056',
              cursor: 'pointer',
              padding: 0,
            }}
          >
            <ArrowDownTrayIcon style={{ width: '20px', height: '20px' }} />
          </button>
          {/* Export CSV étiquettes QL-600 (P-touch/Dymo) */}
          <button
            type="button"
            onClick={() => window.open('/api/catalogue/export/labels', '_blank')}
            title="Export CSV étiquettes (P-touch / Dymo) — QL-600"
            className="flex items-center justify-center transition-colors shrink-0"
            style={{
              width: '37px', height: '37px',
              borderRadius: '50%',
              backgroundColor: 'transparent',
              color: '#fff056',
              border: '2px solid #fff056',
              cursor: 'pointer',
              padding: 0,
            }}
          >
            <TagIcon style={{ width: '20px', height: '20px' }} />
          </button>
          {/* Historique des scans (log localStorage) */}
          <button
            type="button"
            onClick={() => setShowScanLog(true)}
            title="Historique des scans (log local)"
            className="flex items-center justify-center transition-colors shrink-0"
            style={{
              width: '37px', height: '37px',
              borderRadius: '50%',
              backgroundColor: 'transparent',
              color: '#fff056',
              border: '2px solid #fff056',
              cursor: 'pointer',
              padding: 0,
            }}
          >
            <ClockIcon style={{ width: '20px', height: '20px' }} />
          </button>
          <AddButton onClick={() => openAddPiece()} title="Nouvelle pièce" />
        </PageHeader>

        {isLoading && <LoadingSpinner className="py-20" />}

        {!isLoading && (
          <div className="md:bg-black/20 md:rounded-[50px] md:p-5">
           <div className="flex flex-col" style={{ gap: '20px' }}>

            {[...grouped.entries()].map(([mainCat, subMap]) => {
              // Toutes les pièces de la catégorie principale, pour le total
              const allItems = [...subMap.values()].flat();
              // Sous-catégories triées, "" (sans sub) en dernier
              const subs = [...subMap.entries()].sort((a, b) => {
                if (!a[0]) return 1;
                if (!b[0]) return -1;
                return a[0].localeCompare(b[0], 'fr');
              });
              return (
                <div
                  key={mainCat}
                  id={catSlug(mainCat)}
                  className="overflow-hidden"
                  style={{ borderRadius: '30px', scrollMarginTop: '140px' }}
                >
                  {/* Entête jaune : catégorie principale */}
                  <div
                    className="flex items-center justify-between"
                    style={{ backgroundColor: '#fff056', height: '64px', paddingLeft: '30px', paddingRight: '30px' }}
                  >
                    <div className="flex items-center gap-3">
                      <CubeIcon style={{ width: '30px', height: '30px', color: 'rgba(0,0,0,0.5)' }} />
                      <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '24px', fontWeight: 700, lineHeight: 1 }}>
                        {mainCat}
                      </span>
                      <span style={{ color: 'rgba(0,0,0,0.4)', fontSize: '14px' }}>
                        ({allItems.length})
                      </span>
                    </div>
                    <button
                      onClick={() => openAddPiece(mainCat)}
                      className="btn-plus-round"
                      title={`Nouvelle pièce dans ${mainCat}`}
                    >
                      <PlusIcon />
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left table-fixed">
                      <TableColgroup />
                      <TableHead />
                      <tbody>
                        {subs.map(([sub, items], subIdx) => (
                          <React.Fragment key={sub || '__'}>
                            {/* Ligne de sous-catégorie (sauf pour "" = pas de sub) */}
                            {sub && (
                              <tr>
                                <td
                                  colSpan={orderedCols.length}
                                  style={{
                                    backgroundColor: 'rgba(255,255,255,0.35)',
                                    color: '#fff056',
                                    fontSize: '14pt',
                                    fontWeight: 400,
                                    paddingTop: '10pt',
                                    paddingBottom: '10pt',
                                    paddingLeft: '86px',
                                    paddingRight: '16px',
                                    borderTop: subIdx > 0 ? '1px solid rgba(0,0,0,0.12)' : 'none',
                                  }}
                                >
                                  {sub}
                                </td>
                              </tr>
                            )}
                            {items.map((p, i) => <PieceRow key={p._row} p={p} idx={i} />)}
                          </React.Fragment>
                        ))}
                        {/* Ligne total — même style que légende */}
                        <tr className="list-header">
                          {orderedCols.map(col => (
                            <td key={col.id} className={col.cCls}>
                              {col.id === 'nom' ? `${allItems.length} pièces` :
                               col.id === 'prix' ? <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '15px' }}>{frPrix(allItems.reduce((s, x) => s + (x.prixBase || 0), 0))}</span> : ''}
                            </td>
                          ))}
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}

            {filtered.length === 0 && (
              <p className="text-center py-16" style={{ color: 'rgba(255,255,255,0.5)' }}>Aucune pièce trouvée.</p>
            )}
           </div>
          </div>
        )}
      </div>

      <PieceForm
        open={showAdd}
        onClose={() => setShowAdd(false)}
        categories={categories}
        fournisseurs={fournisseurs}
        initialCategorie={addInitCat}
      />

      <BromptonImportModal
        open={showBromp}
        onClose={() => setShowBromp(false)}
        pieces={pieces}
        onDone={() => { mutatePieces(); }}
      />

      <ScanLogModal open={showScanLog} onClose={() => setShowScanLog(false)} />
    </AppShell>
  );
}
