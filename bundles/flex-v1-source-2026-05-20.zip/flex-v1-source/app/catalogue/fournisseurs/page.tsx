'use client';
import React, { useState, useMemo } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock, AddButton, SearchInput } from '@/components/layout/PageHeader';
import PiecesTabs from '@/components/catalogue/PiecesTabs';
import NotesCell from '@/components/catalogue/NotesCell';
import PieceForm from '@/components/catalogue/PieceForm';
import MultiSelectCat from '@/components/ui/MultiSelectCat';
import { usePieces } from '@/hooks/useCatalogue';
import { frPrix } from '@/lib/utils/format';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import DragTh from '@/components/ui/DragTh';
import { useColOrder } from '@/hooks/useColOrder';
import { toast } from '@/components/ui/Toast';
import { CMD_OPTIONS as FLAG_OPTIONS, CMD_STYLE as FLAG_STYLE, CMD_TOOLTIP } from '@/lib/utils/statuts';
import { CubeIcon, ChevronDownIcon, ChevronRightIcon, PlusIcon } from '@heroicons/react/24/outline';
import type { Piece } from '@/types/catalogue';

const COLS = [
  { id: 'acmd',        header: 'statut',       width: '70px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'nom',         header: 'item',         width: '33%',    hCls: 'px-4 py-2',              cCls: 'px-4 py-2 text-gray-800 font-medium whitespace-nowrap overflow-hidden text-ellipsis' },
  { id: 'notes',       header: 'notes',        width: '',       hCls: 'px-3 py-2',              cCls: 'px-2 py-1' },
  { id: 'sku',         header: 'sku',          width: '90px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'oos',         header: 'oos',          width: '48px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'stock',       header: 'stock',        width: '48px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'prix',        header: 'prix',         width: '80px',   hCls: 'px-3 py-2 text-right',  cCls: 'px-3 py-1.5 text-right text-gray-700 font-medium' },
  { id: 'qte',         header: 'qté',          width: '50px',   hCls: 'px-2 py-2 text-center', cCls: 'px-2 py-1.5 text-center' },
  { id: 'sousTotal',   header: 's/total',      width: '80px',   hCls: 'px-3 py-2 text-right',  cCls: 'px-3 py-1.5 text-right text-gray-700 font-medium' },
  { id: 'categorie',   header: 'catégories',   width: '220px',  hCls: 'px-3 py-2',              cCls: 'px-3 py-1.5' },
] as const;

type ColId = typeof COLS[number]['id'];

function isExcluded(nom: string): boolean {
  if (!nom || nom.trim() === '') return true;
  const n = nom.trim().toLowerCase();
  if (n === 'nom item' || n === 'item') return true;
  if (nom.includes('FIN DE →')) return true;
  if (nom.startsWith('FIN DE')) return true;
  return false;
}


export default function FournisseursPage() {
  const { pieces, isLoading, patchPiece } = usePieces();
  const [search, setSearch] = useState('');
  const [busy,   setBusy]   = useState<Set<number>>(new Set());
  const [closed, setClosed] = useState<Set<string>>(new Set());
  const { orderedCols, dragProps, dragOverId } = useColOrder('fournisseurs', COLS as any);

  // Popup Nouvelle pièce
  const [showAdd,     setShowAdd]     = useState(false);
  const [addInitFourn, setAddInitFourn] = useState<string | undefined>(undefined);

  function openAddPiece(initFourn?: string) {
    setAddInitFourn(initFourn);
    setShowAdd(true);
  }

  // Liste de fournisseurs pour le dropdown du popup (catégories est déjà
  // calculé plus bas pour les cellules de catégorie).
  const fournisseursList = useMemo(() =>
    [...new Set(
      pieces
        .filter(p => !isExcluded(p.nom))
        .map(p => p.fournisseur)
        .filter(f => !!f && f.toLowerCase() !== 'fournisseur'),
    )].sort(),
  [pieces]);

  function toggleFournisseur(name: string) {
    setClosed(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  }

  const filtered = useMemo(() =>
    pieces.filter(p => {
      if (isExcluded(p.nom)) return false;
      if (!p.fournisseur) return false; // seulement les pièces avec fournisseur
      if (!search) return true;
      const q = search.toLowerCase();
      return (
        p.nom.toLowerCase().includes(q) ||
        p.fournisseur.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q)
      );
    }),
  [pieces, search]);

  const categories = useMemo(() =>
    [...new Set(pieces.filter(p => !isExcluded(p.nom)).map(p => p.categorie).filter(Boolean))].sort(),
  [pieces]);

  // Ordre prioritaire des fournisseurs
  const FOURNISSEUR_ORDER = ['Babac', 'HLC', 'Brompton', 'C&L'];

  const grouped = useMemo(() => {
    const map = new Map<string, Piece[]>();
    filtered.forEach(p => {
      const f = p.fournisseur || 'Autres';
      if (!map.has(f)) map.set(f, []);
      map.get(f)!.push(p);
    });
    // Trier : ordre prioritaire d'abord, puis alphabétique, "Autres" en dernier
    const entries = [...map.entries()].sort((a, b) => {
      const ia = FOURNISSEUR_ORDER.indexOf(a[0]);
      const ib = FOURNISSEUR_ORDER.indexOf(b[0]);
      if (a[0] === 'Autres') return 1;
      if (b[0] === 'Autres') return -1;
      if (ia >= 0 && ib >= 0) return ia - ib;
      if (ia >= 0) return -1;
      if (ib >= 0) return 1;
      return a[0].localeCompare(b[0], 'fr');
    });
    return new Map(entries);
  }, [filtered]);

  async function save(row: number, fields: Parameters<typeof patchPiece>[1]) {
    setBusy(prev => new Set(prev).add(row));
    try { await patchPiece(row, fields); }
    catch (err: any) { toast(err.message, 'error'); }
    finally { setBusy(prev => { const s = new Set(prev); s.delete(row); return s; }); }
  }

  function renderCell(id: ColId, p: Piece) {
    const isBusy = busy.has(p._row);
    const style  = FLAG_STYLE[p.flag] ?? FLAG_STYLE['...'];

    switch (id) {
      case 'acmd':
        return (
          <select
            value={FLAG_OPTIONS.includes(p.flag as any) ? p.flag : '...'}
            onChange={e => save(p._row, { flag: e.target.value })}
            disabled={isBusy}
            title={CMD_TOOLTIP}
            className="text-xs border rounded px-1 py-0.5 font-bold w-full focus:outline-none focus:ring-1 focus:ring-yellow-400"
            style={{ backgroundColor: style.bg, color: style.fg }}
          >
            {FLAG_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
          </select>
        );
      case 'nom':
        return p.skuUrl
          ? <a href={p.skuUrl} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()}
               className="hover:underline" style={{ color: 'inherit' }} title={p.skuUrl}>{p.nom}</a>
          : <span title={p.nom}>{p.nom}</span>;
      case 'notes':
        return (
          <NotesCell
            value={p.notes}
            disabled={isBusy}
            onSave={val => save(p._row, { notes: val })}
          />
        );
      case 'qte':
        return (
          <span className={`text-xs font-semibold ${p.qteACommander > 0 ? 'text-blue-600' : 'text-gray-400'}`}>
            {p.qteACommander}
          </span>
        );
      case 'categorie':
        return (
          <MultiSelectCat
            value={p.categorie}
            options={categories}
            disabled={isBusy}
            onSave={val => save(p._row, { categorie: val })}
          />
        );
      case 'prix':
        return frPrix(p.prixBase);
      case 'sousTotal':
        return frPrix(p.sousTotal);
      case 'stock':
        return (
          <span className={`text-xs font-semibold tabular-nums ${p.stock > 0 ? 'text-green-600' : 'text-gray-400'}`}>
            {p.stock}
          </span>
        );
      case 'sku':
        return p.skuUrl ? (
          <a href={p.skuUrl} target="_blank" rel="noopener noreferrer"
            className="text-xs font-mono text-blue-500 hover:underline truncate block text-center" title={p.skuUrl}>
            {p.sku || p.skuUrl}
          </a>
        ) : (
          <span className="text-xs font-mono text-gray-500 truncate block text-center" title={p.sku}>
            {p.sku || '—'}
          </span>
        );
      case 'oos':
        return p.oos ? (
          <span className="text-xs font-bold text-red-600">OOS</span>
        ) : null;
    }
  }

  function TableColgroup() {
    return (
      <colgroup>
        {orderedCols.map(col => (
          <col key={col.id} style={{ width: (col as any).width || undefined }} />
        ))}
      </colgroup>
    );
  }

  function TableHead() {
    return (
      <thead>
        <tr className="list-header">
          {orderedCols.map(col => (
            <DragTh key={col.id} className={col.hCls} isDragOver={dragOverId === col.id} {...dragProps(col.id)}>
              {col.header}
            </DragTh>
          ))}
        </tr>
      </thead>
    );
  }

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader subtitle="catalogue achats" title="Pièces" titleSuffix=": fournisseurs">
          <ToolbarBlock>
            <SearchInput value={search} onChange={setSearch} />
            <PiecesTabs />
          </ToolbarBlock>
          <AddButton disabled title="—" />
        </PageHeader>

        {isLoading && <LoadingSpinner className="py-20" />}

        {!isLoading && (
          <div className="md:bg-black/20 md:rounded-[50px] md:p-5">
           <div className="flex flex-col" style={{ gap: '20px' }}>
            {[...grouped.entries()].map(([fournisseur, items]) => {
              const total = items.reduce((s, p) => s + p.sousTotal, 0);
              const isClosed = closed.has(fournisseur);
              return (
              <div key={fournisseur} className="overflow-hidden" style={{ borderRadius: '30px' }}>
                <div
                  className="flex items-center justify-between"
                  style={{ backgroundColor: '#fff056', height: '64px', paddingLeft: '30px', paddingRight: '30px' }}
                >
                  <div className="flex items-center gap-3">
                    <CubeIcon style={{ width: '30px', height: '30px', color: 'rgba(0,0,0,0.5)' }} />
                    <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '24px', fontWeight: 700, lineHeight: 1 }}>
                      {fournisseur}
                    </span>
                    <span style={{ color: 'rgba(0,0,0,0.4)', fontSize: '14px' }}>({items.length})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => openAddPiece(fournisseur)}
                      className="btn-plus-round"
                      title={`Nouvelle pièce pour ${fournisseur}`}
                    >
                      <PlusIcon />
                    </button>
                    <button
                      onClick={() => toggleFournisseur(fournisseur)}
                      className="flex items-center justify-center transition-opacity hover:opacity-70"
                      style={{ width: '35px', height: '35px', color: 'rgba(0,0,0,0.5)' }}
                      title={isClosed ? 'Ouvrir' : 'Fermer'}
                    >
                      {isClosed
                        ? <ChevronRightIcon style={{ width: '24px', height: '24px' }} strokeWidth={3} />
                        : <ChevronDownIcon style={{ width: '24px', height: '24px' }} strokeWidth={3} />}
                    </button>
                  </div>
                </div>
                {!isClosed && <div className="overflow-x-auto">
                  <table className="w-full text-left table-fixed">
                    <TableColgroup />
                    <TableHead />
                    <tbody>
                      {items.map((p, i) => {
                        const isOos = !!p.oos;
                        const OOS_COLS = ['oos', 'stock', 'prix', 'qte', 'sousTotal'];
                        const oosPresent = orderedCols
                          .map(c => c.id)
                          .filter(id => OOS_COLS.includes(id));
                        const oosFirst = oosPresent[0];
                        const oosLast  = oosPresent[oosPresent.length - 1];
                        const baseBg = i % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)';
                        return (
                          <tr key={p._row} className={`text-sm ${busy.has(p._row) ? 'opacity-60' : ''}`}>
                            {orderedCols.map(col => {
                              const inPill = isOos && OOS_COLS.includes(col.id);
                              if (inPill) {
                                const isFirst = col.id === oosFirst;
                                const isLast  = col.id === oosLast;
                                const radius = isFirst && isLast ? '20px'
                                  : isFirst ? '20px 0 0 20px'
                                  : isLast  ? '0 20px 20px 0'
                                  : undefined;
                                return (
                                  <td
                                    key={col.id}
                                    style={{
                                      padding: 0,
                                      paddingTop: '2pt',
                                      paddingBottom: '2pt',
                                      paddingRight: 0,
                                      verticalAlign: 'middle',
                                      backgroundColor: baseBg,
                                    }}
                                  >
                                    <div
                                      className={col.cCls}
                                      style={{
                                        backgroundColor: 'rgba(239,68,68,0.3)',
                                        color: '#7f1d1d',
                                        borderRadius: radius,
                                        whiteSpace: 'nowrap',
                                        height: '36px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        boxSizing: 'border-box',
                                      }}
                                    >
                                      {renderCell(col.id as ColId, p)}
                                    </div>
                                  </td>
                                );
                              }
                              return (
                                <td key={col.id} className={col.cCls} style={{ backgroundColor: baseBg }}>
                                  {renderCell(col.id as ColId, p)}
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })}
                      <tr className="list-header">
                        {orderedCols.map(col => (
                          <td key={col.id} className={col.cCls}>
                            {col.id === 'sousTotal' ? <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '16px' }}>{frPrix(total)}</span> : col.id === 'nom' ? 'total fournisseur' : ''}
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>}
              </div>
            );})}

            {filtered.length === 0 && (
              <p className="text-center py-16" style={{ color: 'rgba(255,255,255,0.5)' }}>Aucune pièce avec fournisseur trouvée.</p>
            )}
           </div>
          </div>
        )}
      </div>

      <PieceForm
        open={showAdd}
        onClose={() => setShowAdd(false)}
        categories={categories}
        fournisseurs={fournisseursList}
        initialFournisseur={addInitFourn}
      />
    </AppShell>
  );
}
