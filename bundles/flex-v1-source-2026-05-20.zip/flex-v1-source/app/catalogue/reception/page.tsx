'use client';
import React, { useState, useMemo } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock, AddButton, UtilButton } from '@/components/layout/PageHeader';
import PiecesTabs from '@/components/catalogue/PiecesTabs';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import PromptDialog from '@/components/ui/PromptDialog';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { usePOs } from '@/hooks/usePO';
import { usePieces } from '@/hooks/useCatalogue';
import { frPrix, normSearch, autoPickCategorie } from '@/lib/utils/format';
import { toast } from '@/components/ui/Toast';
import { PlusIcon, TrashIcon, CheckCircleIcon, ChevronDownIcon, ChevronRightIcon, ClipboardDocumentListIcon, ClipboardDocumentCheckIcon, ArrowUpTrayIcon, ArrowDownTrayIcon, ArrowPathIcon, CubeIcon } from '@heroicons/react/24/outline';
import Modal from '@/components/ui/Modal';
import BarcodeScanner from '@/components/ui/BarcodeScanner';
import ImportModal from '@/components/catalogue/ImportModal';
import { QrCodeIcon } from '@heroicons/react/24/outline';
import PieceForm from '@/components/catalogue/PieceForm';
import AdhocMergePanel from '@/components/reception/AdhocMergePanel';
import { PO_STATUS_STYLE, PO_STATUS_LABEL } from '@/lib/utils/statuts';
import type { PO, POLineItem } from '@/types/po';

// v1.1.4 — Item 6 audit : STATUS_STYLE/STATUS_LABEL locaux remplacés par
// les exports partagés de lib/utils/statuts (aliases pour préserver les
// call-sites du fichier).
const STATUS_STYLE = PO_STATUS_STYLE;
const STATUS_LABEL = PO_STATUS_LABEL;

export default function ReceptionPage() {
  const { pos, isLoading, createPO, addLines, updateLine, deleteLine, reopenPO, finalize, mutate: mutatePOs } = usePOs();
  const { pieces, mutate: mutatePieces } = usePieces();
  const [syncing, setSyncing] = useState(false);

  async function handleSync() {
    setSyncing(true);
    try {
      // 1. Bypass cache serveur (invalide les caches NodeCache)
      await fetch('/api/sync?force=1', { method: 'POST' });

      // 2. Fetch frais avec ?refresh=1 (bypass cache serveur de la current instance)
      const [piecesRes, posRes] = await Promise.all([
        fetch('/api/catalogue/pieces?refresh=1').then(r => r.json()),
        fetch('/api/po?refresh=1').then(r => r.json()),
      ]);

      // 3. Injecter les données fraîches dans SWR (force update sans revalidate)
      await Promise.all([
        mutatePieces(piecesRes, { revalidate: false }),
        mutatePOs(posRes, { revalidate: false }),
      ]);

      toast('Données rafraîchies');
    } catch (err: any) { toast(err.message, 'error'); }
    finally { setSyncing(false); }
  }

  // Formulaire nouveau PO
  const [showNew,     setShowNew]     = useState(false);
  const [newFourn,    setNewFourn]    = useState('');
  const [promptNewFournOpen, setPromptNewFournOpen] = useState(false);
  const [newPoNum,    setNewPoNum]    = useState('');
  const [newDate,     setNewDate]     = useState(new Date().toISOString().slice(0, 10));
  const [newDateRec,  setNewDateRec]  = useState('');
  const [newItems,    setNewItems]    = useState<{ nom: string; sku: string; qteCommandee: number; prixAchat: number; pieceRow: number; pieceId: string; categorie?: string }[]>([]);
  const [searchPiece, setSearchPiece] = useState('');
  const [creating,    setCreating]    = useState(false);

  // PO actif étendu (pour ajouter des items)
  const [expandedPO,      setExpandedPO]      = useState<string | null>(null);
  const [addSearchPiece,  setAddSearchPiece]  = useState('');
  const [addingToPO,      setAddingToPO]      = useState(false);
  // v1.0.16+ : modal d'ajout de pièces à un PO ouvert (remplace le champ inline)
  const [addPieceModalPO, setAddPieceModalPO] = useState<string | null>(null);

  // Création inline d'une pièce absente du catalogue (depuis la réception)
  const [createPieceCtx, setCreatePieceCtx] = useState<
    { nom: string; fournisseur: string; mode: 'new' | 'existing'; poNumber?: string } | null
  >(null);

  // Catégories + fournisseurs disponibles pour le dropdown PieceForm
  const allCategories = useMemo(() =>
    [...new Set(pieces.map(p => p.categorie).filter(Boolean))].sort(),
    [pieces],
  );
  const allFournisseurs = useMemo(() =>
    [...new Set(
      pieces
        .map(p => p.fournisseur)
        .filter(f => !!f && f.toLowerCase() !== 'fournisseur'),
    )].sort(),
    [pieces],
  );

  // Finalisation
  const [finalizeTarget, setFinalizeTarget] = useState<string | null>(null);
  const [syncStockTarget, setSyncStockTarget] = useState<string | null>(null);
  const [scanPO, setScanPO] = useState<string | null>(null);
  const [scanMessage, setScanMessage] = useState<string>('');

  /** Scan handler : match le SKU contre les items du PO ouvert, +1 sur qteRecue. */
  async function handleScan(sku: string) {
    if (!scanPO) return;
    const po = pos.find(p => p.poNumber === scanPO);
    if (!po) return;
    const normSku = sku.trim().toLowerCase();
    const idx = po.items.findIndex(it => (it.sku || '').trim().toLowerCase() === normSku);
    if (idx < 0) {
      setScanMessage(`❌ SKU « ${sku} » absent de ce PO`);
      return;
    }
    const item = po.items[idx];
    const nextRecue = item.qteRecue + 1;
    const autoRecu = nextRecue >= item.qteCommandee;
    try {
      await updateLine(po.poNumber, po._rows[idx], { qteRecue: nextRecue, recu: autoRecu });
      setScanMessage(`✓ ${item.nom} (${sku}) — ${nextRecue}/${item.qteCommandee}`);
      await mutatePieces();
    } catch (err: any) {
      setScanMessage(`❌ ${err.message || 'Échec update'}`);
    }
  }
  const [syncingStock, setSyncingStock] = useState(false);

  async function handleSyncStock() {
    if (!syncStockTarget) return;
    setSyncingStock(true);
    try {
      const res = await fetch(`/api/po/${encodeURIComponent(syncStockTarget)}/sync-stock`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Échec sync stock');
      let msg = `Stock mis à jour : ${data.applied} ligne(s), +${data.totalDelta} unité(s)`;
      if (data.createdPieces?.length > 0) {
        msg += `\n\n${data.createdPieces.length} pièce(s) créée(s) :\n` + data.createdPieces.map((p: any) => `• ${p.nom} (${p.pieceId})`).join('\n');
      }
      toast(msg);
      await mutatePieces();
      setSyncStockTarget(null);
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setSyncingStock(false);
    }
  }
  const [deleteTarget,   setDeleteTarget]   = useState<string | null>(null);
  const [deleting,       setDeleting]       = useState(false);
  const [finalizing,     setFinalizing]     = useState(false);

  // Log modal (items manquants d'un PO PARTIEL)
  const [logPO, setLogPO] = useState<string | null>(null);

  // Import modal — null = nouveau PO, string = ajouter au PO existant
  const [showImport, setShowImport] = useState(false);
  const [importTargetPO, setImportTargetPO] = useState<string | null>(null);

  // Fournisseurs = union du catalogue (pièces) + des POs existants.
  // Les PO incluent les fournisseurs ajoutés via « + Nouveau fournisseur »
  // même s'ils n'ont pas encore de pièce au catalogue → évite qu'ils
  // disparaissent du dropdown après création.
  const fournisseurs = useMemo(() => {
    const set = new Set<string>();
    for (const p of pieces) {
      if (p.fournisseur && p.fournisseur.toLowerCase() !== 'fournisseur') set.add(p.fournisseur);
    }
    for (const po of pos) {
      if (po.fournisseur) set.add(po.fournisseur);
    }
    return [...set].sort((a, b) => a.localeCompare(b, 'fr'));
  }, [pieces, pos]);

  // Pièces filtrées pour le formulaire nouveau PO
  const filteredPieces = useMemo(() => {
    if (!newFourn) return [];
    return pieces.filter(p => {
      if (p.fournisseur !== newFourn) return false;
      if (!p.nom || p.nom === 'Nom ITEM' || p.nom.startsWith('FIN DE')) return false;
      if (!searchPiece) return true;
      const q = normSearch(searchPiece);
      return normSearch(p.nom).includes(q) || normSearch(p.sku).includes(q);
    });
  }, [pieces, newFourn, searchPiece]);

  // Pièces filtrées pour ajouter à un PO existant (modal v1.0.16+)
  const filteredPiecesForAdd = useMemo(() => {
    if (!addPieceModalPO) return [];
    const po = pos.find(p => p.poNumber === addPieceModalPO);
    if (!po) return [];
    const q = normSearch(addSearchPiece);
    return pieces.filter(p => {
      if (p.fournisseur !== po.fournisseur) return false;
      if (!p.nom || p.nom === 'Nom ITEM' || p.nom.startsWith('FIN DE')) return false;
      if (!q) return true; // pas de query → toutes les pièces du fournisseur
      return normSearch(p.nom).includes(q) || normSearch(p.sku).includes(q);
    });
  }, [pieces, pos, addPieceModalPO, addSearchPiece]);

  const addPieceModalPOObj = addPieceModalPO ? pos.find(p => p.poNumber === addPieceModalPO) ?? null : null;

  // PO actifs (EN ATTENTE) et historique — triés par dateCommande desc
  // (récents en haut, demande yako-san 2026-05-16).
  const sortByDateDesc = (a: typeof pos[0], b: typeof pos[0]) =>
    (b.dateCommande || '').localeCompare(a.dateCommande || '');
  const activePOs  = pos.filter(p => p.status === 'EN ATTENTE' || p.status === 'PARTIEL').sort(sortByDateDesc);
  const historyPOs = pos.filter(p => p.status === 'RECU' || p.status === 'ANNULE').sort(sortByDateDesc);

  function addItemToPO(piece: typeof pieces[0]) {
    if (newItems.some(it => it.pieceRow === piece._row)) return;
    setNewItems(prev => [...prev, {
      nom          : piece.nom,
      sku          : piece.sku,
      qteCommandee : piece.qteACommander || 1,
      prixAchat    : piece.prixBase || piece.prixAchat || 0,
      pieceRow     : piece._row,
      pieceId      : piece.pieceId || '',
    }]);
    setSearchPiece('');
  }

  async function handleImportResult(items: { nom: string; sku: string; qteCommandee: number; prixAchat: number; pieceRow: number; pieceId: string }[], meta: Record<string, string>) {
    // Mode 1 : ajouter au PO existant
    if (importTargetPO) {
      const targetPo = pos.find(p => p.poNumber === importTargetPO);
      if (!targetPo) { toast('PO introuvable', 'error'); return; }
      // Filtrer les doublons (déjà présents dans le PO)
      const existing = new Set(targetPo.items.map(it => it.sku || it.nom));
      const newOnes = items.filter(it => !existing.has(it.sku || it.nom));
      if (newOnes.length === 0) { toast('Tous les items sont déjà présents dans le PO', 'error'); return; }
      try {
        await addLines(importTargetPO, newOnes.map(it => {
          const piece = it.pieceId ? pieces.find(p => p.pieceId === it.pieceId) : null;
          const categorie = piece?.categorie || autoPickCategorie(it.nom, allCategories);
          return { ...it, notes: '', categorie };
        }));
        toast(`${newOnes.length} items ajoutés au PO ${importTargetPO}` + (items.length - newOnes.length > 0 ? ` (${items.length - newOnes.length} doublons ignorés)` : ''));
        setImportTargetPO(null);
      } catch (err: any) { toast(err.message, 'error'); }
      return;
    }
    // Mode 2 : nouveau PO — enrichir avec la catégorie (piece existante, ou auto-pick)
    const enriched = items.map(it => {
      const piece = it.pieceId ? pieces.find(p => p.pieceId === it.pieceId) : null;
      const categorie = piece?.categorie || autoPickCategorie(it.nom, allCategories);
      return { ...it, categorie };
    });
    setNewItems(enriched);
    if (meta.orderNumber) setNewPoNum(meta.orderNumber);
    if (meta.invoiceNumber && !meta.orderNumber) setNewPoNum(meta.invoiceNumber);
    // Fournisseur : priorité à meta.fournisseur (choisi par l'utilisateur dans
    // le modal d'import), sinon déduit du 1ᵉʳ item matché au catalogue.
    if (meta.fournisseur) {
      setNewFourn(meta.fournisseur);
    } else {
      const firstMatched = items.find(it => it.pieceId);
      if (firstMatched) {
        const piece = pieces.find(p => p.pieceId === firstMatched.pieceId);
        if (piece) setNewFourn(piece.fournisseur);
      }
    }
    setShowNew(true);
    toast(`${items.length} items importés`);
  }

  function applyNewFourn(fourn: string) {
    setNewFourn(fourn);
    if (fourn) {
      const enCommande = pieces.filter(p =>
        p.fournisseur === fourn && p.flag === '$' && p.nom && p.nom !== 'Nom ITEM' && !p.nom.startsWith('FIN DE')
      );
      setNewItems(enCommande.map(p => ({
        nom          : p.nom,
        sku          : p.sku,
        qteCommandee : p.qteACommander || 1,
        prixAchat    : p.prixBase || p.prixAchat || 0,
        pieceRow     : p._row,
        pieceId      : p.pieceId || '',
        categorie    : p.categorie || '',
      })));
    } else {
      setNewItems([]);
    }
  }

  function removeNewItem(idx: number) {
    setNewItems(prev => prev.filter((_, i) => i !== idx));
  }

  function setNewItemQte(idx: number, qte: number) {
    setNewItems(prev => prev.map((it, i) => i === idx ? { ...it, qteCommandee: Math.max(0, qte) } : it));
  }

  async function handleCreate() {
    if (!newPoNum.trim() || !newFourn || !newItems.length || !newDate || !newDateRec) {
      toast('Remplir tous les champs (fournisseur, n° commande, dates) et au moins 1 item', 'error');
      return;
    }
    setCreating(true);
    try {
      await createPO({
        poNumber    : newPoNum.trim(),
        fournisseur : newFourn,
        dateCommande: newDate,
        items       : newItems.map(it => ({ ...it, notes: '' })),
      });
      toast(`PO ${newPoNum} créé (${newItems.length} items)`);
      const createdPoNum = newPoNum.trim();
      setShowNew(false);
      setNewPoNum('');
      setNewFourn('');
      setNewItems([]);
      setSearchPiece('');
      // Ouvrir le PO créé
      setExpandedPO(createdPoNum);
    } catch (err: any) { toast(err.message, 'error'); }
    finally { setCreating(false); }
  }

  /** Après création d'une pièce depuis la réception : on rafraîchit le
   *  catalogue, on trouve la nouvelle pièce par nom normalisé, puis on
   *  l'ajoute à l'endroit prévu (nouveau PO ou PO existant). */
  async function handlePieceCreatedFromReception(info?: { nom: string; fournisseur: string }) {
    const ctx = createPieceCtx;
    setCreatePieceCtx(null);
    if (!info || !ctx) return;
    try {
      // Bypass cache serveur + refetch SWR
      const res = await fetch('/api/catalogue/pieces?refresh=1').then(r => r.json());
      await mutatePieces(res, { revalidate: false });
      const fresh: typeof pieces = res?.pieces ?? [];
      const normNom = info.nom.toLowerCase().replace(/\s+/g, ' ').trim();
      const newPiece = fresh.find(p => p.nom.toLowerCase().replace(/\s+/g, ' ').trim() === normNom);
      if (!newPiece) {
        toast('Pièce créée mais introuvable au catalogue (rafraîchir la page)', 'error');
        return;
      }
      if (ctx.mode === 'existing' && ctx.poNumber) {
        const po = pos.find(p => p.poNumber === ctx.poNumber);
        if (po) await handleAddToExistingPO(po, newPiece);
      } else {
        addItemToPO(newPiece);
      }
    } catch (err: any) {
      toast(err?.message ?? 'Erreur après création', 'error');
    }
  }

  async function handleAddToExistingPO(po: PO, piece: typeof pieces[0]) {
    // Vérifier que la pièce n'est pas déjà dans le PO
    if (po.items.some(it => it.pieceRow === piece._row)) {
      toast('Cette pièce est déjà dans le PO', 'error');
      return;
    }
    setAddingToPO(true);
    try {
      await addLines(po.poNumber, [{
        nom          : piece.nom,
        sku          : piece.sku,
        qteCommandee : piece.qteACommander || 1,
        prixAchat    : piece.prixBase || piece.prixAchat || 0,
        pieceId      : piece.pieceId || '',
        pieceRow     : piece._row,
        notes        : '',
      }]);
      toast(`${piece.nom} ajouté au PO ${po.poNumber}`);
      setAddSearchPiece('');
    } catch (err: any) { toast(err.message, 'error'); }
    finally { setAddingToPO(false); }
  }

  async function handleToggleRecu(po: PO, itemIdx: number) {
    const item = po.items[itemIdx];
    const row  = po._rows[itemIdx];
    const newRecu = !item.recu;
    try {
      const res = await updateLine(po.poNumber, row, {
        recu    : newRecu,
        qteRecue: newRecu ? item.qteCommandee : 0,
      });
      if (res?.createdPiece) {
        toast(`${res.createdPiece.nom} ajoutée au catalogue (${res.createdPiece.pieceId})`);
        await mutatePieces();
      } else if (res?.stockDelta) {
        await mutatePieces();
      }
    } catch (err: any) { toast(err.message, 'error'); }
  }

  async function handleQteCommandee(po: PO, itemIdx: number, delta: number) {
    const item = po.items[itemIdx];
    const row  = po._rows[itemIdx];
    const next = Math.max(0, item.qteCommandee + delta);
    // Auto-toggle checkbox : recu = TRUE si reçu >= cmd, FALSE sinon
    const autoRecu = item.qteRecue >= next;
    await updateLine(po.poNumber, row, { qteCommandee: next, recu: autoRecu }).catch(err => toast(err.message, 'error'));
  }

  async function handleQteRecue(po: PO, itemIdx: number, delta: number) {
    const item = po.items[itemIdx];
    const row  = po._rows[itemIdx];
    const next = Math.max(0, item.qteRecue + delta);
    // Auto-toggle checkbox : recu = TRUE si reçu >= cmd, FALSE sinon
    const autoRecu = next >= item.qteCommandee;
    try {
      const res = await updateLine(po.poNumber, row, { qteRecue: next, recu: autoRecu });
      if (res?.createdPiece) {
        toast(`${res.createdPiece.nom} ajoutée au catalogue (${res.createdPiece.pieceId})`);
        await mutatePieces();
      } else if (res?.stockDelta) {
        await mutatePieces();
      }
    } catch (err: any) { toast(err.message, 'error'); }
  }

  async function handleDeleteLine(po: PO, itemIdx: number) {
    const row = po._rows[itemIdx];
    await deleteLine(po.poNumber, row).catch(err => toast(err.message, 'error'));
  }

  async function handleDeletePO() {
    if (!deleteTarget) return;
    const po = pos.find(p => p.poNumber === deleteTarget);
    if (!po) { setDeleteTarget(null); return; }
    setDeleting(true);
    try {
      // Supprimer toutes les lignes du PO (de bas en haut pour éviter le décalage)
      const rows = [...po._rows].sort((a, b) => b - a);
      for (const row of rows) {
        await deleteLine(po.poNumber, row);
      }
      toast(`PO ${deleteTarget} supprimé`);
      setDeleteTarget(null);
      if (expandedPO === deleteTarget) setExpandedPO(null);
    } catch (err: any) { toast(err.message, 'error'); }
    finally { setDeleting(false); }
  }

  async function handleFinalize() {
    if (!finalizeTarget) return;
    setFinalizing(true);
    try {
      const result = await finalize(finalizeTarget);
      let msg = `PO ${finalizeTarget} finalisé : ${result.received} reçu(s)`;
      if (result.createdPieces?.length > 0) {
        msg += `\n\n${result.createdPieces.length} pièce(s) créée(s) au catalogue :\n` + result.createdPieces.map(p => `• ${p.nom} (${p.pieceId})`).join('\n');
      }
      if (result.missing.length > 0) {
        msg += `\n\nManquants :\n` + result.missing.map(m => `• ${m.nom} — ${m.manquant}/${m.cmd}`).join('\n');
      }
      toast(msg);
      setFinalizeTarget(null);
    } catch (err: any) { toast(err.message, 'error'); }
    finally { setFinalizing(false); }
  }

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader subtitle="commandes fournisseurs" title="Pièces" titleSuffix=": réception">
          <ToolbarBlock>
            <PiecesTabs />
          </ToolbarBlock>
          <AddButton onClick={() => setShowNew(true)} title="Nouvelle réception" />
        </PageHeader>

        {isLoading && <LoadingSpinner className="py-20" />}

        {!isLoading && (
          <div className="md:bg-black/20 md:rounded-[50px] md:p-5">
            <div className="flex flex-col" style={{ gap: '20px' }}>

              {/* Formulaire nouveau PO — dans un Modal */}

              {/* PO actifs */}
              {activePOs.map(po => {
                const isExpanded = expandedPO === po.poNumber;
                return (
                  <div key={po.poNumber} className="overflow-visible" style={{ borderRadius: '30px' }}>
                    {/* Header cliquable */}
                    <button
                      type="button"
                      onClick={() => { setExpandedPO(isExpanded ? null : po.poNumber); setAddSearchPiece(''); }}
                      className="w-full flex items-center gap-3 text-left"
                      style={{ backgroundColor: po.status === 'PARTIEL' ? '#ffcdd2' : '#fff056', height: '64px', paddingLeft: '30px', paddingRight: '20px', borderRadius: isExpanded ? '30px 30px 0 0' : '30px', border: 'none', cursor: 'pointer' }}
                    >
                      {isExpanded
                        ? <ChevronDownIcon style={{ width: '20px', height: '20px', color: 'rgba(0,0,0,0.5)' }} />
                        : <ChevronRightIcon style={{ width: '20px', height: '20px', color: 'rgba(0,0,0,0.5)' }} />
                      }
                      <CubeIcon style={{ width: '30px', height: '30px', color: 'rgba(0,0,0,0.5)' }} />
                      <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '24px', fontWeight: 700, lineHeight: 1 }}>
                        {po.fournisseur} — #{po.poNumber}
                      </span>
                      <span style={{ color: 'rgba(0,0,0,0.4)', fontSize: '14px' }}>
                        {po.dateCommande} · {po.items.length} items · {frPrix(po.items.reduce((s, it) => s + it.prixAchat * it.qteCommandee, 0))}
                      </span>
                      <span
                        className="inline-block text-xs font-bold px-2 py-0.5 rounded"
                        style={{ backgroundColor: STATUS_STYLE[po.status]?.bg, color: STATUS_STYLE[po.status]?.fg }}
                      >
                        {STATUS_LABEL[po.status] ?? po.status}
                      </span>
                      {po.items.some(it => it.qteRecue !== it.qteCommandee && it.qteRecue > 0) && (
                        <span
                          className="flex items-center justify-center rounded-full transition-colors hover:bg-black/10"
                          style={{ width: '32px', height: '32px', cursor: 'pointer', color: 'rgba(0,0,0,0.5)' }}
                          onClick={(e) => { e.stopPropagation(); setLogPO(po.poNumber); }}
                          title="Voir le log (écarts)"
                        >
                          <ClipboardDocumentListIcon style={{ width: '18px', height: '18px' }} />
                        </span>
                      )}
                      <span className="ml-auto flex items-center gap-2">
                        {/* v1.0.16+ : Sync stock — pill icône-only (yellow icon, dark bg, outline jaune) */}
                        <span
                          className="flex items-center justify-center rounded-full transition-opacity hover:opacity-80"
                          style={{
                            backgroundColor: 'rgba(0,0,0,0.5)',
                            color: '#fff056',
                            border: '1px solid #fff056',
                            width: '28px',
                            height: '28px',
                            cursor: 'pointer',
                          }}
                          onClick={(e) => { e.stopPropagation(); setSyncStockTarget(po.poNumber); }}
                          title="Sync stock — appliquer les qté reçues au stock"
                        >
                          <ArrowPathIcon style={{ width: '14px', height: '14px' }} />
                        </span>
                        <span
                          className="flex items-center gap-1 rounded-full transition-opacity hover:opacity-80"
                          style={{ backgroundColor: 'rgba(0,0,0,0.5)', color: '#fff056', padding: '4px 12px', fontSize: '12px', fontWeight: 700, cursor: 'pointer' }}
                          onClick={(e) => { e.stopPropagation(); window.open(`/api/po/export?po=${encodeURIComponent(po.poNumber)}`, '_blank'); }}
                          title="Exporter ce PO"
                        >
                          <ArrowUpTrayIcon style={{ width: '12px', height: '12px' }} /> Exporter
                        </span>
                        <span style={{ color: 'rgba(0,0,0,0.4)', fontSize: '13px', marginLeft: '8px' }}>
                          {po.items.reduce((s, it) => s + it.qteRecue, 0)}/{po.items.reduce((s, it) => s + it.qteCommandee, 0)} reçu
                        </span>
                        <span
                          className="flex items-center justify-center rounded-full transition-colors hover:bg-black/10"
                          style={{ width: '32px', height: '32px', cursor: 'pointer', color: 'rgba(0,0,0,0.5)' }}
                          onClick={(e) => { e.stopPropagation(); setDeleteTarget(po.poNumber); }}
                          title="Supprimer le PO"
                        >
                          <TrashIcon style={{ width: '18px', height: '18px' }} />
                        </span>
                      </span>
                    </button>

                    {/* Contenu déplié — vue desktop (table) + vue mobile (cards) */}
                    {isExpanded && (
                      <div style={{ backgroundColor: 'rgba(0,0,0,0.20)', borderRadius: '0 0 30px 30px', overflow: 'hidden' }}>
                        {/* ── Vue desktop : tableau horizontal (hidden md+) ── */}
                        <div className="hidden md:block">
                        {/* Header légende — style BDC */}
                        <div className="flex items-center" style={{ padding: '6px 16px', backgroundColor: 'rgba(255,255,255,0.5)', color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontWeight: 700, fontStyle: 'italic' }}>
                          <div style={{ width: '32px' }}></div>
                          <div className="flex-1">item</div>
                          <div style={{ width: '230px' }}>catégorie</div>
                          <div style={{ width: '160px' }}>sku</div>
                          <div style={{ width: '70px', textAlign: 'center' }}>cmd</div>
                          <div style={{ width: '60px', textAlign: 'center' }}>restant</div>
                          <div style={{ width: '70px', textAlign: 'center' }}>reçu</div>
                          <div style={{ width: '70px', textAlign: 'right' }}>prix unit.</div>
                          <div style={{ width: '70px', textAlign: 'right' }}>total</div>
                          <div style={{ width: '40px', textAlign: 'center' }}>✓</div>
                        </div>

                        {/* Items — style BDC services */}
                        {po.items.map((item, idx) => {
                          const restant = item.qteCommandee - item.qteRecue;
                          const skuPiece = item.sku ? pieces.find(p => p.sku === item.sku) : null;
                          return (
                            <div
                              key={idx}
                              className="flex items-center"
                              style={{
                                padding: '10px 16px',
                                borderBottom: '1px solid rgba(0,0,0,0.06)',
                                backgroundColor: item.qteRecue > item.qteCommandee ? '#ffe0b2'
                                  : item.recu ? '#d4edbc'
                                  : (item.qteRecue > 0 && item.qteRecue < item.qteCommandee) ? '#ffcdd2'
                                  : idx % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)',
                              }}
                            >
                              <button type="button" onClick={() => handleDeleteLine(po, idx)}
                                className="flex items-center justify-center shrink-0 transition-opacity hover:opacity-70"
                                style={{ width: '32px', color: 'rgba(0,0,0,0.5)' }}>
                                <TrashIcon style={{ width: '20px', height: '20px' }} />
                              </button>
                              <div className="flex-1" style={{ color: 'rgba(0,0,0,0.7)', fontSize: '14px', fontWeight: 700 }}>{item.nom}</div>
                              <div style={{ width: '230px', paddingRight: '30px' }}>
                                <select
                                  value={item.categorie || ''}
                                  onChange={e => {
                                    const newCat = e.target.value;
                                    updateLine(po.poNumber, po._rows[idx], { categorie: newCat }).catch(err => toast(err.message, 'error'));
                                  }}
                                  style={{
                                    width: '100%', height: '26px', fontSize: '12px',
                                    padding: '0 6px', borderRadius: '6px',
                                    border: '1px solid rgba(0,0,0,0.15)',
                                    backgroundColor: item.categorie ? '#fff' : 'rgba(255,200,200,0.3)',
                                    cursor: 'pointer',
                                  }}
                                  title={item.categorie || '(aucune) — choisir une catégorie avant de finaliser pour que la pièce soit bien classée'}
                                >
                                  <option value="">— aucune —</option>
                                  {allCategories.map(c => <option key={c} value={c}>{c}</option>)}
                                </select>
                              </div>
                              <div style={{ width: '160px', fontSize: '14px', fontWeight: 700, color: 'rgba(0,0,0,0.4)' }}>
                                {skuPiece?.skuUrl ? (
                                  <a href={skuPiece.skuUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">{item.sku}</a>
                                ) : (item.sku || '—')}
                              </div>
                              <div className="flex items-center justify-center" style={{ width: '70px' }}>
                                <span style={{ fontSize: '14px', fontWeight: 700, color: 'rgba(0,0,0,0.7)', minWidth: '20px', textAlign: 'center' }}>{item.qteCommandee}</span>
                                <div className="flex flex-col shrink-0" style={{ borderRadius: '4px', overflow: 'hidden', backgroundColor: 'rgba(0,0,0,0.04)' }}>
                                  <button type="button" onClick={() => handleQteCommandee(po, idx, +1)}
                                    className="flex items-center justify-center transition-colors hover:bg-yellow-200"
                                    style={{ width: '18px', height: '12px', cursor: 'pointer', color: 'rgba(0,0,0,0.6)', border: 'none', background: 'transparent' }}
                                  ><span style={{ fontSize: '8px', lineHeight: 1 }}>▲</span></button>
                                  <button type="button" onClick={() => handleQteCommandee(po, idx, -1)}
                                    className="flex items-center justify-center transition-colors hover:bg-yellow-200"
                                    style={{ width: '18px', height: '12px', cursor: 'pointer', color: 'rgba(0,0,0,0.6)', border: 'none', borderTop: '1px solid rgba(0,0,0,0.1)', background: 'transparent' }}
                                  ><span style={{ fontSize: '8px', lineHeight: 1 }}>▼</span></button>
                                </div>
                              </div>
                              <div style={{ width: '60px', textAlign: 'center', fontSize: '14px', fontWeight: 700, color: restant > 0 ? '#e65100' : '#2e7d32' }}>
                                {restant > 0 ? restant : restant === 0 ? '0' : `+${Math.abs(restant)}`}
                              </div>
                              <div className="flex items-center justify-center" style={{ width: '70px' }}>
                                <span style={{ fontSize: '14px', fontWeight: 700, color: 'rgba(0,0,0,0.7)', minWidth: '20px', textAlign: 'center' }}>{item.qteRecue}</span>
                                <div className="flex flex-col shrink-0" style={{ borderRadius: '4px', overflow: 'hidden', backgroundColor: 'rgba(0,0,0,0.04)' }}>
                                  <button type="button" onClick={() => handleQteRecue(po, idx, +1)}
                                    className="flex items-center justify-center transition-colors hover:bg-yellow-200"
                                    style={{ width: '18px', height: '12px', cursor: 'pointer', color: 'rgba(0,0,0,0.6)', border: 'none', background: 'transparent' }}
                                  ><span style={{ fontSize: '8px', lineHeight: 1 }}>▲</span></button>
                                  <button type="button" onClick={() => handleQteRecue(po, idx, -1)}
                                    className="flex items-center justify-center transition-colors hover:bg-yellow-200"
                                    style={{ width: '18px', height: '12px', cursor: 'pointer', color: 'rgba(0,0,0,0.6)', border: 'none', borderTop: '1px solid rgba(0,0,0,0.1)', background: 'transparent' }}
                                  ><span style={{ fontSize: '8px', lineHeight: 1 }}>▼</span></button>
                                </div>
                              </div>
                              <div style={{ width: '70px', textAlign: 'right', fontSize: '14px', fontWeight: 700, color: 'rgba(0,0,0,0.5)' }}>{frPrix(item.prixAchat)}</div>
                              <div style={{ width: '70px', textAlign: 'right', fontSize: '14px', fontWeight: 700, color: 'rgba(0,0,0,0.7)' }}>{frPrix(item.qteRecue * item.prixAchat)}</div>
                              <div style={{ width: '40px', textAlign: 'center' }}>
                                <input type="checkbox" checked={item.recu} onChange={() => handleToggleRecu(po, idx)} className="custom-checkbox" />
                              </div>
                            </div>
                          );
                        })}

                        {/* Footer total — style BDC */}
                        <div className="flex items-center" style={{ padding: '6px 16px', backgroundColor: 'rgba(255,255,255,0.5)', color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontWeight: 700, fontStyle: 'italic' }}>
                          <div style={{ width: '32px' }}></div>
                          <div className="flex-1">{po.items.length} items</div>
                          <div style={{ width: '230px' }}></div>
                          <div style={{ width: '160px' }}></div>
                          <div style={{ width: '70px', textAlign: 'center' }}>{po.items.reduce((s, it) => s + it.qteCommandee, 0)}</div>
                          <div style={{ width: '60px', textAlign: 'center' }}>{po.items.reduce((s, it) => s + (it.qteCommandee - it.qteRecue), 0)}</div>
                          <div style={{ width: '70px', textAlign: 'center' }}>{po.items.reduce((s, it) => s + it.qteRecue, 0)}</div>
                          <div style={{ width: '70px', textAlign: 'right' }}></div>
                          <div style={{ width: '70px', textAlign: 'right' }}>{frPrix(po.items.reduce((s, it) => s + it.prixAchat * it.qteRecue, 0))}</div>
                          <div style={{ width: '40px', textAlign: 'center' }}>{po.items.filter(it => it.recu).length}/{po.items.length}</div>
                        </div>
                        </div>{/* /vue desktop */}

                        {/* ── Vue mobile : cards verticales (md:hidden) ── */}
                        <div className="md:hidden flex flex-col">
                          {po.items.map((item, idx) => {
                            const restant = item.qteCommandee - item.qteRecue;
                            const skuPiece = item.sku ? pieces.find(p => p.sku === item.sku) : null;
                            const cardBg = item.qteRecue > item.qteCommandee ? '#ffe0b2'
                              : item.recu ? '#d4edbc'
                              : (item.qteRecue > 0 && item.qteRecue < item.qteCommandee) ? '#ffcdd2'
                              : idx % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)';
                            return (
                              <div
                                key={idx}
                                style={{
                                  padding: '12px 16px',
                                  borderBottom: '1px solid rgba(0,0,0,0.06)',
                                  backgroundColor: cardBg,
                                }}
                              >
                                {/* Ligne 1 : nom + checkbox reçu + bouton trash */}
                                <div className="flex items-start gap-3" style={{ marginBottom: '10px' }}>
                                  <button type="button" onClick={() => handleDeleteLine(po, idx)}
                                    className="shrink-0 transition-opacity hover:opacity-70"
                                    style={{ color: 'rgba(0,0,0,0.4)', padding: '2px' }}
                                    title="Supprimer"
                                  >
                                    <TrashIcon style={{ width: '18px', height: '18px' }} />
                                  </button>
                                  <div className="flex-1 min-w-0" style={{ color: 'rgba(0,0,0,0.85)', fontSize: '15px', fontWeight: 700, wordBreak: 'break-word' }}>
                                    {item.nom}
                                  </div>
                                  <input
                                    type="checkbox"
                                    checked={item.recu}
                                    onChange={() => handleToggleRecu(po, idx)}
                                    className="custom-checkbox shrink-0"
                                    style={{ marginTop: '2px' }}
                                  />
                                </div>

                                {/* Ligne 2 : SKU + catégorie */}
                                <div className="flex items-center gap-2" style={{ marginBottom: '12px' }}>
                                  <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.5)', fontFamily: 'monospace', minWidth: 0, flexShrink: 0 }}>
                                    {skuPiece?.skuUrl ? (
                                      <a href={skuPiece.skuUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">{item.sku}</a>
                                    ) : (item.sku || '—')}
                                  </div>
                                  <select
                                    value={item.categorie || ''}
                                    onChange={e => updateLine(po.poNumber, po._rows[idx], { categorie: e.target.value }).catch(err => toast(err.message, 'error'))}
                                    style={{
                                      flex: 1, minWidth: 0,
                                      height: '28px', fontSize: '12px',
                                      padding: '0 8px', borderRadius: '8px',
                                      border: '1px solid rgba(0,0,0,0.15)',
                                      backgroundColor: item.categorie ? '#fff' : 'rgba(255,200,200,0.3)',
                                    }}
                                  >
                                    <option value="">— catégorie —</option>
                                    {allCategories.map(c => <option key={c} value={c}>{c}</option>)}
                                  </select>
                                </div>

                                {/* Ligne 3 : cmd / reçu (qte avec +/-) */}
                                <div className="flex items-center justify-between" style={{ gap: '12px', marginBottom: '8px' }}>
                                  {/* Bloc cmd */}
                                  <div className="flex items-center gap-1">
                                    <span style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)', fontWeight: 600, textTransform: 'lowercase', minWidth: '32px' }}>cmd</span>
                                    <button type="button" onClick={() => handleQteCommandee(po, idx, -1)}
                                      style={{ width: '28px', height: '28px', borderRadius: '6px', border: '1px solid rgba(0,0,0,0.15)', backgroundColor: '#fff', fontSize: '14px', fontWeight: 700, cursor: 'pointer' }}
                                    >−</button>
                                    <span style={{ fontSize: '15px', fontWeight: 700, color: 'rgba(0,0,0,0.7)', minWidth: '28px', textAlign: 'center' }}>{item.qteCommandee}</span>
                                    <button type="button" onClick={() => handleQteCommandee(po, idx, +1)}
                                      style={{ width: '28px', height: '28px', borderRadius: '6px', border: '1px solid rgba(0,0,0,0.15)', backgroundColor: '#fff', fontSize: '14px', fontWeight: 700, cursor: 'pointer' }}
                                    >+</button>
                                  </div>
                                  {/* Bloc reçu */}
                                  <div className="flex items-center gap-1">
                                    <span style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)', fontWeight: 600, textTransform: 'lowercase', minWidth: '32px' }}>reçu</span>
                                    <button type="button" onClick={() => handleQteRecue(po, idx, -1)}
                                      style={{ width: '28px', height: '28px', borderRadius: '6px', border: '1px solid rgba(0,0,0,0.15)', backgroundColor: '#fff', fontSize: '14px', fontWeight: 700, cursor: 'pointer' }}
                                    >−</button>
                                    <span style={{ fontSize: '15px', fontWeight: 700, color: 'rgba(0,0,0,0.7)', minWidth: '28px', textAlign: 'center' }}>{item.qteRecue}</span>
                                    <button type="button" onClick={() => handleQteRecue(po, idx, +1)}
                                      style={{ width: '28px', height: '28px', borderRadius: '6px', border: '1px solid rgba(0,0,0,0.15)', backgroundColor: '#fff', fontSize: '14px', fontWeight: 700, cursor: 'pointer' }}
                                    >+</button>
                                  </div>
                                </div>

                                {/* Ligne 4 : restant + prix unit + total */}
                                <div className="flex items-center justify-between" style={{ fontSize: '12px' }}>
                                  <span style={{ color: restant > 0 ? '#e65100' : restant < 0 ? '#ffe0b2' : '#2e7d32', fontWeight: 700 }}>
                                    {restant > 0 ? `restant ${restant}` : restant === 0 ? 'complet' : `surplus +${Math.abs(restant)}`}
                                  </span>
                                  <span style={{ color: 'rgba(0,0,0,0.5)' }}>
                                    {frPrix(item.prixAchat)} × {item.qteRecue} ={' '}
                                    <strong style={{ color: 'rgba(0,0,0,0.85)', fontSize: '14px' }}>{frPrix(item.qteRecue * item.prixAchat)}</strong>
                                  </span>
                                </div>
                              </div>
                            );
                          })}
                          {/* Footer total mobile */}
                          <div style={{ padding: '10px 16px', backgroundColor: 'rgba(255,255,255,0.5)', color: 'rgba(0,0,0,0.5)', fontSize: '13px', fontWeight: 700, fontStyle: 'italic' }}>
                            <div className="flex justify-between">
                              <span>{po.items.length} items · {po.items.filter(it => it.recu).length}/{po.items.length} reçus</span>
                              <span style={{ color: 'rgba(0,0,0,0.7)' }}>{frPrix(po.items.reduce((s, it) => s + it.prixAchat * it.qteRecue, 0))}</span>
                            </div>
                          </div>
                        </div>

                        {/* v1.0.14+ : Réceptions ADHOC du fournisseur à fusionner.
                            Affiche les PO ADHOC-... du même fournisseur en status RECU
                            et propose de les fusionner dans cette PO cible. */}
                        <AdhocMergePanel po={po} pos={pos} mutatePOs={mutatePOs} />

                        {/* v1.0.16+ : Actions PO ouvert — (+) ajouter pièces (modal),
                            Scanner, Finaliser. Sync stock est passé dans la barre jaune.
                            v1.0.17+ : (+) au même style que Scanner (btn-secondary). */}
                        <div className="flex items-center gap-3" style={{ padding: '16px 24px 20px', backgroundColor: 'rgba(255,255,255,0.6)' }}>
                          <button
                            type="button"
                            onClick={() => { setAddSearchPiece(''); setAddPieceModalPO(po.poNumber); setExpandedPO(po.poNumber); }}
                            disabled={addingToPO}
                            className="btn-secondary flex items-center gap-2 ml-auto"
                            title="Ajouter des pièces à ce PO"
                            aria-label="Ajouter des pièces"
                          >
                            <PlusIcon style={{ width: '16px', height: '16px' }} />
                          </button>
                          <button
                            type="button"
                            onClick={() => { setScanPO(po.poNumber); setScanMessage(''); }}
                            className="btn-secondary flex items-center gap-2"
                            title="Scanner les SKU des pièces reçues (caméra)"
                          >
                            <QrCodeIcon style={{ width: '16px', height: '16px' }} /> Scanner
                          </button>
                          <button
                            type="button"
                            onClick={() => setFinalizeTarget(po.poNumber)}
                            className="btn-primary flex items-center gap-2"
                          >
                            <CheckCircleIcon style={{ width: '18px', height: '18px' }} /> Finaliser la réception
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Historique */}
              {historyPOs.length > 0 && (
                <div>
                  <h3 className="text-sm font-bold uppercase" style={{ color: 'rgba(255,255,255,0.5)', marginBottom: '12px' }}>Historique</h3>
                  {historyPOs.map(po => {
                    const isHistExpanded = expandedPO === `hist-${po.poNumber}`;
                    return (
                      <div key={po.poNumber} className="mb-2">
                        <button
                          type="button"
                          onClick={() => setExpandedPO(isHistExpanded ? null : `hist-${po.poNumber}`)}
                          className="w-full flex items-center gap-3 text-left mb-0"
                          style={{ padding: '12px 20px', borderRadius: isHistExpanded ? '20px 20px 0 0' : '20px', backgroundColor: 'rgba(255,255,255,0.3)', border: 'none', cursor: 'pointer' }}
                        >
                          {isHistExpanded
                            ? <ChevronDownIcon style={{ width: '14px', height: '14px', color: 'rgba(255,255,255,0.5)' }} />
                            : <ChevronRightIcon style={{ width: '14px', height: '14px', color: 'rgba(255,255,255,0.5)' }} />
                          }
                          <span className="font-bold" style={{ color: 'rgba(255,255,255,0.8)' }}>
                            {po.status === 'RECU' && <span style={{ color: '#81c784', marginRight: '4px' }}>√</span>}
                            {po.fournisseur}
                          </span>
                          <span style={{ color: 'rgba(255,255,255,0.5)' }}>#{po.poNumber}</span>
                          <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px' }}>{po.dateCommande} → {po.dateReception || '—'}</span>
                          <span
                            className="inline-block text-xs font-bold px-2 py-0.5 rounded"
                            style={{ backgroundColor: STATUS_STYLE[po.status]?.bg, color: STATUS_STYLE[po.status]?.fg }}
                          >
                            {STATUS_LABEL[po.status] ?? po.status}
                          </span>
                          <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px' }}>{po.items.length} items · {frPrix(po.items.reduce((s, it) => s + it.prixAchat * it.qteCommandee, 0))}</span>
                          {po.items.some(it => it.qteRecue !== it.qteCommandee) && (
                            <span
                              className="flex items-center justify-center rounded-full transition-colors hover:bg-white/20"
                              style={{ width: '28px', height: '28px', cursor: 'pointer', color: 'rgba(255,255,255,0.5)' }}
                              onClick={(e) => { e.stopPropagation(); setLogPO(po.poNumber); }}
                              title="Voir le log (écarts)"
                            >
                              <ClipboardDocumentListIcon style={{ width: '16px', height: '16px' }} />
                            </span>
                          )}
                          <span
                            className="ml-auto flex items-center gap-1 text-xs font-bold uppercase px-3 py-1 rounded-full transition-colors"
                            style={{ color: 'rgba(255,255,255,0.6)', border: '1px solid rgba(255,255,255,0.3)' }}
                            onClick={(e) => { e.stopPropagation(); window.open(`/api/po/export?po=${encodeURIComponent(po.poNumber)}`, '_blank'); }}
                            onMouseEnter={e => { e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.15)'; }}
                            onMouseLeave={e => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                            title="Exporter ce PO en xlsx"
                          >
                            <ArrowUpTrayIcon style={{ width: '12px', height: '12px' }} /> Exporter
                          </span>
                          <span
                            className="text-xs font-bold uppercase px-3 py-1 rounded-full transition-colors"
                            style={{ color: 'rgba(255,255,255,0.6)', border: '1px solid rgba(255,255,255,0.3)' }}
                            onClick={async (e) => {
                              e.stopPropagation();
                              try {
                                await reopenPO(po.poNumber);
                                toast(`PO ${po.poNumber} réactivé`);
                              } catch (err: any) { toast(err.message, 'error'); }
                            }}
                            onMouseEnter={e => { e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.15)'; }}
                            onMouseLeave={e => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                          >
                            Réactiver
                          </span>
                        </button>
                        {isHistExpanded && (
                          <div style={{ backgroundColor: 'rgba(0,0,0,0.15)', borderRadius: '0 0 20px 20px', overflow: 'hidden', padding: '8px 0' }}>
                            <table className="w-full" style={{ fontSize: 'var(--h4-size)' }}>
                              <tbody>
                                {po.items.map((item, idx) => (
                                  <tr key={idx} style={{ color: 'rgba(255,255,255,0.7)', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                                    <td className="py-1 px-4">{item.nom}</td>
                                    <td className="py-1 px-2 font-mono" style={{ color: 'rgba(255,255,255,0.4)' }}>{item.sku || '—'}</td>
                                    <td className="py-1 px-2 text-center">cmd {item.qteCommandee}</td>
                                    <td className="py-1 px-2 text-center">reçu {item.qteRecue}</td>
                                    <td className="py-1 px-2 text-center" style={{ color: item.recu ? '#81c784' : '#ffab91' }}>
                                      {item.recu ? '✓' : `manquant ${item.qteCommandee - item.qteRecue}`}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {activePOs.length === 0 && !showNew && (
                <p className="text-center py-16" style={{ color: 'rgba(255,255,255,0.5)' }}>
                  Aucune commande en attente. Cliquez sur « Nouvelle réception » pour commencer.
                </p>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Modal nouveau PO */}
      <Modal
        open={showNew}
        onClose={() => { setShowNew(false); setNewItems([]); setNewFourn(''); setNewPoNum(''); }}
        title="Nouvelle réception"
        size="xl"
        headerAction={
          <button
            type="button"
            onClick={() => { setImportTargetPO(null); setShowImport(true); }}
            title="Importer une facture fournisseur (xlsx/csv)"
            className="flex items-center justify-center transition-colors shrink-0"
            style={{
              width: '37px', height: '37px', borderRadius: '50%',
              backgroundColor: '#fff056',
              color: 'rgba(0,0,0,0.5)',
              border: 'none',
              padding: 0,
            }}
          >
            <ArrowDownTrayIcon style={{ width: '18px', height: '18px' }} />
          </button>
        }
      >
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <label className="label-system">fournisseur *</label>
            <select value={fournisseurs.includes(newFourn) ? newFourn : (newFourn ? '__custom__' : '')} onChange={e => {
              const fourn = e.target.value;
              if (fourn === '__new__') {
                setPromptNewFournOpen(true);
                return;
              }
              if (fourn === '__custom__') {
                // no-op — déjà un custom, on le garde
                return;
              }
              applyNewFourn(fourn);
            }} className="input-system">
              <option value="">— Sélection —</option>
              {newFourn && !fournisseurs.includes(newFourn) && (
                <option value="__custom__">{newFourn}</option>
              )}
              {fournisseurs.map(f => <option key={f} value={f}>{f}</option>)}
              <option value="__new__">＋ Nouveau fournisseur</option>
            </select>
          </div>
          <div>
            <label className="label-system">n° commande *</label>
            <input type="text" value={newPoNum} onChange={e => setNewPoNum(e.target.value)} className="input-system" placeholder="ex. 110731" />
          </div>
          <div>
            <label className="label-system">date commande *</label>
            <input type="date" value={newDate} onChange={e => setNewDate(e.target.value)} className="input-system" />
          </div>
          <div>
            <label className="label-system">date réception *</label>
            <input type="date" value={newDateRec} onChange={e => setNewDateRec(e.target.value)} className="input-system" />
          </div>
        </div>

        {/* Recherche pièce */}
        {newFourn && (
          <div className="mb-4" style={{ position: 'relative', zIndex: 15 }}>
            <label className="label-system">ajouter des pièces</label>
            <input
              type="search" placeholder="Rechercher une pièce…" value={searchPiece}
              onChange={e => setSearchPiece(e.target.value)}
              className="input-system" style={{ maxWidth: '400px' }}
            />
            {searchPiece && filteredPieces.length > 0 && (
              <div className="mt-1 border rounded-lg overflow-hidden" style={{ maxHeight: '200px', overflowY: 'auto', position: 'relative', zIndex: 16, backgroundColor: '#fff' }}>
                {filteredPieces.slice(0, 20).map(p => (
                  <button
                    key={p._row}
                    type="button"
                    onClick={() => addItemToPO(p)}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-yellow-50 flex justify-between"
                    style={{ borderBottom: '1px solid rgba(0,0,0,0.06)' }}
                  >
                    <span>{p.nom}</span>
                    <span className="text-gray-400 font-mono text-xs">{p.sku || '—'}</span>
                  </button>
                ))}
              </div>
            )}
            {searchPiece && filteredPieces.length === 0 && (
              <div className="mt-2 flex items-center gap-2">
                <p className="text-xs" style={{ color: 'rgba(0,0,0,0.4)' }}>Aucune pièce trouvée</p>
                <button
                  type="button"
                  onClick={() => setCreatePieceCtx({
                    nom: searchPiece,
                    fournisseur: newFourn,
                    mode: 'new',
                  })}
                  className="btn-secondary"
                  style={{ padding: '4px 10px', fontSize: '12px' }}
                >
                  + Créer "{searchPiece}" au catalogue
                </button>
              </div>
            )}
          </div>
        )}

        {/* Items ajoutés */}
        {newItems.length > 0 && (
          <div className="mb-4" style={{ borderRadius: '12px', overflow: 'hidden' }}>
            <div className="flex items-center" style={{ padding: '6px 16px', backgroundColor: 'rgba(0,0,0,0.06)', color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontWeight: 700, fontStyle: 'italic' }}>
              <div style={{ width: '32px' }}></div>
              <div className="flex-1">item</div>
              <div style={{ width: '230px' }}>catégorie</div>
              <div style={{ width: '160px' }}>sku</div>
              <div style={{ width: '70px', textAlign: 'center' }}>qté</div>
              <div style={{ width: '70px', textAlign: 'right' }}>prix</div>
            </div>
            {newItems.map((it, i) => (
              <div key={i} className="flex items-center" style={{ padding: '10px 16px', borderBottom: '1px solid rgba(0,0,0,0.06)', backgroundColor: i % 2 === 0 ? 'rgba(0,0,0,0.02)' : 'transparent' }}>
                <button type="button" onClick={() => removeNewItem(i)}
                  className="flex items-center justify-center shrink-0 transition-opacity hover:opacity-70"
                  style={{ width: '32px', color: 'rgba(0,0,0,0.5)' }}>
                  <TrashIcon style={{ width: '20px', height: '20px' }} />
                </button>
                <div className="flex-1" style={{ color: 'rgba(0,0,0,0.7)', fontSize: '14px', fontWeight: 700 }}>{it.nom}</div>
                <div style={{ width: '230px', paddingRight: '30px' }}>
                  <select
                    value={it.categorie || ''}
                    onChange={e => {
                      const v = e.target.value;
                      setNewItems(prev => prev.map((x, j) => j === i ? { ...x, categorie: v } : x));
                    }}
                    style={{
                      width: '100%', height: '26px', fontSize: '12px',
                      padding: '0 6px', borderRadius: '6px',
                      border: '1px solid rgba(0,0,0,0.15)',
                      backgroundColor: it.categorie ? '#fff' : 'rgba(255,200,200,0.3)',
                      cursor: 'pointer',
                    }}
                    title={it.categorie || '(aucune)'}
                  >
                    <option value="">— aucune —</option>
                    {allCategories.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div style={{ width: '160px', fontSize: '14px', fontWeight: 700, color: 'rgba(0,0,0,0.4)' }}>{it.sku || '—'}</div>
                <div className="flex items-center justify-center" style={{ width: '70px' }}>
                  <span style={{ fontSize: '14px', fontWeight: 700, color: 'rgba(0,0,0,0.7)', minWidth: '20px', textAlign: 'center' }}>{it.qteCommandee}</span>
                  <div className="flex flex-col shrink-0" style={{ borderRadius: '4px', overflow: 'hidden', backgroundColor: 'rgba(0,0,0,0.04)' }}>
                    <button type="button" onClick={() => setNewItemQte(i, it.qteCommandee + 1)}
                      className="flex items-center justify-center transition-colors hover:bg-yellow-200"
                      style={{ width: '18px', height: '12px', cursor: 'pointer', color: 'rgba(0,0,0,0.6)', border: 'none', background: 'transparent' }}
                    ><span style={{ fontSize: '8px', lineHeight: 1 }}>▲</span></button>
                    <button type="button" onClick={() => setNewItemQte(i, it.qteCommandee - 1)}
                      className="flex items-center justify-center transition-colors hover:bg-yellow-200"
                      style={{ width: '18px', height: '12px', cursor: 'pointer', color: 'rgba(0,0,0,0.6)', border: 'none', borderTop: '1px solid rgba(0,0,0,0.1)', background: 'transparent' }}
                    ><span style={{ fontSize: '8px', lineHeight: 1 }}>▼</span></button>
                  </div>
                </div>
                <div style={{ width: '70px', textAlign: 'right', fontSize: '14px', fontWeight: 700, color: 'rgba(0,0,0,0.5)' }}>{frPrix(it.prixAchat)}</div>
              </div>
            ))}
          </div>
        )}

        <div className="flex items-center gap-3" style={{ paddingTop: '20px' }}>
          <button type="button" onClick={() => { setShowNew(false); setNewItems([]); setNewFourn(''); setNewPoNum(''); }} className="btn-secondary">Annuler</button>
          <button
            type="button"
            onClick={handleCreate}
            disabled={!newPoNum.trim() || !newFourn || !newItems.length || !newDate || !newDateRec || creating}
            className="btn-primary ml-auto"
          >
            {creating ? 'Création…' : `Créer le PO (${newItems.length} items)`}
          </button>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!finalizeTarget}
        title="Confirmation de commande"
        message={(() => {
          const po = pos.find(p => p.poNumber === finalizeTarget);
          if (!po) return '';
          const full    = po.items.filter(it => it.qteRecue > 0 && it.qteRecue === it.qteCommandee);
          const surplus = po.items.filter(it => it.qteRecue > it.qteCommandee);
          const partial = po.items.filter(it => it.qteRecue > 0 && it.qteRecue < it.qteCommandee);
          const none    = po.items.filter(it => it.qteRecue === 0);
          let msg = `Confirmer la réception de :\n${po.fournisseur} — #${po.poNumber} ?`;
          const pl = (n: number, w: string) => n > 1 ? w + 's' : w;
          if (full.length > 0)    msg += `\n\n✓ ${full.length} ${pl(full.length, 'item')} ${pl(full.length, 'reçu')} → stock incrémenté`;
          if (surplus.length > 0) msg += `\n⚠ ${surplus.length} ${pl(surplus.length, 'item')} en surplus`;
          if (partial.length > 0) msg += `\n✗ ${partial.length} ${pl(partial.length, 'item')} ${pl(partial.length, 'incomplet')}`;
          if (none.length > 0)    msg += `\n✗ ${none.length} ${pl(none.length, 'item')} non ${pl(none.length, 'reçu')}`;
          return msg;
        })()}
        cancelLabel="Modifier"
        confirmLabel={finalizing ? 'Confirmation…' : 'Confirmer'}
        onConfirm={handleFinalize}
        onCancel={() => setFinalizeTarget(null)}
      />

      <ConfirmDialog
        open={!!syncStockTarget}
        title="Sync stock maintenant"
        size="lg"
        message={(() => {
          const po = pos.find(p => p.poNumber === syncStockTarget);
          if (!po) return '';
          const toApply = po.items.filter(it => it.qteRecue > 0);
          const lines = toApply.map(it => `• ${it.nom} — +${it.qteRecue}`).join('\n');
          return `Ajouter au stock du catalogue :\n\n${lines}\n\n⚠ Ne pas cliquer 2x (additionne à chaque clic).\nLes pièces manquantes seront auto-créées.`;
        })()}
        cancelLabel="Annuler"
        confirmLabel={syncingStock ? 'Sync…' : 'Appliquer'}
        onConfirm={handleSyncStock}
        onCancel={() => { if (!syncingStock) setSyncStockTarget(null); }}
      />

      <ConfirmDialog
        open={!!deleteTarget}
        title="Supprimer le PO"
        message={(() => {
          const po = pos.find(p => p.poNumber === deleteTarget);
          if (!po) return '';
          return `Supprimer définitivement le PO ${po.fournisseur} — #${po.poNumber} ?\n\n${po.items.length} item(s) seront effacés du sheet _PO_.\n\nCette action est irréversible.`;
        })()}
        danger
        cancelLabel="Annuler"
        confirmLabel={deleting ? 'Suppression…' : 'Supprimer'}
        onConfirm={handleDeletePO}
        onCancel={() => setDeleteTarget(null)}
      />

      {/* v1.0.16+ : Modal d'ajout de pièces à un PO ouvert (remplace le champ inline). */}
      <Modal
        open={!!addPieceModalPO}
        onClose={() => { setAddPieceModalPO(null); setAddSearchPiece(''); }}
        title={addPieceModalPOObj
          ? `Ajouter des pièces — ${addPieceModalPOObj.fournisseur} #${addPieceModalPOObj.poNumber}`
          : 'Ajouter des pièces'}
        size="md"
      >
        {addPieceModalPOObj && (
          <div className="flex flex-col" style={{ gap: '14px' }}>
            <input
              type="search"
              autoFocus
              placeholder={`Rechercher chez ${addPieceModalPOObj.fournisseur}…`}
              value={addSearchPiece}
              onChange={e => setAddSearchPiece(e.target.value)}
              className="input-system"
              disabled={addingToPO}
            />

            <div
              className="overflow-y-auto"
              style={{
                maxHeight: '50vh',
                border: '1.5px solid rgba(0,0,0,0.15)',
                borderRadius: '12px',
                backgroundColor: '#fff',
              }}
            >
              {filteredPiecesForAdd.length === 0 ? (
                <div className="flex items-center justify-between gap-2" style={{ padding: '14px 16px' }}>
                  <p className="text-sm" style={{ color: 'rgba(0,0,0,0.5)' }}>
                    {addSearchPiece ? 'Aucune pièce trouvée' : 'Aucune pièce dans le catalogue pour ce fournisseur.'}
                  </p>
                  <button
                    type="button"
                    onClick={() => setCreatePieceCtx({
                      nom        : addSearchPiece || '',
                      fournisseur: addPieceModalPOObj.fournisseur,
                      mode       : 'existing',
                      poNumber   : addPieceModalPOObj.poNumber,
                    })}
                    className="btn-secondary flex items-center gap-1 shrink-0"
                    style={{ padding: '6px 12px', fontSize: '12px' }}
                  >
                    <PlusIcon style={{ width: '14px', height: '14px' }} />
                    Nouvelle pièce
                  </button>
                </div>
              ) : (
                filteredPiecesForAdd.slice(0, 100).map(p => {
                  const already = addPieceModalPOObj.items.some(it => it.pieceRow === p._row);
                  return (
                    <button
                      key={p._row}
                      type="button"
                      onClick={() => handleAddToExistingPO(addPieceModalPOObj, p)}
                      disabled={addingToPO || already}
                      className="w-full text-left flex items-center justify-between hover:bg-yellow-50 disabled:opacity-40"
                      style={{ padding: '10px 14px', borderBottom: '1px solid rgba(0,0,0,0.06)', fontSize: '14px' }}
                    >
                      <span style={{ color: 'rgba(0,0,0,0.8)' }}>{p.nom}</span>
                      <span className="text-gray-400 font-mono text-xs">{p.sku || '—'}{already ? ' · déjà au PO' : ''}</span>
                    </button>
                  );
                })
              )}
            </div>

            {/* Footer : bouton « Nouvelle pièce » toujours dispo, même quand des résultats existent. */}
            <div className="flex items-center justify-between" style={{ paddingTop: '4px' }}>
              <p className="text-xs" style={{ color: 'rgba(0,0,0,0.4)' }}>
                {filteredPiecesForAdd.length > 100
                  ? `100+ résultats — affine la recherche`
                  : `${filteredPiecesForAdd.length} résultat${filteredPiecesForAdd.length > 1 ? 's' : ''}`}
              </p>
              <button
                type="button"
                onClick={() => setCreatePieceCtx({
                  nom        : addSearchPiece || '',
                  fournisseur: addPieceModalPOObj.fournisseur,
                  mode       : 'existing',
                  poNumber   : addPieceModalPOObj.poNumber,
                })}
                disabled={addingToPO}
                className="btn-primary flex items-center gap-1 shrink-0"
                style={{ height: '34px', padding: '0 12px', fontSize: '12px' }}
                title="Créer une pièce hors catalogue et l'ajouter à ce PO"
              >
                <PlusIcon style={{ width: '14px', height: '14px' }} />
                Nouvelle pièce
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Modal log — items manquants d'un PO PARTIEL */}
      <Modal open={!!logPO} onClose={() => setLogPO(null)} title={`Log réception — #${logPO}`} size="lg">
        {(() => {
          const po = pos.find(p => p.poNumber === logPO);
          if (!po) return null;
          const missing = po.items.filter(it => it.qteRecue < it.qteCommandee);
          const surplus = po.items.filter(it => it.qteRecue > it.qteCommandee);
          if (missing.length === 0 && surplus.length === 0) return <p style={{ color: 'rgba(0,0,0,0.5)' }}>Tous les items ont été reçus.</p>;

          const copyLog = () => {
            const header = `Log réception — ${po.fournisseur} #${po.poNumber}`;
            const lines: string[] = [];
            if (missing.length > 0) {
              lines.push('MANQUANTS :');
              missing.forEach(it => lines.push(`  ${it.nom} | ${it.sku || '—'} | cmd ${it.qteCommandee} | reçu ${it.qteRecue} | manquant ${it.qteCommandee - it.qteRecue}${it.notes ? ' | ' + it.notes : ''}`));
            }
            if (surplus.length > 0) {
              lines.push('SURPLUS :');
              surplus.forEach(it => lines.push(`  ${it.nom} | ${it.sku || '—'} | cmd ${it.qteCommandee} | reçu ${it.qteRecue} | surplus +${it.qteRecue - it.qteCommandee}`));
            }
            navigator.clipboard.writeText([header, '', ...lines].join('\n'));
            toast('Log copié');
          };

          return (
            <>
              <div className="flex justify-end mb-3">
                <button
                  type="button"
                  onClick={copyLog}
                  className="flex items-center gap-1 text-xs transition-colors hover:text-black"
                  style={{ color: 'rgba(0,0,0,0.4)', padding: '4px 8px', borderRadius: '6px', border: '1px solid rgba(0,0,0,0.15)' }}
                >
                  <ClipboardDocumentCheckIcon style={{ width: '14px', height: '14px' }} /> Copier
                </button>
              </div>
              <table className="w-full" style={{ fontSize: 'var(--h4-size)' }}>
              <thead>
                <tr style={{ color: 'rgba(0,0,0,0.4)', fontStyle: 'italic', fontSize: 'var(--h6-size)' }}>
                  <th className="py-1 px-2 text-left">item</th>
                  <th className="py-1 px-2 text-left">sku</th>
                  <th className="py-1 px-2 text-center">cmd</th>
                  <th className="py-1 px-2 text-center">reçu</th>
                  <th className="py-1 px-2 text-center">écart</th>
                  <th className="py-1 px-2 text-left">notes</th>
                </tr>
              </thead>
              <tbody>
                {missing.map((item, idx) => (
                  <tr key={`m${idx}`} style={{ borderBottom: '1px solid rgba(0,0,0,0.06)' }}>
                    <td className="py-2 px-2">{item.nom}</td>
                    <td className="py-2 px-2 font-mono" style={{ color: 'rgba(0,0,0,0.4)' }}>{item.sku || '—'}</td>
                    <td className="py-2 px-2 text-center">{item.qteCommandee}</td>
                    <td className="py-2 px-2 text-center">{item.qteRecue}</td>
                    <td className="py-2 px-2 text-center font-bold" style={{ color: '#c62828' }}>−{item.qteCommandee - item.qteRecue}</td>
                    <td className="py-2 px-2" style={{ color: 'rgba(0,0,0,0.4)' }}>{item.notes || ''}</td>
                  </tr>
                ))}
                {surplus.map((item, idx) => (
                  <tr key={`s${idx}`} style={{ borderBottom: '1px solid rgba(0,0,0,0.06)', backgroundColor: '#ffe0b2' }}>
                    <td className="py-2 px-2">{item.nom}</td>
                    <td className="py-2 px-2 font-mono" style={{ color: 'rgba(0,0,0,0.4)' }}>{item.sku || '—'}</td>
                    <td className="py-2 px-2 text-center">{item.qteCommandee}</td>
                    <td className="py-2 px-2 text-center">{item.qteRecue}</td>
                    <td className="py-2 px-2 text-center font-bold" style={{ color: '#e65100' }}>+{item.qteRecue - item.qteCommandee}</td>
                    <td className="py-2 px-2" style={{ color: '#e65100' }}>surplus +{item.qteRecue - item.qteCommandee}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            </>
          );
        })()}
      </Modal>

      <ImportModal
        open={showImport}
        onClose={() => { setShowImport(false); setImportTargetPO(null); }}
        pieces={pieces}
        fournisseurs={fournisseurs}
        onImport={handleImportResult}
      />

      <PieceForm
        open={createPieceCtx !== null}
        onClose={() => setCreatePieceCtx(null)}
        categories={allCategories}
        fournisseurs={allFournisseurs}
        initialNom={createPieceCtx?.nom}
        initialFournisseur={createPieceCtx?.fournisseur}
        onCreated={handlePieceCreatedFromReception}
      />

      {/* Prompt « Nouveau fournisseur » — remplace window.prompt natif */}
      <PromptDialog
        open={promptNewFournOpen}
        title="Nouveau fournisseur"
        message="Nom du nouveau fournisseur :"
        placeholder="ex. Norco Bicycles"
        confirmLabel="Ajouter"
        onConfirm={nom => {
          setPromptNewFournOpen(false);
          applyNewFourn(nom);
        }}
        onCancel={() => setPromptNewFournOpen(false)}
      />

      {/* Scanner SKU pièces via caméra */}
      <BarcodeScanner
        open={scanPO !== null}
        onClose={() => { setScanPO(null); setScanMessage(''); }}
        onScan={handleScan}
        lastMessage={scanMessage}
      />
    </AppShell>
  );
}
