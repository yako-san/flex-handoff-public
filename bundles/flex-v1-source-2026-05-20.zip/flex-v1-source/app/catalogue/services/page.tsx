'use client';
import { useState, useMemo } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock, AddButton, SearchInput } from '@/components/layout/PageHeader';
import MultiSelectCat from '@/components/ui/MultiSelectCat';
import ServiceForm from '@/components/catalogue/ServiceForm';
import { useServices } from '@/hooks/useCatalogue';
import { useIsAdmin } from '@/hooks/useIsAdmin';
import { frPrix } from '@/lib/utils/format';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import DragTh from '@/components/ui/DragTh';
import { useColOrder } from '@/hooks/useColOrder';
import { toast } from '@/components/ui/Toast';
import { PlusIcon, WrenchScrewdriverIcon } from '@heroicons/react/24/outline';
import type { Service } from '@/types/catalogue';

/** Cellule éditable inline — apparence texte normal, devient input au focus. */
function EditableCell({
  value, onSave, disabled = false, align = 'left', placeholder,
}: {
  value: string;
  onSave: (v: string) => void;
  disabled?: boolean;
  align?: 'left' | 'center' | 'right';
  placeholder?: string;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft]     = useState(value);
  if (disabled || !editing) {
    return (
      <span
        onClick={() => { if (!disabled) { setDraft(value); setEditing(true); } }}
        title={disabled ? undefined : 'Cliquer pour modifier'}
        style={{
          cursor: disabled ? 'default' : 'text',
          display: 'inline-block',
          minWidth: '20px',
          width: '100%',
          textAlign: align,
        }}
      >
        {value || (placeholder ? <em style={{ color: 'rgba(0,0,0,0.3)' }}>{placeholder}</em> : '—')}
      </span>
    );
  }
  return (
    <input
      autoFocus
      value={draft}
      onChange={e => setDraft(e.target.value)}
      onBlur={() => {
        setEditing(false);
        if (draft !== value) onSave(draft);
      }}
      onKeyDown={e => {
        if (e.key === 'Enter')   { e.currentTarget.blur(); }
        if (e.key === 'Escape')  { setDraft(value); setEditing(false); }
      }}
      style={{
        border: '1px solid rgba(0,0,0,0.25)',
        borderRadius: '6px',
        padding: '2px 6px',
        fontSize: 'inherit',
        fontFamily: 'inherit',
        color: 'inherit',
        background: '#fff',
        width: '100%',
        textAlign: align,
      }}
    />
  );
}

const COLS = [
  { id: 'service',   header: 'service',   width: '',       hCls: 'px-4 py-2',              cCls: 'px-4 py-2 text-gray-800'         },
  { id: 'duree',     header: 'durée',     width: '70px',   hCls: 'px-4 py-2 text-center',  cCls: 'px-4 py-2 text-center text-gray-400 text-xs italic' },
  { id: 'categorie', header: 'catégorie', width: '300px',  hCls: 'px-4 py-2',              cCls: 'px-3 py-1.5'                     },
  { id: 'prix',      header: 'prix',      width: '80px',   hCls: 'px-4 py-2 text-right',   cCls: 'px-4 py-2 text-right font-medium text-gray-700' },
] as const;

type ColId = typeof COLS[number]['id'];

export default function ServicesPage() {
  const { services, isLoading, patchService } = useServices();
  const { isAdmin }         = useIsAdmin();
  const [search, setSearch] = useState('');
  const [busy,   setBusy]   = useState<Set<number>>(new Set());
  const { orderedCols, dragProps, dragOverId } = useColOrder('services', COLS as any);

  async function saveLabel(s: Service, val: string) {
    setBusy(prev => new Set(prev).add(s._row));
    try { await patchService(s._row, { label: val }); toast('Titre mis à jour'); }
    catch (err: any) { toast(err.message, 'error'); }
    finally { setBusy(prev => { const n = new Set(prev); n.delete(s._row); return n; }); }
  }

  async function saveDuree(s: Service, val: string) {
    setBusy(prev => new Set(prev).add(s._row));
    try { await patchService(s._row, { duree: val }); toast('Durée et prix mis à jour'); }
    catch (err: any) { toast(err.message, 'error'); }
    finally { setBusy(prev => { const n = new Set(prev); n.delete(s._row); return n; }); }
  }

  // Popup Nouveau service — l'ancien formulaire inline a été remplacé
  // par un composant Modal partagé (ServiceForm).
  const [showAdd,    setShowAdd]    = useState(false);
  const [addInitCat, setAddInitCat] = useState<string | undefined>(undefined);

  function openAddService(initCat?: string) {
    setAddInitCat(initCat);
    setShowAdd(true);
  }

  // Toutes les catégories uniques (col F / categorieAffichee)
  const allCategories = useMemo(() =>
    [...new Set(services.map(s => s.categorieAffichee).filter(Boolean))].sort(),
  [services]);

  // Ordre des blocs de catégories (col C du sheet SERVICES - À LA CARTE)
  // tel que défini dans le brief v5.2. Tout ce qui n'est pas dans cette
  // liste est regroupé dans "Autres" en fin de page.
  const CATEGORIE_ORDER = [
    'Forfaits',
    'Services - À la carte',
    'Services - Rencontres',
    'Services - Réhab',
    'Services - Divers',
  ];

  const filtered = services
    // Masquer les sous-items de forfait qui commencent par "- " ou "— "
    // (et le tiret isolé "-" / "—" / "--" utilisés comme séparateurs).
    .filter(s => {
      const t = s.label.trim();
      if (!t) return false;
      if (t === '-' || t === '--' || t === '—') return false;
      if (t.startsWith('- ') || t.startsWith('— ')) return false;
      return true;
    })
    .filter(s =>
      !search ||
      s.label.toLowerCase().includes(search.toLowerCase()) ||
      s.categorieAffichee.toLowerCase().includes(search.toLowerCase())
    );

  // Groupement par catégorie (col C = Service.categorie). Normalise
  // les valeurs en essayant d'abord un match exact puis en tolérant les
  // variations (case-insensitive).
  const groupedByCategorie = useMemo(() => {
    const byCat = new Map<string, typeof filtered>();
    // Initialise les buckets dans l'ordre défini
    for (const c of CATEGORIE_ORDER) byCat.set(c, []);
    for (const s of filtered) {
      const rawCat = (s.categorie ?? '').trim();
      // Match exact d'abord
      let target = CATEGORIE_ORDER.find(c => c === rawCat);
      // Sinon match case-insensitive
      if (!target) target = CATEGORIE_ORDER.find(c => c.toLowerCase() === rawCat.toLowerCase());
      const key = target ?? (rawCat || 'Autres');
      if (!byCat.has(key)) byCat.set(key, []);
      byCat.get(key)!.push(s);
    }
    // Retire les buckets vides ; garde l'ordre défini pour les buckets connus
    // puis ajoute les autres (alphabétique).
    const result: [string, typeof filtered][] = [];
    for (const c of CATEGORIE_ORDER) {
      const items = byCat.get(c);
      if (items && items.length > 0) result.push([c, items]);
      byCat.delete(c);
    }
    // Ajouter les catégories non listées (alpha)
    const extras = [...byCat.entries()]
      .filter(([, items]) => items.length > 0)
      .sort((a, b) => a[0].localeCompare(b[0], 'fr'));
    return [...result, ...extras];
  }, [filtered]);

  async function saveCategorie(s: Service, val: string) {
    setBusy(prev => new Set(prev).add(s._row));
    try { await patchService(s._row, { categoriePrio: val }); }
    catch (err: any) { toast(err.message, 'error'); }
    finally { setBusy(prev => { const n = new Set(prev); n.delete(s._row); return n; }); }
  }

  function renderCell(id: ColId, s: Service) {
    const isBusy = busy.has(s._row);
    const isSeparator = s.label === '--' || s.label === '—';
    switch (id) {
      case 'service':
        if (isSeparator) return s.label;
        return isAdmin
          ? <EditableCell value={s.label} onSave={v => saveLabel(s, v)} disabled={isBusy} placeholder="(sans titre)" />
          : s.label;
      case 'duree':
        if (isSeparator) return null;
        return isAdmin
          ? <EditableCell value={s.duree || ''} onSave={v => saveDuree(s, v)} disabled={isBusy} align="center" placeholder="—" />
          : (s.duree || '—');
      case 'categorie':
        if (isSeparator) return null;
        return (
          <MultiSelectCat
            value={s.categoriePrio || s.categorie}
            options={allCategories}
            disabled={isBusy}
            onSave={val => saveCategorie(s, val)}
          />
        );
      case 'prix':
        if (isSeparator) return null;
        return frPrix(s.prix);
    }
  }

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader
          subtitle="catalogue à la carte"
          title="Services"
          helpTopic="07-services-pieces"
          helpTitle="Catalogue services"
          helpHint="Forfaits + services à la carte affichés dans le popup d'ajout BDT. Voir le tutoriel pour les forfaits, hover tooltip et création à la volée."
        >
          <ToolbarBlock>
            <SearchInput value={search} onChange={setSearch} />
          </ToolbarBlock>
          <AddButton onClick={() => openAddService()} title="Nouveau service" />
        </PageHeader>

        {isLoading && <LoadingSpinner className="py-20" />}

        {!isLoading && (
          <div className="md:bg-black/20 md:rounded-[50px] md:p-5">
            <div className="flex flex-col" style={{ gap: '20px' }}>
              {groupedByCategorie.map(([cat, items]) => (
                <div key={cat} className="overflow-hidden" style={{ borderRadius: '30px' }}>
                  {/* Entête jaune du bloc catégorie */}
                  <div
                    className="flex items-center justify-between"
                    style={{ backgroundColor: '#fff056', height: '64px', paddingLeft: '30px', paddingRight: '30px' }}
                  >
                    <div className="flex items-center gap-3">
                      <WrenchScrewdriverIcon style={{ width: '30px', height: '30px', color: 'rgba(0,0,0,0.5)' }} />
                      <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '24px', fontWeight: 700, lineHeight: 1 }}>
                        {cat}
                      </span>
                      <span style={{ color: 'rgba(0,0,0,0.4)', fontSize: '14px' }}>
                        ({items.length})
                      </span>
                    </div>
                    <button
                      onClick={() => openAddService(cat)}
                      className="btn-plus-round"
                      title={`Nouveau service dans ${cat}`}
                    >
                      <PlusIcon />
                    </button>
                  </div>

                  <table className="w-full text-left table-fixed">
                    <colgroup>
                      {orderedCols.map(col => (
                        <col key={col.id} style={{ width: col.width || undefined }} />
                      ))}
                    </colgroup>
                    <thead>
                      <tr className="list-header">
                        {orderedCols.map(col => (
                          <DragTh key={col.id} className={col.hCls} isDragOver={dragOverId === col.id} {...dragProps(col.id)}>
                            {col.header}
                          </DragTh>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {items.map((s, i) => (
                        <tr
                          key={s._row}
                          className={`text-sm ${busy.has(s._row) ? 'opacity-60' : ''}`}
                          style={{ backgroundColor: i % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)' }}
                        >
                          {orderedCols.map(col => (
                            <td key={col.id} className={col.cCls}>
                              {renderCell(col.id as ColId, s)}
                            </td>
                          ))}
                        </tr>
                      ))}
                      {/* Total du bloc */}
                      <tr className="list-header">
                        {orderedCols.map(col => (
                          <td key={col.id} className={col.cCls}>
                            {col.id === 'service' ? `${items.length} service${items.length > 1 ? 's' : ''}` :
                             col.id === 'prix'    ? <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '15px' }}>{frPrix(items.reduce((s, x) => s + (x.prix || 0), 0))}</span> : ''}
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              ))}

              {filtered.length === 0 && (
                <p className="text-center py-16" style={{ color: 'rgba(255,255,255,0.5)' }}>Aucun service trouvé.</p>
              )}
            </div>
          </div>
        )}
      </div>

      <ServiceForm
        open={showAdd}
        onClose={() => setShowAdd(false)}
        categories={allCategories}
        initialCategorie={addInitCat}
      />
    </AppShell>
  );
}
