'use client';
import React, { useState, useMemo } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock, AddButton, SearchInput } from '@/components/layout/PageHeader';
import Modal from '@/components/ui/Modal';
import ImportModal from '@/components/catalogue/ImportModal';
import BarcodeScanner from '@/components/ui/BarcodeScanner';
import PieceForm from '@/components/catalogue/PieceForm';
import ScanLogModal from '@/components/ui/ScanLogModal';
import { logScan, updateLastScanAction } from '@/lib/utils/scanLog';
import FacturerVenteModal, { type FacturerVenteSubmit } from '@/components/ventes/FacturerVenteModal';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import HelpHint from '@/components/ui/HelpHint';
import { useVentes } from '@/hooks/useVentes';
import { usePieces, useServices } from '@/hooks/useCatalogue';
import { useClients } from '@/hooks/useClients';
import ClientForm from '@/components/clients/ClientForm';
import FactureStatusPanel from '@/components/bdc/FactureStatusPanel';
import { BanknotesIcon } from '@heroicons/react/24/outline';
import { frPrix, normSearch } from '@/lib/utils/format';
import { computeTaxes } from '@/lib/finances/taxes';
import { toast } from '@/components/ui/Toast';
import { TrashIcon, ArchiveBoxArrowDownIcon, ChevronDownIcon, ChevronRightIcon, DocumentArrowUpIcon, ArrowDownTrayIcon, DocumentIcon, PlusIcon, ArrowPathIcon, QrCodeIcon, FunnelIcon, ClockIcon, CheckCircleIcon } from '@heroicons/react/24/outline';
import { mutate as swrMutate } from 'swr';

/** Input prix formaté : affiche frPrix au blur, valeur brute au focus. */
function PrixInput({ value, onChange, style }: { value: number; onChange: (v: number) => void; style?: React.CSSProperties }) {
  const [editing, setEditing] = React.useState(false);
  const [raw, setRaw]         = React.useState('');
  return editing ? (
    <input
      type="number" step="0.01" autoFocus
      value={raw}
      onChange={e => setRaw(e.target.value)}
      onBlur={() => { setEditing(false); onChange(parseFloat(raw) || 0); }}
      className="text-right"
      style={{ width: '80px', backgroundColor: '#fff', border: '1px solid rgba(0,0,0,0.3)', borderRadius: '6px', padding: '3px 4px', fontSize: '13px', ...style }}
    />
  ) : (
    <span
      onClick={() => { setEditing(true); setRaw(String(value)); }}
      className="cursor-pointer"
      style={{ display: 'inline-block', width: '80px', textAlign: 'right', fontSize: '13px', ...style }}
      title="Cliquer pour modifier"
    >
      {frPrix(value)}
    </span>
  );
}

export default function VentesPage() {
  const { ventes, isLoading, createVente, deleteVente, archiveVente, markVentePayee, deleteVenteItem, patchVenteItemQte, addItemsToVente, facturerVente } = useVentes();
  const { pieces, patchPiece } = usePieces();
  const { services } = useServices();
  const { allNoms, grouped } = useClients();
  // v1.0.21+ : modal d'ajout client à la volée depuis la fenêtre Nouvelle vente
  const [showClientForm, setShowClientForm] = useState(false);
  // v1.0.25+ : modal de gestion statut/mode paiement post-facturation. Stocke
  // le factureNumero de la vente courante. Ouvre FactureStatusPanel inline.
  const [factureStatutRef, setFactureStatutRef] = useState<string | null>(null);

  // Map nomComplet → Client pour récupérer la langue préférée
  const clientByName = useMemo(() => {
    const m = new Map<string, { lang?: string }>();
    const all = [...(grouped?.recents ?? []), ...(grouped?.actifs ?? []), ...(grouped?.autres ?? [])];
    for (const c of all) if (!m.has(c.nomComplet)) m.set(c.nomComplet, c);
    return m;
  }, [grouped]);

  const [showNew, setShowNew] = useState(false);
  // ── Filtres liste ventes ──
  const [venteSearch, setVenteSearch] = useState('');
  const [venteStatut, setVenteStatut] = useState<'all' | 'pending' | 'done'>('all');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const filtersRef = React.useRef<HTMLDivElement>(null);
  const filtersRefMobile = React.useRef<HTMLDivElement>(null);

  // Fermer le dropdown filtres au clic extérieur
  React.useEffect(() => {
    if (!filtersOpen) return;
    function onClick(e: MouseEvent) {
      const target = e.target as Node;
      if (filtersRef.current?.contains(target)) return;
      if (filtersRefMobile.current?.contains(target)) return;
      setFiltersOpen(false);
    }
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, [filtersOpen]);

  async function handleSync() {
    if (syncing) return;
    setSyncing(true);
    try {
      const res = await fetch('/api/sync?force=1', { method: 'POST' });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Erreur sync');
      await swrMutate(() => true, undefined, { revalidate: true });
      toast('Données synchronisées');
    } catch (err: any) {
      toast(err?.message ?? 'Erreur de synchronisation', 'error');
    } finally {
      setSyncing(false);
    }
  }
  // ── PDF preview inline ──
  const [pdfPreviewUrl, setPdfPreviewUrl] = useState<string | null>(null);
  const [showImport, setShowImport] = useState(false);
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [client, setClient] = useState('');
  const [lang,   setLang]   = useState<'FR' | 'EN'>('FR');
  const [items, setItems] = useState<{ pieceId: string; sku: string; nom: string; qte: number; prixUnit: number }[]>([]);
  const [search, setSearch] = useState('');
  const [creating, setCreating] = useState(false);
  const [expandedVente, setExpandedVente] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [facturingId, setFacturingId] = useState<string | null>(null);
  // v1.1.16+ : id de la vente en cours de re-génération (pour disabled + spinner)
  const [regeneratingId, setRegeneratingId] = useState<string | null>(null);

  /** v1.1.16+ — re-génère le PDF d'une vente déjà facturée (refonte template,
   *  changement adresse client après facturation, PDF perdu). N'incrémente PAS
   *  le compteur facture, n'écrit PAS dans le journal VENTES (pas de doublon). */
  async function regenererVente(venteId: string, factureNumero: string) {
    if (regeneratingId) return;
    if (!window.confirm(`Re-générer le PDF facture ${factureNumero} ?\n\n• Nouveau PDF dans Drive (l'ancien reste)\n• Nouveau brouillon Gmail (l'ancien reste)\n• Pas de double-ligne dans le journal comptable`)) return;
    setRegeneratingId(venteId);
    toast('Re-génération du PDF…', 'info');
    try {
      const res = await fetch(`/api/ventes/${encodeURIComponent(venteId)}/regenerer-facture`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? `HTTP ${res.status}`);
      toast(`PDF re-généré — ${data.message ?? 'OK'}`, 'success');
      if (data.draftUrl) window.open(data.draftUrl, '_blank', 'noopener,noreferrer');
    } catch (err: any) {
      toast(err.message ?? 'Erreur re-génération', 'error');
    } finally {
      setRegeneratingId(null);
    }
  }
  // venteId cible du modal de facturation (null = fermé)
  const [factureTargetId, setFactureTargetId] = useState<string | null>(null);
  const [appendTargetId,  setAppendTargetId]  = useState<string | null>(null);
  const [appendItems,     setAppendItems]     = useState<{ pieceId: string; sku: string; nom: string; qte: number; prixUnit: number }[]>([]);
  const [appendSearch,    setAppendSearch]    = useState('');
  const [appending,       setAppending]       = useState(false);
  const [cost, setCost] = useState(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('vente_cost') === '1';
  });

  // Prix à utiliser selon le toggle Cost
  function priceFor(p: typeof pieces[0], useCost: boolean): number {
    if (useCost) return p.prixCost || p.prixAchat || p.prixBase || 0;
    // Prix unitaire de vente : col R (prixBDC) en priorité, puis col P
    // (prixVente), puis fallbacks col O / col L. Permet à l'utilisateur
    // de fixer un prix de vente spécifique en col R distinct du prix P.
    return p.prixBDC || p.prixVente || p.prixBase || p.prixAchat || 0;
  }

  function toggleCost() {
    setCost(prev => {
      const next = !prev;
      if (typeof window !== 'undefined') localStorage.setItem('vente_cost', next ? '1' : '0');
      // Recalculer prixUnit de tous les items existants selon le nouveau mode
      setItems(curr => curr.map(it => {
        const p = pieces.find(x => x.pieceId === it.pieceId);
        if (!p) return it;
        return { ...it, prixUnit: priceFor(p, next) };
      }));
      return next;
    });
  }

  const filteredPieces = useMemo(() => {
    if (!search) return [];
    const q = normSearch(search);
    return pieces.filter(p => {
      if (!p.nom || p.nom === 'Nom ITEM' || p.nom.startsWith('FIN DE')) return false;
      return normSearch(p.nom).includes(q) || normSearch(p.sku).includes(q);
    }).slice(0, 20);
  }, [pieces, search]);

  /** Handler du bouton Import du modal Nouvelle vente.
   *  Les items importés (matchés par SKU ou nom) sont ajoutés à la vente.
   *  Prix unitaire = prix de vente catalogue (priceFor + toggle Cost).
   *  Les items sans match / en double sont ignorés (toast récap). */
  function handleImportItems(
    imported: { nom: string; sku: string; qteCommandee: number; prixAchat: number; pieceRow: number; pieceId: string }[],
  ) {
    let added = 0;
    let skippedNoMatch = 0;
    let skippedDup = 0;
    setItems(curr => {
      const next = [...curr];
      for (const row of imported) {
        if (!row.pieceId) { skippedNoMatch++; continue; }
        if (next.some(it => it.pieceId === row.pieceId)) { skippedDup++; continue; }
        const p = pieces.find(x => x.pieceId === row.pieceId);
        if (!p) { skippedNoMatch++; continue; }
        next.push({
          pieceId : p.pieceId,
          sku     : p.sku,
          nom     : p.nom,
          qte     : Math.max(1, row.qteCommandee || 1),
          prixUnit: priceFor(p, cost),
        });
        added++;
      }
      return next;
    });
    setShowImport(false);
    const parts = [`${added} item${added > 1 ? 's' : ''} ajouté${added > 1 ? 's' : ''}`];
    if (skippedDup)     parts.push(`${skippedDup} doublon${skippedDup > 1 ? 's' : ''}`);
    if (skippedNoMatch) parts.push(`${skippedNoMatch} sans match`);
    toast(parts.join(' · '));
  }

  function addItem(p: typeof pieces[0]) {
    // Si déjà au panier → +1 sur qté (au lieu de skip). Utile pour le scan
    // répété du même code en caisse.
    const existingIdx = items.findIndex(it => it.pieceId === p.pieceId);
    if (existingIdx >= 0) {
      setItems(prev => prev.map((it, i) => i === existingIdx ? { ...it, qte: it.qte + 1 } : it));
      setSearch('');
      return;
    }
    setItems(prev => [...prev, {
      pieceId: p.pieceId,
      sku    : p.sku,
      nom    : p.nom,
      qte    : 1,
      prixUnit: priceFor(p, cost),
    }]);
    setSearch('');
  }

  // v1.0.21+ : ajoute un service du catalogue à la vente. Auto-incrémente
  // la qté si déjà présent. Pas de gestion stock (services ≠ pièces).
  // Le prix vient du catalogue À LA CARTE.
  function addService(svcId: string, label: string, prix: number) {
    const existingIdx = items.findIndex(it => it.pieceId === svcId);
    if (existingIdx >= 0) {
      setItems(prev => prev.map((it, i) => i === existingIdx ? { ...it, qte: it.qte + 1 } : it));
      return;
    }
    setItems(prev => [...prev, {
      pieceId : svcId,
      sku     : '',
      nom     : label,
      qte     : 1,
      prixUnit: prix,
    }]);
  }

  // v1.0.21+ : services prioritaires (en tête du dropdown) + reste alpha.
  // IDs prioritaires :
  //   - S00088 = ⛑️ Urgent. : Flat (legacy, prix par défaut 15 $)
  //   - Les 2 autres « mécanicien forfait entreprise » et « mécanicien
  //     volant (/h) » sont matchés par label (IDs variables).
  const orderedServices = useMemo(() => {
    const PRIORITY_LABELS = [
      'Flat',                                          // matche « Flat » ou « ⛑️ Urgent. : Flat »
      'mécanicien - forfait entreprise',               // matche « Service : mécanicien - forfait entreprise »
      'mécanicien volant',                             // matche « Service : mécanicien volant (/h) »
    ];
    const priority: typeof services = [];
    const rest: typeof services = [];
    for (const s of services) {
      if (!s.label || s.label.startsWith('FIN DE')) continue;
      const matched = PRIORITY_LABELS.some(p =>
        s.label.toLowerCase().includes(p.toLowerCase())
      );
      if (matched) priority.push(s);
      else rest.push(s);
    }
    // Trie les prioritaires selon l'ordre PRIORITY_LABELS
    priority.sort((a, b) => {
      const ai = PRIORITY_LABELS.findIndex(p => a.label.toLowerCase().includes(p.toLowerCase()));
      const bi = PRIORITY_LABELS.findIndex(p => b.label.toLowerCase().includes(p.toLowerCase()));
      return ai - bi;
    });
    rest.sort((a, b) => a.label.localeCompare(b.label, 'fr-CA'));
    return { priority, rest };
  }, [services]);

  // ── Scanner SKU (caméra iOS/Android) ──────────────────────────
  const [showScanner, setShowScanner] = useState(false);
  const [scanMessage, setScanMessage] = useState('');
  // Code scanné non reconnu (ni par codeBarre ni par SKU) — ouvre la
  // modal "Associer à une pièce existante"
  const [unknownScanCode, setUnknownScanCode] = useState<string>('');
  const [mapSearch, setMapSearch] = useState('');
  // Création d'une nouvelle pièce depuis un scan — pré-remplit le codeBarre
  const [createFromScanCode, setCreateFromScanCode] = useState<string>('');
  // Historique des scans (log local)
  const [scanLogOpen, setScanLogOpen] = useState(false);
  function handleScan(code: string) {
    const norm = code.trim();
    const lc   = norm.toLowerCase();
    // 1. Priorité : code-barre fabricant (exact) — EAN/UPC
    let piece = pieces.find(p => (p.codeBarre || '').trim() === norm);
    let matchedBy: 'barcode' | 'sku' | null = piece ? 'barcode' : null;
    // 2. Fallback : SKU (compat ancien workflow)
    if (!piece) {
      piece = pieces.find(p => (p.sku || '').trim().toLowerCase() === lc);
      if (piece) matchedBy = 'sku';
    }
    if (!piece) {
      // 3. Pas trouvé — proposer mapping ou création
      logScan({ code: norm, action: 'unknown' });
      setUnknownScanCode(norm);
      setMapSearch('');  // toujours partir d'un champ vide à l'ouverture
      setScanMessage(`⚠ Code « ${norm} » inconnu — mappe ou crée une pièce`);
      return;
    }
    // Log du match réussi (barcode ou SKU)
    logScan({
      code     : norm,
      action   : matchedBy === 'barcode' ? 'matched-barcode' : 'matched-sku',
      pieceId  : piece.pieceId,
      pieceName: piece.nom,
    });
    const existing = items.find(it => it.pieceId === piece.pieceId);
    addItem(piece);
    const nextQty = (existing?.qte ?? 0) + 1;
    setScanMessage(`✓ ${piece.nom} — qté ${nextQty}`);
  }

  function removeItem(idx: number) {
    setItems(prev => prev.filter((_, i) => i !== idx));
  }

  function updateItem(idx: number, fields: Partial<{ qte: number; prixUnit: number }>) {
    setItems(prev => prev.map((it, i) => {
      if (i !== idx) return it;
      const next = { ...it, ...fields };
      if (fields.qte !== undefined) {
        // v1.0.23+ : qté accepte décimales (ex. 1,5h mécanicien volant).
        // Min 0,01 pour permettre toute valeur > 0. Pas de plafond.
        next.qte = Math.max(0.01, fields.qte);
        // Si qté > stock, s'assurer que la qte à commander couvre le manque.
        const piece = pieces.find(p => p.pieceId === it.pieceId);
        if (piece) {
          const deficit = Math.max(0, next.qte - (piece.stock ?? 0));
          const curCmd  = piece.qteACommander ?? 0;
          if (deficit > curCmd) {
            // Persiste le nouveau qteACommander + flag '$' (en commande)
            patchPiece(piece._row, {
              qteACommander: deficit,
              ...(piece.flag !== '$' ? { flag: '$' } : {}),
            }).catch(err => toast(err.message, 'error'));
          }
        }
      }
      return next;
    }));
  }

  async function handleCreate(andFacturer = false) {
    if (!items.length || !date) {
      toast('Date et au moins 1 item requis', 'error');
      return;
    }
    // Pour facturer sans client choisi (walk-in flat) : fallback Walk-in.
    // Le client Walk-in doit exister dans CLIENTS (courriel walkin@cycloflex.local).
    const clientFinal = andFacturer && !client ? 'Walk-in' : client;
    setCreating(true);
    try {
      const res = await createVente({ date, client: clientFinal, items, cost });
      toast('Vente enregistrée — stock décrémenté');
      setShowNew(false);
      setItems([]);
      setClient('');
      setSearch('');
      if (andFacturer && res?.venteId) {
        // Ouvre le modal de facturation pour permettre note/remise/langue
        setFactureTargetId(res.venteId);
      }
    } catch (err: any) { toast(err.message, 'error'); }
    finally { setCreating(false); }
  }

  /** Ouvre le modal de confirmation/remise pour facturer une vente. */
  function openFactureModal(venteId: string, client: string) {
    if (!client) {
      toast('Cette vente n\'a pas de client — impossible de facturer', 'error');
      return;
    }
    setFactureTargetId(venteId);
  }

  /** Submit du modal de facturation : appelle l'API avec les paramètres saisis. */
  async function submitFacture(values: FacturerVenteSubmit) {
    if (!factureTargetId) return;
    setFacturingId(factureTargetId);
    try {
      const res = await facturerVente(
        factureTargetId,
        values.noteClient,
        values.lang,
        values.remisePce,
        values.modePaiement,
        values.generatePdf,
        values.payeMaintenant,
      );
      const isWalkin = !res.draftUrl && res.pdfUrl;
      toast(
        isWalkin
          ? `Facture ${res.factureNumero ?? ''} (Walk-in) — PDF ouvert pour impression`.trim()
          : `Facture ${res.factureNumero ?? ''} créée`.trim()
      );
      setFactureTargetId(null);
      // Walk-in (.local courriel) → pas de brouillon Gmail, on ouvre le PDF.
      // Sinon → ouvre le brouillon Gmail dans la boîte utilisateur.
      if (res.draftUrl) window.open(res.draftUrl, '_blank');
      else if (res.pdfUrl) window.open(res.pdfUrl, '_blank');
    } catch (err: any) {
      if (err?.alreadyFacturee) {
        toast(`Déjà facturée (${err.factureNumero})`, 'error');
        setFactureTargetId(null);
      } else {
        toast(err?.message ?? 'Erreur', 'error');
      }
    } finally { setFacturingId(null); }
  }

  /** Extrait le fileId d'un webViewLink Drive et construit l'URL de preview embarquée. */
  function drivePreviewUrl(url: string): string | null {
    // Format attendu : https://drive.google.com/file/d/{fileId}/view?...
    const m = url.match(/\/file\/d\/([^/]+)/);
    if (m) return `https://drive.google.com/file/d/${m[1]}/preview`;
    // Fallback : ouvre le lien tel quel dans l'iframe
    return url;
  }

  /** Affichage badge facture : "V0012 — 2026-04-26" (formats V/F supportés). */
  function displayFacture(num?: string): string {
    if (!num) return '';
    // Nouveau format : V0012-2026-04-26
    const mV = num.match(/^V(\d{4,})-(\d{4}-\d{2}-\d{2})$/);
    if (mV) return `V${mV[1]} — ${mV[2]}`;
    // Legacy : F2026-04-15-0001
    const m1 = num.match(/^F(\d{4}-\d{2}-\d{2})-(\d{4,})$/);
    if (m1) return `V${m1[2]} — ${m1[1]}`;
    const m2 = num.match(/^F(\d{4})-(\d{4,})$/);
    if (m2) return `V${m2[2]} — ${m2[1]}`;
    return num;
  }

  // ── Ajout d'items à une vente existante ─────────────────────────
  // v1.1.5+ (cluster 4 item n) — Le picker accepte maintenant pièces ET
  // services. Chaque entrée du dropdown est normalisée en `PickerEntry`
  // pour partager le même rendu. Les services portent un pieceId
  // S-préfixé (serviceId) ; le pipeline de stock skip ces lignes
  // (cf lib/sheets/ventes.ts _adjustStock).
  interface PickerEntry {
    kind   : 'piece' | 'service';
    pieceId: string;   // P00xxx pour pièce, S00xxx pour service
    sku    : string;   // SKU pièce, '—' pour services (pas de SKU)
    nom    : string;
    prix   : number;
  }

  const appendTargetVente = appendTargetId ? ventes.find(x => x.venteId === appendTargetId) : null;
  const appendFiltered = useMemo<PickerEntry[]>(() => {
    if (!appendSearch) return [];
    const q = normSearch(appendSearch);
    const useCost = appendTargetVente?.cost ?? false;

    const pieceEntries: PickerEntry[] = pieces
      .filter(p => {
        if (!p.nom || p.nom === 'Nom ITEM' || p.nom.startsWith('FIN DE')) return false;
        return normSearch(p.nom).includes(q) || normSearch(p.sku).includes(q);
      })
      .map(p => ({
        kind   : 'piece',
        pieceId: p.pieceId,
        sku    : p.sku,
        nom    : p.nom,
        prix   : priceFor(p, useCost),
      }));

    const serviceEntries: PickerEntry[] = services
      .filter(s => normSearch(s.label).includes(q))
      .map(s => ({
        kind   : 'service',
        pieceId: s.serviceId,   // S-préfixé → backend skip stock
        sku    : '—',
        nom    : s.label,
        prix   : s.prix,
      }));

    // Pièces d'abord (priorité historique), services ensuite, total capé à 20.
    return [...pieceEntries, ...serviceEntries].slice(0, 20);
  }, [pieces, services, appendSearch, appendTargetVente?.cost]);

  function closeAppend() {
    setAppendTargetId(null);
    setAppendItems([]);
    setAppendSearch('');
  }
  function addAppendItem(p: PickerEntry) {
    if (appendItems.some(it => it.pieceId === p.pieceId)) return;
    setAppendItems(prev => [...prev, {
      pieceId : p.pieceId,
      sku     : p.sku === '—' ? '' : p.sku,
      nom     : p.nom,
      qte     : 1,
      prixUnit: p.prix,
    }]);
    setAppendSearch('');
  }
  function updateAppendItem(idx: number, patch: Partial<{ qte: number; prixUnit: number }>) {
    // v1.0.23+ : qté min 0,01 (décimales acceptées, cf updateItem)
    const safePatch = { ...patch };
    if (safePatch.qte !== undefined) safePatch.qte = Math.max(0.01, safePatch.qte);
    setAppendItems(prev => prev.map((it, i) => i === idx ? { ...it, ...safePatch } : it));
  }
  function removeAppendItem(idx: number) {
    setAppendItems(prev => prev.filter((_, i) => i !== idx));
  }
  async function submitAppend() {
    if (!appendTargetId || !appendItems.length) return;
    setAppending(true);
    try {
      await addItemsToVente(appendTargetId, appendItems);
      toast(`${appendItems.length} item${appendItems.length > 1 ? 's' : ''} ajouté${appendItems.length > 1 ? 's' : ''} — stock décrémenté`);
      closeAppend();
    } catch (err: any) { toast(err.message, 'error'); }
    finally { setAppending(false); }
  }
  const appendTotal = appendItems.reduce((s, it) => s + it.qte * it.prixUnit, 0);

  async function handleDeleteItem(venteId: string, row: number) {
    try {
      await deleteVenteItem(venteId, row);
      toast('Item supprimé');
    } catch (err: any) { toast(err.message, 'error'); }
  }

  /** Modifie la qté d'un item d'une vente brouillon. AB et AC bougent
   *  en temps réel via snapshot/recompute (cf. v6.6.0). */
  async function handlePatchQte(venteId: string, row: number, qte: number) {
    if (qte < 1) return;
    try {
      await patchVenteItemQte(venteId, row, qte);
    } catch (err: any) { toast(err.message, 'error'); }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      // Brouillon → suppression directe (libère le stock engagé).
      // Facturée → archivage (déplacement vers _VENTES_ARCHIVES_).
      const target = ventes.find(v => v.venteId === deleteTarget);
      const isFact = !!target?.factureDate;
      if (isFact) {
        await archiveVente(deleteTarget);
        toast('Vente archivée');
      } else {
        await deleteVente(deleteTarget);
        toast('Brouillon supprimé');
      }
      setDeleteTarget(null);
    } catch (err: any) { toast(err.message, 'error'); }
    finally { setDeleting(false); }
  }

  const total = items.reduce((s, it) => s + it.qte * it.prixUnit, 0);
  const totalVentes = ventes.reduce((s, v) => s + v.total, 0);

  // ── Ventes filtrées ──
  const ventesFiltered = useMemo(() => {
    let list = ventes;
    // Filtre statut
    if (venteStatut === 'pending') list = list.filter(v => !v.factureDate);
    if (venteStatut === 'done')    list = list.filter(v => !!v.factureDate);
    // Recherche texte (client, numéro facture, date, items)
    if (venteSearch) {
      const q = venteSearch.toLowerCase();
      list = list.filter(v =>
        (v.client ?? '').toLowerCase().includes(q) ||
        (v.factureNumero ?? '').toLowerCase().includes(q) ||
        v.date.includes(q) ||
        v.items.some(it => it.nom.toLowerCase().includes(q) || it.sku.toLowerCase().includes(q))
      );
    }
    return list;
  }, [ventes, venteSearch, venteStatut]);

  // Catégories + fournisseurs uniques dérivés du catalogue (pour PieceForm)
  const pfCategories = useMemo(() =>
    [...new Set(pieces.map(p => p.categorie).filter(Boolean))].sort(),
    [pieces],
  );
  const pfFournisseurs = useMemo(() =>
    [...new Set(pieces.map(p => p.fournisseur).filter(f => !!f && f.toLowerCase() !== 'fournisseur'))].sort(),
    [pieces],
  );

  // Total taxes incluses (TTC) — somme des sous-totaux HT puis taxes Québec.
  const totalVentesTTC = computeTaxes(totalVentes).grandTotal;
  const subtitleText = ventes.length > 0
    ? `${ventes.length} vente${ventes.length > 1 ? 's' : ''} · ${frPrix(totalVentes)} HT · ${frPrix(totalVentesTTC)} TTC`
    : 'ventes directes';
  return (
    <AppShell>
      <div className="p-0 md:p-5 md:pt-[50px]">
        {/* ── HEADER MOBILE : titre + (+) gros, pill toolbar en dessous ── */}
        <div
          className="md:hidden flex flex-col"
          style={{
            position: 'sticky',
            top: 0,
            zIndex: 20,
            paddingTop: '0px',
            paddingBottom: '0px',
            marginBottom: '20px',
            gap: '12px',
          }}
        >
          {/* Titre + (+) gros — en premier */}
          <div className="flex items-center gap-3">
            <div className="flex flex-col flex-1 min-w-0">
              <p style={{ color: '#fff', fontSize: '13px', fontWeight: 700, marginBottom: '2px' }}>{subtitleText}</p>
              <h1 style={{
                color: '#fff056',
                fontFamily: "'HelveticaNeue-Thin', 'Helvetica Neue Thin', 'Helvetica Neue', Helvetica, Arial, sans-serif",
                fontWeight: 300,
                fontSize: '42px',
                lineHeight: 1,
                marginBottom: 0,
              }}>
                Ventes
                <span style={{ marginLeft: '12px' }}>
                  <HelpHint
                    topic="09-vente-rapide"
                    title="Vente rapide POS"
                    hint={(
                      <>
                        <b>Pour vendre une pièce sans BDT.</b>
                        <br />1. Tap <b>+</b> ➜ choisis client (ou Walk-in)
                        <br />2. Cherche la pièce ou tap <b>📷 Scan</b>
                        <br />3. Ajuste qté/prix au besoin
                        <br />4. Save → Brouillon
                        <br />5. Clic <b>Facturer</b> → PDF + Gmail + stock décrémenté
                        <br /><br />
                        <i>Walk-in</i> = client sans fiche. <i>Cost</i> = prix fournisseur.
                      </>
                    )}
                    variant="outlined"
                  />
                </span>
              </h1>
            </div>
            <button
              type="button"
              onClick={() => setShowNew(true)}
              title="Nouvelle vente"
              className="flex items-center justify-center shrink-0"
              style={{
                width: '56px', height: '56px', borderRadius: '50%',
                backgroundColor: '#fff056',
                color: '#000',
                fontSize: '36px',
                fontWeight: 700,
                lineHeight: 1,
                border: 'none',
                cursor: 'pointer',
                padding: 0,
              }}
            >
              <span style={{ position: 'relative', top: '-2px' }}>+</span>
            </button>
          </div>
        </div>

        {/* ── HEADER DESKTOP : PageHeader classique ── */}
        <div className="hidden md:block">
        <PageHeader
          subtitle={subtitleText}
          title="Ventes"
          helpTopic="09-vente-rapide"
          helpTitle="Vente rapide POS"
          helpHint="Vendre une pièce sans BDT : Walk-in, scan iPhone, facturer en 1 clic. Voir le tutoriel pour le workflow complet."
        >
          <ToolbarBlock>
            {/* Dropdown filtres (recherche + statut) — ordre 3 mobile / 1 desktop */}
            <div className="relative order-3 md:order-1" ref={filtersRef}>
              <button
                type="button"
                onClick={() => setFiltersOpen(o => !o)}
                className="flex items-center whitespace-nowrap"
                style={{
                  padding: '0 14px',
                  height: '32px',
                  borderRadius: '32px',
                  fontSize: '13px',
                  fontWeight: 700,
                  letterSpacing: '0.02em',
                  backgroundColor: 'rgba(255,255,255,0.3)',
                  color: 'rgba(0,0,0,0.5)',
                  border: 'none',
                  cursor: 'pointer',
                }}
              >
                filtres
                <ChevronDownIcon
                  style={{
                    width: '14px', height: '14px', marginLeft: '6px',
                    strokeWidth: 3,
                    transform: filtersOpen ? 'rotate(180deg)' : 'none',
                    transition: 'transform 0.15s',
                  }}
                />
              </button>
              {filtersOpen && (
                <div
                  className="absolute right-0"
                  style={{
                    top: 'calc(100% + 6px)',
                    minWidth: '300px',
                    backgroundColor: '#fff',
                    borderRadius: '20px',
                    boxShadow: '0 6px 24px rgba(0,0,0,0.25)',
                    zIndex: 50,
                  }}
                >
                  <div className="flex flex-col" style={{ gap: '10px', padding: '12px 16px' }}>
                    <input
                      type="search"
                      value={venteSearch}
                      onChange={e => setVenteSearch(e.target.value)}
                      placeholder="Client, n° facture, SKU…"
                      className="focus:outline-none focus:ring-2 focus:ring-yellow-400"
                      style={{
                        height: '32px', borderRadius: '32px',
                        backgroundColor: 'rgba(0,0,0,0.06)',
                        color: 'rgba(0,0,0,0.7)', border: 'none',
                        fontSize: '13px', padding: '0 14px',
                      }}
                    />
                    <div className="flex items-center" style={{ gap: '6px' }}>
                      {(['all', 'pending', 'done'] as const).map(s => {
                        const labels: Record<string, string> = { all: 'Toutes', pending: 'À facturer', done: 'Facturées' };
                        const active = venteStatut === s;
                        return (
                          <button key={s} type="button" onClick={() => setVenteStatut(s)}
                            className="flex items-center whitespace-nowrap"
                            style={{
                              padding: '0 12px', height: '28px', borderRadius: '28px',
                              fontSize: '12px', fontWeight: 700, border: 'none', cursor: 'pointer',
                              backgroundColor: active ? '#fff056' : 'rgba(0,0,0,0.06)',
                              color: active ? '#000' : 'rgba(0,0,0,0.5)',
                            }}
                          >
                            {labels[s]}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Sync — ordre 2 mobile/desktop */}
            <button
              type="button"
              onClick={handleSync}
              disabled={syncing}
              title="Rafraîchir les données"
              className="flex items-center justify-center shrink-0 order-2"
              style={{
                width: '32px', height: '32px', borderRadius: '50%',
                backgroundColor: 'transparent',
                color: '#fff056',
                border: '2px solid #fff056',
                cursor: syncing ? 'wait' : 'pointer',
                padding: 0,
              }}
            >
              <ArrowPathIcon
                className={syncing ? 'animate-spin' : ''}
                style={{ width: '14px', height: '14px', strokeWidth: 2.5 }}
              />
            </button>

            {/* Export xlsx — masqué sur mobile, ordre 3 desktop */}
            <button
              type="button"
              onClick={() => window.open(`/api/ventes/export?statut=${venteStatut}`, '_blank')}
              title="Exporter les ventes en xlsx"
              className="hidden md:flex items-center justify-center shrink-0 md:order-3"
              style={{
                width: '32px', height: '32px', borderRadius: '50%',
                backgroundColor: 'transparent',
                color: '#fff056',
                border: '2px solid #fff056',
                cursor: 'pointer',
                padding: 0,
              }}
            >
              <ArrowDownTrayIcon style={{ width: '14px', height: '14px', strokeWidth: 2.5 }} />
            </button>

            {/* Nouvelle vente — ordre 1 mobile / 4 desktop */}
            <button
              type="button"
              onClick={() => setShowNew(true)}
              title="Nouvelle vente"
              className="flex items-center justify-center shrink-0 order-1 md:order-4"
              style={{
                width: '32px', height: '32px', borderRadius: '50%',
                backgroundColor: '#fff056',
                color: '#000',
                fontSize: '20px',
                fontWeight: 700,
                lineHeight: 1,
                border: 'none',
                cursor: 'pointer',
                padding: 0,
              }}
            >
              <span style={{ position: 'relative', top: '-1px' }}>+</span>
            </button>
          </ToolbarBlock>
        </PageHeader>
        </div>

        {isLoading && <LoadingSpinner className="py-20" />}

        {!isLoading && (
          <div className="md:bg-[rgba(0,0,0,0.20)] md:rounded-[50px] md:p-5">
            {ventesFiltered.length === 0 && (
              <p className="text-center py-16" style={{ color: 'rgba(255,255,255,0.5)' }}>
                {ventes.length === 0 ? 'Aucune vente. Cliquez sur « + » pour en créer une.' : 'Aucune vente ne correspond aux filtres.'}
              </p>
            )}
            <div className="flex flex-col" style={{ gap: '20px' }}>
              {ventesFiltered.map(v => {
                const isExpanded = expandedVente === v.venteId;
                // "facturée" = PDF déjà généré (factureDate présente).
                // factureNumero est toujours attribué à la création.
                const isFact     = !!v.factureDate;
                // v1.1.5+ (cluster 4 item m) — payée = col P _VENTES_ === 'payé'.
                // Une vente payée est archivable et change d'apparence (gris).
                const isPaye     = v.payeStatus === 'payé';
                // Bouton action 37px — fond noir 50%, icône jaune
                const actionBtn: React.CSSProperties = {
                  width: '37px', height: '37px', borderRadius: '50%',
                  backgroundColor: 'rgba(0,0,0,0.5)', color: '#fff056',
                  border: 'none', cursor: 'pointer', padding: 0,
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0,
                };
                // Icônes 22px (grossies)
                const ICON_SZ = 22;
                // Header — 3 états (cluster 4 item m) :
                //   payé → gris (#e0e0e0), label "Payé"
                //   facturé pas payé → blanc 50%, label "Facture envoyée"
                //   pas facturé → jaune, label "À facturer"
                const headerBg     = isPaye ? '#e0e0e0' : (isFact ? 'rgba(255,255,255,0.5)' : '#fff056');
                const statusLabel  = isPaye ? 'Payé' : (isFact ? 'Facture envoyée' : 'À facturer');
                const statusColor  = isPaye ? 'rgba(0,0,0,0.45)' : (isFact ? 'rgba(0,0,0,0.55)' : 'rgba(0,0,0,0.6)');
                return (
                  <div key={v.venteId} className="overflow-hidden" style={{ borderRadius: '30px' }}>
                    {/* ── MOBILE : 2 lignes compactes + actions ─────────── */}
                    {(() => {
                      const isWalkin = v.client === 'Walk-in';
                      const labelMobile = isFact
                        ? (isWalkin ? 'Payé' : 'Facture envoyée')
                        : 'À facturer';
                      const hasRemise = isFact && v.remiseValue && v.remiseValue > 0;
                      const montantRemise = hasRemise
                        ? (v.remiseType === 'fixed'
                            ? Math.min(v.remiseValue!, v.total)
                            : Math.round(v.total * v.remiseValue!) / 100)
                        : 0;
                      const amount = hasRemise ? Math.max(0, v.total - montantRemise) : v.total;
                      return (
                    <div
                      className="md:hidden flex items-start gap-2"
                      style={{
                        backgroundColor: headerBg,
                        padding: '12px 16px',
                        borderRadius: isExpanded ? '30px 30px 0 0' : '30px',
                      }}
                    >
                      {/* Bloc texte cliquable (expand/collapse) */}
                      <button
                        type="button"
                        onClick={() => setExpandedVente(isExpanded ? null : v.venteId)}
                        className="flex-1 min-w-0 flex flex-col gap-1 text-left"
                        style={{ background: 'transparent', border: 'none', cursor: 'pointer', padding: 0 }}
                      >
                        {/* Ligne 1 : numéro/date — statut */}
                        <div className="flex items-center justify-between gap-2">
                          <span style={{ fontSize: '16px', fontWeight: 700, color: 'rgba(0,0,0,0.8)', letterSpacing: '0.01em' }}>
                            {v.factureNumero ? displayFacture(v.factureNumero) : v.date}
                          </span>
                          <span
                            className="inline-flex items-center whitespace-nowrap"
                            style={{
                              height: '22px', padding: '0 10px',
                              borderRadius: '999px',
                              backgroundColor: 'rgba(0,0,0,0.08)',
                              color: statusColor,
                              fontSize: '12px',
                              fontWeight: 700,
                              textTransform: 'uppercase', letterSpacing: '0.04em',
                            }}
                          >
                            {labelMobile}
                          </span>
                        </div>
                        {/* Ligne 2 : client — nb items — total */}
                        <div className="flex items-center justify-between gap-2">
                          <span style={{ fontSize: '14px', color: 'rgba(0,0,0,0.7)', minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: '1 1 0' }}>
                            {v.client || '—'}
                          </span>
                          <span style={{ fontSize: '13px', color: 'rgba(0,0,0,0.5)' }}>
                            {v.items.length} item{v.items.length > 1 ? 's' : ''}
                          </span>
                          {hasRemise && (
                            <span
                              className="inline-flex items-center whitespace-nowrap"
                              style={{
                                height: '20px', padding: '0 8px',
                                borderRadius: '999px',
                                backgroundColor: 'rgba(239,68,68,0.2)',
                                color: '#b91c1c',
                                fontSize: '11px',
                                fontWeight: 700,
                              }}
                              title={`Sous-total ${frPrix(v.total)} − remise ${frPrix(montantRemise)}`}
                            >
                              − {v.remiseType === 'fixed' ? frPrix(v.remiseValue!) : `${v.remiseValue} %`}
                            </span>
                          )}
                          <span style={{ fontSize: '18px', fontWeight: 700, color: 'rgba(0,0,0,0.8)' }}>
                            {frPrix(amount)}
                          </span>
                        </div>
                      </button>

                      {/* Actions mobile (colonne à droite) :
                          - Facturée : poubelle uniquement (pas de PDF, pas de +)
                          - À facturer : (+) puis Facturer (ordre inversé) puis poubelle */}
                      <div className="flex flex-col shrink-0" style={{ gap: '6px' }}>
                        {!isFact && (
                          <>
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); setAppendTargetId(v.venteId); }}
                              title="Ajouter une pièce"
                              style={actionBtn}
                            >
                              <PlusIcon style={{ width: ICON_SZ, height: ICON_SZ }} />
                            </button>
                            {v.client && (
                              <button
                                type="button"
                                onClick={(e) => { e.stopPropagation(); if (facturingId !== v.venteId) openFactureModal(v.venteId, v.client); }}
                                disabled={facturingId === v.venteId}
                                title={facturingId === v.venteId ? 'Facturation…' : 'Facturer (PDF + brouillon Gmail)'}
                                style={{ ...actionBtn, opacity: facturingId === v.venteId ? 0.4 : 1 }}
                              >
                                <DocumentArrowUpIcon style={{ width: ICON_SZ, height: ICON_SZ }} />
                              </button>
                            )}
                          </>
                        )}
                        {/* v1.0.25+ : statut/mode paiement post-facturation
                            (vente facturée seulement). Ouvre FactureStatusPanel
                            dans une modal. */}
                        {isFact && v.factureNumero && (
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setFactureStatutRef(v.factureNumero!); }}
                            title="Statut & mode de paiement (PAYÉ / ÉMIS / ANNULÉ)"
                            style={actionBtn}
                          >
                            <BanknotesIcon style={{ width: ICON_SZ, height: ICON_SZ }} />
                          </button>
                        )}
                        {/* v1.1.5+ (cluster 4 item m) — bouton "Marquer payée".
                            Visible quand facturée. Coché = payée (gris). */}
                        {isFact && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              markVentePayee(v.venteId, !isPaye).catch(err => toast(err.message, 'error'));
                            }}
                            title={isPaye ? 'Annuler le statut payé' : 'Marquer comme payée → archivable'}
                            style={{
                              ...actionBtn,
                              backgroundColor: isPaye ? '#16a34a' : 'rgba(0,0,0,0.5)',
                              color          : isPaye ? '#fff' : '#fff056',
                            }}
                          >
                            <CheckCircleIcon style={{ width: ICON_SZ, height: ICON_SZ }} />
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            // v1.1.5+ : facturée non payée → bloquer suppression,
                            // forcer le passage par "marquer payée" d'abord.
                            if (isFact && !isPaye) {
                              toast('Marquer la vente comme payée avant de l\'archiver', 'error');
                              return;
                            }
                            setDeleteTarget(v.venteId);
                          }}
                          title="Supprimer la vente"
                          style={actionBtn}
                        >
                          <TrashIcon style={{ width: ICON_SZ, height: ICON_SZ }} />
                        </button>
                      </div>
                    </div>
                      );
                    })()}

                    {/* ── DESKTOP : ligne horizontale ───────────────────── */}
                    <div
                      className="hidden md:flex items-center gap-3"
                      style={{
                        backgroundColor: headerBg,
                        padding: '12px 16px',
                        borderRadius: isExpanded ? '30px 30px 0 0' : '30px',
                      }}
                    >
                      {/* Zone cliquable : expand/collapse + contenu infos */}
                      <button
                        type="button"
                        onClick={() => setExpandedVente(isExpanded ? null : v.venteId)}
                        className="flex-1 min-w-0 flex items-center gap-3 text-left"
                        style={{ background: 'transparent', border: 'none', cursor: 'pointer' }}
                      >
                        <div className="flex items-center gap-2">
                          {isExpanded
                            ? <ChevronDownIcon style={{ width: '18px', height: '18px', color: 'rgba(0,0,0,0.5)', flexShrink: 0 }} />
                            : <ChevronRightIcon style={{ width: '18px', height: '18px', color: 'rgba(0,0,0,0.5)', flexShrink: 0 }} />
                          }
                          <span style={{ fontSize: '22px', color: 'rgba(0,0,0,0.8)', fontWeight: 700, letterSpacing: '0.01em' }}>
                            {v.factureNumero ? displayFacture(v.factureNumero) : v.date}
                          </span>
                        </div>

                        <span
                          className="inline-flex items-center whitespace-nowrap"
                          style={{
                            height: '22px', padding: '0 10px',
                            borderRadius: '999px',
                            backgroundColor: 'rgba(0,0,0,0.08)',
                            color: statusColor,
                            fontSize: '11px',
                            fontWeight: 700,
                            textTransform: 'uppercase', letterSpacing: '0.04em',
                          }}
                        >
                          {statusLabel}
                        </span>

                        {v.client && (
                          <span style={{ fontSize: '14px', color: 'rgba(0,0,0,0.6)' }}>
                            {v.client}
                          </span>
                        )}

                        <span style={{ fontSize: '13px', color: 'rgba(0,0,0,0.4)' }}>
                          {v.items.length} item{v.items.length > 1 ? 's' : ''}
                        </span>

                        <div className="ml-auto flex items-center gap-3">
                          {(() => {
                            const hasRemise = isFact && v.remiseValue && v.remiseValue > 0;
                            if (!hasRemise) return null;
                            const remiseAffichee = v.remiseType === 'fixed'
                              ? frPrix(v.remiseValue!)
                              : `${v.remiseValue} %`;
                            const montantRemise  = v.remiseType === 'fixed'
                              ? Math.min(v.remiseValue!, v.total)
                              : Math.round(v.total * v.remiseValue!) / 100;
                            return (
                              <span
                                className="inline-flex items-center whitespace-nowrap"
                                style={{
                                  height: '22px', padding: '0 10px',
                                  borderRadius: '999px',
                                  backgroundColor: 'rgba(239,68,68,0.2)',
                                  color: '#b91c1c',
                                  fontSize: '12px',
                                  fontWeight: 700,
                                }}
                                title={`Sous-total ${frPrix(v.total)} − remise ${frPrix(montantRemise)}`}
                              >
                                − {remiseAffichee}
                              </span>
                            );
                          })()}
                          {(() => {
                            const hasRemise = isFact && v.remiseValue && v.remiseValue > 0;
                            const amount = hasRemise
                              ? Math.max(0, v.total - (v.remiseType === 'fixed'
                                  ? Math.min(v.remiseValue!, v.total)
                                  : Math.round(v.total * v.remiseValue!) / 100))
                              : v.total;
                            return (
                              <span style={{ fontSize: '18px', fontWeight: 700, color: 'rgba(0,0,0,0.8)' }}>
                                {frPrix(amount)}
                              </span>
                            );
                          })()}
                        </div>
                      </button>

                      {/* Actions desktop : facturer/PDF + ajouter + poubelle */}
                      <div className="flex items-center gap-2 shrink-0">
                        {/* v1.0.25+ : Statut & mode paiement (vente facturée) */}
                        {isFact && v.factureNumero && (
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setFactureStatutRef(v.factureNumero!); }}
                            title="Statut & mode de paiement (PAYÉ / ÉMIS / ANNULÉ)"
                            style={actionBtn}
                          >
                            <BanknotesIcon style={{ width: ICON_SZ, height: ICON_SZ }} />
                          </button>
                        )}
                        {isFact && v.factureUrl && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              const url = drivePreviewUrl(v.factureUrl!);
                              if (url) setPdfPreviewUrl(url);
                            }}
                            title="Voir la facture PDF"
                            style={actionBtn}
                          >
                            <DocumentIcon style={{ width: ICON_SZ, height: ICON_SZ }} />
                          </button>
                        )}
                        {!isFact && v.client && (
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); if (facturingId !== v.venteId) openFactureModal(v.venteId, v.client); }}
                            disabled={facturingId === v.venteId}
                            title={facturingId === v.venteId ? 'Facturation…' : 'Facturer (PDF + brouillon Gmail)'}
                            style={{ ...actionBtn, opacity: facturingId === v.venteId ? 0.4 : 1 }}
                          >
                            <DocumentArrowUpIcon style={{ width: ICON_SZ, height: ICON_SZ }} />
                          </button>
                        )}
                        {/* v1.1.16+ : sur une vente facturée, le « + » laisse
                            la place à un bouton « Re-générer PDF » (icône
                            ArrowPath qui tourne pendant l'appel). Sinon : +
                            classique pour ajouter une pièce. */}
                        {isFact ? (
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); if (v.factureNumero) regenererVente(v.venteId, v.factureNumero); }}
                            disabled={regeneratingId === v.venteId}
                            title={regeneratingId === v.venteId
                              ? 'Re-génération…'
                              : 'Re-générer le PDF facture (nouveau PDF + brouillon Gmail, pas de double-ligne dans le journal)'}
                            style={{ ...actionBtn, opacity: regeneratingId === v.venteId ? 0.4 : 1 }}
                          >
                            <ArrowPathIcon
                              style={{
                                width: ICON_SZ,
                                height: ICON_SZ,
                                ...(regeneratingId === v.venteId ? { animation: 'spin 1s linear infinite' } : {}),
                              }}
                            />
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setAppendTargetId(v.venteId); }}
                            title="Ajouter une pièce"
                            style={actionBtn}
                          >
                            <PlusIcon style={{ width: ICON_SZ, height: ICON_SZ }} />
                          </button>
                        )}
                        {/* v1.1.5+ (cluster 4 item m) — bouton "Marquer payée"
                            desktop. Idem mobile : coché = payée (vert). */}
                        {isFact && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              markVentePayee(v.venteId, !isPaye).catch(err => toast(err.message, 'error'));
                            }}
                            title={isPaye ? 'Annuler le statut payé' : 'Marquer comme payée → archivable'}
                            style={{
                              ...actionBtn,
                              backgroundColor: isPaye ? '#16a34a' : 'rgba(0,0,0,0.5)',
                              color          : isPaye ? '#fff' : '#fff056',
                            }}
                          >
                            <CheckCircleIcon style={{ width: ICON_SZ, height: ICON_SZ }} />
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (isFact && !isPaye) {
                              toast('Marquer la vente comme payée avant de l\'archiver', 'error');
                              return;
                            }
                            setDeleteTarget(v.venteId);
                          }}
                          title={isFact && !isPaye
                            ? 'Marquer payée avant d\'archiver'
                            : (isFact ? 'Archiver la vente' : 'Supprimer la vente')}
                          style={{
                            ...actionBtn,
                            opacity: isFact && !isPaye ? 0.4 : 1,
                          }}
                        >
                          <ArchiveBoxArrowDownIcon style={{ width: ICON_SZ, height: ICON_SZ }} />
                        </button>
                      </div>
                    </div>

                    {/* Corps déplié : légende + items + total */}
                    {isExpanded && (
                      <>
                        {/* Ligne légende — colonnes alignées sur les pages Pièces */}
                        <div
                          className="hidden md:flex items-center list-header"
                          style={{ height: '35px', padding: '0 16px' }}
                        >
                          <div style={{ width: '32px' }}></div>
                          <div className="flex-1">item</div>
                          <div style={{ flex: '1 1 0' }}>notes</div>
                          <div style={{ width: '90px', textAlign: 'center' }}>sku</div>
                          <div style={{ width: '80px', textAlign: 'right' }}>prix</div>
                          <div style={{ width: '50px', textAlign: 'center' }}>stock</div>
                          <div style={{ width: '50px', textAlign: 'center' }}>qté</div>
                          <div style={{ width: '80px', textAlign: 'right', paddingRight: '8px' }}>s/total</div>
                        </div>

                        {/* Items — couleurs alternées 0.7 / 0.85 (même convention que pieces pages) */}
                        <div>
                          {v.items.map((item, i) => {
                            const piece   = pieces.find(p => p.pieceId === item.pieceId);
                            const skuUrl  = piece?.skuUrl;
                            const notes   = piece?.notes ?? '';
                            const itemRow = v._rows[i];
                            const rowBg   = i % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)';
                            return (
                              <div
                                key={i}
                                style={{ borderBottom: '1px solid rgba(0,0,0,0.06)', backgroundColor: rowBg }}
                              >
                                {/* DESKTOP : colonnes horizontales */}
                                <div className="hidden md:flex items-center" style={{ padding: '10px 16px' }}>
                                  <button
                                    type="button"
                                    onClick={() => !isFact && handleDeleteItem(v.venteId, itemRow)}
                                    disabled={isFact}
                                    title={isFact ? 'Vente facturée — suppression bloquée' : 'Supprimer cet item'}
                                    className="flex items-center justify-center shrink-0 transition-opacity hover:opacity-70 disabled:opacity-25"
                                    style={{ width: '32px', color: 'rgba(0,0,0,0.5)', background: 'transparent', border: 'none', cursor: isFact ? 'not-allowed' : 'pointer' }}
                                  >
                                    <TrashIcon style={{ width: '16px', height: '16px' }} />
                                  </button>
                                  <div className="flex-1 whitespace-nowrap overflow-hidden text-ellipsis" style={{ color: 'rgba(0,0,0,0.7)', fontSize: '14px', fontWeight: 700 }} title={item.nom}>{item.nom}</div>
                                  <div className="whitespace-nowrap overflow-hidden text-ellipsis" style={{ flex: '1 1 0', paddingRight: '8px', color: 'rgba(0,0,0,0.55)', fontSize: '12px', fontStyle: 'italic' }} title={notes || undefined}>
                                    {notes || ''}
                                  </div>
                                  <div style={{ width: '90px', textAlign: 'center', fontFamily: 'monospace', fontSize: '12px' }}>
                                    {skuUrl ? (
                                      <a href={skuUrl} target="_blank" rel="noopener noreferrer"
                                        className="text-blue-600 hover:underline" title={skuUrl}>
                                        {item.sku || '—'}
                                      </a>
                                    ) : (
                                      <span style={{ color: 'rgba(0,0,0,0.4)' }}>{item.sku || '—'}</span>
                                    )}
                                  </div>
                                  <div style={{ width: '80px', textAlign: 'right', color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontWeight: 700 }}>{frPrix(item.prixUnit)}</div>
                                  <div style={{
                                    width: '50px', textAlign: 'center',
                                    fontSize: '13px', fontWeight: 700,
                                    color: (piece?.stock ?? 0) > 0 ? '#166534' : 'rgba(0,0,0,0.35)',
                                  }}>
                                    {piece?.stock ?? '—'}
                                  </div>
                                  <div style={{ width: '50px', textAlign: 'center' }}>
                                    {isFact ? (
                                      <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '14px', fontWeight: 700 }}>{item.qte}</span>
                                    ) : (
                                      <div className="flex items-center justify-center gap-1">
                                        <button type="button" onClick={() => handlePatchQte(v.venteId, itemRow, item.qte - 1)} disabled={item.qte <= 1}
                                          style={{ width: '20px', height: '20px', borderRadius: '4px', border: '1px solid rgba(0,0,0,0.2)', background: 'rgba(0,0,0,0.04)', color: 'rgba(0,0,0,0.7)', fontSize: '12px', fontWeight: 700, lineHeight: 1, cursor: item.qte <= 1 ? 'not-allowed' : 'pointer', opacity: item.qte <= 1 ? 0.4 : 1 }}>−</button>
                                        <span style={{ minWidth: '18px', textAlign: 'center', color: 'rgba(0,0,0,0.8)', fontSize: '13px', fontWeight: 700 }}>{item.qte}</span>
                                        <button type="button" onClick={() => handlePatchQte(v.venteId, itemRow, item.qte + 1)}
                                          style={{ width: '20px', height: '20px', borderRadius: '4px', border: '1px solid rgba(0,0,0,0.2)', background: 'rgba(0,0,0,0.04)', color: 'rgba(0,0,0,0.7)', fontSize: '12px', fontWeight: 700, lineHeight: 1, cursor: 'pointer' }}>+</button>
                                      </div>
                                    )}
                                  </div>
                                  <div style={{ width: '80px', textAlign: 'right', paddingRight: '8px', color: 'rgba(0,0,0,0.7)', fontSize: '14px', fontWeight: 700 }}>{frPrix(item.sousTotal)}</div>
                                </div>

                                {/* MOBILE : 4 lignes empilées */}
                                <div className="md:hidden flex flex-col" style={{ padding: '10px 14px', gap: '2px' }}>
                                  {/* Ligne 1 : nom item + poubelle */}
                                  <div className="flex items-start gap-2">
                                    <div className="flex-1" style={{ color: 'rgba(0,0,0,0.8)', fontSize: '14px', fontWeight: 700, lineHeight: 1.25 }}>
                                      {item.nom}
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => !isFact && handleDeleteItem(v.venteId, itemRow)}
                                      disabled={isFact}
                                      title={isFact ? 'Vente facturée — suppression bloquée' : 'Supprimer cet item'}
                                      className="flex items-center justify-center shrink-0 transition-opacity hover:opacity-70 disabled:opacity-25"
                                      style={{ width: '24px', height: '24px', color: 'rgba(0,0,0,0.5)', background: 'transparent', border: 'none', cursor: isFact ? 'not-allowed' : 'pointer', padding: 0 }}
                                    >
                                      <TrashIcon style={{ width: '16px', height: '16px' }} />
                                    </button>
                                  </div>
                                  {/* Ligne 2 : sku | s/total (prix unit) */}
                                  <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.6)' }}>
                                    <span style={{ color: 'rgba(0,0,0,0.45)' }}>sku :</span>{' '}
                                    {skuUrl ? (
                                      <a href={skuUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline" style={{ fontFamily: 'monospace' }}>
                                        {item.sku || '—'}
                                      </a>
                                    ) : (
                                      <span style={{ fontFamily: 'monospace' }}>{item.sku || '—'}</span>
                                    )}
                                    <span style={{ color: 'rgba(0,0,0,0.3)' }}> | </span>
                                    <span style={{ color: 'rgba(0,0,0,0.45)' }}>s/total :</span>{' '}
                                    <span style={{ fontWeight: 700 }}>{frPrix(item.prixUnit)}</span>
                                  </div>
                                  {/* Ligne 3 : stock | qté */}
                                  <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.6)' }}>
                                    <span style={{ color: 'rgba(0,0,0,0.45)' }}>stock :</span>{' '}
                                    <span style={{ fontWeight: 700, color: (piece?.stock ?? 0) > 0 ? '#166534' : 'rgba(0,0,0,0.5)' }}>
                                      {piece?.stock ?? '—'}
                                    </span>
                                    <span style={{ color: 'rgba(0,0,0,0.3)' }}> | </span>
                                    <span style={{ color: 'rgba(0,0,0,0.45)' }}>qté :</span>{' '}
                                    {isFact ? (
                                      <span style={{ fontWeight: 700 }}>{item.qte}</span>
                                    ) : (
                                      <span className="inline-flex items-center" style={{ gap: '4px', verticalAlign: 'middle' }}>
                                        <button type="button" onClick={() => handlePatchQte(v.venteId, itemRow, item.qte - 1)} disabled={item.qte <= 1}
                                          style={{ width: '24px', height: '24px', borderRadius: '4px', border: '1px solid rgba(0,0,0,0.2)', background: 'rgba(0,0,0,0.04)', color: 'rgba(0,0,0,0.7)', fontSize: '14px', fontWeight: 700, lineHeight: 1, cursor: item.qte <= 1 ? 'not-allowed' : 'pointer', opacity: item.qte <= 1 ? 0.4 : 1, padding: 0 }}>−</button>
                                        <span style={{ fontWeight: 700, minWidth: '18px', textAlign: 'center' }}>{item.qte}</span>
                                        <button type="button" onClick={() => handlePatchQte(v.venteId, itemRow, item.qte + 1)}
                                          style={{ width: '24px', height: '24px', borderRadius: '4px', border: '1px solid rgba(0,0,0,0.2)', background: 'rgba(0,0,0,0.04)', color: 'rgba(0,0,0,0.7)', fontSize: '14px', fontWeight: 700, lineHeight: 1, cursor: 'pointer', padding: 0 }}>+</button>
                                      </span>
                                    )}
                                    <span style={{ color: 'rgba(0,0,0,0.3)' }}> |</span>
                                  </div>
                                  {/* Ligne 4 : total (sous-total ligne) */}
                                  <div style={{ fontSize: '13px', color: 'rgba(0,0,0,0.8)' }}>
                                    <span style={{ color: 'rgba(0,0,0,0.45)', fontSize: '12px' }}>total :</span>{' '}
                                    <span style={{ fontWeight: 700 }}>{frPrix(item.sousTotal)}</span>
                                  </div>
                                </div>
                              </div>
                            );
                          })}

                        </div>

                        {/* Total */}
                        <div
                          className="flex items-center justify-between md:justify-start"
                          style={{ backgroundColor: 'rgba(255,255,255,0.5)', height: '35px', padding: '0 16px' }}
                        >
                          <div className="hidden md:block" style={{ width: '32px' }}></div>
                          <div className="md:flex-1" style={{ color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontWeight: 700, fontStyle: 'italic', textAlign: 'right' }}>
                            total
                          </div>
                          <div className="hidden md:block" style={{ flex: '1 1 0' }}></div>
                          <div className="hidden md:block" style={{ width: '90px' }}></div>
                          <div className="hidden md:block" style={{ width: '80px' }}></div>
                          <div className="hidden md:block" style={{ width: '50px' }}></div>
                          <div className="hidden md:block" style={{ width: '50px' }}></div>
                          <div style={{ textAlign: 'right', paddingRight: '8px', color: 'rgba(0,0,0,0.7)', fontSize: '18px', fontWeight: 700 }} className="md:w-[80px]">
                            {frPrix(v.total)}
                          </div>
                        </div>

                        {/* Flag Cost (lecture seule) sous le total */}
                        <div
                          className="flex items-center"
                          style={{ padding: '6px 16px 10px', backgroundColor: 'rgba(255,255,255,0.35)' }}
                        >
                          <div className="flex-1"></div>
                          <label
                            className="flex items-center gap-2"
                            style={{ color: 'rgba(0,0,0,0.55)', fontSize: '12px', fontWeight: 700, cursor: 'default' }}
                            title="Prix COST appliqués lors de la création de cette vente"
                          >
                            <input
                              type="checkbox"
                              checked={!!v.cost}
                              readOnly
                              disabled
                              className="custom-checkbox"
                            />
                            cost
                          </label>
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Modal preview PDF facture (iframe Drive) */}
      <Modal
        open={pdfPreviewUrl !== null}
        onClose={() => setPdfPreviewUrl(null)}
        title="Facture PDF"
        size="xl"
        fullHeight
      >
        {pdfPreviewUrl && (
          <div className="flex-1 min-h-0" style={{ height: '100%' }}>
            <iframe
              src={pdfPreviewUrl}
              className="w-full h-full"
              style={{ border: 'none', borderRadius: '12px', minHeight: '70vh' }}
              allow="autoplay"
            />
          </div>
        )}
      </Modal>

      {/* Modal nouvelle vente */}
      <Modal open={showNew} onClose={() => { setShowNew(false); setItems([]); setSearch(''); setClient(''); }} title="Nouvelle vente" size="xl" fullHeight maxWidth="924px">
        {/* Mobile : seulement client (date = today implicite, pas affichée).
            Desktop : date + client sur la même ligne. La langue est dérivée
            automatiquement du client choisi (ou FR par défaut). */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
          <div className="hidden sm:block">
            <label className="label-system">date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} className="input-system" />
          </div>
          <div>
            <label className="label-system">client (optionnel)</label>
            {/* v1.0.21+ : select + bouton « + » qui ouvre ClientForm pour
                créer un client à la volée sans quitter la fenêtre Nouvelle
                vente. Auto-sélection du nouveau client après création. */}
            <div className="flex items-center gap-2">
              <select
                value={client}
                onChange={e => {
                  const name = e.target.value;
                  setClient(name);
                  const l = clientByName.get(name)?.lang;
                  if (l === 'FR' || l === 'EN') setLang(l);
                }}
                className="input-system flex-1"
              >
                <option value="">Sélection →</option>
                {allNoms.map(n => <option key={n} value={n}>{n}</option>)}
              </select>
              <button
                type="button"
                onClick={() => setShowClientForm(true)}
                className="btn-plus-round shrink-0"
                title="Ajouter un nouveau client"
                aria-label="Ajouter un client"
              >
                <PlusIcon />
              </button>
            </div>
          </div>
        </div>

        {/* Service + Pièce — sur 2 lignes mobile, côte-à-côte desktop. */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4" style={{ position: 'relative' }}>
          {/* — colonne SERVICE — */}
          {/* v1.0.21+ : dropdown au lieu d'un bouton fixe. Top 3 services en
              optgroup « Prioritaires » (Flat, mécanicien forfait, mécanicien
              volant) + reste alphabétique en optgroup « Tous les services ». */}
          <div>
            <label className="label-system">ajouter un service</label>
            <select
              value=""
              onChange={e => {
                const svcId = e.target.value;
                if (!svcId) return;
                const svc = services.find(s => s.serviceId === svcId);
                if (!svc) return;
                addService(svcId, svc.label, svc.prix || 0);
                // reset au sélection placeholder pour permettre de re-choisir
                e.target.value = '';
              }}
              className="input-system"
              style={{ height: '40px' }}
            >
              <option value="">Sélection →</option>
              {orderedServices.priority.length > 0 && (
                <optgroup label="── Prioritaires ──">
                  {orderedServices.priority.map(s => (
                    <option key={s.serviceId} value={s.serviceId}>
                      {s.label} — {frPrix(s.prix || 0)}
                    </option>
                  ))}
                </optgroup>
              )}
              {orderedServices.rest.length > 0 && (
                <optgroup label="── Tous les services ──">
                  {orderedServices.rest.map(s => (
                    <option key={s.serviceId} value={s.serviceId}>
                      {s.label} — {frPrix(s.prix || 0)}
                    </option>
                  ))}
                </optgroup>
              )}
            </select>
          </div>

          {/* — colonne PIÈCE — */}
          <div>
          <label className="label-system">ajouter une pièce</label>
          <input
            type="search" placeholder="Rechercher par nom ou SKU…"
            value={search} onChange={e => setSearch(e.target.value)}
            className="input-system w-full"
          />
          <div className="flex items-center gap-2 mt-2">
            <button
              type="button"
              onClick={() => { setShowScanner(true); setScanMessage(''); }}
              className="btn-secondary flex items-center gap-1"
              title="Scanner un code-barres (caméra)"
            >
              <QrCodeIcon style={{ width: '16px', height: '16px' }} />
              Scan
            </button>
            <button
              type="button"
              onClick={() => setShowImport(true)}
              className="btn-secondary hidden sm:inline-flex items-center gap-1"
              title="Importer depuis un fichier xlsx/csv (facture fournisseur, liste)"
            >
              <ArrowDownTrayIcon style={{ width: '16px', height: '16px' }} />
              Importer
            </button>
          </div>
          </div> {/* ferme la colonne PIÈCE */}
        </div> {/* ferme le grid 2 cols (service / pièce) */}

        {/* Dropdown autocomplete — sorti du grid pour s'étaler sur toute la
            largeur du modal (priorité iOS où la col PIÈCE seule est trop étroite) */}
        {search && filteredPieces.length > 0 && (
          <div className="mt-1 mb-4 border rounded-lg overflow-hidden" style={{ maxHeight: '240px', overflowY: 'auto', backgroundColor: '#fff', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }}>
            {filteredPieces.map(p => (
              <button
                key={p.pieceId || p._row}
                type="button"
                onClick={() => addItem(p)}
                disabled={items.some(it => it.pieceId === p.pieceId)}
                className="w-full text-left px-3 py-2 text-sm hover:bg-yellow-50 flex justify-between disabled:opacity-40"
                style={{ borderBottom: '1px solid rgba(0,0,0,0.06)' }}
              >
                <span className="flex-1 truncate">{p.nom}</span>
                <span className="text-gray-400 font-mono text-xs ml-2">{p.sku || '—'}</span>
                <span className="text-gray-500 text-xs ml-2">{frPrix(priceFor(p, cost))}</span>
              </button>
            ))}
          </div>
        )}

        {items.length > 0 && (
          <div className="mb-4" style={{ borderRadius: '12px', overflowX: 'auto' }}>
            <div style={{ minWidth: '640px' }}>
            <div className="flex items-center" style={{ padding: '6px 16px', backgroundColor: 'rgba(0,0,0,0.06)', color: 'rgba(0,0,0,0.5)', fontSize: '13px', fontWeight: 700, fontStyle: 'italic' }}>
              <div style={{ width: '32px' }}></div>
              <div className="flex-1">item</div>
              <div style={{ width: '90px' }}>sku</div>
              <div style={{ width: '50px', textAlign: 'center' }}>stock</div>
              <div style={{ width: '70px', textAlign: 'center' }}>cmd</div>
              <div style={{ width: '70px', textAlign: 'center' }}>qté</div>
              <div style={{ width: '90px', textAlign: 'right' }}>prix unit.</div>
              <div style={{ width: '80px', textAlign: 'right' }}>s/total</div>
            </div>
            {items.map((it, i) => {
              const piece = pieces.find(p => p.pieceId === it.pieceId);
              const skuUrl = piece?.skuUrl;
              return (
              <div key={i} className="flex items-center" style={{ padding: '8px 16px', borderBottom: '1px solid rgba(0,0,0,0.06)', backgroundColor: i % 2 === 0 ? 'rgba(0,0,0,0.02)' : 'transparent' }}>
                <button type="button" onClick={() => removeItem(i)}
                  className="flex items-center justify-center shrink-0 transition-opacity hover:opacity-70"
                  style={{ width: '32px', color: 'rgba(0,0,0,0.5)' }}>
                  <TrashIcon style={{ width: '18px', height: '18px' }} />
                </button>
                <div className="flex-1" style={{ fontSize: '13px', fontWeight: 600, color: 'rgba(0,0,0,0.7)' }}>{it.nom}</div>
                <div style={{ width: '90px', fontFamily: 'monospace', fontSize: '12px' }}>
                  {skuUrl ? (
                    <a href={skuUrl} target="_blank" rel="noopener noreferrer"
                      className="text-blue-600 hover:underline" title={skuUrl}>
                      {it.sku || '—'}
                    </a>
                  ) : (
                    <span style={{ color: 'rgba(0,0,0,0.4)' }}>{it.sku || '—'}</span>
                  )}
                </div>
                <div style={{
                  width: '50px', textAlign: 'center',
                  fontSize: '13px', fontWeight: 700,
                  color: (piece?.stock ?? 0) > 0 ? '#166534' : 'rgba(0,0,0,0.35)',
                }}>
                  {piece?.stock ?? '—'}
                </div>
                <div style={{ width: '70px', textAlign: 'center' }} className="flex items-center justify-center">
                  {(() => {
                    const stockVal = piece?.stock ?? 0;
                    const needCmd  = !!piece && it.qte >= stockVal;
                    if (!needCmd) return null;
                    const curCmd = piece.qteACommander ?? 0;
                    return (
                      <input
                        type="number"
                        min={0}
                        defaultValue={curCmd}
                        key={`${piece.pieceId}-${curCmd}`}
                        onBlur={e => {
                          const next = Math.max(0, parseInt(e.target.value) || 0);
                          if (next === curCmd) return;
                          // Persiste dans PIÈCES col V (qteACommander) + flag '$'
                          // si on commande au moins 1 unité.
                          patchPiece(piece._row, {
                            qteACommander: next,
                            ...(next > 0 && piece.flag !== '$' ? { flag: '$' } : {}),
                          }).catch(err => toast(err.message, 'error'));
                        }}
                        className="qte-input text-center"
                        style={{
                          width: '56px',
                          backgroundColor: '#fff056',
                          border: '1px solid rgba(0,0,0,0.25)',
                          borderRadius: '6px',
                          padding: '3px 4px',
                          fontSize: '13px',
                          fontWeight: 700,
                          color: 'rgba(0,0,0,0.7)',
                        }}
                        title="Qté à commander du fournisseur (col V PIÈCES). Flag → $ (en commande)."
                      />
                    );
                  })()}
                </div>
                <div style={{ width: '70px', textAlign: 'center' }} className="flex items-center justify-center">
                  {(() => {
                    const stockVal = piece?.stock ?? 0;
                    const deficit  = stockVal > 0 ? Math.max(0, it.qte - stockVal) : 0;
                    const warn     = piece && it.qte > stockVal;
                    return (
                      <input
                        type="text"
                        inputMode="decimal"
                        value={it.qte}
                        onChange={e => {
                          // v1.0.23+ : accepte virgule décimale (1,5h mécanicien
                          // volant, etc.) + sanitisation [0-9.,]
                          const v = e.target.value.replace(/[^\d.,]/g, '');
                          const n = parseFloat(v.replace(',', '.'));
                          if (Number.isFinite(n)) updateItem(i, { qte: n });
                          else if (v === '') updateItem(i, { qte: 1 });
                        }}
                        className="qte-input text-center"
                        style={{
                          width: '56px',
                          backgroundColor: 'rgba(255,255,255,0.9)',
                          border: warn ? '1px solid #dc2626' : '1px solid rgba(0,0,0,0.25)',
                          borderRadius: '6px',
                          padding: '3px 4px',
                          fontSize: '13px',
                          color: warn ? '#dc2626' : undefined,
                        }}
                        title={warn
                          ? `Dépasse le stock (${stockVal}) — ${deficit} à commander ajouté`
                          : 'Quantité à vendre (décimal accepté : 1,5)'}
                      />
                    );
                  })()}
                </div>
                <div style={{ width: '90px', textAlign: 'right' }} className="flex items-center justify-end gap-1">
                  <PrixInput value={it.prixUnit} onChange={v => updateItem(i, { prixUnit: v })} />
                  {/* v1.1.5+ (cluster 4 item o) — Bouton "🆓" : met prixUnit à 0
                      en un clic. Use case : forfait FLAT (30 $ TTC fixe) +
                      chambre à air ajoutée pour gestion stock mais sans coût.
                      Le stock se décrémente normalement (qte > 0). Pour revenir
                      au prix catalogue, taper la valeur dans le champ prix. */}
                  <button
                    type="button"
                    onClick={() => updateItem(i, { prixUnit: 0 })}
                    title={it.prixUnit === 0
                      ? "Item inclus (prix 0 $) — stock toujours décrémenté"
                      : "Mettre le prix à 0 (inclus dans un forfait)"}
                    className="shrink-0 transition-opacity hover:opacity-70"
                    style={{
                      width: '24px', height: '24px', fontSize: '14px',
                      background: 'transparent', border: 'none', cursor: 'pointer',
                      opacity: it.prixUnit === 0 ? 1 : 0.4,
                    }}
                  >
                    🆓
                  </button>
                </div>
                <div style={{ width: '80px', textAlign: 'right', fontWeight: 700, color: 'rgba(0,0,0,0.7)' }}>
                  {it.prixUnit === 0
                    ? <span style={{ color: 'rgba(0,0,0,0.4)', fontStyle: 'italic', fontWeight: 400 }}>inclus</span>
                    : frPrix(it.qte * it.prixUnit)}
                </div>
              </div>
              );
            })}
            <div className="flex items-center" style={{ padding: '8px 16px', backgroundColor: 'rgba(0,0,0,0.06)', color: 'rgba(0,0,0,0.7)', fontSize: '14px', fontWeight: 700 }}>
              <div className="flex-1 text-right">Total</div>
              <div style={{ width: '80px', textAlign: 'right', marginLeft: '16px' }}>{frPrix(total)}</div>
            </div>
            <div className="flex items-center" style={{ padding: '6px 16px' }}>
              <div style={{ width: '32px' }}></div>
              <div className="flex-1"></div>
              <div style={{ width: '90px' }}></div>
              <div style={{ width: '70px' }}></div>
              <label
                className="text-xs font-bold cursor-pointer"
                style={{ width: '90px', textAlign: 'right', color: 'rgba(0,0,0,0.7)' }}
                htmlFor="vente-cost-toggle"
                title="Utiliser le prix COST (col Q) pour les nouveaux items et recalculer les items existants"
              >
                Cost
              </label>
              <div style={{ width: '80px', marginLeft: '16px', display: 'flex', justifyContent: 'flex-end' }}>
                <input
                  id="vente-cost-toggle"
                  type="checkbox"
                  checked={cost}
                  onChange={toggleCost}
                  className="custom-checkbox"
                />
              </div>
            </div>
            </div>
          </div>
        )}

        <div className="flex items-center flex-wrap gap-3" style={{ paddingTop: '20px' }}>
          <button type="button" onClick={() => handleCreate(false)}
            disabled={!items.length || !date || creating}
            className="btn-secondary sm:ml-auto">
            {creating ? 'Enregistrement…' : `Enregistrer (${items.length} item${items.length > 1 ? 's' : ''})`}
          </button>
          <button type="button" onClick={() => handleCreate(true)}
            disabled={!items.length || !date || creating}
            className="btn-primary"
            title={!client ? 'Facturer en Walk-in (pas de client choisi)' : 'Enregistrer + générer facture PDF + draft Gmail'}
          >
            {creating ? '…' : (client ? 'Facturer' : 'Facturer (Walk-in)')}
          </button>
        </div>
      </Modal>

      <ImportModal
        open={showImport}
        onClose={() => setShowImport(false)}
        pieces={pieces}
        onImport={handleImportItems}
      />

      {/* Modal : code scanné inconnu — associer à une pièce existante */}
      <Modal
        open={!!unknownScanCode}
        onClose={() => { setUnknownScanCode(''); setMapSearch(''); }}
        title="Code-barre inconnu — associer à une pièce"
        size="md"
      >
        {unknownScanCode && (
          <div className="flex flex-col" style={{ gap: '14px' }}>
            <div style={{
              backgroundColor: 'rgba(245,158,11,0.12)',
              borderRadius: '12px',
              padding: '10px 14px',
              fontSize: '13px',
              color: '#7c2d12',
            }}>
              <div style={{ fontWeight: 700 }}>Code scanné :</div>
              <div style={{ marginTop: '4px', fontFamily: 'monospace', fontSize: '16px' }}>{unknownScanCode}</div>
            </div>
            <input
              type="search"
              autoFocus
              placeholder="Rechercher une pièce par nom ou SKU…"
              value={mapSearch}
              onChange={e => setMapSearch(e.target.value)}
              className="input-system"
            />
            <div className="overflow-y-auto" style={{
              maxHeight: '320px',
              border: '1.5px solid rgba(0,0,0,0.15)',
              borderRadius: '12px',
            }}>
              {(() => {
                const q = mapSearch.trim().toLowerCase();
                const list = pieces
                  .filter(p => {
                    if (!p.nom) return false;
                    if (!q) return true;
                    return (
                      p.nom.toLowerCase().includes(q) ||
                      (p.sku || '').toLowerCase().includes(q)
                    );
                  })
                  .slice(0, 100);
                if (!list.length) {
                  return <p className="text-center text-sm py-6" style={{ color: 'rgba(0,0,0,0.4)' }}>Aucune pièce trouvée.</p>;
                }
                return list.map(p => (
                  <button
                    key={p.pieceId || p._row}
                    type="button"
                    onClick={async () => {
                      const code = unknownScanCode;
                      // Associer le code-barre à cette pièce existante
                      try {
                        await patchPiece(p._row, { codeBarre: code });
                        addItem(p);
                        updateLastScanAction(code, {
                          action   : 'mapped-existing',
                          pieceId  : p.pieceId,
                          pieceName: p.nom,
                        });
                        setScanMessage(`✓ ${p.nom} — code-barre enregistré`);
                      } catch (err: any) {
                        updateLastScanAction(code, { note: `Erreur map : ${err?.message ?? ''}` });
                        toast(err.message || 'Erreur', 'error');
                      } finally {
                        setUnknownScanCode('');
                        setMapSearch('');
                      }
                    }}
                    className="w-full text-left transition-colors hover:bg-yellow-50"
                    style={{
                      padding: '10px 14px',
                      borderBottom: '1px solid rgba(0,0,0,0.06)',
                      background: 'transparent',
                      border: 'none',
                      cursor: 'pointer',
                      fontSize: '13px',
                      color: 'rgba(0,0,0,0.75)',
                    }}
                  >
                    <div style={{ fontWeight: 700 }}>{p.nom}</div>
                    <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.45)', marginTop: '2px' }}>
                      {p.categorie || '—'} · SKU : {p.sku || '—'} · {frPrix(priceFor(p, false))}
                    </div>
                  </button>
                ));
              })()}
            </div>
            <div className="flex items-center justify-end" style={{ paddingTop: '4px' }}>
              <button
                type="button"
                onClick={() => {
                  // Ouvre PieceForm pré-rempli avec le code scanné
                  setCreateFromScanCode(unknownScanCode);
                  setUnknownScanCode('');
                  setMapSearch('');
                }}
                className="btn-primary"
              >
                Créer Pièce
              </button>
            </div>
          </div>
        )}
      </Modal>

      <BarcodeScanner
        open={showScanner}
        onClose={() => { setShowScanner(false); setScanMessage(''); }}
        onScan={handleScan}
        lastMessage={scanMessage}
      />

      {/* Modal : ajouter des items à une vente existante */}
      <Modal
        open={appendTargetId !== null}
        onClose={() => { if (!appending) closeAppend(); }}
        title={`Ajouter à la vente ${appendTargetVente?.date ?? ''}`}
        size="lg"
      >
        <div className="flex flex-col" style={{ gap: '14px' }}>
          <div style={{ position: 'relative' }}>
            <label className="label-system">rechercher une pièce</label>
            <input
              type="search"
              placeholder="Rechercher par nom ou SKU…"
              value={appendSearch}
              onChange={e => setAppendSearch(e.target.value)}
              disabled={appending}
              className="input-system w-full"
            />
            {appendSearch && appendFiltered.length > 0 && (
              <div className="mt-1 border rounded-lg overflow-hidden" style={{ maxHeight: '220px', overflowY: 'auto', backgroundColor: '#fff', position: 'absolute', zIndex: 20, width: '100%', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }}>
                {appendFiltered.map(p => (
                  <button
                    key={p.pieceId}
                    type="button"
                    onClick={() => addAppendItem(p)}
                    disabled={appendItems.some(it => it.pieceId === p.pieceId)}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-yellow-50 flex justify-between disabled:opacity-40"
                    style={{ borderBottom: '1px solid rgba(0,0,0,0.06)' }}
                  >
                    {/* v1.1.5+ (cluster 4 n) : préfixe icône pour distinguer service vs pièce */}
                    <span className="flex-1 truncate">
                      <span className="mr-1">{p.kind === 'service' ? '🧰' : '⚙️'}</span>
                      {p.nom}
                    </span>
                    <span className="text-gray-400 font-mono text-xs ml-2">{p.sku}</span>
                    <span className="text-gray-500 text-xs ml-2">{frPrix(p.prix)}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {appendItems.length > 0 && (
            <div style={{ borderRadius: '12px', overflow: 'hidden' }}>
              <div className="flex items-center list-header" style={{ padding: '6px 16px', fontSize: '11px' }}>
                <div style={{ width: '32px' }}></div>
                <div className="flex-1">item</div>
                <div style={{ width: '80px', textAlign: 'right' }}>prix</div>
                <div style={{ width: '60px', textAlign: 'center' }}>qté</div>
                <div style={{ width: '80px', textAlign: 'right' }}>s/total</div>
              </div>
              {appendItems.map((it, i) => (
                <div key={i} className="flex items-center" style={{ padding: '8px 16px', borderBottom: '1px solid rgba(0,0,0,0.06)', backgroundColor: i % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)' }}>
                  <button type="button" onClick={() => removeAppendItem(i)}
                          className="flex items-center justify-center shrink-0 transition-opacity hover:opacity-70"
                          style={{ width: '32px', color: 'rgba(0,0,0,0.5)', background: 'transparent', border: 'none', cursor: 'pointer' }}>
                    <TrashIcon style={{ width: '16px', height: '16px' }} />
                  </button>
                  <div className="flex-1 whitespace-nowrap overflow-hidden text-ellipsis" style={{ fontSize: '13px', fontWeight: 700, color: 'rgba(0,0,0,0.7)' }} title={it.nom}>{it.nom}</div>
                  <div style={{ width: '80px', textAlign: 'right' }} className="flex items-center justify-end gap-1">
                    <PrixInput value={it.prixUnit} onChange={v => updateAppendItem(i, { prixUnit: v })} />
                    {/* v1.1.5+ (cluster 4 item o) — Toggle "🆓 inclus" : prix 0 $
                        en 1 clic (item gardé pour gestion stock seulement). */}
                    <button
                      type="button"
                      onClick={() => updateAppendItem(i, { prixUnit: 0 })}
                      title={it.prixUnit === 0
                        ? "Item inclus (prix 0 $) — stock toujours décrémenté"
                        : "Mettre le prix à 0 (inclus dans un forfait)"}
                      className="shrink-0 transition-opacity hover:opacity-70"
                      style={{
                        width: '20px', height: '20px', fontSize: '12px',
                        background: 'transparent', border: 'none', cursor: 'pointer',
                        opacity: it.prixUnit === 0 ? 1 : 0.4,
                      }}
                    >
                      🆓
                    </button>
                  </div>
                  <div style={{ width: '60px', textAlign: 'center' }}>
                    {/* v1.0.23+ : qté décimale acceptée (virgule + parser parseFloat) */}
                    <input
                      type="text"
                      inputMode="decimal"
                      value={it.qte}
                      onChange={e => {
                        const v = e.target.value.replace(/[^\d.,]/g, '');
                        const n = parseFloat(v.replace(',', '.'));
                        if (Number.isFinite(n)) updateAppendItem(i, { qte: n });
                        else if (v === '') updateAppendItem(i, { qte: 1 });
                      }}
                      title="Quantité (décimal accepté : 1,5)"
                      style={{ width: '50px', textAlign: 'center', backgroundColor: 'rgba(255,255,255,0.9)', border: '1px solid rgba(0,0,0,0.15)', borderRadius: '6px', padding: '3px 4px', fontSize: '13px' }}
                    />
                  </div>
                  <div style={{ width: '80px', textAlign: 'right', fontWeight: 700, color: 'rgba(0,0,0,0.7)' }}>
                    {it.prixUnit === 0
                      ? <span style={{ color: 'rgba(0,0,0,0.4)', fontStyle: 'italic', fontWeight: 400 }}>inclus</span>
                      : frPrix(it.qte * it.prixUnit)}
                  </div>
                </div>
              ))}
              <div className="flex items-center" style={{ padding: '8px 16px', backgroundColor: 'rgba(255,240,86,0.25)', fontSize: '14px', fontWeight: 700 }}>
                <div className="flex-1 text-right" style={{ color: 'rgba(0,0,0,0.6)' }}>À ajouter</div>
                <div style={{ width: '80px', textAlign: 'right', color: 'rgba(0,0,0,0.8)', marginLeft: '60px' }}>{frPrix(appendTotal)}</div>
              </div>
            </div>
          )}

          <div className="flex items-center gap-3" style={{ paddingTop: '8px' }}>
            <button type="button" onClick={submitAppend} disabled={!appendItems.length || appending} className="btn-primary ml-auto">
              {appending ? 'Ajout…' : `Ajouter (${appendItems.length})`}
            </button>
          </div>
        </div>
      </Modal>

      <FacturerVenteModal
        open={factureTargetId !== null}
        onClose={() => { if (!facturingId) setFactureTargetId(null); }}
        vente={ventes.find(v => v.venteId === factureTargetId) ?? null}
        clientLang={(() => {
          const tv = ventes.find(v => v.venteId === factureTargetId);
          const l  = tv ? clientByName.get(tv.client)?.lang : undefined;
          return (l === 'FR' || l === 'EN') ? l : undefined;
        })()}
        submitting={facturingId !== null && facturingId === factureTargetId}
        onSubmit={submitFacture}
      />

      {/* v1.0.25+ : Modal statut/mode paiement post-facturation pour une
          vente facturée. Réutilise FactureStatusPanel (utilisé aussi sur la
          fiche BDT facturé). Lecture/écriture via GET/PATCH
          /api/factures/log-status avec docType='vente'. */}
      <Modal
        open={!!factureStatutRef}
        onClose={() => setFactureStatutRef(null)}
        title={factureStatutRef ? `Statut facture ${factureStatutRef}` : 'Statut facture'}
        size="md"
      >
        {factureStatutRef && (
          <FactureStatusPanel factureRef={factureStatutRef} docType="vente" />
        )}
      </Modal>

      {/* v1.0.21+ : ClientForm modal — création de client à la volée depuis
          la fenêtre Nouvelle vente. onCreated reçoit le nomComplet du
          nouveau client → on l'auto-sélectionne dans le select. */}
      <ClientForm
        open={showClientForm}
        onClose={() => setShowClientForm(false)}
        onCreated={(nomComplet) => {
          setShowClientForm(false);
          setClient(nomComplet);
          const l = clientByName.get(nomComplet)?.lang;
          if (l === 'FR' || l === 'EN') setLang(l);
        }}
      />

      <ConfirmDialog
        open={!!deleteTarget}
        title={(() => {
          const t = ventes.find(v => v.venteId === deleteTarget);
          return t?.factureDate ? 'Archiver la vente' : 'Supprimer le brouillon';
        })()}
        message={(() => {
          const t = ventes.find(v => v.venteId === deleteTarget);
          return t?.factureDate
            ? 'La vente sera déplacée vers _VENTES_ARCHIVES_.\n\nElle restera consultable depuis la page Archives 2026 et pourra être désarchivée si besoin.\n\nLe stock n\'est pas modifié (vente déjà facturée).'
            : 'Le brouillon sera supprimé définitivement.\n\nLe stock engagé sera restauré (AB remonte, AC redescend).';
        })()}
        danger
        confirmLabel={(() => {
          const t = ventes.find(v => v.venteId === deleteTarget);
          if (deleting) return t?.factureDate ? 'Archivage…' : 'Suppression…';
          return t?.factureDate ? 'Archiver' : 'Supprimer';
        })()}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      {/* ── PieceForm : création d'une pièce pré-remplie depuis un scan ── */}
      <PieceForm
        open={!!createFromScanCode}
        onClose={() => {
          if (createFromScanCode) {
            updateLastScanAction(createFromScanCode, { action: 'unknown-cancelled' });
          }
          setCreateFromScanCode('');
        }}
        categories={pfCategories}
        fournisseurs={pfFournisseurs}
        initialCodeBarre={createFromScanCode}
        onCreated={(info) => {
          updateLastScanAction(createFromScanCode, {
            action   : 'created-new',
            pieceName: info?.nom,
            note     : 'Nouvelle pièce créée depuis scan',
          });
          setCreateFromScanCode('');
          setScanMessage('✓ Pièce créée au catalogue');
        }}
      />

      {/* ── Modal historique des scans (log local) ── */}
      <ScanLogModal open={scanLogOpen} onClose={() => setScanLogOpen(false)} />

      {/* ── Pill commune sync + filtres (flottant fixe bas-droite mobile) ── */}
      <div
        ref={filtersRefMobile}
        className="md:hidden"
        style={{
          position: 'fixed',
          bottom: '20px',
          right: '20px',
          zIndex: 9999,
        }}
      >
        <div
          className="flex items-center"
          style={{
            height: '56px',
            backgroundColor: 'rgba(255,255,255,0.5)',
            borderRadius: '50px',
            padding: '0 10px',
            gap: '10px',
            boxShadow: '0 6px 16px rgba(0,0,0,0.30)',
            backdropFilter: 'blur(8px)',
            WebkitBackdropFilter: 'blur(8px)',
          }}
        >
          {/* Sync */}
          <button
            type="button"
            onClick={handleSync}
            disabled={syncing}
            title="Rafraîchir les données"
            className="flex items-center justify-center shrink-0"
            style={{
              width: '40px', height: '40px', borderRadius: '50%',
              backgroundColor: 'transparent',
              color: 'rgba(0,0,0,0.5)',
              border: 'none',
              cursor: syncing ? 'wait' : 'pointer',
              padding: 0,
            }}
          >
            <ArrowPathIcon
              className={syncing ? 'animate-spin' : ''}
              style={{ width: '22px', height: '22px', strokeWidth: 2.5 }}
            />
          </button>
          {/* Filtres */}
          <button
            type="button"
            onClick={() => setFiltersOpen(o => !o)}
            title="Filtres"
            className="flex items-center justify-center shrink-0"
            style={{
              width: '40px', height: '40px', borderRadius: '50%',
              backgroundColor: 'transparent',
              color: 'rgba(0,0,0,0.5)',
              border: 'none',
              cursor: 'pointer',
              padding: 0,
            }}
          >
            <FunnelIcon style={{ width: '22px', height: '22px', strokeWidth: 2 }} />
          </button>
        </div>
        {/* Dropdown filtres — s'ouvre AU-DESSUS de la pill */}
        {filtersOpen && (
          <div
            className="absolute right-0"
            style={{
              bottom: 'calc(100% + 8px)',
              minWidth: '300px',
              backgroundColor: '#fff',
              borderRadius: '20px',
              boxShadow: '0 6px 24px rgba(0,0,0,0.25)',
              zIndex: 50,
            }}
          >
            <div className="flex flex-col" style={{ gap: '10px', padding: '12px 16px' }}>
              <input
                type="search"
                value={venteSearch}
                onChange={e => setVenteSearch(e.target.value)}
                placeholder="Client, n° facture, SKU…"
                className="focus:outline-none focus:ring-2 focus:ring-yellow-400"
                style={{
                  height: '32px', borderRadius: '32px',
                  backgroundColor: 'rgba(0,0,0,0.06)',
                  color: 'rgba(0,0,0,0.7)', border: 'none',
                  fontSize: '13px', padding: '0 14px',
                }}
              />
              <div className="flex items-center" style={{ gap: '6px' }}>
                {(['all', 'pending', 'done'] as const).map(s => {
                  const labels: Record<string, string> = { all: 'Toutes', pending: 'À facturer', done: 'Facturées' };
                  const active = venteStatut === s;
                  return (
                    <button key={s} type="button" onClick={() => setVenteStatut(s)}
                      className="flex items-center whitespace-nowrap"
                      style={{
                        padding: '0 12px', height: '28px', borderRadius: '28px',
                        fontSize: '12px', fontWeight: 700, border: 'none', cursor: 'pointer',
                        backgroundColor: active ? '#fff056' : 'rgba(0,0,0,0.06)',
                        color: active ? '#000' : 'rgba(0,0,0,0.5)',
                      }}
                    >
                      {labels[s]}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
