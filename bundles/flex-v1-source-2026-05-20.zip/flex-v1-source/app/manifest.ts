import type { MetadataRoute } from 'next';

/**
 * PWA manifest pour iOS "Add to Home Screen" + Android Add to Home.
 *
 * Quand l'utilisateur installe l'app via Safari → Partager → Sur l'écran
 * d'accueil, il aura :
 *  - icône du logo FLEX rond (depuis /app/apple-icon.svg)
 *  - lancement en mode standalone (sans barre Safari)
 *  - splash screen jaune signature
 */
export default function manifest(): MetadataRoute.Manifest {
  return {
    name           : 'FLEX-REV — Yako Cyclo',
    short_name     : 'FLEX-REV',
    description    : 'Gestion d\'atelier vélo — Yako Cyclo, Montréal',
    start_url      : '/menu',
    display        : 'standalone',
    background_color: '#929292',
    theme_color    : '#fff056',
    orientation    : 'portrait',
    icons: [
      {
        src   : '/favicon-fv.svg',
        sizes : '192x192',
        type  : 'image/svg+xml',
      },
      {
        src   : '/favicon-fv.svg',
        sizes : '512x512',
        type  : 'image/svg+xml',
      },
    ],
  };
}
