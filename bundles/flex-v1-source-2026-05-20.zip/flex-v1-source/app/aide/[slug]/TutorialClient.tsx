'use client';
import { useState } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock } from '@/components/layout/PageHeader';
import PillToggle from '@/components/ui/PillToggle';
import {
  ChevronUpIcon,
  ChevronDownIcon,
  ChevronRightIcon,
  ChevronLeftIcon,
} from '@heroicons/react/24/outline';

interface Props {
  slug: string;
  title: string;
  slides: string[];
}

/** Bouton rond 32px style toolbar — actif = jaune plein, inactif = outline. */
function ModeButton({ active, onClick, title, children }: {
  active: boolean;
  onClick: () => void;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      aria-label={title}
      className="flex items-center justify-center shrink-0"
      style={{
        width: '32px',
        height: '32px',
        borderRadius: '50%',
        backgroundColor: active ? '#fff056' : 'transparent',
        color: active ? '#000' : '#fff056',
        border: active ? 'none' : '2px solid #fff056',
        cursor: 'pointer',
        padding: 0,
        transition: 'background-color 0.15s, color 0.15s',
      }}
    >
      {children}
    </button>
  );
}


/**
 * Affiche un tutoriel — soit en mode "scroll" (toutes les slides empilées),
 * soit en mode "diapo" (une slide à la fois avec prev/next).
 */
export default function TutorialClient({ slug, title, slides }: Props) {
  const [mode, setMode] = useState<'scroll' | 'diapo'>('scroll');
  const [idx, setIdx] = useState(0);

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader
          subtitle={`tutoriel ${slug.split('-')[0]}`}
          title={title}
        >
          <ToolbarBlock>
            {/* Toggle scroll/diapo — composant standard du design system */}
            <PillToggle
              value={mode}
              onChange={setMode}
              options={[
                {
                  value: 'scroll',
                  icon: <ChevronDownIcon style={{ width: 14, height: 14, strokeWidth: 2.5 }} />,
                  ariaLabel: 'Mode liste (scroll)',
                },
                {
                  value: 'diapo',
                  icon: <ChevronRightIcon style={{ width: 14, height: 14, strokeWidth: 2.5 }} />,
                  ariaLabel: 'Mode diapo (une slide à la fois)',
                },
              ]}
            />
            {/* Retour vers /aide — flèche haut, bouton séparé */}
            <ModeButton
              active={false}
              onClick={() => { window.location.href = '/aide'; }}
              title="Retour à la liste des tutoriels"
            >
              <ChevronUpIcon style={{ width: 18, height: 18, strokeWidth: 2.5 }} />
            </ModeButton>
          </ToolbarBlock>
        </PageHeader>

        <div className="md:bg-black/20 md:rounded-[50px] md:p-5">
          {mode === 'scroll' ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {slides.map((html, i) => (
                <div
                  key={i}
                  style={{
                    backgroundColor: 'rgba(255,255,255,0.92)',
                    borderRadius: '24px',
                    padding: '28px 32px',
                    color: 'rgba(0,0,0,0.85)',
                    fontSize: '14px',
                  }}
                >
                  <div
                    style={{
                      fontSize: '11px',
                      fontWeight: 700,
                      color: 'rgba(0,0,0,0.4)',
                      marginBottom: '12px',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                    }}
                  >
                    Slide {i + 1} / {slides.length}
                  </div>
                  <div dangerouslySetInnerHTML={{ __html: html }} />
                </div>
              ))}
            </div>
          ) : (
            <div>
              <div
                style={{
                  backgroundColor: 'rgba(255,255,255,0.92)',
                  borderRadius: '24px',
                  padding: '32px 36px',
                  color: 'rgba(0,0,0,0.85)',
                  fontSize: '15px',
                  minHeight: '420px',
                }}
              >
                <div
                  style={{
                    fontSize: '11px',
                    fontWeight: 700,
                    color: 'rgba(0,0,0,0.4)',
                    marginBottom: '14px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                  }}
                >
                  Slide {idx + 1} / {slides.length}
                </div>
                <div dangerouslySetInnerHTML={{ __html: slides[idx] }} />
              </div>

              {/* Nav prev/next */}
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginTop: '16px',
                  padding: '0 4px',
                }}
              >
                <button
                  onClick={() => setIdx(Math.max(0, idx - 1))}
                  disabled={idx === 0}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    padding: '10px 18px',
                    borderRadius: '20px',
                    backgroundColor: idx === 0 ? 'rgba(255,255,255,0.3)' : 'rgba(255,255,255,0.85)',
                    color: idx === 0 ? 'rgba(0,0,0,0.3)' : 'rgba(0,0,0,0.85)',
                    border: 'none',
                    cursor: idx === 0 ? 'default' : 'pointer',
                    fontSize: '14px',
                    fontWeight: 600,
                  }}
                >
                  <ChevronLeftIcon style={{ width: 18, height: 18 }} /> Précédent
                </button>

                <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', justifyContent: 'center', maxWidth: '60%' }}>
                  {slides.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setIdx(i)}
                      style={{
                        width: '10px',
                        height: '10px',
                        borderRadius: '50%',
                        backgroundColor: i === idx ? '#fff056' : 'rgba(255,255,255,0.4)',
                        border: 'none',
                        cursor: 'pointer',
                        padding: 0,
                      }}
                      aria-label={`Slide ${i + 1}`}
                    />
                  ))}
                </div>

                <button
                  onClick={() => setIdx(Math.min(slides.length - 1, idx + 1))}
                  disabled={idx === slides.length - 1}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    padding: '10px 18px',
                    borderRadius: '20px',
                    backgroundColor: idx === slides.length - 1 ? 'rgba(255,255,255,0.3)' : 'rgba(255,255,255,0.85)',
                    color: idx === slides.length - 1 ? 'rgba(0,0,0,0.3)' : 'rgba(0,0,0,0.85)',
                    border: 'none',
                    cursor: idx === slides.length - 1 ? 'default' : 'pointer',
                    fontSize: '14px',
                    fontWeight: 600,
                  }}
                >
                  Suivant <ChevronRightIcon style={{ width: 18, height: 18 }} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
