import fs from 'node:fs/promises';
import path from 'node:path';
import { notFound } from 'next/navigation';
import { renderTutorialMarkdown } from '@/lib/markdown';
import TutorialClient from './TutorialClient';

/**
 * Page Aide — détail d'un tutoriel.
 * Lit `docs/tutoriels/<slug>.md` et passe les slides rendues
 * en HTML au composant client pour navigation.
 */
const ALLOWED_SLUGS = [
  '01-recevoir-velo',
  '02-evaluer-velo',
  '03-reparer-velo',
  '04-dashboard',
  '05-workflow-bdt',
  '06-statut-bdt',
  '07-services-pieces',
  '08-inventaire-mobile',
  '09-vente-rapide',
  '10-scanner-codebarre',
  '11-facturation',
];

export const dynamic = 'force-static';

export async function generateStaticParams() {
  return ALLOWED_SLUGS.map(slug => ({ slug }));
}

export default async function TutorialPage({ params }: { params: { slug: string } }) {
  const { slug } = params;
  if (!ALLOWED_SLUGS.includes(slug)) notFound();

  const filepath = path.join(process.cwd(), 'docs', 'tutoriels', `${slug}.md`);
  let raw: string;
  try {
    raw = await fs.readFile(filepath, 'utf8');
  } catch {
    notFound();
  }

  const { slides } = renderTutorialMarkdown(raw!);

  // Extraire le titre du tutoriel (1ère ligne `# Tutoriel N — xxx`)
  const titleMatch = /^#\s+(.*)$/m.exec(raw!);
  const fullTitle = titleMatch ? titleMatch[1] : slug;

  return <TutorialClient slug={slug} title={fullTitle} slides={slides} />;
}
