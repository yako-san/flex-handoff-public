'use client';
import Link from 'next/link';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';
import {
  ChartBarIcon,
  PaintBrushIcon,
  ArrowPathIcon,
  ArrowDownTrayIcon,
  PaperAirplaneIcon,
  WrenchScrewdriverIcon,
  DevicePhoneMobileIcon,
  QrCodeIcon,
  Squares2X2Icon,
  BanknotesIcon,
  ClipboardDocumentListIcon,
  ArrowsRightLeftIcon,
  CubeIcon,
  ReceiptPercentIcon,
  CodeBracketIcon,
} from '@heroicons/react/24/outline';

/**
 * Page Aide — index des 12 tutoriels regroupés en 3 colonnes thématiques.
 * Chaque tuile pointe vers /aide/<slug> (rend docs/tutoriels/<slug>.md).
 * v1.1.0+ : Section 12 = changelog post-v1.0.0 pour synchronisation V2.
 */
type Tile = {
  slug: string;
  num: string;
  title: string;
  desc: string;
  duree: string;
  device: string;
  icon: typeof ChartBarIcon;
};
type Column = {
  legende: string;
  icon: typeof ClipboardDocumentListIcon;
  tiles: Tile[];
};

const COLUMNS: Column[] = [
  {
    legende: 'Bons de travail',
    icon: ClipboardDocumentListIcon,
    tiles: [
      { slug: '01-recevoir-velo', num: '01', title: 'Recevoir un v\u00e9lo',  desc: 'Cr\u00e9er un client + son v\u00e9lo + ouvrir le BDT',                duree: '4 min', device: 'Desktop',      icon: ArrowDownTrayIcon },
      { slug: '02-evaluer-velo',  num: '02', title: '\u00c9valuer un v\u00e9lo',    desc: 'Composer le devis, g\u00e9n\u00e9rer PDF + brouillon Gmail',           duree: '3 min', device: 'Desktop',      icon: PaperAirplaneIcon },
      { slug: '03-reparer-velo',  num: '03', title: 'R\u00e9parer un v\u00e9lo',     desc: 'Approuv\u00e9 \u2192 Bon de sortie + facture',                       duree: '4 min', device: 'Desktop/iPad', icon: WrenchScrewdriverIcon },
    ],
  },
  {
    legende: 'Flux de travail',
    icon: ArrowsRightLeftIcon,
    tiles: [
      { slug: '04-dashboard',     num: '04', title: 'Dashboard',              desc: 'Vue d\u2019ensemble de la journ\u00e9e : RV, suivis, factures',          duree: '3 min', device: 'Desktop',      icon: ChartBarIcon },
      { slug: '05-workflow-bdt',  num: '05', title: 'Workflow : Bon de Travail', desc: 'Le cycle complet en 4 cases : RDV \u2022 \u00c9val \u2022 Approuv\u00e9 \u2022 Termin\u00e9', duree: '5 min', device: 'Desktop/iPad', icon: ArrowPathIcon },
      { slug: '06-statut-bdt',    num: '06', title: 'Statut : Bon de Travail', desc: 'L\u00e9gende des couleurs : NOUVEAU \u2192 \u00c9val \u2192 Approuv\u00e9 \u2192 Termin\u00e9', duree: '2 min', device: 'Tous',         icon: PaintBrushIcon },
      { slug: '11-facturation',   num: '11', title: 'Facturation & taxes',    desc: 'TPS/TVQ, modes de paiement, journal comptable, FPZ-500',         duree: '5 min', device: 'Desktop',      icon: ReceiptPercentIcon },
      // v1.1.0+ : changelog vivant pour synchroniser V2 (Sprint 4 β+ basé v1.0.19)
      { slug: '12-changements-v2', num: '12', title: 'Changements pour V2',   desc: 'Inventaire des features post-v1.0.0 à porter dans le repo V2',  duree: '8 min', device: 'Desktop',      icon: CodeBracketIcon },
    ],
  },
  {
    legende: 'Services + pi\u00e8ces',
    icon: CubeIcon,
    tiles: [
      { slug: '07-services-pieces',   num: '07', title: 'Services + pi\u00e8ces',     desc: 'Le d\u00e9tail des 2 popups (forfaits, scan, cr\u00e9ation \u00e0 la vol\u00e9e)', duree: '5 min', device: 'Desktop',         icon: Squares2X2Icon },
      { slug: '08-inventaire-mobile', num: '08', title: 'Inventaire mobile',  desc: 'Utiliser FLEX-REV sur iPhone : suivis, scan, recherche',     duree: '3 min', device: 'iPhone',          icon: DevicePhoneMobileIcon },
      { slug: '09-vente-rapide',      num: '09', title: 'Vente rapide POS',   desc: 'Vendre une pi\u00e8ce sans BDT : nouvelle vente \u2192 facturer',     duree: '3 min', device: 'iPhone/Desktop',  icon: BanknotesIcon },
      { slug: '10-scanner-codebarre', num: '10', title: 'Scanner code-barre', desc: 'Cam\u00e9ra iPhone : EAN \u2192 pi\u00e8ce identifi\u00e9e en 2 sec',         duree: '2 min', device: 'iPhone',          icon: QrCodeIcon },
    ],
  },
];

export default function AidePage() {
  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader
          subtitle="tutoriels pour mecanos / collegues"
          title="Aide"
        />

        <div className="md:bg-black/20 md:rounded-[50px] md:p-5">
          {/* 1 col mobile, 3 cols desktop */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6" style={{ padding: '8px' }}>
            {COLUMNS.map((col, ci) => {
              const ColIcon = col.icon;
              return (
                <div key={ci} className="flex flex-col" style={{ gap: '12px' }}>
                  {/* En-tête colonne */}
                  <div
                    className="flex items-center"
                    style={{
                      gap: '10px',
                      padding: '8px 16px',
                      color: '#fff056',
                    }}
                  >
                    <ColIcon style={{ width: '20px', height: '20px' }} />
                    <span style={{ fontSize: '13px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
                      {col.legende}
                    </span>
                  </div>

                  {/* Tuiles de la colonne */}
                  {col.tiles.map(({ slug, num, title, desc, duree, device, icon: Icon }) => (
                    <Link
                      key={slug}
                      href={`/aide/${slug}`}
                      className="flex items-start gap-4 transition-colors hover:bg-yellow-50"
                      style={{
                        padding: '20px 22px',
                        borderRadius: '24px',
                        backgroundColor: 'rgba(255,255,255,0.85)',
                        textDecoration: 'none',
                        color: 'inherit',
                      }}
                    >
                      <div
                        className="flex items-center justify-center shrink-0"
                        style={{
                          width: '52px',
                          height: '52px',
                          borderRadius: '50%',
                          backgroundColor: '#fff056',
                          color: 'rgba(0,0,0,0.65)',
                        }}
                      >
                        <Icon style={{ width: '26px', height: '26px' }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div style={{ fontSize: '30px', fontWeight: 700, color: 'rgba(0,0,0,0.85)', marginBottom: '6px', lineHeight: 1.15 }}>
                          {num}. {title}
                        </div>
                        <div style={{ fontSize: '13px', color: 'rgba(0,0,0,0.55)', lineHeight: 1.4, marginBottom: '6px' }}>
                          {desc}
                        </div>
                        <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.45)', display: 'flex', gap: '10px' }}>
                          <span>⏱ {duree}</span>
                          <span>📱 {device}</span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              );
            })}
          </div>
        </div>

        <div
          style={{
            marginTop: '24px',
            padding: '16px 24px',
            borderRadius: '20px',
            backgroundColor: 'rgba(255,255,255,0.5)',
            fontSize: '12px',
            color: 'rgba(0,0,0,0.55)',
            lineHeight: 1.5,
          }}
        >
          <b>Astuce</b> — partout dans l’app, l’icône <span style={{ display: 'inline-block', width: 16, height: 16, borderRadius: '50%', background: '#fff056', color: 'rgba(0,0,0,0.65)', fontSize: 11, fontWeight: 700, textAlign: 'center', lineHeight: '16px' }}>?</span> ouvre directement le tutoriel correspondant. Les tutoriels peuvent aussi être convertis en PowerPoint (voir <code>docs/tutoriels/README.md</code>).
        </div>
      </div>
    </AppShell>
  );
}
