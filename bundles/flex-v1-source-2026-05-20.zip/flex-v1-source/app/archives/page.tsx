'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock, UtilButton } from '@/components/layout/PageHeader';
import Modal from '@/components/ui/Modal';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import DragTh from '@/components/ui/DragTh';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import PillToggle from '@/components/ui/PillToggle';
import { useArchives } from '@/hooks/useArchives';
import { useArchivedVentes } from '@/hooks/useArchivedVentes';
import { frDate, frPrix } from '@/lib/utils/format';
import { getArchiveStatutDisplay } from '@/lib/utils/statuts';
import { useColOrder } from '@/hooks/useColOrder';
import { ArrowUturnLeftIcon, ArrowPathIcon, ArchiveBoxArrowDownIcon, TrashIcon, LockClosedIcon, XMarkIcon, ClockIcon, NoSymbolIcon } from '@heroicons/react/24/outline';
import BackupsModal from '@/components/archives/BackupsModal';
import { toast } from '@/components/ui/Toast';
import type { BDC } from '@/types/bdc';
import type { Vente } from '@/types/vente';

// Couleur "texte doux" unifiée : noir 50% pour toutes les cellules qui
// \u00e9taient pr\u00e9c\u00e9demment en gray-400/gray-500 (dates, montants partiels).
const TXT_SOFT_STYLE = 'rgba(0,0,0,0.5)';

const COLS = [
  { id: 'delete',   header: '',         hCls: 'px-2 py-2 w-10',       cCls: 'px-2 py-2 text-center' },
  { id: 'restore',  header: 'restaurer',hCls: 'px-2 py-2 w-20 text-center', cCls: 'px-2 py-2 text-center' },
  { id: 'statut',   header: 'statut',   hCls: 'px-3 py-2 text-center',cCls: 'px-3 py-2 text-center' },
  { id: 'id',       header: 'id',       hCls: 'px-4 py-2',            cCls: 'px-4 py-2 font-mono whitespace-nowrap text-center' },
  { id: 'client',   header: 'client',   hCls: 'px-4 py-2',            cCls: 'px-4 py-2 text-gray-700 font-medium' },
  { id: 'velo',     header: 'vélo',     hCls: 'px-4 py-2',            cCls: 'px-4 py-2 text-gray-600' },
  { id: 'noteVelo', header: 'note',     hCls: 'px-4 py-2',            cCls: 'px-4 py-2 text-gray-600' },
  { id: 'dateIn',   header: 'date in',  hCls: 'px-4 py-2',            cCls: 'px-4 py-2 whitespace-nowrap' },
  { id: 'dateOut',  header: 'date out', hCls: 'px-4 py-2',            cCls: 'px-4 py-2 whitespace-nowrap' },
  { id: 'services', header: 'services', hCls: 'px-4 py-2 text-right', cCls: 'px-4 py-2 text-right whitespace-nowrap' },
  { id: 'pieces',   header: 'pièces',   hCls: 'px-4 py-2 text-right', cCls: 'px-4 py-2 text-right whitespace-nowrap' },
  { id: 'total',    header: 'total',    hCls: 'px-4 py-2 text-right', cCls: 'px-4 py-2 text-right font-bold text-gray-900 whitespace-nowrap' },
] as const;

/** Colonnes dont le texte doit \u00eatre rendu en noir 50%. */
const SOFT_TEXT_COLS = new Set(['dateIn', 'dateOut', 'services', 'pieces']);

// v1.1.4 — Item 6 audit : statutColors local consolidé dans
// lib/utils/statuts.ts → getArchiveStatutDisplay (alias ci-dessous pour
// préserver les call-sites du fichier sans refonte massive).
const statutColors = getArchiveStatutDisplay;

type ColId = typeof COLS[number]['id'];

export default function ArchivesPage() {
  const router = useRouter();
  const { bdcs: allBdcs, isLoading, error, desarchiver, deleteArchive, mutate } = useArchives();
  const {
    ventes: archivedVentes,
    isLoading: ventesLoading,
    error: ventesError,
    desarchiver: desarchiverVente,
    deleteArchive: deleteArchivedVente,
  } = useArchivedVentes();
  // Nouvelle clé de col-order ('archives-v3') pour forcer le reset des
  // ordres sauvegardés (les nouvelles colonnes delete/statut viendraient
  // sinon se placer à la fin par défaut).
  const { orderedCols, dragProps, dragOverId } = useColOrder('archives-v4', COLS as any);
  const [restoreTarget, setRestoreTarget] = useState<BDC | null>(null);
  const [deleteTarget,  setDeleteTarget]  = useState<BDC | null>(null);
  const [detailTarget,  setDetailTarget]  = useState<BDC | null>(null);
  const [restoring, setRestoring] = useState(false);
  const [deleting,  setDeleting]  = useState(false);
  const [consolidating, setConsolidating] = useState(false);
  const [showBackups, setShowBackups] = useState(false);
  // Vue : 'archives' (par défaut), 'refuses' ou 'ventes' (ventes directes
  // archivées). Les BDT refusés sont exclus du total revenu puisqu'ils n'ont
  // jamais été facturés.
  const [view, setView] = useState<'archives' | 'refuses' | 'ventes'>('archives');
  // Cibles (restaurer/supprimer) pour les ventes archivées.
  const [venteRestoreTarget, setVenteRestoreTarget] = useState<Vente | null>(null);
  const [venteDeleteTarget,  setVenteDeleteTarget]  = useState<Vente | null>(null);
  const [venteRestoring, setVenteRestoring] = useState(false);
  const [venteDeleting,  setVenteDeleting]  = useState(false);

  const isRefuse = (status: string | undefined) => {
    const s = (status ?? '').trim().toUpperCase();
    return s === 'REFUSÉ' || s === 'REFUSE';
  };
  const archivedBdcs = allBdcs.filter(b => !isRefuse(b.archiveStatus));
  const refusedBdcs  = allBdcs.filter(b =>  isRefuse(b.archiveStatus));
  const bdcs         = view === 'archives' ? archivedBdcs : refusedBdcs;

  // Le total revenu ne prend en compte que les archives facturées
  // (exclut les BDT refusés — ils n'ont pas de facture).
  const totalRevenu = archivedBdcs.reduce((s, b) => s + b.totalServices + b.totalPieces, 0);

  async function handleConsolidate() {
    setConsolidating(true);
    try {
      const res = await fetch('/api/archives', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'consolidate' }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      const ids = data.consolidated as string[];
      if (ids.length === 0) {
        toast('Aucun BDC fantôme trouvé');
      } else {
        toast(`${ids.length} BDC consolidé(s) : ${ids.join(', ')}`);
      }
      await mutate();
    } catch (err: any) { toast(err.message, 'error'); }
    finally { setConsolidating(false); }
  }

  async function handleRestore() {
    if (!restoreTarget) return;
    const target = restoreTarget;
    setRestoring(true);
    try {
      await desarchiver(target.id, target._bonRow);
      toast(`BDT ${target.id} ramené dans l'inventaire`);
      // Retour à la LISTE Inventaire (pas la page détail). Si on push vers
      // /inventaire/[id] juste après desarchiver(), SWR n'a pas encore le
      // vélo dans son cache → la page détail montre « Erreur BDC :
      // Introuvable » pendant ~5 sec avant que le re-fetch ne complète.
      router.push('/inventaire');
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setRestoring(false);
      setRestoreTarget(null);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await deleteArchive(deleteTarget.id, deleteTarget._bonRow);
      toast(`BDC ${deleteTarget.id} supprimé définitivement`);
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setDeleting(false);
      setDeleteTarget(null);
    }
  }

  async function handleVenteRestore() {
    if (!venteRestoreTarget) return;
    setVenteRestoring(true);
    try {
      await desarchiverVente(venteRestoreTarget.venteId);
      toast(`Vente ${venteRestoreTarget.factureNumero ?? venteRestoreTarget.venteId} désarchivée`);
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setVenteRestoring(false);
      setVenteRestoreTarget(null);
    }
  }

  async function handleVenteDelete() {
    if (!venteDeleteTarget) return;
    setVenteDeleting(true);
    try {
      await deleteArchivedVente(venteDeleteTarget.venteId);
      toast(`Vente ${venteDeleteTarget.factureNumero ?? venteDeleteTarget.venteId} supprimée définitivement`);
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setVenteDeleting(false);
      setVenteDeleteTarget(null);
    }
  }

  function renderCell(id: ColId, bdc: BDC) {
    const total = bdc.totalServices + bdc.totalPieces;
    const colors = statutColors(bdc.archiveStatus);
    switch (id) {
      case 'delete':
        return (
          <button
            onClick={() => setDeleteTarget(bdc)}
            title="Supprimer définitivement (snapshot conservé)"
            className="flex items-center justify-center mx-auto hover:opacity-100 transition-opacity"
            style={{ width: '32px', height: '32px', opacity: 0.5, color: 'rgba(0,0,0,0.6)' }}
          >
            <TrashIcon
              style={{ width: '22px', height: '22px', flexShrink: 0 }}
              strokeWidth={1.8}
            />
          </button>
        );
      case 'restore':
        return (
          <button
            onClick={() => setRestoreTarget(bdc)}
            className="flex items-center justify-center transition-opacity mx-auto hover:opacity-100"
            style={{
              width: '32px',
              height: '32px',
              backgroundColor: 'transparent',
              color: 'rgba(0,0,0,0.5)',
              border: 'none',
              padding: 0,
              opacity: 0.75,
            }}
            title="Ramener dans l'inventaire"
          >
            <ArrowUturnLeftIcon
              style={{ width: '22px', height: '22px', flexShrink: 0 }}
              strokeWidth={1.8}
            />
          </button>
        );
      case 'statut':
        return <span className="font-bold" style={{ fontSize: '13px', letterSpacing: '0.05em' }}>{colors.label}</span>;
      case 'id':
        return (
          <button
            type="button"
            onClick={() => setDetailTarget(bdc)}
            className="font-bold hover:underline"
            style={{
              background: 'none',
              border: 'none',
              padding: 0,
              cursor: 'pointer',
              color: 'inherit',
              fontSize: 'var(--h3-size)',
              fontWeight: 'var(--h3-weight)',
            }}
          >
            {bdc.id}
          </button>
        );
      case 'client':   return bdc.clientNom;
      case 'velo':     return bdc.veloDesc;
      case 'noteVelo': return bdc.noteVelo || '—';
      case 'dateIn':   return frDate(bdc.dateIn);
      case 'dateOut':  return bdc.dateOut ? frDate(bdc.dateOut) : '—';
      case 'services': return frPrix(bdc.totalServices);
      case 'pieces':   return frPrix(bdc.totalPieces);
      case 'total':    return frPrix(total);
    }
  }

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader
          subtitle={(() => {
            if (view === 'refuses') {
              return refusedBdcs.length > 0 ? `${refusedBdcs.length} BDT refusé${refusedBdcs.length > 1 ? 's' : ''}` : 'BDT refusés';
            }
            if (view === 'ventes') {
              return archivedVentes.length > 0 ? `${archivedVentes.length} vente${archivedVentes.length > 1 ? 's' : ''} archivée${archivedVentes.length > 1 ? 's' : ''}` : 'Ventes archivées';
            }
            return archivedBdcs.length > 0 ? `${archivedBdcs.length} BDC archivé${archivedBdcs.length > 1 ? 's' : ''}` : 'BDC archivés';
          })()}
          title={view === 'refuses' ? 'Refusés' : view === 'ventes' ? 'Ventes archivées' : 'Archives 2026'}
        >
          <ToolbarBlock>
            {/* 1. Revenus (archives BDC uniquement) */}
            {view === 'archives' && archivedBdcs.length > 0 && (
              <>
                <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '13px', fontStyle: 'italic' }}>Revenus</span>
                <span style={{ color: '#fff056', fontSize: '24px', fontWeight: 700, lineHeight: 1 }}>{frPrix(totalRevenu)}</span>
              </>
            )}
            {/* Total ventes archivées (vue ventes) */}
            {view === 'ventes' && archivedVentes.length > 0 && (
              <>
                <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '13px', fontStyle: 'italic' }}>Total</span>
                <span style={{ color: '#fff056', fontSize: '24px', fontWeight: 700, lineHeight: 1 }}>
                  {frPrix(archivedVentes.reduce((s, v) => s + v.total, 0))}
                </span>
              </>
            )}
            {/* 2. Backups + Consolider — masqués dans la vue ventes (pas applicable) */}
            {view !== 'ventes' && (
              <>
                <UtilButton onClick={() => setShowBackups(true)} title="Backups BDT">
                  <ClockIcon style={{ width: '100%', height: '100%' }} />
                </UtilButton>
                <UtilButton onClick={handleConsolidate} title={consolidating ? 'Consolidation…' : 'Consolider'}>
                  <ArrowPathIcon className={consolidating ? 'animate-spin' : ''} style={{ width: '100%', height: '100%' }} />
                </UtilButton>
              </>
            )}
            {/* 3. Toggle Archivés | Refusés | Ventes — composant standard PillToggle */}
            <PillToggle
              value={view}
              onChange={setView}
              options={[
                { value: 'archives', label: `Archivés (${archivedBdcs.length})` },
                { value: 'refuses',  label: `Refusés (${refusedBdcs.length})`  },
                { value: 'ventes',   label: `Ventes (${archivedVentes.length})` },
              ]}
            />
          </ToolbarBlock>
        </PageHeader>

        {/* États de chargement et d'erreur — communs aux 3 vues */}
        {(view === 'ventes' ? ventesLoading : isLoading) && <LoadingSpinner className="py-20" />}
        {(view === 'ventes' ? ventesError : error) && (
          <p className="text-red-600">Erreur : {(view === 'ventes' ? (ventesError as any).message : (error as any).message)}</p>
        )}

        {/* Vide — message contextuel selon la vue */}
        {view !== 'ventes' && !isLoading && bdcs.length === 0 && (
          <div className="text-center text-sm" style={{ borderRadius: '50px', backgroundColor: 'rgba(255,255,255,0.50)', padding: '40px', color: 'rgba(0,0,0,0.4)' }}>
            {view === 'refuses' ? 'Aucun BDT refusé.' : "Aucun BDC archivé pour l'instant."}
          </div>
        )}
        {view === 'ventes' && !ventesLoading && archivedVentes.length === 0 && (
          <div className="text-center text-sm" style={{ borderRadius: '50px', backgroundColor: 'rgba(255,255,255,0.50)', padding: '40px', color: 'rgba(0,0,0,0.4)' }}>
            Aucune vente archivée pour l&apos;instant.
          </div>
        )}

        {/* Vue VENTES archivées — table dédiée (colonnes différentes des BDC) */}
        {view === 'ventes' && archivedVentes.length > 0 && (
          <div className="md:bg-black/20 md:rounded-[50px] md:p-5">
            <div className="overflow-hidden" style={{ borderRadius: '30px' }}>
              <div
                className="flex items-center gap-3"
                style={{
                  backgroundColor: '#fff056',
                  height: '64px',
                  paddingLeft: '30px', paddingRight: '30px',
                }}
              >
                <ArchiveBoxArrowDownIcon style={{ width: '30px', height: '30px', color: 'rgba(0,0,0,0.5)' }} />
                <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '24px', fontWeight: 700, lineHeight: 1 }}>
                  Ventes archivées
                </span>
                <span style={{ color: 'rgba(0,0,0,0.4)', fontSize: '14px' }}>({archivedVentes.length})</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="list-header">
                      <th className="px-2 py-2 w-10"></th>
                      <th className="px-2 py-2 w-20 text-center">restaurer</th>
                      <th className="px-4 py-2">facture</th>
                      <th className="px-4 py-2">date</th>
                      <th className="px-4 py-2">client</th>
                      <th className="px-4 py-2 text-center">items</th>
                      <th className="px-4 py-2 text-right">total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {archivedVentes.map((v, i) => {
                      const baseBg  = i % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)';
                      const pillBg  = '#e0e0e0';
                      const pillFg  = 'rgba(0,0,0,0.5)';
                      return (
                        <tr key={v.venteId} className="text-sm">
                          <td className="px-2 py-2 text-center" style={{ backgroundColor: baseBg }}>
                            <button
                              onClick={() => setVenteDeleteTarget(v)}
                              title="Supprimer définitivement (admin)"
                              className="flex items-center justify-center mx-auto hover:opacity-100 transition-opacity"
                              style={{ width: '32px', height: '32px', opacity: 0.5, color: 'rgba(0,0,0,0.6)' }}
                            >
                              <TrashIcon style={{ width: '22px', height: '22px' }} strokeWidth={1.8} />
                            </button>
                          </td>
                          <td className="px-2 py-2 text-center" style={{ backgroundColor: baseBg }}>
                            <button
                              onClick={() => setVenteRestoreTarget(v)}
                              title="Désarchiver — replacer dans la liste des ventes"
                              className="flex items-center justify-center mx-auto hover:opacity-100 transition-opacity"
                              style={{ width: '32px', height: '32px', opacity: 0.75, color: 'rgba(0,0,0,0.5)' }}
                            >
                              <ArrowUturnLeftIcon style={{ width: '22px', height: '22px' }} strokeWidth={1.8} />
                            </button>
                          </td>
                          {/* Pill statut/facture */}
                          <td style={{ padding: 0, paddingTop: '2pt', paddingBottom: '2pt', verticalAlign: 'middle', backgroundColor: baseBg }}>
                            <div
                              className="px-4 py-2 font-mono whitespace-nowrap"
                              style={{
                                backgroundColor: pillBg,
                                color: pillFg,
                                borderRadius: '20px 0 0 20px',
                                height: '36px',
                                display: 'flex',
                                alignItems: 'center',
                                fontWeight: 700,
                                fontSize: 'var(--h3-size)',
                              }}
                            >
                              {v.factureNumero ?? v.venteId}
                            </div>
                          </td>
                          <td style={{ padding: 0, paddingTop: '2pt', paddingBottom: '2pt', verticalAlign: 'middle', backgroundColor: baseBg }}>
                            <div
                              className="px-4 py-2 whitespace-nowrap"
                              style={{
                                backgroundColor: pillBg,
                                color: pillFg,
                                borderRadius: '0 20px 20px 0',
                                height: '36px',
                                display: 'flex',
                                alignItems: 'center',
                              }}
                            >
                              {frDate(v.factureDate ?? v.date)}
                            </div>
                          </td>
                          <td className="px-4 py-2 font-medium" style={{ backgroundColor: baseBg, color: 'rgba(0,0,0,0.7)' }}>
                            {v.client}
                          </td>
                          <td className="px-4 py-2 text-center" style={{ backgroundColor: baseBg, color: TXT_SOFT_STYLE }}>
                            {v.items.length}
                          </td>
                          <td className="px-4 py-2 text-right font-bold whitespace-nowrap" style={{ backgroundColor: baseBg }}>
                            {frPrix(v.total)}
                          </td>
                        </tr>
                      );
                    })}
                    {/* Ligne total */}
                    <tr className="list-header">
                      <td colSpan={4}></td>
                      <td className="px-4 py-2">total</td>
                      <td className="px-4 py-2 text-center">
                        {archivedVentes.reduce((s, v) => s + v.items.length, 0)}
                      </td>
                      <td className="px-4 py-2 text-right">
                        <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '18px' }}>
                          {frPrix(archivedVentes.reduce((s, v) => s + v.total, 0))}
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {view !== 'ventes' && bdcs.length > 0 && (
          <div className="md:bg-black/20 md:rounded-[50px] md:p-5">
           <div className="overflow-hidden" style={{ borderRadius: '30px' }}>
            {/* Entête : jaune pour archives, rouge doux pour refusés */}
            <div
              className="flex items-center gap-3"
              style={{
                backgroundColor: view === 'refuses' ? '#ffcdd2' : '#fff056',
                height: '64px',
                paddingLeft: '30px', paddingRight: '30px',
              }}
            >
              {view === 'refuses'
                ? <NoSymbolIcon style={{ width: '30px', height: '30px', color: '#b71c1c' }} />
                : <ArchiveBoxArrowDownIcon style={{ width: '30px', height: '30px', color: 'rgba(0,0,0,0.5)' }} />}
              <span style={{ color: view === 'refuses' ? '#b71c1c' : 'rgba(0,0,0,0.5)', fontSize: '24px', fontWeight: 700, lineHeight: 1 }}>
                {view === 'refuses' ? 'Refusés' : 'Archives'}
              </span>
              <span style={{ color: 'rgba(0,0,0,0.4)', fontSize: '14px' }}>({bdcs.length})</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="list-header">
                    {orderedCols.map(col => (
                      <DragTh key={col.id} className={col.hCls} isDragOver={dragOverId === col.id} {...dragProps(col.id)}>
                        {col.header}
                      </DragTh>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {bdcs.map((b, i) => {
                    const baseBg = i % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)';
                    const colors = statutColors(b.archiveStatus);
                    const PILL_COLS = new Set(['statut', 'id', 'dateIn', 'dateOut']);
                    const pillIdxs = orderedCols
                      .map((c2, idx2) => (PILL_COLS.has(c2.id) ? idx2 : -1))
                      .filter(idx2 => idx2 >= 0);
                    const firstPill = pillIdxs[0];
                    const lastPill  = pillIdxs[pillIdxs.length - 1];
                    return (
                    <tr key={`${b.id}-${i}`} className="text-sm">
                      {orderedCols.map((col, idx) => {
                        const isPill      = PILL_COLS.has(col.id);
                        const isFirstPill = isPill && idx === firstPill;
                        const isLastPill  = isPill && idx === lastPill;
                        const radius = isFirstPill && isLastPill ? '20px'
                          : isFirstPill ? '20px 0 0 20px'
                          : isLastPill  ? '0 20px 20px 0'
                          : undefined;
                        if (isPill) {
                          return (
                            <td
                              key={col.id}
                              style={{
                                padding: 0,
                                paddingTop: '2pt',
                                paddingBottom: '2pt',
                                verticalAlign: 'middle',
                                backgroundColor: baseBg,
                              }}
                            >
                              <div
                                className={col.cCls}
                                style={{
                                  backgroundColor: colors.bg,
                                  color: colors.fg,
                                  borderRadius: radius,
                                  whiteSpace: 'nowrap',
                                  height: '36px',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: col.id === 'statut' || col.id === 'id' ? 'center' : 'flex-start',
                                  boxSizing: 'border-box',
                                }}
                              >
                                {renderCell(col.id as ColId, b)}
                              </div>
                            </td>
                          );
                        }
                        const softStyle: React.CSSProperties = SOFT_TEXT_COLS.has(col.id)
                          ? { color: TXT_SOFT_STYLE, backgroundColor: baseBg }
                          : { backgroundColor: baseBg };
                        return (
                          <td key={col.id} className={col.cCls} style={softStyle}>
                            {renderCell(col.id as ColId, b)}
                          </td>
                        );
                      })}
                    </tr>
                    );
                  })}
                  {/* Ligne total — récapitulatif de la vue courante */}
                  <tr className="list-header">
                    {orderedCols.map(col => {
                      let content: React.ReactNode = '';
                      const sumSvc   = bdcs.reduce((s, b) => s + b.totalServices, 0);
                      const sumPce   = bdcs.reduce((s, b) => s + b.totalPieces,   0);
                      const sumTotal = sumSvc + sumPce;
                      if (col.id === 'client')   content = 'total';
                      if (col.id === 'services') content = <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '15px' }}>{frPrix(sumSvc)}</span>;
                      if (col.id === 'pieces')   content = <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '15px' }}>{frPrix(sumPce)}</span>;
                      if (col.id === 'total')    content = <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '18px' }}>{frPrix(sumTotal)}</span>;
                      return <td key={col.id} className={col.cCls}>{content}</td>;
                    })}
                  </tr>
                </tbody>
              </table>
            </div>
           </div>
          </div>
        )}
      </div>

      <ConfirmDialog
        open={!!restoreTarget}
        title="Ramener dans l'inventaire"
        message={`Désarchiver le BDC ${restoreTarget?.id} (${restoreTarget?.clientNom}) et le remettre dans l'inventaire ?`}
        confirmLabel={restoring ? 'Restauration…' : 'Restaurer'}
        onConfirm={handleRestore}
        onCancel={() => setRestoreTarget(null)}
      />

      <ConfirmDialog
        open={!!deleteTarget}
        title="Supprimer définitivement"
        message={`Supprimer définitivement le BDC ${deleteTarget?.id} (${deleteTarget?.clientNom}) ? Un snapshot est conservé dans _BDC_BACKUPS_ pour permettre une récupération via /api/admin/restore-bdc.`}
        confirmLabel={deleting ? 'Suppression…' : 'Supprimer'}
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      {/* ── Modal détail BDC archivé (lecture seule) ── */}
      <Modal open={!!detailTarget} onClose={() => setDetailTarget(null)} size="lg">
        {detailTarget && (() => {
          const b = detailTarget;
          const colors = statutColors(b.archiveStatus);
          const services = b.items.filter(it => it.service);
          const pieces   = b.items.filter(it => it.piece);
          const total    = b.totalServices + b.totalPieces;

          return (
            <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {/* 1. ID + statut pill */}
              <div className="flex items-center gap-3">
                <span
                  className="font-bold inline-flex items-center gap-2 flex-1"
                  style={{
                    backgroundColor: colors.bg,
                    color: colors.fg,
                    padding: '6px 18px',
                    borderRadius: '20px',
                    fontSize: '18px',
                  }}
                >
                  {b.id}
                  <span style={{ fontSize: '13px', fontWeight: 700, letterSpacing: '0.05em' }}>{colors.label}</span>
                  <span className="ml-auto inline-flex items-center gap-2" style={{ flexShrink: 0 }}>
                    <span
                      className="inline-flex items-center justify-center"
                      style={{
                        width: '28px',
                        height: '28px',
                        borderRadius: '50%',
                        border: `2px solid ${colors.fg}`,
                      }}
                      title="Lecture seule"
                    >
                      <LockClosedIcon style={{ width: '14px', height: '14px' }} />
                    </span>
                    <button
                      onClick={() => setDetailTarget(null)}
                      className="inline-flex items-center justify-center hover:opacity-70 transition-opacity"
                      style={{
                        width: '28px',
                        height: '28px',
                        borderRadius: '50%',
                        border: `2px solid ${colors.fg}`,
                        background: 'none',
                        color: colors.fg,
                        cursor: 'pointer',
                      }}
                      title="Fermer"
                    >
                      <XMarkIcon style={{ width: '14px', height: '14px' }} strokeWidth={3} />
                    </button>
                  </span>
                </span>
              </div>

              {/* 2. Client + Vélo */}
              <div className="text-sm" style={{ color: 'rgba(0,0,0,0.6)' }}>
                <strong>Client :</strong> {b.clientNom} &nbsp;&nbsp; <strong>Vélo :</strong> {b.veloDesc}
              </div>

              {/* 3. Dates */}
              <div className="text-sm" style={{ color: 'rgba(0,0,0,0.6)' }}>
                <strong>Date in :</strong> {frDate(b.dateIn)}
                {b.dateOut && <> &nbsp;&nbsp; <strong>Date out :</strong> {frDate(b.dateOut)}</>}
              </div>

              {/* 4. Séquence de travail — tout sur une ligne */}
              <div className="text-sm" style={{ color: 'rgba(0,0,0,0.6)' }}>
                <strong>Séquence de travail :</strong>{' '}
                {[
                  { label: 'évaluation', name: b.evalMecano },
                  { label: 'mécanique',  name: b.mecaMecano },
                  { label: 'ctrl. qlté', name: b.ctrlMecano },
                ].map((e, i, arr) => {
                  const isAttente = !e.name || e.name.toLowerCase().startsWith('attente');
                  const icon = isAttente ? '–' : '✓';
                  return (
                    <span key={e.label} style={{ color: 'rgba(0,0,0,0.5)' }}>
                      {icon} {e.label} : {e.name || 'En attente'}
                      {i < arr.length - 1 && <span style={{ margin: '0 8px', color: 'rgba(0,0,0,0.3)' }}>|</span>}
                    </span>
                  );
                })}
              </div>

              {/* 5. Note interne — nettoyage automatique :
                  Les anciens BDT contenaient du texte auto-généré avant une ligne
                  de séparation (ex. "reçu par : Flex éval par : yako … ────────").
                  On masque tout ce qui précède (et incluant) la première ligne de
                  séparation composée uniquement de tirets ─ / ━ / - / =. */}
              {(() => {
                const note = b.noteInterne ?? '';
                if (!note) return null;
                // Trouve la 1re ligne de séparation (≥ 10 caractères de tirets variés)
                const sepRegex = /^[─━\-=]{10,}\s*$/m;
                const m = note.match(sepRegex);
                let cleaned = note;
                if (m && m.index !== undefined) {
                  const afterSep = note.slice(m.index + m[0].length).trim();
                  cleaned = afterSep;
                }
                if (!cleaned) return null;
                return (
                  <div className="text-sm" style={{ color: 'rgba(0,0,0,0.5)', whiteSpace: 'pre-wrap' }}>
                    <strong style={{ color: 'rgba(0,0,0,0.6)' }}>Note interne</strong>
                    <div style={{ marginTop: '4px' }}>{cleaned}</div>
                  </div>
                );
              })()}

              {/* Note vélo */}
              {b.noteVelo && (
                <p className="text-sm italic" style={{ color: 'rgba(0,0,0,0.5)' }}>
                  Note vélo : {b.noteVelo}
                </p>
              )}

              {/* Services */}
              {services.length > 0 && (
                <div>
                  <h3 className="text-sm font-bold uppercase" style={{ color: 'rgba(0,0,0,0.4)', marginBottom: '8px', paddingTop: '12px', borderTop: '1px solid rgba(0,0,0,0.5)' }}>Services</h3>
                  <table className="w-full text-sm">
                    <thead>
                      <tr style={{ color: 'rgba(0,0,0,0.4)', fontStyle: 'italic', fontSize: '12px' }}>
                        <th className="text-left py-1 px-2">items</th>
                        <th className="text-right py-1 px-2 w-20">prix</th>
                      </tr>
                    </thead>
                    <tbody>
                      {services.map((it, i) => (
                        <tr key={i} style={{ backgroundColor: i % 2 === 0 ? 'rgba(0,0,0,0.03)' : 'transparent' }}>
                          <td className="py-1 px-2">{it.service!.nom}</td>
                          <td className="py-1 px-2 text-right">{frPrix(it.service!.prix)}</td>
                        </tr>
                      ))}
                      <tr style={{ fontWeight: 700 }}>
                        <td className="py-1 px-2">Total services</td>
                        <td className="py-1 px-2 text-right">{frPrix(b.totalServices)}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}

              {/* Pièces */}
              {pieces.length > 0 && (
                <div>
                  <h3 className="text-sm font-bold uppercase" style={{ color: 'rgba(0,0,0,0.4)', marginBottom: '8px', paddingTop: '12px', borderTop: '1px solid rgba(0,0,0,0.5)' }}>Pièces</h3>
                  <table className="w-full text-sm">
                    <thead>
                      <tr style={{ color: 'rgba(0,0,0,0.4)', fontStyle: 'italic', fontSize: '12px' }}>
                        <th className="text-left py-1 px-2">items</th>
                        <th className="text-right py-1 px-2 w-20">prix</th>
                        <th className="text-center py-1 px-2 w-12">qté</th>
                        <th className="text-right py-1 px-2 w-24">s/total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pieces.map((it, i) => (
                        <tr key={i} style={{ backgroundColor: i % 2 === 0 ? 'rgba(0,0,0,0.03)' : 'transparent' }}>
                          <td className="py-1 px-2">{it.piece!.nom}</td>
                          <td className="py-1 px-2 text-right">{frPrix(it.piece!.prix)}</td>
                          <td className="py-1 px-2 text-center">{it.piece!.qte}</td>
                          <td className="py-1 px-2 text-right">{frPrix(it.piece!.sousTotal)}</td>
                        </tr>
                      ))}
                      <tr style={{ fontWeight: 700 }}>
                        <td className="py-1 px-2" colSpan={3}>Total pièces</td>
                        <td className="py-1 px-2 text-right">{frPrix(b.totalPieces)}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}

              {/* Grand total */}
              <div className="flex justify-end" style={{ fontSize: '20px', fontWeight: 700 }}>
                Total : {frPrix(total)}
              </div>

              {services.length === 0 && pieces.length === 0 && (
                <p className="text-center text-sm" style={{ color: 'rgba(0,0,0,0.4)', padding: '20px' }}>
                  Aucun détail disponible pour ce BDC.
                </p>
              )}
            </div>
          );
        })()}
      </Modal>

      <ConfirmDialog
        open={!!venteRestoreTarget}
        title="Désarchiver la vente"
        message={`Replacer la vente ${venteRestoreTarget?.factureNumero ?? venteRestoreTarget?.venteId ?? ''} (${venteRestoreTarget?.client ?? ''}) dans la liste des ventes ?`}
        confirmLabel={venteRestoring ? 'Désarchivage…' : 'Désarchiver'}
        onConfirm={handleVenteRestore}
        onCancel={() => setVenteRestoreTarget(null)}
      />

      <ConfirmDialog
        open={!!venteDeleteTarget}
        title="Supprimer définitivement la vente"
        message={`Supprimer définitivement la vente ${venteDeleteTarget?.factureNumero ?? venteDeleteTarget?.venteId ?? ''} (${venteDeleteTarget?.client ?? ''}) ?\n\nAucun snapshot — action irréversible. Réservé aux administrateurs.`}
        confirmLabel={venteDeleting ? 'Suppression…' : 'Supprimer'}
        danger
        onConfirm={handleVenteDelete}
        onCancel={() => setVenteDeleteTarget(null)}
      />

      <BackupsModal open={showBackups} onClose={() => setShowBackups(false)} />
    </AppShell>
  );
}
