/**
 * GET /api/health/google — ping rapide des APIs Google OAuth utilisateur
 * pour détecter un token expiré avant que l'utilisateur soit bloqué.
 *
 * Teste 3 services (Drive, Gmail, People) avec une requête minimale.
 * Sheets est exclu car il utilise un service account, toujours OK.
 *
 * Retourne :
 *   {
 *     drive   : 'ok' | 'expired' | 'error',
 *     gmail   : 'ok' | 'expired' | 'error',
 *     contacts: 'ok' | 'expired' | 'error',
 *     details?: { drive?: string, gmail?: string, contacts?: string },
 *   }
 */
import { NextResponse } from 'next/server';
import { google } from 'googleapis';
import { auth } from '@/lib/auth';
import { withTokenRetry, isAuthError, GoogleAuthError } from '@/lib/google/withTokenRetry';
import { getSheetsClient, SHEET_IDS } from '@/lib/sheets/client';

type Status = 'ok' | 'expired' | 'error';
type HealthReport = {
  sheets  : Status;
  drive   : Status;
  gmail   : Status;
  contacts: Status;
  details?: Record<string, string>;
};

function getOAuth(accessToken: string, refreshToken?: string) {
  const o = new google.auth.OAuth2(
    process.env.AUTH_GOOGLE_ID,
    process.env.AUTH_GOOGLE_SECRET,
  );
  o.setCredentials({ access_token: accessToken, refresh_token: refreshToken ?? null });
  return o;
}

async function pingService(
  name: 'drive' | 'gmail' | 'contacts',
  ping: (token: string) => Promise<any>,
  accessToken: string,
  refreshToken?: string,
): Promise<{ status: Status; error?: string }> {
  try {
    await withTokenRetry(ping, accessToken, refreshToken);
    return { status: 'ok' };
  } catch (err: any) {
    if (err instanceof GoogleAuthError || isAuthError(err)) {
      return { status: 'expired', error: err?.message ?? 'Token expiré' };
    }
    return { status: 'error', error: err?.message ?? 'Erreur inconnue' };
  }
}

/** Ping Sheets via le service account (indépendant du OAuth utilisateur). */
async function pingSheets(): Promise<{ status: Status; error?: string }> {
  try {
    const sheets = getSheetsClient();
    const spreadsheetId = SHEET_IDS.INVENTAIRE || SHEET_IDS.PIECES;
    if (!spreadsheetId) {
      return { status: 'error', error: 'Aucun sheetId configuré' };
    }
    await sheets.spreadsheets.get({ spreadsheetId, fields: 'spreadsheetId' });
    return { status: 'ok' };
  } catch (err: any) {
    return { status: 'error', error: err?.message ?? 'Erreur Sheets' };
  }
}

export async function GET() {
  const session      = await auth();
  const accessToken  = session?.googleAccessToken  as string | undefined;
  const refreshToken = session?.googleRefreshToken as string | undefined;

  // Sheets d'abord (service account, indépendant de la session user)
  const sheetsPromise = pingSheets();

  if (!accessToken) {
    const sheetsRes = await sheetsPromise;
    return NextResponse.json<HealthReport>({
      sheets  : sheetsRes.status,
      drive   : 'expired',
      gmail   : 'expired',
      contacts: 'expired',
      details : {
        ...(sheetsRes.error ? { sheets: sheetsRes.error } : {}),
        drive   : 'Non authentifié',
        gmail   : 'Non authentifié',
        contacts: 'Non authentifié',
      },
    }, { status: 200 });
  }

  const [sheetsRes, driveRes, gmailRes, contactsRes] = await Promise.all([
    sheetsPromise,
    pingService('drive', async (token) => {
      const auth  = getOAuth(token, refreshToken);
      const drive = google.drive({ version: 'v3', auth });
      await drive.about.get({ fields: 'user/emailAddress' });
    }, accessToken, refreshToken),
    pingService('gmail', async (token) => {
      const auth  = getOAuth(token, refreshToken);
      const gmail = google.gmail({ version: 'v1', auth });
      await gmail.users.getProfile({ userId: 'me' });
    }, accessToken, refreshToken),
    pingService('contacts', async (token) => {
      const auth   = getOAuth(token, refreshToken);
      const people = google.people({ version: 'v1', auth });
      await people.people.get({ resourceName: 'people/me', personFields: 'names' });
    }, accessToken, refreshToken),
  ]);

  const report: HealthReport = {
    sheets  : sheetsRes.status,
    drive   : driveRes.status,
    gmail   : gmailRes.status,
    contacts: contactsRes.status,
  };
  const details: Record<string, string> = {};
  if (sheetsRes.error)   details.sheets   = sheetsRes.error;
  if (driveRes.error)    details.drive    = driveRes.error;
  if (gmailRes.error)    details.gmail    = gmailRes.error;
  if (contactsRes.error) details.contacts = contactsRes.error;
  if (Object.keys(details).length) report.details = details;

  return NextResponse.json(report, { status: 200 });
}
