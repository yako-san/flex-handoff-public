import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getArchivedBDCs, desarchiverBDC, patchArchiveDate, consolidateGhostBDCs, renameArchivedBDC, deleteArchivedBDC } from '@/lib/sheets/bdc';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';
import { parseBody } from '@/lib/validate';
import { ArchivePatchSchema, ArchiveDeleteSchema, ArchivePostSchema } from '@/lib/schemas/archives';

/** GET /api/archives — liste des BDC archivés */
export async function GET() {
  try {
    const bdcs = await getArchivedBDCs();
    return NextResponse.json(bdcs);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** PATCH /api/archives — modifier une date d'un BDC archivé.
 *  v1.1.7 — Item 4 : validation zod. */
export async function PATCH(req: Request) {
  const parsed = await parseBody(req, ArchivePatchSchema);
  if (!parsed.ok) return parsed.response;
  try {
    const { archiveRow, field, value } = parsed.data;
    await patchArchiveDate(archiveRow, field, value || '');
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** DELETE /api/archives — supprime DÉFINITIVEMENT une ligne archive (snapshot d'abord)
 *  v1.1.2 — Item 1 : action irréversible sur trace comptable. Admin only.
 *  v1.1.7 — Item 4 : validation zod. */
export async function DELETE(req: Request) {
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status },
    );
  }
  const parsed = await parseBody(req, ArchiveDeleteSchema);
  if (!parsed.ok) return parsed.response;
  try {
    const { bdcId, archiveRow } = parsed.data;
    await deleteArchivedBDC(bdcId, archiveRow);
    return NextResponse.json({ ok: true, deleted: bdcId });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** POST /api/archives — désarchiver OU consolider les fantômes OU rename.
 *  v1.1.7 — Item 4 : validation zod (union de 3 schémas selon action). */
export async function POST(req: Request) {
  const parsed = await parseBody(req, ArchivePostSchema);
  if (!parsed.ok) return parsed.response;
  const body = parsed.data;
  try {
    if ('action' in body && body.action === 'rename') {
      await renameArchivedBDC(body.archiveRow, body.oldId, body.newId);
      return NextResponse.json({ ok: true });
    }
    if ('action' in body && body.action === 'consolidate') {
      const consolidated = await consolidateGhostBDCs();
      return NextResponse.json({ ok: true, consolidated });
    }
    // Désarchivage classique (3e branche de l'union)
    const { bdcId, archiveRow } = body as { bdcId: string; archiveRow: number };
    // Snapshot avant désarchive. Si l'archive était FACTURÉ, engaged_after
    // perd cette qté (BDT revient à ÉVAL. dans INVENTAIRE) → AB remonte.
    const before = await snapshotStock();
    await desarchiverBDC(bdcId, archiveRow);
    await safeRecomputeStockState(before, 'ALL');
    return NextResponse.json({ ok: true, id: bdcId });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
