import { NextResponse } from 'next/server';
import { getArchivedBDCs } from '@/lib/sheets/bdc';
import * as XLSX from 'xlsx';

/**
 * GET /api/archives/export — Exporte tous les BDC archivés en xlsx.
 */
export async function GET() {
  try {
    const bdcs = await getArchivedBDCs();
    const rows = bdcs.map(b => ({
      'ID'          : b.id,
      'Date IN'     : b.dateIn,
      'Date OUT'    : b.dateOut ?? '',
      'Vélo'        : b.veloDesc,
      'Client'      : b.clientNom,
      'Statut'      : b.archiveStatus ?? '',
      'Services'    : b.totalServices,
      'Pièces'      : b.totalPieces,
      'Total'       : b.totalServices + b.totalPieces,
      'Nb items'    : (b.items ?? []).length,
      'Note client' : b.noteClient ?? '',
    }));

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, 'Archives');
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    return new NextResponse(buf, {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="archives-${new Date().toISOString().slice(0, 10)}.xlsx"`,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
