import { NextResponse } from 'next/server';
import { creerBon } from '@/lib/sheets/bdc';
import { getVelo } from '@/lib/sheets/inventaire';

/** GET /api/archives/fix-0106 — Recréer le BDC 0106 dans BONS DE COMMANDES */
export async function GET() {
  try {
    const velo = await getVelo('0106');
    if (!velo) return NextResponse.json({ error: 'Vélo 0106 introuvable dans INVENTAIRE' }, { status: 404 });

    const veloDesc = [velo.marque, velo.modele, velo.couleur, velo.taille].filter(Boolean).join(', ');
    await creerBon('0106', velo.client, veloDesc);

    return NextResponse.json({ ok: true, message: `BDC 0106 recréé pour ${velo.client} — ${veloDesc}` });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
