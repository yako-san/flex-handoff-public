/**
 * /api/parametres/equipe — gestion de l'équipe atelier (fiche complète).
 *
 *  GET    : liste des membres
 *  POST   : créer un membre (admin)
 *  PATCH  : modifier un membre (body: { row, fields }) (admin)
 *  DELETE : supprimer (body: { row }) (admin)
 */
import { NextResponse } from 'next/server';
import {
  getEquipeMembers,
  creerEquipeMember,
  patchEquipeMember,
  deleteEquipeMember,
} from '@/lib/sheets/equipe';
import { requireAdmin } from '@/lib/auth/requireAdmin';

const NO_STORE = { 'Cache-Control': 'no-store, no-cache, must-revalidate' };
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const members = await getEquipeMembers();
    return NextResponse.json(members, { headers: NO_STORE });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500, headers: NO_STORE });
  }
}

export async function POST(req: Request) {
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status, headers: NO_STORE },
    );
  }
  try {
    const body = await req.json();
    if (!body?.prenom?.trim() && !body?.nom?.trim()) {
      return NextResponse.json({ error: 'Prénom (ou Nom) requis' }, { status: 400, headers: NO_STORE });
    }
    const created = await creerEquipeMember({
      prenom   : String(body.prenom ?? '').trim(),
      nom      : String(body.nom ?? '').trim(),
      surnom   : String(body.surnom ?? '').trim(),
      courriel : String(body.courriel ?? '').trim(),
      tel      : String(body.tel ?? '').trim(),
      indicatif: String(body.indicatif ?? '+1').trim(),
      lang     : body.lang === 'EN' ? 'EN' : 'FR',
      role     : String(body.role ?? '').trim(),
      active   : body.active !== false,
      notes    : String(body.notes ?? '').trim(),
    });
    return NextResponse.json(created, { status: 201, headers: NO_STORE });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500, headers: NO_STORE });
  }
}

export async function PATCH(req: Request) {
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status, headers: NO_STORE },
    );
  }
  try {
    const body = await req.json();
    const row = parseInt(String(body.row ?? 0), 10);
    if (!row) return NextResponse.json({ error: 'row manquant' }, { status: 400, headers: NO_STORE });
    if (!body.fields || typeof body.fields !== 'object') {
      return NextResponse.json({ error: 'fields manquant' }, { status: 400, headers: NO_STORE });
    }
    await patchEquipeMember(row, body.fields);
    return NextResponse.json({ ok: true }, { headers: NO_STORE });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500, headers: NO_STORE });
  }
}

export async function DELETE(req: Request) {
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status, headers: NO_STORE },
    );
  }
  try {
    const body = await req.json();
    const row = parseInt(String(body.row ?? 0), 10);
    if (!row) return NextResponse.json({ error: 'row manquant' }, { status: 400, headers: NO_STORE });
    await deleteEquipeMember(row);
    return NextResponse.json({ ok: true }, { headers: NO_STORE });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500, headers: NO_STORE });
  }
}
