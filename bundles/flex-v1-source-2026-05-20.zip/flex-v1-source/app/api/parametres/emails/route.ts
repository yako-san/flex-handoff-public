import { NextResponse } from 'next/server';
import { getEmailTemplates, saveEmailTemplates } from '@/lib/sheets/emailTemplates';
import { requireAdmin } from '@/lib/auth/requireAdmin';

export const maxDuration = 30;
// Force dynamic (jamais de cache CDN). Sans ça, Vercel a déjà mis en cache un
// 405 généré pendant la fenêtre où le middleware redirigeait PUT → /login GET
// → 405 HTML. Le HIT continuait à servir cette erreur même après le fix.
export const dynamic = 'force-dynamic';

const NO_STORE = { 'Cache-Control': 'no-store, no-cache, must-revalidate' };

/** GET /api/parametres/emails — retourne tous les templates.
 *  Lecture autorisée pour tout utilisateur authentifié (les templates
 *  sont utilisés par tous les endroits de l'app, pas seulement les
 *  admins). */
export async function GET() {
  try {
    const templates = await getEmailTemplates();
    return NextResponse.json(templates, { headers: NO_STORE });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500, headers: NO_STORE });
  }
}

/** PUT /api/parametres/emails — sauvegarde un ou plusieurs templates.
 *  Réservé aux admins (liste admin_emails côté sheet, yako.cyclo@gmail.com
 *  toujours admin en fail-safe). */
export async function PUT(request: Request) {
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status, headers: NO_STORE },
    );
  }
  try {
    const body = await request.json();
    if (!body || typeof body !== 'object') {
      return NextResponse.json({ error: 'Body doit être un objet clé/valeur' }, { status: 400, headers: NO_STORE });
    }
    await saveEmailTemplates(body);
    return NextResponse.json({ ok: true }, { headers: NO_STORE });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500, headers: NO_STORE });
  }
}
