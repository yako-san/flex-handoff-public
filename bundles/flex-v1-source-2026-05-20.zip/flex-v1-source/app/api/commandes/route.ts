/**
 * GET /api/commandes
 *
 * Agrège toutes les pièces à commander ou en commande
 * depuis les BDC actifs (cmd = '√' ou '$').
 *
 * Retourne : { commandes: CommandeItem[] }
 */
import { NextResponse } from 'next/server';
import { getBDCs }      from '@/lib/sheets/bdc';

/** Statuts affichés dans la page Commandes (bons de travail) */
const CMD_COMMANDES = new Set(['√', '$', '@']);

export interface CommandeItem {
  bdcId     : string;
  clientNom : string;
  veloDesc  : string;
  nom       : string;
  prix      : number;
  qte       : number;
  cmd       : string;   // '√' = à commander | '$' = en commande
  sousTotal : number;
  _row      : number;
}

export async function GET() {
  try {
    const bdcs      = await getBDCs();
    const commandes : CommandeItem[] = [];

    for (const bdc of bdcs) {
      for (const item of bdc.items) {
        if (!item.piece) continue;
        const cmd = item.piece.cmd;
        if (!CMD_COMMANDES.has(cmd)) continue;

        commandes.push({
          bdcId    : bdc.id,
          clientNom: bdc.clientNom,
          veloDesc : bdc.veloDesc,
          nom      : item.piece.nom,
          prix     : item.piece.prix,
          qte      : item.piece.qte,
          cmd,
          sousTotal: item.piece.sousTotal,
          _row     : item._row,
        });
      }
    }

    // Tri : √ (à commander) d'abord, puis $ (en commande), puis par BDC
    commandes.sort((a, b) => {
      if (a.cmd === '√' && b.cmd !== '√') return -1;
      if (a.cmd !== '√' && b.cmd === '√') return  1;
      return a.bdcId.localeCompare(b.bdcId);
    });

    return NextResponse.json({ commandes });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
