/**
 * GET /api/bdc-backups — liste les snapshots de _BDC_BACKUPS_
 *
 * ?limit=N (default 200) — nombre max d'entrées (les plus récentes)
 *
 * Retourne uniquement les métadonnées (timestamp, action, bdcId, client,
 * vélo, note + flags hasBdcRows/hasInvRow). Les JSON bruts ne sont pas
 * exposés pour ne pas bloater la réponse ; consulter le sheet directement
 * pour restaurer manuellement.
 */
import { NextResponse } from 'next/server';
import { getBDCBackups } from '@/lib/sheets/bdc';

export async function GET(req: Request) {
  try {
    const limit = parseInt(new URL(req.url).searchParams.get('limit') ?? '200', 10) || 200;
    const entries = await getBDCBackups(limit);
    return NextResponse.json(entries);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
