/**
 * GET /api/factures/preview-pdf?venteId=V0006&lang=FR
 *
 * Route preview admin only — v1.3.0-preview.
 *
 * Génère un PDF facture via le nouveau pipeline Puppeteer + HTML
 * (`lib/pdf/templates/facture-html.ts` + `lib/pdf/render-puppeteer.ts`)
 * et le retourne **directement dans le navigateur** (Content-Type
 * application/pdf). Permet d'itérer visuellement sur le design avant
 * de remplacer le pipeline production (qui reste sur les templates
 * Sheets BASE-YC/BASE-CF, inchangé).
 *
 * Cette route NE modifie RIEN :
 *   - Pas d'upload Drive
 *   - Pas de brouillon Gmail
 *   - Pas d'écriture journal
 *   - Pas de marquage facturée
 *
 * Query params :
 *   - `venteId` (requis) : id de la vente à prévisualiser (ex. V0006)
 *     OU bdcId si on prévisualise un BDT (ex. 0042)
 *   - `lang` (opt) : 'FR' (défaut) ou 'EN' — override de client.lang
 *   - `bdc` (opt) : si '1', traite l'id comme un bdcId (BDT) au lieu
 *     d'un venteId. Utile pour tester le rendu BDT facturé.
 */
import { type NextRequest, NextResponse } from 'next/server';
import { requireAdmin }                   from '@/lib/auth/requireAdmin';
import { getVentes }                       from '@/lib/sheets/ventes';
import { getBDC }                          from '@/lib/sheets/bdc';
import { getClients }                      from '@/lib/sheets/clients';
import { getEmailTemplates }               from '@/lib/sheets/emailTemplates';
import { computeTaxes }                    from '@/lib/finances/taxes';
import { renderFactureHtml, type FactureHtmlData } from '@/lib/pdf/templates/facture-html';
import { renderHtmlToPdfBuffer }           from '@/lib/pdf/render-puppeteer';
import { todayStr }                        from '@/lib/utils/format';
import type { Vente }                       from '@/types/vente';
import type { BDC }                         from '@/types/bdc';

export const maxDuration = 30;  // 30s pour cold start Chromium + render

async function _getClientByNom(nom: string) {
  const grouped = await getClients();
  const all = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
  return all.find(c => c.nomComplet === nom) ?? null;
}

export async function GET(req: NextRequest) {
  // 1. Admin only
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status },
    );
  }

  // 2. Parse query
  const { searchParams } = new URL(req.url);
  const id    = (searchParams.get('venteId') || searchParams.get('id') || '').trim();
  const lang  = (searchParams.get('lang') === 'EN' ? 'EN' : 'FR') as 'FR' | 'EN';
  const isBdc = searchParams.get('bdc') === '1';
  if (!id) {
    return NextResponse.json({ error: 'Param `venteId` (ou `id`) requis' }, { status: 400 });
  }

  try {
    // 3. Récupérer la source (vente OU bdc)
    let docType: 'facture' | 'vente' = 'vente';
    let numero    = '';
    let dateStr   = todayStr();
    let veloDesc  : string | undefined = undefined;
    let clientNom = '';
    let services  : { nom: string; prix: number }[] = [];
    let pieces    : { nom: string; prix: number; qte: number; sousTotal: number }[] = [];

    if (isBdc) {
      const bdc = await getBDC(id);
      if (!bdc) return NextResponse.json({ error: `BDT ${id} introuvable` }, { status: 404 });
      docType   = 'facture';
      numero    = bdc.id;
      veloDesc  = bdc.veloDesc;
      clientNom = bdc.clientNom;
      services  = bdc.items
        .filter(it => it.service)
        .map(it => ({ nom: it.service!.nom, prix: it.service!.prix }));
      pieces    = bdc.items
        .filter(it => it.piece)
        .map(it => ({ nom: it.piece!.nom, prix: it.piece!.prix, qte: it.piece!.qte, sousTotal: it.piece!.sousTotal }));
    } else {
      const ventes = await getVentes();
      // Cherche par venteId (id interne) OU par factureNumero (ex. "V0006"
      // ou ancien format "V0006-2026-05-12") — l'URL reçoit souvent le
      // factureNumero car c'est ce qui est affiché dans l'UI.
      const vente  = ventes.find(v =>
        v.venteId === id ||
        (v.factureNumero && (
          v.factureNumero === id ||
          v.factureNumero.startsWith(id + '-')
        ))
      );
      if (!vente) {
        // Debug : liste les 10 premières ventes facturées pour diagnostiquer
        const debugList = ventes
          .filter(v => v.factureNumero)
          .slice(0, 10)
          .map(v => ({ venteId: v.venteId, factureNumero: v.factureNumero }));
        return NextResponse.json(
          { error: `Vente ${id} introuvable`, debug_factured: debugList },
          { status: 404 },
        );
      }
      docType   = 'vente';
      numero    = vente.factureNumero || vente.venteId;
      dateStr   = vente.factureDate || vente.date;
      clientNom = vente.client;
      // Découpe services / pièces selon pieceId : préfixe S = service.
      for (const it of vente.items) {
        const isService = (it.pieceId || '').startsWith('S');
        const nom       = it.qte !== 1 ? `${it.nom} (×${String(it.qte).replace('.', ',')})` : it.nom;
        if (isService) {
          services.push({ nom, prix: it.sousTotal });
        } else {
          pieces.push({ nom, prix: it.prixUnit, qte: it.qte, sousTotal: it.sousTotal });
        }
      }
    }

    // 4. Client + employeur
    const client = await _getClientByNom(clientNom);
    if (!client) return NextResponse.json({ error: `Client "${clientNom}" introuvable` }, { status: 404 });

    // 5. Workshop info depuis email templates
    const tpl = await getEmailTemplates();
    const leadIsYc = client.lead === 'yako.cyclo';
    const workshop = {
      nom        : leadIsYc ? 'yako.cyclo' : 'Cyclo Flex Montréal',
      courriel   : leadIsYc ? 'yako.cyclo@gmail.com' : 'cycloflex.mtl@gmail.com',
      telephone  : '(514) 995-3445',
      adresse    : '4109, St-Denis, Montréal',
      neq        : (leadIsYc ? tpl.workshop_neq_yc : tpl.workshop_neq_cf) || undefined,
      tpsNumero  : (leadIsYc ? tpl.workshop_tps_yc : tpl.workshop_tps_cf) || undefined,
      tvqNumero  : (leadIsYc ? tpl.workshop_tvq_yc : tpl.workshop_tvq_cf) || undefined,
    };

    // 6. Totaux (taxes calculées sur le sous-total HT)
    const totalServices = services.reduce((s, it) => s + it.prix, 0);
    const totalPieces   = pieces.reduce((s, it) => s + it.sousTotal, 0);
    const sousTotal     = totalServices + totalPieces;
    const { tps, tvq, grandTotal } = computeTaxes(sousTotal);

    // 7. Build FactureHtmlData
    const data: FactureHtmlData = {
      docType, lang,
      workshop,
      numero, date: dateStr,
      client: {
        nomComplet       : client.nomComplet,
        courriel         : client.courriel,
        adressePostale   : client.adressePostale,
        entrepriseName   : client.entrepriseName,
        entrepriseAdresse: client.entrepriseAdresse,
      },
      veloDesc,
      services,
      pieces,
      sousTotal,
      totalRemise: 0,    // preview neutre — remises non appliquées
      tps, tvq,
      totalTTC   : grandTotal,
      noteClient : '',
      // Logo absolu : Vercel sert /public à la racine du site
      logoUrl    : new URL('/logo-yako-cyclo.svg', req.nextUrl.origin).toString(),
    };

    // 8. Render HTML → PDF
    const html      = renderFactureHtml(data);
    const pdfBuffer = await renderHtmlToPdfBuffer(html);

    // Buffer Node → Uint8Array pour BodyInit (TypeScript strict)
    const body = new Uint8Array(pdfBuffer);
    return new NextResponse(body, {
      status : 200,
      headers: {
        'Content-Type'       : 'application/pdf',
        // Inline → ouvre dans le browser au lieu de télécharger
        'Content-Disposition': `inline; filename="preview-${numero}.pdf"`,
        'Cache-Control'      : 'no-store',
      },
    });
  } catch (err: any) {
    console.error('[preview-pdf]', err);
    return NextResponse.json(
      { error: err?.message ?? 'Erreur interne', stack: err?.stack ?? null },
      { status: 500 },
    );
  }
}
