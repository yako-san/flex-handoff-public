/**
 * GET   /api/factures/log-status?ref=0042&type=facture       → lit statut + mode
 * PATCH /api/factures/log-status                             → update statut/mode
 *   body : { factureRef, docType: 'facture'|'vente', statut?, modePaiement? }
 *
 * Permet de marquer une facture déjà émise comme PAYÉ et choisir le
 * mode de paiement (comptant/interac/cartes) directement depuis la
 * fiche BDT/Vente, sans toucher au sheet manuellement.
 */
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { updateFactureLogStatus, getFactureLogStatus } from '@/lib/sheets/factures';
import { logError } from '@/lib/log';

export async function GET(req: NextRequest) {
  try {
    const session = await auth();
    if (!session) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

    const ref     = req.nextUrl.searchParams.get('ref') ?? '';
    const docType = (req.nextUrl.searchParams.get('type') ?? 'facture') as 'facture' | 'vente';
    if (!ref) return NextResponse.json({ error: 'ref requis' }, { status: 400 });
    if (docType !== 'facture' && docType !== 'vente') {
      return NextResponse.json({ error: 'type doit être "facture" ou "vente"' }, { status: 400 });
    }

    const status = await getFactureLogStatus(ref, docType);
    return NextResponse.json({ status });
  } catch (err: any) {
    logError('facture-log-status-get-failed', { error: err?.message ?? String(err) });
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const session = await auth();
    if (!session) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const factureRef = String(body?.factureRef ?? '').trim();
    const docType    = body?.docType as 'facture' | 'vente';

    if (!factureRef) return NextResponse.json({ error: 'factureRef requis' }, { status: 400 });
    if (docType !== 'facture' && docType !== 'vente') {
      return NextResponse.json({ error: 'docType doit être "facture" ou "vente"' }, { status: 400 });
    }

    const fields: { statut?: any; modePaiement?: any } = {};
    if (body.statut !== undefined) {
      const v = String(body.statut);
      if (!['ÉMIS', 'PAYÉ', 'ANNULÉ'].includes(v)) {
        return NextResponse.json({ error: 'statut doit être ÉMIS, PAYÉ ou ANNULÉ' }, { status: 400 });
      }
      fields.statut = v;
    }
    if (body.modePaiement !== undefined) {
      const v = String(body.modePaiement);
      if (!['comptant', 'interac', 'cartes'].includes(v)) {
        return NextResponse.json({ error: 'modePaiement doit être comptant, interac ou cartes' }, { status: 400 });
      }
      fields.modePaiement = v;
    }

    const result = await updateFactureLogStatus(factureRef, docType, fields);
    return NextResponse.json(result);
  } catch (err: any) {
    logError('facture-log-status-patch-failed', { error: err?.message ?? String(err) });
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}
