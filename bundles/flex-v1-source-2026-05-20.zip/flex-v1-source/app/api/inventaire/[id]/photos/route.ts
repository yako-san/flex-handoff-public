/**
 * GET  /api/inventaire/[id]/photos                       → liste photos du BDT
 * POST /api/inventaire/[id]/photos (multipart: file)      → upload une photo
 *
 * Utilise le OAuth token utilisateur (storage perso Drive). Les photos
 * sont stockées dans `<DRIVE_CLIENTS_FOLDER_ID>/<nomClient>/BDT-<bdcId>/`
 * — par vélo, pas par client (v1.0.10+).
 */
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { listVeloPhotos, uploadVeloPhoto } from '@/lib/drive/veloFolders';
import { googleApiError } from '@/lib/google/apiErrorResponse';
import { getVelo } from '@/lib/sheets/inventaire';

async function getTokens() {
  const session = await auth();
  if (!session) return null;
  const accessToken  = session.googleAccessToken  as string | undefined;
  const refreshToken = session.googleRefreshToken as string | undefined;
  if (!accessToken) return null;
  return { accessToken, refreshToken };
}

/** Résout le client à partir du bdcId (via INVENTAIRE col H = client). */
async function getClientForBdc(bdcId: string): Promise<string> {
  const velo = await getVelo(bdcId);
  if (!velo) throw new Error(`BDT ${bdcId} introuvable`);
  if (!velo.client) throw new Error(`BDT ${bdcId} sans client associé`);
  return velo.client;
}

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const tokens = await getTokens();
    if (!tokens) {
      return NextResponse.json(
        { error: 'Non authentifié — reconnecte-toi', code: 'GOOGLE_AUTH_EXPIRED', reconnect: true },
        { status: 401 },
      );
    }
    const bdcId  = params.id;
    if (!bdcId) return NextResponse.json({ error: 'bdcId requis' }, { status: 400 });
    const client = await getClientForBdc(bdcId);
    const photos = await listVeloPhotos(client, bdcId, tokens.accessToken, tokens.refreshToken);
    return NextResponse.json({ photos, bdcId, client });
  } catch (err: any) {
    return googleApiError(err);
  }
}

const MAX_UPLOAD_BYTES = 4 * 1024 * 1024;

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const tokens = await getTokens();
    if (!tokens) return NextResponse.json({ error: 'Non authentifié — reconnectez-vous.' }, { status: 401 });
    const bdcId  = params.id;
    if (!bdcId) return NextResponse.json({ error: 'bdcId requis' }, { status: 400 });
    const client = await getClientForBdc(bdcId);

    const form = await req.formData();
    const file = form.get('file');
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'Fichier manquant (champ "file")' }, { status: 400 });
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      const mb = (file.size / 1024 / 1024).toFixed(1);
      return NextResponse.json(
        { error: `Fichier trop volumineux (${mb} MB). Max : 4 MB — redimensionne la photo avant upload.` },
        { status: 413 },
      );
    }
    const buf = Buffer.from(await file.arrayBuffer());
    const res = await uploadVeloPhoto(
      client, bdcId,
      { name: file.name, mimeType: file.type || 'application/octet-stream', buffer: buf },
      tokens.accessToken,
      tokens.refreshToken,
    );
    return NextResponse.json(res, { status: 201 });
  } catch (err: any) {
    const msg = String(err?.message ?? '');
    if (/DRIVE_CLIENTS_FOLDER_ID/.test(msg)) {
      return NextResponse.json(
        { error: 'Drive non configuré (DRIVE_CLIENTS_FOLDER_ID manquant côté serveur).' },
        { status: 500 },
      );
    }
    return googleApiError(err);
  }
}
