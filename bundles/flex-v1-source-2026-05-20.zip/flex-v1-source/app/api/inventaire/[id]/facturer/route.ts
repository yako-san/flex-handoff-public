import { NextResponse } from 'next/server';
import { getVelo, updateVelo } from '@/lib/sheets/inventaire';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';

/** POST /api/inventaire/[id]/facturer */
export async function POST(_req: Request, { params }: { params: { id: string } }) {
  try {
    const velo = await getVelo(params.id);
    if (!velo) return NextResponse.json({ error: 'Vélo introuvable' }, { status: 404 });

    const before = await snapshotStock();

    const updated = await updateVelo(params.id, { status: 'FACTURÉ' });

    // Recalcule AB + AC selon engagement avant/après le passage à FACTURÉ.
    await safeRecomputeStockState(before, 'BDT');

    return NextResponse.json({ velo: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
