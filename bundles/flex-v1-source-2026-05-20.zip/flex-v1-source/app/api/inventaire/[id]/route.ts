import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getVelo, updateVelo, deleteVelo } from '@/lib/sheets/inventaire';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';
import type { PatchVeloBody } from '@/types/api';

/** GET /api/inventaire/[id] */
export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const velo = await getVelo(params.id);
    if (!velo) return NextResponse.json({ error: 'Introuvable' }, { status: 404 });
    return NextResponse.json(velo);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** PATCH /api/inventaire/[id] — mise à jour partielle statut/champs */
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const body: PatchVeloBody = await req.json();
    const before = body.status !== undefined ? await snapshotStock() : undefined;
    const velo = await updateVelo(params.id, body);
    if (before) {
      await safeRecomputeStockState(before, 'BDT');
    }
    return NextResponse.json(velo);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** DELETE /api/inventaire/[id] — supprimer un vélo
 *  v1.1.2 — Item 1 : perte de l'historique vélo → admin only. */
export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  try {
    const check = await requireAdmin();
    if (!check.ok) {
      return NextResponse.json(
        { error: check.error, code: 'ADMIN_REQUIRED' },
        { status: check.status },
      );
    }
    const before = await snapshotStock();
    await deleteVelo(params.id);
    await safeRecomputeStockState(before, 'BDT');
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
