import { NextResponse } from 'next/server';
import { getVelos, addVelo } from '@/lib/sheets/inventaire';
import { creerBon } from '@/lib/sheets/bdc';
import { prochainID } from '@/lib/sheets/counter';
import type { PostVeloBody } from '@/types/api';

/** GET /api/inventaire — liste tous les vélos, triés par date de réception desc */
export async function GET() {
  try {
    const velos = await getVelos();
    velos.sort((a, b) => {
      const da = a.date1 ?? '';
      const db = b.date1 ?? '';
      return db.localeCompare(da);
    });
    return NextResponse.json(velos);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** POST /api/inventaire — ajouterLigneVelo */
export async function POST(req: Request) {
  try {
    const body: PostVeloBody = await req.json().catch(() => ({}));

    const idStr = await prochainID();
    const velo  = await addVelo(idStr, body);
    await creerBon(idStr, body.client ?? '', body.marque ?? '');

    return NextResponse.json({ id: idStr, velo }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
