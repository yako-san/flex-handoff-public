import { NextResponse } from 'next/server';
import { getVelos, updateVelo } from '@/lib/sheets/inventaire';
import { getBDC } from '@/lib/sheets/bdc';

/**
 * POST /api/inventaire/sync
 * Synchronise les colonnes SERVICES et PIÈCES de l'INVENTAIRE depuis les BDC actifs.
 * Équivalent de syncServicesEtPiecesVersInventaire() dans le GAS.
 */
export async function POST() {
  try {
    const velos = await getVelos();
    const results: { id: string; ok: boolean }[] = [];

    for (const velo of velos) {
      try {
        const bdc = await getBDC(velo.id);
        if (!bdc) continue;

        const services = bdc.items
          .filter(i => i.service)
          .map(i => i.service!.nom)
          .join('\n');

        const pieces = bdc.items
          .filter(i => i.piece)
          .map(i => `${i.piece!.nom} ×${i.piece!.qte}`)
          .join('\n');

        await updateVelo(velo.id, { services, pieces });
        results.push({ id: velo.id, ok: true });
      } catch {
        results.push({ id: velo.id, ok: false });
      }
    }

    return NextResponse.json({ synced: results.filter(r => r.ok).length, results });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
