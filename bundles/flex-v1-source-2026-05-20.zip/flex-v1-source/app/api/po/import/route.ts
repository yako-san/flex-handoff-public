import { NextResponse } from 'next/server';
import { parseBuffer } from '@/lib/import/parseFile';

/**
 * POST /api/po/import — Parse un fichier xlsx/csv uploadé.
 * Retourne les headers, données, métadonnées et columnMap détectés.
 * Le matching avec le catalogue se fait côté client (les pièces sont déjà chargées via usePieces).
 */
export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    if (!file) return NextResponse.json({ error: 'Fichier requis' }, { status: 400 });

    const buffer = await file.arrayBuffer();
    const parsed = parseBuffer(buffer, file.name);

    return NextResponse.json(parsed);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
