import { NextResponse } from 'next/server';
import { getPOs } from '@/lib/sheets/po';
import * as XLSX from 'xlsx';

/** Libellé lisible du statut pour l'export. */
function statusLabel(s: string): string {
  switch (s) {
    case 'EN ATTENTE': return 'À recevoir';
    case 'PARTIEL'   : return 'Partiel';
    case 'RECU'      : return 'Reçu';
    case 'ANNULE'    : return 'Annulé';
    default          : return s;
  }
}

/**
 * GET /api/po/export — Exporte tous les PO en xlsx.
 * ?po=110731 → exporte uniquement ce PO.
 *
 * Mise en forme :
 * - Colonnes : Fournisseur, PO#, Date CMD, Date REÇU, Statut, Item, SKU, Cmd, Reçu, Reçu/Cmd, Prix, Notes
 * - Les 4 colonnes d'en-tête PO (Fournisseur..Date REÇU) ne sont remplies que sur la 1re ligne
 * - Prix formaté "00,00 $"
 * - Reçu/Cmd calculé : "qteRecue/qteCommandee"
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const targetPo = searchParams.get('po');
    const allPos = await getPOs();
    const pos = targetPo ? allPos.filter(p => p.poNumber === targetPo) : allPos;

    const fmtPrix = (n: number): string =>
      `${n.toFixed(2).replace('.', ',')} $`;

    const rows = pos.flatMap(po =>
      po.items.map((item, i) => ({
        'Fournisseur'    : i === 0 ? po.fournisseur : '',
        'PO#'            : i === 0 ? po.poNumber    : '',
        'Date CMD'       : i === 0 ? po.dateCommande : '',
        'Date REÇU'      : i === 0 ? (po.dateReception || '') : '',
        'Statut'         : i === 0 ? statusLabel(po.status) : '',
        'Item'           : item.nom,
        'SKU'            : item.sku,
        'Cmd'            : item.qteCommandee,
        'Reçu'           : item.qteRecue,
        'Reçu/Cmd'       : `${item.qteRecue}/${item.qteCommandee}`,
        'Prix'           : fmtPrix(item.prixAchat),
        'Notes'          : item.notes,
      }))
    );

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, 'PO');
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    const fileName = targetPo
      ? `po-${targetPo}-${new Date().toISOString().slice(0, 10)}.xlsx`
      : `po-export-${new Date().toISOString().slice(0, 10)}.xlsx`;

    return new NextResponse(buf, {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="${fileName}"`,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
