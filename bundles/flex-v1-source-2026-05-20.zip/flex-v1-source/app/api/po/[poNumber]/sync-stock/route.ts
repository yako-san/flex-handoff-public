/**
 * POST /api/po/[poNumber]/sync-stock
 *
 * One-shot : applique les qteRecue courantes du PO au stock du catalogue.
 * Auto-crée les pièces manquantes via addPieceToCatalogue.
 *
 * v1.1.3 — Item 2 audit sécurité : idempotence + admin.
 *   - requireAdmin obligatoire (action stock destructive du côté double-clic)
 *   - Lit `stockSyncedAt` (col P, écrit par `markPOStockSynced`). Si déjà
 *     synchronisé → refuse avec 409, sauf si le body contient `force: true`.
 *   - Marque le PO comme synced en cas de succès (best-effort — si le
 *     marquage échoue après que le stock a été appliqué, on retourne quand
 *     même l'erreur pour que le caller la voie ; mais le stock est déjà
 *     dans le catalogue).
 */
import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getPO, syncStockForPO, markPOStockSynced } from '@/lib/sheets/po';
import { parseBody } from '@/lib/validate';
import { POSyncStockSchema } from '@/lib/schemas/po';

export async function POST(req: Request, { params }: { params: { poNumber: string } }) {
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status },
    );
  }

  // v1.1.7 — Item 4 : validation zod (body optionnel, juste `force`)
  const parsed = await parseBody(req, POSyncStockSchema);
  if (!parsed.ok) return parsed.response;
  const force = parsed.data.force === true;

  try {
    const po = await getPO(params.poNumber);
    if (!po) {
      return NextResponse.json({ error: `PO ${params.poNumber} introuvable` }, { status: 404 });
    }

    if (po.stockSyncedAt && !force) {
      return NextResponse.json(
        {
          error          : `PO ${params.poNumber} déjà synchronisé le ${po.stockSyncedAt}.`,
          code           : 'ALREADY_SYNCED',
          stockSyncedAt  : po.stockSyncedAt,
          hint           : 'Renvoie { force: true } pour forcer une 2e application (cas exceptionnel — risque de doubler le stock).',
        },
        { status: 409 },
      );
    }

    const result = await syncStockForPO(params.poNumber);
    await markPOStockSynced(params.poNumber);
    return NextResponse.json({ ok: true, forced: force, ...result });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
