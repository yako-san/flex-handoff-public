import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getPO, addLinesToPO, updatePOLine, deletePOLine, reopenPO } from '@/lib/sheets/po';

/** GET /api/po/[poNumber] — détails d'un PO. */
export async function GET(_req: Request, { params }: { params: { poNumber: string } }) {
  try {
    const po = await getPO(params.poNumber);
    if (!po) return NextResponse.json({ error: 'PO introuvable' }, { status: 404 });
    return NextResponse.json(po);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** POST /api/po/[poNumber] — ajoute des lignes à un PO existant EN ATTENTE. */
export async function POST(request: Request, { params }: { params: { poNumber: string } }) {
  try {
    const { items } = await request.json();
    if (!items?.length) return NextResponse.json({ error: 'items requis' }, { status: 400 });
    await addLinesToPO(params.poNumber, items);
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** PATCH /api/po/[poNumber] — met à jour une ligne ou réouvre un PO. */
export async function PATCH(request: Request, { params }: { params: { poNumber: string } }) {
  try {
    const body = await request.json();

    // Réouverture du PO
    if (body.action === 'reopen') {
      await reopenPO(params.poNumber);
      return NextResponse.json({ ok: true });
    }

    // Mise à jour d'une ligne
    const { sheetRow, ...fields } = body;
    if (!sheetRow) return NextResponse.json({ error: 'sheetRow requis' }, { status: 400 });
    const result = await updatePOLine(sheetRow, fields);
    return NextResponse.json({ ok: true, ...result });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** DELETE /api/po/[poNumber] — supprime une ligne.
 *  v1.1.2 — Item 1 : suppression ligne PO destructive (perte engagement
 *  fournisseur + qté commandée). Admin only. */
export async function DELETE(request: Request) {
  try {
    const check = await requireAdmin();
    if (!check.ok) {
      return NextResponse.json(
        { error: check.error, code: 'ADMIN_REQUIRED' },
        { status: check.status },
      );
    }
    const { sheetRow } = await request.json();
    if (!sheetRow) return NextResponse.json({ error: 'sheetRow requis' }, { status: 400 });
    await deletePOLine(sheetRow);
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
