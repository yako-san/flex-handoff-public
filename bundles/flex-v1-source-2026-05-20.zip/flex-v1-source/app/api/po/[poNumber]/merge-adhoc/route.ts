/**
 * POST /api/po/[poNumber]/merge-adhoc
 * Body : { adhocPoNumbers: string[] }
 *
 * Fusionne plusieurs PO ADHOC dans la PO cible (poNumber). Les items
 * des ADHOC sont append dans la cible, les ADHOC sont marqués ANNULE
 * avec note de traçabilité. Pas de re-sync stock (déjà appliqué par
 * les ADHOC à leur création).
 *
 * Cas d'usage : la facture fournisseur (Babac, HLC) arrive après la
 * semaine de scans rapides ad-hoc. L'utilisateur crée la vraie PO et
 * "absorbe" les ADHOC du même fournisseur dedans pour avoir un
 * historique consolidé.
 */
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { mergeAdhocPOsIntoPO } from '@/lib/sheets/po';
import { logError } from '@/lib/log';

export const maxDuration = 60;

export async function POST(req: Request, { params }: { params: { poNumber: string } }) {
  try {
    const session = await auth();
    if (!session) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

    const targetPoNumber = decodeURIComponent(params.poNumber ?? '').trim();
    if (!targetPoNumber) {
      return NextResponse.json({ error: 'poNumber requis' }, { status: 400 });
    }

    const body = await req.json().catch(() => ({}));
    const adhocPoNumbers = Array.isArray(body?.adhocPoNumbers) ? body.adhocPoNumbers as string[] : [];
    if (adhocPoNumbers.length === 0) {
      return NextResponse.json({ error: 'adhocPoNumbers requis (array non vide)' }, { status: 400 });
    }
    // Validation : tous des strings non vides
    if (!adhocPoNumbers.every(n => typeof n === 'string' && n.trim())) {
      return NextResponse.json({ error: 'adhocPoNumbers doit contenir des strings non vides' }, { status: 400 });
    }

    const result = await mergeAdhocPOsIntoPO(targetPoNumber, adhocPoNumbers);
    return NextResponse.json(result, { status: 200 });
  } catch (err: any) {
    logError('po-merge-adhoc-failed', { error: err?.message ?? String(err) });
    return NextResponse.json(
      { error: err?.message ?? 'Erreur interne' },
      { status: 500 },
    );
  }
}
