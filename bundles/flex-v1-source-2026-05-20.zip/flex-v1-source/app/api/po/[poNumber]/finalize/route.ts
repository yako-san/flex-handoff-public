import { NextResponse } from 'next/server';
import { finalizePO } from '@/lib/sheets/po';

/** POST /api/po/[poNumber]/finalize — finalise la réception d'un PO. */
export async function POST(_req: Request, { params }: { params: { poNumber: string } }) {
  try {
    const result = await finalizePO(params.poNumber);
    return NextResponse.json(result);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
