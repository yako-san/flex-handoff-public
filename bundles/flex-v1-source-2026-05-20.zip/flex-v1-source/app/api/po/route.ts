import { NextResponse } from 'next/server';
import { getPOs, createPO } from '@/lib/sheets/po';
import cache, { CACHE_KEYS } from '@/lib/cache';
import { parseBody } from '@/lib/validate';
import { POCreateSchema } from '@/lib/schemas/po';

/** GET /api/po — liste tous les PO. ?refresh=1 pour bypass cache */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    if (searchParams.get('refresh') === '1') await cache.del(CACHE_KEYS.POS);
    const pos = await getPOs();
    return NextResponse.json(pos);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** POST /api/po — crée un nouveau PO. v1.1.7 — Item 4 : validation zod. */
export async function POST(request: Request) {
  const parsed = await parseBody(request, POCreateSchema);
  if (!parsed.ok) return parsed.response;
  try {
    await createPO(parsed.data);
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
