/**
 * POST /api/po/adhoc-receive — réception ad-hoc d'un item sans PO préalable.
 *
 * Cas d'usage : scan d'un SKU à l'atelier pour un item arrivé hors flow
 * fournisseur (achat magasin, dépôt client, dépannage). Crée une PO
 * `ADHOC-YYYYMMDD-HHMMSS` en status RECU directement et alimente le stock.
 *
 * Body :
 * ```
 * {
 *   sku       : string,    // requis (le SKU scanné)
 *   nom       : string,    // requis (nom de la pièce)
 *   qte       : number,    // requis, > 0
 *   fournisseur : string,  // requis
 *   prixAchat : number,    // optionnel, défaut 0
 *   pieceId   ?: string,   // optionnel — si match catalogue déjà fait côté UI
 *   notes     ?: string,   // optionnel
 * }
 * ```
 *
 * Réponse :
 * ```
 * { poNumber, applied: number, createdPiece?: { ... } }
 * ```
 */
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { createAdhocPO } from '@/lib/sheets/po';
import { logError } from '@/lib/log';

export const maxDuration = 30;

export async function POST(req: Request) {
  try {
    const session = await auth();
    if (!session) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const sku         = String(body?.sku ?? '').trim();
    const nom         = String(body?.nom ?? '').trim();
    const fournisseur = String(body?.fournisseur ?? '').trim();
    const qte         = Number(body?.qte);
    const prixAchat   = Number(body?.prixAchat ?? 0);
    const pieceId     = String(body?.pieceId ?? '').trim() || undefined;
    const notes       = String(body?.notes ?? '').trim() || undefined;

    // Validation
    if (!nom)         return NextResponse.json({ error: 'nom requis' }, { status: 400 });
    if (!fournisseur) return NextResponse.json({ error: 'fournisseur requis' }, { status: 400 });
    if (!Number.isFinite(qte) || qte <= 0) {
      return NextResponse.json({ error: 'qte doit être un nombre > 0' }, { status: 400 });
    }
    if (!Number.isFinite(prixAchat) || prixAchat < 0) {
      return NextResponse.json({ error: 'prixAchat doit être un nombre ≥ 0' }, { status: 400 });
    }

    const result = await createAdhocPO({
      fournisseur,
      pieceId,
      sku,
      nom,
      qte,
      prixAchat,
      notes,
    });

    return NextResponse.json({
      poNumber     : result.poNumber,
      applied      : result.sync.applied,
      totalDelta   : result.sync.totalDelta,
      createdPiece : result.sync.createdPieces[0] ?? null,
    }, { status: 201 });
  } catch (err: any) {
    logError('adhoc-receive-failed', { error: err?.message ?? String(err) });
    return NextResponse.json(
      { error: err?.message ?? 'Erreur interne' },
      { status: 500 },
    );
  }
}
