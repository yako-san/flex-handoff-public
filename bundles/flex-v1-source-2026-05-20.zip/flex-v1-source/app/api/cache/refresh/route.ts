import { NextResponse } from 'next/server';
import cache, { CACHE_KEYS } from '@/lib/cache';

/** POST /api/cache/refresh — invalide tout le cache serveur */
export async function POST() {
  const keys = Object.values(CACHE_KEYS);
  await Promise.all(keys.map(k => cache.del(k)));
  return NextResponse.json({ cleared: keys, ok: true });
}
