import { NextRequest, NextResponse } from 'next/server';
import { repairBdcTotaux, getBDC } from '@/lib/sheets/bdc';
import { requireAdmin } from '@/lib/auth/requireAdmin';

/**
 * POST /api/admin/repair-bdt/[id] — force le recalcul des totaux d'un BDT.
 * Crée la ligne TOT si absente (cas observé sur BDT 0121).
 *
 * v1.1.2 — Item 8 audit sécurité : endpoint RETIRÉ du middleware publicPaths
 * et protégé par requireAdmin(). Auparavant n'importe qui pouvait recalculer
 * les totaux d'un BDT en prod (DoS potentiel sur quota Sheets).
 *
 * Usage : POST https://<host>/api/admin/repair-bdt/0121
 * Réponse : { ok: true, totalServices, totalPieces, items }
 */
export async function POST(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status },
    );
  }

  const id = params.id;
  if (!id) return NextResponse.json({ error: 'id manquant' }, { status: 400 });

  try {
    await repairBdcTotaux(id);
    const bdc = await getBDC(id);
    if (!bdc) {
      return NextResponse.json(
        { error: `BDT ${id} introuvable après réparation` },
        { status: 404 },
      );
    }
    return NextResponse.json({
      ok           : true,
      bdcId        : id,
      totalServices: bdc.totalServices,
      totalPieces  : bdc.totalPieces,
      itemsCount   : bdc.items.length,
      // Debug : détail de chaque item pour identifier où sont les prix
      items: bdc.items.map(it => ({
        row    : it._row,
        service: it.service ? { nom: it.service.nom, prix: it.service.prix } : null,
        piece  : it.piece   ? { nom: it.piece.nom, prix: it.piece.prix, qte: it.piece.qte, sousTotal: it.piece.sousTotal } : null,
      })),
    });
  } catch (err: any) {
    return NextResponse.json(
      { error: err?.message ?? 'Erreur réparation' },
      { status: 500 },
    );
  }
}

/** GET supportée aussi (pour curl simple depuis navigateur). */
export async function GET(req: NextRequest, ctx: { params: { id: string } }) {
  return POST(req, ctx);
}
