/**
 * POST /api/admin/cleanup-test-ventes — supprime toutes les ventes
 * dont le client est `_TEST_CLIENT_` (orphelines du harness test-stock).
 *
 * Body (optionnel) : { dryRun?: boolean } (default false).
 * Renvoie la liste des ventes supprimées + l'état stock après recompute.
 */
import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getVentes, deleteVente } from '@/lib/sheets/ventes';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';
import { parseBody } from '@/lib/validate';
import { CleanupTestVentesSchema } from '@/lib/schemas/admin';

const TEST_CLIENT = '_TEST_CLIENT_';

export async function POST(req: NextRequest) {
  // v1.1.2 — Item 1 : harnais qui supprime potentiellement des ventes
  // réelles si quelqu'un crée un client `_TEST_CLIENT_` par erreur → admin.
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status },
    );
  }

  // v1.1.7 — Item 4 : validation zod (body optionnel)
  const parsed = await parseBody(req, CleanupTestVentesSchema);
  if (!parsed.ok) return parsed.response;
  const dryRun = parsed.data.dryRun === true;

  try {

    const ventes = await getVentes();
    const orphans = ventes.filter(v => v.client === TEST_CLIENT);

    if (dryRun) {
      return NextResponse.json({
        dryRun: true,
        wouldDelete: orphans.map(v => ({
          venteId: v.venteId,
          date: v.date,
          factureDate: v.factureDate ?? null,
          itemCount: v.items.length,
          totalQte: v.items.reduce((s, it) => s + it.qte, 0),
        })),
      });
    }

    const before = await snapshotStock();
    const deleted: string[] = [];
    for (const v of orphans) {
      try {
        await deleteVente(v.venteId);
        deleted.push(v.venteId);
      } catch (err: any) {
        console.warn('[cleanup-test-ventes]', v.venteId, err?.message);
      }
    }
    await safeRecomputeStockState(before, 'VENTE');

    return NextResponse.json({
      dryRun: false,
      deleted,
      remaining: orphans.length - deleted.length,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? String(err) }, { status: 500 });
  }
}
