/**
 * GET /api/admin/refresh-token — affiche le refresh_token Google de la
 * session actuelle, pour pouvoir le copier dans la Vercel env var
 * `GOOGLE_OWNER_REFRESH_TOKEN`.
 *
 * SÉCURITÉ : accessible uniquement à l'admin (yako.cyclo@gmail.com ou
 * email dans la liste admin_emails). Retour JSON — la valeur ne doit
 * être copiée qu'une fois, puis la env var configurée dans Vercel, puis
 * cet endpoint n'a plus à être appelé (ni vu par qui que ce soit).
 */
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { requireAdmin } from '@/lib/auth/requireAdmin';

export async function GET() {
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json({ error: check.error }, { status: check.status });
  }

  const session = await auth();
  const refreshToken = session?.googleRefreshToken as string | undefined;

  if (!refreshToken) {
    return NextResponse.json({
      error: 'Aucun refresh_token dans la session actuelle. Déconnecte-toi puis reconnecte-toi pour que Google émette un nouveau refresh_token (indispensable après ajout d\'un scope).',
    }, { status: 400 });
  }

  return NextResponse.json({
    refreshToken,
    usage: 'Copie cette valeur dans Vercel → Settings → Environment Variables → ajouter GOOGLE_OWNER_REFRESH_TOKEN. Puis redéploie.',
  });
}
