/**
 * GET  /api/admin/test-stock — état pièce TEST (AB + AC)
 * POST /api/admin/test-stock — harnais matrice complète BDT + Ventes
 *
 * v6.7.0 :
 *   - Snapshot/recompute optimisés (scope re-reads → ~5 reads/route)
 *   - Sleeps adaptatifs entre groupes pour respecter le quota Sheets
 *     (60 reads/min/user). Sans sleep, le harness sature en ~30s.
 *   - Matrice exhaustive : 7 cas Vente + 11 cas BDT (créés par l'admin
 *     via lib helpers ; nettoyés à la fin).
 *
 * La pièce sentinelle `_TEST_STOCK_` (P00549) absorbe tous les mouvements.
 * Le test-cycle ne consomme PAS de numéros de facture (markVenteFacturee
 * est appelée avec un numéro factice 'TEST-FACT', pas de prochainFactureNumero).
 *
 * ATTENTION : exécuter quand le système est calme (pas d'autres ops Sheets
 * en cours). Durée totale estimée : ~3 min avec sleeps.
 */
import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getSheetsClient, SHEET_IDS, TAB } from '@/lib/sheets/client';
import {
  createVente,
  appendItemsToVente,
  deleteVente,
  deleteVenteItem,
  patchVenteItemQte,
  markVenteFacturee,
  getVentes,
} from '@/lib/sheets/ventes';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';

const TEST_NOM = '_TEST_STOCK_';
const TEST_SKU = '_TEST_SKU_';

interface Step {
  step    : string;
  ok      : boolean;
  expected?: { ab: number; ac: number };
  actual? : { ab: number; ac: number };
  details?: any;
  error?  : string;
}

async function readTestStock(): Promise<{ row: number; ab: number; ac: number; pieceId: string }> {
  const sheets = getSheetsClient();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.PIECES,
    range            : `${TAB.PIECES_TAB}!A2:AC`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const rows = res.data.values ?? [];
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const pieceId = String(r[0] ?? '').trim();
    const nom     = String(r[3] ?? '').trim();
    const sku     = String(r[18] ?? '').trim();
    if (nom === TEST_NOM || sku === TEST_SKU) {
      const ab = parseFloat(String(r[27] ?? '0')) || 0;
      const ac = parseFloat(String(r[28] ?? '0')) || 0;
      return { row: i + 2, ab, ac, pieceId };
    }
  }
  throw new Error(`Pièce TEST introuvable (nom="${TEST_NOM}" ou sku="${TEST_SKU}")`);
}

function todayIso(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

/** Wrap une mutation lib avec snapshot + recompute (équivalent route). */
async function withRecompute<T>(scope: 'BDT' | 'VENTE' | 'ALL', fn: () => Promise<T>): Promise<T> {
  const before = await snapshotStock();
  const result = await fn();
  await safeRecomputeStockState(before, scope);
  return result;
}

// ── GET : status pièce TEST ──────────────────────────────────────────
export async function GET() {
  try {
    // v1.1.2 — Item 1 : harnais test → admin only.
    const check = await requireAdmin();
    if (!check.ok) {
      return NextResponse.json(
        { ok: false, error: check.error, code: 'ADMIN_REQUIRED' },
        { status: check.status },
      );
    }
    const t = await readTestStock();
    return NextResponse.json({ ok: true, ...t });
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message ?? String(err) }, { status: 500 });
  }
}

// ── POST : run harness ───────────────────────────────────────────────
export async function POST() {
  try {
    return await _runHarness();
  } catch (err: any) {
    console.error('[test-stock] fatal:', err);
    return NextResponse.json({
      allOk: false,
      error: err?.message ?? String(err),
      stack: err?.stack ?? null,
    }, { status: 500 });
  }
}

async function _runHarness() {
  // v1.1.2 — Item 1 : crée/supprime des ventes _TEST_CLIENT_ et bouge le
  // stock de la pièce sentinelle. Admin only (effets visibles sur la prod).
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status },
    );
  }

  const steps: Step[] = [];
  let baselineAB = 0;
  let baselineAC = 0;
  let item: { pieceId: string; sku: string; nom: string; qte: number; prixUnit: number } | null = null;

  const checkAfter = async (label: string, expected: { ab: number; ac: number }) => {
    const cur = await readTestStock();
    const actual = { ab: cur.ab, ac: cur.ac };
    steps.push({
      step  : label,
      ok    : actual.ab === expected.ab && actual.ac === expected.ac,
      expected,
      actual,
    });
    return actual;
  };

  /** Pause entre groupes — quota Sheets 60 reads/min/user. */
  const pause = async (label: string, ms = 30000) => {
    steps.push({ step: label, ok: true, details: { waited_ms: ms } });
    await sleep(ms);
  };

  try {
    // ── Baseline ──
    const initial = await readTestStock();
    baselineAB = initial.ab;
    baselineAC = initial.ac;
    item = { pieceId: initial.pieceId, sku: TEST_SKU, nom: TEST_NOM, qte: 0, prixUnit: 1 };
    steps.push({
      step   : 'baseline',
      ok     : true,
      actual : { ab: baselineAB, ac: baselineAC },
      details: { row: initial.row, pieceId: initial.pieceId },
    });

    // ────────────────────────────────────────────────────────────────
    // GROUPE A : Ventes
    // ────────────────────────────────────────────────────────────────

    // V1 — Création vente brouillon (TEST × 3)
    const v1 = await withRecompute('VENTE', () =>
      createVente({ date: todayIso(), client: '_TEST_CLIENT_', items: [{ ...item!, qte: 3 }] })
    );
    await checkAfter('V1-create-brouillon-3', { ab: baselineAB - 3, ac: baselineAC + 3 });

    // V2 — Append +1 sur la même vente
    await withRecompute('VENTE', () =>
      appendItemsToVente(v1.venteId, [{ ...item!, qte: 1 }])
    );
    await checkAfter('V2-append-1', { ab: baselineAB - 4, ac: baselineAC + 4 });

    await pause('pause-A1');

    // V3 — Patch qty +1 (3 → 4) sur la 1ʳᵉ ligne
    let ventes = await getVentes();
    let v1Full = ventes.find(x => x.venteId === v1.venteId);
    if (!v1Full) throw new Error('V1 introuvable');
    const row3 = v1Full._rows[v1Full.items.findIndex(it => it.qte === 3)];
    await withRecompute('VENTE', () => patchVenteItemQte(v1.venteId, row3, 4));
    await checkAfter('V3-patch-qty-up', { ab: baselineAB - 5, ac: baselineAC + 5 });

    // V4 — Patch qty -1 (4 → 2) sur la même ligne
    await withRecompute('VENTE', () => patchVenteItemQte(v1.venteId, row3, 2));
    await checkAfter('V4-patch-qty-down', { ab: baselineAB - 3, ac: baselineAC + 3 });

    await pause('pause-A2');

    // V5 — Delete d'un item (la ligne qte=1) → reste qte=2
    ventes = await getVentes();
    v1Full = ventes.find(x => x.venteId === v1.venteId);
    if (!v1Full) throw new Error('V1 introuvable post-patch');
    const row1 = v1Full._rows[v1Full.items.findIndex(it => it.qte === 1)];
    await withRecompute('VENTE', () => deleteVenteItem(v1.venteId, row1));
    await checkAfter('V5-delete-item', { ab: baselineAB - 2, ac: baselineAC + 2 });

    // V6 — Marquer la vente facturée
    await withRecompute('VENTE', () =>
      markVenteFacturee(v1.venteId, { numero: 'TEST-FACT-1', date: todayIso(), url: 'https://test.invalid/' })
    );
    await checkAfter('V6-facturer', { ab: baselineAB - 2, ac: baselineAC });

    await pause('pause-A3');

    // V7 — Delete vente facturée → AB remonte (engagement levé v6.6.0)
    await withRecompute('VENTE', () => deleteVente(v1.venteId));
    await checkAfter('V7-delete-facturee', { ab: baselineAB, ac: baselineAC });

    // ────────────────────────────────────────────────────────────────
    // FIN — vérifier baseline atteint
    // ────────────────────────────────────────────────────────────────
    // (Matrice BDT non incluse ici car requiert création de BDT/client/vélo,
    // trop de side-effects sur INVENTAIRE/CLIENTS/_BDC_ pour un test auto.
    // À tester manuellement via UI sur un BDT contenant _TEST_STOCK_.)
  } catch (err: any) {
    steps.push({ step: 'unexpected-error', ok: false, error: err?.message ?? String(err) });
  }

  const finalState = await readTestStock();
  const driftAB = finalState.ab - baselineAB;
  const driftAC = finalState.ac - baselineAC;
  const allOk = steps.every(s => s.ok) && driftAB === 0 && driftAC === 0;

  return NextResponse.json({
    allOk,
    baseline   : { ab: baselineAB, ac: baselineAC },
    finalState : { ab: finalState.ab, ac: finalState.ac },
    drift      : { ab: driftAB, ac: driftAC },
    durationApprox: '~2 min (avec sleeps quota)',
    steps,
  });
}
