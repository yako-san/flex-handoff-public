/**
 * POST /api/admin/migrate-bdc-pceid
 *
 * Migration one-shot — backfill de la colonne O (`PCE_ID`) dans l'onglet
 * BONS DE COMMANDES. Pour chaque ligne ITEM qui contient un nom de pièce
 * (col P) mais pas de pieceId (col O), tente de matcher le nom à une
 * pièce du catalogue et y écrit le pieceId.
 *
 * Préalable : l'admin doit avoir écrit le header `PCE_ID` dans la
 * cellule O1 de l'onglet BONS DE COMMANDES. Le code ne touche pas O1.
 *
 * Idempotent : peut être ré-exécuté ; ne ré-écrit pas les lignes déjà
 * mappées. Les pièces renommées qui n'ont plus de match exact restent
 * orphelines (`unmatched`) — l'admin doit corriger à la main.
 *
 * Logique de matching :
 *   1. Normalise le nom du BDT (retire stock, préfixes décoratifs, trim)
 *   2. Cherche un nom catalogue avec match exact (case insensitive)
 *   3. Si plusieurs matches → ambigu, skip (rapporté dans la réponse)
 *
 * Réponse :
 *   { totalItemRows, alreadyMapped, matched, unmatched, ambiguous,
 *     updates: [{ row, nom, pieceId }] }
 *
 * Admin only — fail-safe à yako.cyclo@gmail.com.
 */
import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import {
  getSheetsClient,
  SHEET_IDS,
  TAB,
  BDC_COL,
  BDC_TAG,
  ROW,
} from '@/lib/sheets/client';
import { getPieces } from '@/lib/sheets/catalogue';
import { pceNomClean, stripIconPrefix } from '@/lib/utils/pieces';
import { invalidateBDCsCache } from '@/lib/sheets/bdc';

export const maxDuration = 60;

/** Normalisation pour matching nom BDT ↔ nom catalogue. */
function normalizeName(raw: string): string {
  return stripIconPrefix(pceNomClean(raw)).toLowerCase().trim();
}

/** Convertit un index de colonne 1-based en lettre Sheets (A=1, O=15…). */
function colLetter(col1Based: number): string {
  let n = col1Based;
  let letter = '';
  while (n > 0) {
    const rem = (n - 1) % 26;
    letter = String.fromCharCode(65 + rem) + letter;
    n = Math.floor((n - 1) / 26);
  }
  return letter;
}

export async function POST() {
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status },
    );
  }

  try {
    const sheets = getSheetsClient();

    // 1. Lire toutes les pièces du catalogue → index nom normalisé → pieceId
    const pieces = await getPieces();
    const byName = new Map<string, string[]>();  // nom normalisé → pieceId(s)
    for (const p of pieces) {
      if (!p.nom || !p.pieceId) continue;
      const key = normalizeName(p.nom);
      if (!key) continue;
      const list = byName.get(key) ?? [];
      list.push(p.pieceId);
      byName.set(key, list);
    }

    // 2. Lire toutes les lignes BDT (A:W pour avoir PCE_ID col O + CMD_NOTE col W)
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.BDC}!A${ROW.BDC_INS}:W`,
      valueRenderOption: 'UNFORMATTED_VALUE',
    });
    const rows = res.data.values ?? [];

    // 3. Parcourir les lignes ITEM avec PCE (nom) mais sans PCE_ID
    const colO = colLetter(BDC_COL.PCE_ID);
    const updates: { row: number; nom: string; pieceId: string }[] = [];
    const unmatchedNames: string[] = [];
    const ambiguousNames: string[] = [];
    let totalItemRows = 0;
    let alreadyMapped = 0;

    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      const tag = String(r[BDC_COL.TAG - 1] ?? '').trim();
      if (tag !== BDC_TAG.ITEM) continue;

      const pceNom = String(r[BDC_COL.PCE - 1] ?? '').trim();
      if (!pceNom) continue;  // ligne ITEM service-only

      totalItemRows++;

      const existingId = String(r[BDC_COL.PCE_ID - 1] ?? '').trim();
      if (existingId) { alreadyMapped++; continue; }

      const key = normalizeName(pceNom);
      const ids = byName.get(key);
      if (!ids || ids.length === 0) {
        unmatchedNames.push(pceNom);
        continue;
      }
      if (ids.length > 1) {
        ambiguousNames.push(`${pceNom} → [${ids.join(', ')}]`);
        continue;
      }

      // Row absolue dans la sheet = ROW.BDC_INS + i
      const sheetRow = ROW.BDC_INS + i;
      updates.push({ row: sheetRow, nom: pceNom, pieceId: ids[0] });
    }

    // 4. Batch-write des col O qui ont matché
    if (updates.length > 0) {
      const data = updates.map(u => ({
        range : `${TAB.BDC}!${colO}${u.row}`,
        values: [[u.pieceId]],
      }));
      await sheets.spreadsheets.values.batchUpdate({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        requestBody  : { valueInputOption: 'RAW', data },
      });
      await invalidateBDCsCache();
    }

    return NextResponse.json({
      totalItemRows,
      alreadyMapped,
      matched   : updates.length,
      unmatched : unmatchedNames.length,
      ambiguous : ambiguousNames.length,
      // Échantillons pour diag (max 20 chacun)
      sample_unmatched: unmatchedNames.slice(0, 20),
      sample_ambiguous: ambiguousNames.slice(0, 20),
      updates   : updates.slice(0, 50),  // max 50 pour limiter taille réponse
    });
  } catch (err: any) {
    console.error('[migrate-bdc-pceid]', err);
    return NextResponse.json(
      { error: err?.message ?? 'Erreur interne', stack: err?.stack ?? null },
      { status: 500 },
    );
  }
}
