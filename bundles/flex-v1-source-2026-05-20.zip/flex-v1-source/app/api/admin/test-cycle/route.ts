/**
 * POST /api/admin/test-cycle — harnais de test automatisé pour le cycle
 * archivage / désarchivage / restauration. Dev only.
 *
 * Body : { id: string }
 *
 * Le test :
 *   1. Capture l'état complet du BDC (INVENTAIRE row + BDC rows)
 *   2. Snapshot manuel via snapshotBDC (baseline)
 *   3. archiverBDC → vérifie ARCHIVES (notes col W, items JSON col X, status)
 *   4. desarchiverBDC → vérifie INVENTAIRE (status ÉVAL., notes préservées,
 *      checkboxes BON correctes, items FAIT=false)
 *   5. archiverBDCRefuse → vérifie status REFUSÉ
 *   6. desarchiverBDC → vérifie retour à ÉVAL.
 *   7. snapshotBDC + restaurer via les rows snapshotées (vérif round-trip)
 *
 * En finally : restaure TOUJOURS l'état initial capturé à l'étape 1, peu
 * importe les erreurs intermédiaires. 0109 (ou autre BDC test) revient à
 * son état d'origine après le test.
 *
 * Auth : disabled in development. Returns 403 in production.
 */
import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getSheetsClient, SHEET_IDS, TAB, ROW } from '@/lib/sheets/client';
import {
  archiverBDC,
  archiverBDCRefuse,
  desarchiverBDC,
  snapshotBDC,
} from '@/lib/sheets/bdc';

interface BdcCapture {
  invRow      : unknown[];           // ligne INVENTAIRE A:X
  invRowNum   : number;
  bdcRows     : unknown[][];         // toutes les lignes BDC du BON au SEP
  bonRowNum   : number;
  sepRowNum   : number;
}

/** Pause pour laisser le quota Sheets se reconstituer (60 reads/min/user). */
async function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms));
}

type Step = {
  step: string;
  ok: boolean;
  details?: any;
  error?: string;
};

async function captureBdcState(bdcId: string): Promise<BdcCapture> {
  const sheets = getSheetsClient();

  // INVENTAIRE row
  const invRes = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.INVENTAIRE}!A1:X100`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const invAll = invRes.data.values ?? [];
  const invRowIdx = invAll.findIndex(r => String(r[3] ?? '').trim() === bdcId);
  if (invRowIdx < 0) throw new Error(`BDC ${bdcId} introuvable dans INVENTAIRE`);
  const invRow = invAll[invRowIdx];
  while (invRow.length < 24) invRow.push('');

  // BDC rows BON→SEP
  const bdcRes = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!A1:W500`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const bdcAll = bdcRes.data.values ?? [];
  const bonIdx = bdcAll.findIndex(r => r[0] === 'BON' && String(r[1] ?? '').trim() === bdcId);
  if (bonIdx < 0) throw new Error(`BON ${bdcId} introuvable dans BDC`);
  let sepIdx = -1;
  for (let i = bonIdx + 1; i < bdcAll.length; i++) {
    if (bdcAll[i][0] === 'SEP') { sepIdx = i; break; }
  }
  if (sepIdx < 0) throw new Error(`SEP non trouvé après BON ${bdcId}`);
  const bdcRows = bdcAll.slice(bonIdx, sepIdx + 1).map(r => {
    const row = [...r];
    while (row.length < 23) row.push('');
    return row.slice(0, 23);
  });

  return {
    invRow      : invRow.slice(0, 24),
    invRowNum   : invRowIdx + 1,
    bdcRows,
    bonRowNum   : bonIdx + 1,
    sepRowNum   : sepIdx + 1,
  };
}

async function writeBdcState(bdcId: string, capture: BdcCapture): Promise<void> {
  const sheets = getSheetsClient();

  // 1. Trouver la ligne INVENTAIRE actuelle pour ce BDC (peut avoir changé)
  let invCur = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.INVENTAIRE}!A1:X100`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  let invAll = invCur.data.values ?? [];
  let invIdx = invAll.findIndex(r => String(r[3] ?? '').trim() === bdcId);

  // Si le BDC est encore archivé (test interrompu en plein vol), il faut
  // d'abord le désarchiver pour qu'il revienne en INVENTAIRE.
  if (invIdx < 0) {
    const archive = await findArchiveRow(bdcId);
    if (archive) {
      await desarchiverBDC(bdcId, archive.row);
      // Re-lire INVENTAIRE
      invCur = await sheets.spreadsheets.values.get({
        spreadsheetId    : SHEET_IDS.INVENTAIRE,
        range            : `${TAB.INVENTAIRE}!A1:X100`,
        valueRenderOption: 'UNFORMATTED_VALUE',
      });
      invAll = invCur.data.values ?? [];
      invIdx = invAll.findIndex(r => String(r[3] ?? '').trim() === bdcId);
    }
  }

  if (invIdx >= 0) {
    // Réécrire la ligne existante
    const targetRow = invIdx + 1;
    await sheets.spreadsheets.values.update({
      spreadsheetId   : SHEET_IDS.INVENTAIRE,
      range           : `${TAB.INVENTAIRE}!A${targetRow}:X${targetRow}`,
      valueInputOption: 'RAW',
      requestBody     : { values: [capture.invRow] },
    });
  } else {
    throw new Error(`writeBdcState: BDC ${bdcId} introuvable dans INVENTAIRE ni ARCHIVES`);
  }

  // 2. Trouver la ligne BDC actuelle
  const bdcCur = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `${TAB.BDC}!A1:W500`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const bdcAll = bdcCur.data.values ?? [];
  const bonIdx = bdcAll.findIndex(r => r[0] === 'BON' && String(r[1] ?? '').trim() === bdcId);
  if (bonIdx < 0) {
    throw new Error(`Restore BDC: BON ${bdcId} introuvable — impossible de restaurer en place`);
  }
  let sepIdx = -1;
  for (let i = bonIdx + 1; i < bdcAll.length; i++) {
    if (bdcAll[i][0] === 'SEP') { sepIdx = i; break; }
  }
  if (sepIdx < 0) throw new Error(`Restore BDC: SEP non trouvé`);

  // Trouver le sheetId BDC
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    fields       : 'sheets.properties',
  });
  const bdcSheet = meta.data.sheets?.find(s => s.properties?.title === TAB.BDC);
  const bdcSheetId = bdcSheet?.properties?.sheetId;
  if (bdcSheetId === undefined) throw new Error('Onglet BDC introuvable');

  const startIdx = bonIdx;
  const endIdxExcl = sepIdx + 1;

  // Supprimer puis insérer les nouvelles lignes
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        deleteDimension: { range: { sheetId: bdcSheetId, dimension: 'ROWS', startIndex: startIdx, endIndex: endIdxExcl } },
      }],
    },
  });
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SHEET_IDS.INVENTAIRE,
    requestBody  : {
      requests: [{
        insertDimension: {
          range: { sheetId: bdcSheetId, dimension: 'ROWS', startIndex: startIdx, endIndex: startIdx + capture.bdcRows.length },
          inheritFromBefore: true,
        },
      }],
    },
  });
  const newRowNum = startIdx + 1;
  await sheets.spreadsheets.values.update({
    spreadsheetId   : SHEET_IDS.INVENTAIRE,
    range           : `${TAB.BDC}!A${newRowNum}:W${newRowNum + capture.bdcRows.length - 1}`,
    valueInputOption: 'RAW',
    requestBody     : { values: capture.bdcRows },
  });
}

async function findArchiveRow(bdcId: string): Promise<{ row: number; data: unknown[] } | null> {
  const sheets = getSheetsClient();
  const r = await sheets.spreadsheets.values.get({
    spreadsheetId    : SHEET_IDS.INVENTAIRE,
    range            : `'${TAB.ARCHIVES}'!A1:X100`,
    valueRenderOption: 'UNFORMATTED_VALUE',
  });
  const all = r.data.values ?? [];
  const idx = all.findIndex(row => String(row[3] ?? '').trim() === bdcId);
  if (idx < 0) return null;
  return { row: idx + 1, data: all[idx] };
}

export async function POST(req: NextRequest) {
  // v1.1.2 — Item 1 + 15 : harnais qui archive/désarchive un BDT réel
  // (effet de bord sur INVENTAIRE + BDC + ARCHIVES). Maintenant double-gate :
  //  1) admin (requireAdmin), 2) opt-in via env var ENABLE_DEV_ENDPOINTS=1.
  // Avant : seul check NODE_ENV !== 'production' → dangereux si déployé en
  // preview Vercel avec la même DB que prod.
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status },
    );
  }
  if (process.env.ENABLE_DEV_ENDPOINTS !== '1') {
    return NextResponse.json(
      { error: 'Endpoint désactivé — exporter ENABLE_DEV_ENDPOINTS=1 pour activer' },
      { status: 403 },
    );
  }

  const body = await req.json().catch(() => ({}));
  const id = String(body.id ?? '0109').trim();
  if (!id) return NextResponse.json({ error: 'id manquant' }, { status: 400 });

  const steps: Step[] = [];
  let initial: BdcCapture | null = null;

  try {
    // ──────────────────────────────────────────────────────────────────
    // STEP 1 — Capture initiale
    // ──────────────────────────────────────────────────────────────────
    initial = await captureBdcState(id);
    steps.push({
      step: 'capture-initial',
      ok: true,
      details: {
        invRowNum  : initial.invRowNum,
        invStatus  : initial.invRow[2],
        invNote    : String(initial.invRow[20] ?? '').substring(0, 60),
        bdcRows    : initial.bdcRows.length,
        bonRow     : initial.bonRowNum,
        sepRow     : initial.sepRowNum,
        bonChecks  : initial.bdcRows[0] ? {
          D: initial.bdcRows[0][3],
          E: initial.bdcRows[0][4],
          F: initial.bdcRows[0][5],
          G: initial.bdcRows[0][6],
        } : null,
      },
    });

    // ──────────────────────────────────────────────────────────────────
    // STEP 2 — Snapshot manuel (baseline append-only)
    // ──────────────────────────────────────────────────────────────────
    await snapshotBDC(id, 'manual', 'test-cycle baseline');
    steps.push({ step: 'snapshot-baseline', ok: true });

    // ──────────────────────────────────────────────────────────────────
    // STEP 3 — Archive normal
    // ──────────────────────────────────────────────────────────────────
    await archiverBDC(id);
    const arch1 = await findArchiveRow(id);
    if (!arch1) throw new Error('Archive non trouvée après archiverBDC');

    // Vérifications archive normale :
    //   col C status (peut être ce qu'il était avant — REÇU, ÉVAL., LIVRÉ, etc.)
    //   col W (idx 22) = notes internes préservées
    //   col X (idx 23) = JSON BDC rows
    const arch1Notes  = String(arch1.data[22] ?? '');
    const arch1Json   = String(arch1.data[23] ?? '');
    let arch1JsonOk = false;
    let arch1JsonItems = 0;
    try {
      const parsed = JSON.parse(arch1Json);
      arch1JsonOk = Array.isArray(parsed) && parsed.length > 0;
      arch1JsonItems = arch1JsonOk ? parsed.filter((r: any) => r[0] === 'ITEM').length : 0;
    } catch {}

    const initialNote = String(initial.invRow[20] ?? '');
    const initialItems = initial.bdcRows.filter(r => r[0] === 'ITEM').length;

    steps.push({
      step: 'archive-normal',
      ok: arch1JsonOk && arch1JsonItems === initialItems && arch1Notes === initialNote,
      details: {
        archiveRow      : arch1.row,
        statusInArchive : arch1.data[2],
        notesMatch      : arch1Notes === initialNote,
        notesPreview    : arch1Notes.substring(0, 60),
        jsonValid       : arch1JsonOk,
        itemsInJson     : arch1JsonItems,
        itemsExpected   : initialItems,
      },
    });

    // ──────────────────────────────────────────────────────────────────
    // STEP 4 — Désarchive normal
    // ──────────────────────────────────────────────────────────────────
    await desarchiverBDC(id, arch1.row);
    const post4 = await captureBdcState(id);

    // Vérifications désarchive :
    //   - status ÉVAL.
    //   - col F (date travaux) vide
    //   - col G (date sortie) vide
    //   - notes préservées
    //   - BON checkbox D=true, E/F/G=false
    //   - tous les ITEMs L=false
    const bonRow = post4.bdcRows.find(r => r[0] === 'BON');
    const items4 = post4.bdcRows.filter(r => r[0] === 'ITEM');
    const allItemsNotFait = items4.every(r => r[11] === false || r[11] === '' || r[11] === 'FALSE');
    const bonChecksOk = !!(bonRow && bonRow[3] === true && !bonRow[4] && !bonRow[5] && !bonRow[6]);

    steps.push({
      step: 'desarchive-normal',
      ok: post4.invRow[2] === 'ÉVAL.'
        && !post4.invRow[5]
        && !post4.invRow[6]
        && String(post4.invRow[20] ?? '') === initialNote
        && bonChecksOk
        && allItemsNotFait
        && items4.length === initialItems,
      details: {
        status        : post4.invRow[2],
        dateTravaux   : post4.invRow[5],
        dateSortie    : post4.invRow[6],
        notesMatch    : String(post4.invRow[20] ?? '') === initialNote,
        notesPreview  : String(post4.invRow[20] ?? '').substring(0, 60),
        bonChecks     : bonRow ? { D: bonRow[3], E: bonRow[4], F: bonRow[5], G: bonRow[6] } : null,
        bonChecksOk,
        itemsCount    : items4.length,
        itemsExpected : initialItems,
        allItemsNotFait,
      },
    });

    // Pause pour respecter le quota Sheets (60 reads/min) — un cycle
    // archive+desarchive consomme ~20-25 reads, donc on attend large.
    steps.push({ step: 'pause-1', ok: true, details: { waited_ms: 65000 } });
    await sleep(65000);

    // ──────────────────────────────────────────────────────────────────
    // STEP 5 — Archive REFUSÉ
    // ──────────────────────────────────────────────────────────────────
    await archiverBDCRefuse(id);
    const arch2 = await findArchiveRow(id);
    if (!arch2) throw new Error('Archive REFUSÉ non trouvée');
    steps.push({
      step: 'archive-refuse',
      ok: arch2.data[2] === 'REFUSÉ',
      details: {
        archiveRow      : arch2.row,
        statusInArchive : arch2.data[2],
      },
    });

    // Pause supplémentaire avant le second désarchive (quota friendly)
    steps.push({ step: 'pause-2', ok: true, details: { waited_ms: 65000 } });
    await sleep(65000);

    // ──────────────────────────────────────────────────────────────────
    // STEP 6 — Désarchive depuis REFUSÉ
    // ──────────────────────────────────────────────────────────────────
    await desarchiverBDC(id, arch2.row);
    const post6 = await captureBdcState(id);
    const bonRow6 = post6.bdcRows.find(r => r[0] === 'BON');
    const items6 = post6.bdcRows.filter(r => r[0] === 'ITEM');
    const bonChecksOk6 = !!(bonRow6 && bonRow6[3] === true && !bonRow6[4] && !bonRow6[5] && !bonRow6[6]);
    steps.push({
      step: 'desarchive-from-refuse',
      ok: post6.invRow[2] === 'ÉVAL.'
        && bonChecksOk6
        && items6.length === initialItems,
      details: {
        status      : post6.invRow[2],
        bonChecks   : bonRow6 ? { D: bonRow6[3], E: bonRow6[4], F: bonRow6[5], G: bonRow6[6] } : null,
        itemsCount  : items6.length,
        notesMatch  : String(post6.invRow[20] ?? '') === initialNote,
      },
    });

  } catch (err: any) {
    steps.push({ step: 'unexpected-error', ok: false, error: err?.message ?? String(err) });
  } finally {
    // ──────────────────────────────────────────────────────────────────
    // STEP FINAL — Restauration garantie de l'état initial
    // ──────────────────────────────────────────────────────────────────
    if (initial) {
      // Si on a hit le quota, attendre 60s avant de tenter le restore final
      const lastError = steps[steps.length - 1]?.error ?? '';
      if (lastError.includes('Quota')) {
        steps.push({ step: 'wait-quota-recovery', ok: true, details: { waited_ms: 65000 } });
        await sleep(65000);
      }
      // Retry final restore avec un délai entre tentatives en cas d'erreur Sheets
      let restoreOk = false;
      let restoreErr: string | undefined;
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          await writeBdcState(id, initial);
          restoreOk = true;
          break;
        } catch (err: any) {
          restoreErr = err?.message ?? String(err);
          if (attempt < 3) await sleep(20000);
        }
      }
      steps.push({
        step: 'restore-final',
        ok: restoreOk,
        details: restoreOk ? { status: initial.invRow[2] } : undefined,
        error: restoreOk ? undefined : restoreErr,
      });
    }
  }

  const allOk = steps.every(s => s.ok);
  return NextResponse.json({
    bdcId    : id,
    allOk,
    steps,
  });
}
