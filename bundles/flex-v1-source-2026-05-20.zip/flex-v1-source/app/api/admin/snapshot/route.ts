/**
 * POST /api/admin/snapshot — déclenche un snapshot manuel d'un BDC
 *
 * Body : { id: string, note?: string }
 *
 * Sauvegarde l'état complet (BDC rows + INVENTAIRE row) dans l'onglet
 * `_BDC_BACKUPS_` avec action='manual'. À utiliser AVANT toute opération
 * risquée (édition manuelle du sheet, expérimentation, etc.).
 *
 * Authentification : NextAuth session requise.
 *
 * Usage CLI :
 *   curl -b cookies.txt -X POST http://localhost:3000/api/admin/snapshot \
 *        -H 'Content-Type: application/json' \
 *        -d '{"id":"0109","note":"avant test"}'
 */
import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { snapshotBDC } from '@/lib/sheets/bdc';
import { parseBody } from '@/lib/validate';
import { SnapshotSchema } from '@/lib/schemas/admin';

export async function POST(req: NextRequest) {
  // v1.1.2 — Item 1 : snapshot append-only dans _BDC_BACKUPS_ avec données
  // client/montants. Admin only (pas critique mais expose des données).
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status },
    );
  }

  // v1.1.7 — Item 4 : validation zod
  const parsed = await parseBody(req, SnapshotSchema);
  if (!parsed.ok) return parsed.response;
  const id   = parsed.data.id;
  const note = parsed.data.note?.trim() || 'snapshot manuel';

  try {
    await snapshotBDC(id, 'manual', note);

    return NextResponse.json({
      ok    : true,
      bdcId : id,
      action: 'manual',
      note,
    });
  } catch (err: any) {
    console.error('[snapshot]', err);
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}
