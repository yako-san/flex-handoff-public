/**
 * GET /api/admin/export-v1 — Dump complet de l'état v1 en JSON pivot.
 *
 * Usage : input pour l'outil d'import v2 (nouveau repo `flex-app`,
 * Postgres multi-tenant). Voir `lib/export/v1.ts` pour le format complet
 * et la philosophie (lossless, normalisé, multi-tenant ready).
 *
 * Authentification : NextAuth session requise (admin = liste
 * NEXTAUTH_ALLOWED_EMAILS du .env).
 *
 * Usage CLI :
 *   curl -b cookies.txt http://localhost:3000/api/admin/export-v1 \
 *        -o flex-rev-export-$(date +%Y%m%d).json
 *
 * Coût : ~12 reads Sheets en parallèle. ~5-10 s en prod.
 */
import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { buildExportV1 } from '@/lib/export/v1';
import { logError } from '@/lib/log';

// Version applicative — bump manuel quand on incrémente v7.0.x.
const APP_VERSION = 'v1.0.0';

// Pas de mise en cache HTTP — chaque appel doit être frais.
export const dynamic = 'force-dynamic';

export async function GET(_req: NextRequest) {
  try {
    // v1.1.2 — Item 1 : dump complet de l'état applicatif (clients, BDTs,
    // pièces, factures, ventes, dépenses) → données ultra-sensibles, admin only.
    const check = await requireAdmin();
    if (!check.ok) {
      return NextResponse.json(
        { error: check.error, code: 'ADMIN_REQUIRED' },
        { status: check.status },
      );
    }

    const data = await buildExportV1(APP_VERSION);

    const filename = `flex-rev-export-${data.exportedAt.slice(0, 10)}.json`;
    return new NextResponse(JSON.stringify(data, null, 2), {
      status : 200,
      headers: {
        'Content-Type'       : 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="${filename}"`,
      },
    });
  } catch (err: any) {
    logError('export-v1-failed', { error: err?.message ?? String(err) });
    return NextResponse.json(
      { error: err?.message ?? 'Erreur interne' },
      { status: 500 },
    );
  }
}
