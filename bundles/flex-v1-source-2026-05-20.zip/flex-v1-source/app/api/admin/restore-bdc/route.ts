/**
 * POST /api/admin/restore-bdc — restaure un BDC depuis un snapshot
 * GET  /api/admin/restore-bdc?id=XXXX — liste les snapshots disponibles
 *
 * Endpoint d'administration : utilise les snapshots append-only de l'onglet
 * `_BDC_BACKUPS_` pour réinjecter les lignes BON→SEP perdues d'un BDC.
 *
 * Authentification : NextAuth session requise (pas un endpoint public).
 *
 * Usage CLI :
 *   curl -b cookies.txt http://localhost:3000/api/admin/restore-bdc?id=0109
 *   curl -b cookies.txt -X POST http://localhost:3000/api/admin/restore-bdc \
 *        -H 'Content-Type: application/json' \
 *        -d '{"id":"0109","backupRow":7}'
 */
import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getSheetsClient, SHEET_IDS, TAB } from '@/lib/sheets/client';
import { parseBody } from '@/lib/validate';
import { RestoreBdcSchema } from '@/lib/schemas/admin';

interface SnapshotMeta {
  backupRow : number;
  timestamp : string;
  action    : string;
  bdcId     : string;
  clientNom : string;
  veloDesc  : string;
  itemCount : number;
  note      : string;
}

function parseItemCount(json: string): number {
  try {
    const arr = JSON.parse(json) as unknown[];
    return Array.isArray(arr) ? arr.filter(r => Array.isArray(r) && (r as unknown[])[0] === 'ITEM').length : 0;
  } catch { return 0; }
}

// ── GET : liste les snapshots ────────────────────────────────────────
export async function GET(req: NextRequest) {
  try {
    // v1.1.2 — Item 1 : restore-bdc peut écraser des lignes BDC + INVENTAIRE
    // en place → admin only même pour le GET (les snapshots peuvent
    // contenir des données client/montant historiques).
    const check = await requireAdmin();
    if (!check.ok) {
      return NextResponse.json(
        { error: check.error, code: 'ADMIN_REQUIRED' },
        { status: check.status },
      );
    }

    const id = new URL(req.url).searchParams.get('id') ?? '';
    const sheets = getSheetsClient();
    const r = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.BDC_BACKUPS}!A2:H`,
      valueRenderOption: 'FORMATTED_VALUE',
    }).catch(() => ({ data: { values: [] } }));

    const all = r.data.values ?? [];
    const snapshots: SnapshotMeta[] = [];
    all.forEach((row, idx) => {
      const bdcId = String(row[2] ?? '').trim();
      if (!bdcId) return;
      if (id && bdcId !== id) return;
      snapshots.push({
        backupRow : idx + 2, // +1 for header, +1 for 1-based
        timestamp : String(row[0] ?? ''),
        action    : String(row[1] ?? ''),
        bdcId,
        clientNom : String(row[3] ?? ''),
        veloDesc  : String(row[4] ?? ''),
        itemCount : parseItemCount(String(row[5] ?? '[]')),
        note      : String(row[7] ?? ''),
      });
    });

    // Trier du plus récent au plus ancien
    snapshots.sort((a, b) => b.timestamp.localeCompare(a.timestamp));

    return NextResponse.json({ count: snapshots.length, snapshots });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}

// ── POST : restaure un BDC depuis un snapshot ────────────────────────
export async function POST(req: NextRequest) {
  // v1.1.2 — Item 1 : opération destructive (delete + insert dimensions).
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status },
    );
  }

  // v1.1.7 — Item 4 : validation zod
  const parsed = await parseBody(req, RestoreBdcSchema);
  if (!parsed.ok) return parsed.response;
  const bdcId          = parsed.data.id;
  const backupRow      = parsed.data.backupRow;
  const overrideClient = parsed.data.overrideClient?.trim() ?? '';

  try {

    const sheets = getSheetsClient();

    // 1. Lire le snapshot
    const snapRes = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.BDC_BACKUPS}!A${backupRow}:H${backupRow}`,
      valueRenderOption: 'FORMATTED_VALUE',
    });
    const snap = snapRes.data.values?.[0];
    if (!snap) return NextResponse.json({ error: `Snapshot row ${backupRow} introuvable` }, { status: 404 });
    const snapBdcId = String(snap[2] ?? '').trim();
    if (snapBdcId !== bdcId) {
      return NextResponse.json({
        error: `Snapshot row ${backupRow} concerne BDC ${snapBdcId}, pas ${bdcId}`,
      }, { status: 400 });
    }

    let bdcRows: unknown[][] = [];
    let invRow : unknown[]   = [];
    try { bdcRows = JSON.parse(String(snap[5] ?? '[]')); } catch {
      return NextResponse.json({ error: 'JSON snapshot invalide (col F bdc)' }, { status: 500 });
    }
    try { invRow = JSON.parse(String(snap[6] ?? '[]')); } catch {
      return NextResponse.json({ error: 'JSON snapshot invalide (col G inventaire)' }, { status: 500 });
    }
    if ((!Array.isArray(bdcRows) || bdcRows.length === 0) && (!Array.isArray(invRow) || invRow.length === 0)) {
      return NextResponse.json({ error: 'Snapshot vide — rien à restaurer' }, { status: 400 });
    }

    // 2. Trouver le sheetId de l'onglet BDC
    const meta = await sheets.spreadsheets.get({
      spreadsheetId: SHEET_IDS.INVENTAIRE,
      fields       : 'sheets.properties',
    });
    const bdcSheet = meta.data.sheets?.find(s => s.properties?.title === TAB.BDC);
    const bdcSheetId = bdcSheet?.properties?.sheetId;
    if (bdcSheetId === undefined) {
      return NextResponse.json({ error: 'Onglet BONS DE COMMANDES introuvable' }, { status: 500 });
    }

    // 3. Lire la sheet courante pour trouver les bornes du BDC actuel
    const curRes = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.BDC}!A1:W500`,
      valueRenderOption: 'FORMATTED_VALUE',
    });
    const curRows = curRes.data.values ?? [];
    const curBon  = curRows.findIndex(r => r[0] === 'BON' && String(r[1] ?? '').trim() === bdcId);
    const bdcExists = curBon >= 0;

    let startIndex: number;

    if (bdcExists) {
      // Cas A : BDC existe → remplace en place
      let curSep = -1;
      for (let i = curBon + 1; i < curRows.length; i++) {
        if (curRows[i][0] === 'SEP') { curSep = i; break; }
      }
      if (curSep < 0) {
        return NextResponse.json({ error: `Ligne SEP non trouvée après BON ${bdcId}` }, { status: 500 });
      }

      startIndex = curBon;        // 0-based
      const endIndex = curSep + 1; // exclusif

      // 4a. Supprimer les lignes BDC actuelles
      await sheets.spreadsheets.batchUpdate({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        requestBody  : {
          requests: [{
            deleteDimension: {
              range: { sheetId: bdcSheetId, dimension: 'ROWS', startIndex, endIndex },
            },
          }],
        },
      });
    } else {
      // Cas B : BDC n'existe pas (perdu, ex. désarchivage + crash) → on
      // insère à la position standard BDC_INS_ROW pour le reconstruire.
      const { ROW } = await import('@/lib/sheets/client');
      startIndex = ROW.BDC_INS - 1;  // 0-based
    }

    // 5. Insérer le bon nombre de nouvelles lignes (que le BDC existait ou pas)
    await sheets.spreadsheets.batchUpdate({
      spreadsheetId: SHEET_IDS.INVENTAIRE,
      requestBody  : {
        requests: [{
          insertDimension: {
            range: { sheetId: bdcSheetId, dimension: 'ROWS', startIndex, endIndex: startIndex + bdcRows.length },
            inheritFromBefore: true,
          },
        }],
      },
    });

    // 6. Écrire les valeurs (padding à 23 colonnes)
    //    ⚠ valueInputOption: 'RAW' — sinon Sheets convertit "0109" → 109 et
    //    casse le matching par bdcId. RAW préserve les strings telles quelles.
    //    Si overrideClient est fourni, on remplace le nom client dans la
    //    ligne GAP (col H = VELO = index 7, où le nom client est stocké).
    const padded = bdcRows.map(r => {
      const row = Array.isArray(r) ? [...r] : [];
      while (row.length < 23) row.push('');
      // GAP row → patch client column
      if (overrideClient && row[0] === 'GAP') {
        row[7] = overrideClient; // col H (BDC_COL.VELO - 1)
      }
      return row.slice(0, 23);
    });
    const newRowNum = startIndex + 1; // 1-based
    await sheets.spreadsheets.values.update({
      spreadsheetId   : SHEET_IDS.INVENTAIRE,
      range           : `${TAB.BDC}!A${newRowNum}:W${newRowNum + padded.length - 1}`,
      valueInputOption: 'RAW',
      requestBody     : { values: padded },
    });

    // 7. Restaurer aussi la ligne INVENTAIRE depuis le snapshot col G.
    //    Le snapshot capture A:X (24 colonnes) — on les réécrit en RAW.
    //    Si la ligne vélo n'existe plus (vélo perdu aussi), on l'insère
    //    à INS_ROW comme pour un nouveau vélo.
    let invRestoredCol = 0;
    if (Array.isArray(invRow) && invRow.length > 0) {
      const { findVeloRow } = await import('@/lib/sheets/inventaire');
      const { ROW } = await import('@/lib/sheets/client');
      const invPadded = [...invRow];
      while (invPadded.length < 24) invPadded.push('');

      // Si overrideClient fourni, patch col H (CLIENT) de l'inventaire (index 7)
      if (overrideClient) {
        invPadded[7] = overrideClient;
      }

      let veloRowNum = await findVeloRow(bdcId);
      if (veloRowNum <= 0) {
        // Vélo aussi perdu → insérer une nouvelle ligne à INS_ROW
        const invMeta = await sheets.spreadsheets.get({
          spreadsheetId: SHEET_IDS.INVENTAIRE,
          fields       : 'sheets.properties',
        });
        const invSheet = invMeta.data.sheets?.find(s => s.properties?.title === TAB.INVENTAIRE);
        const invSheetId = invSheet?.properties?.sheetId;
        if (invSheetId !== undefined) {
          await sheets.spreadsheets.batchUpdate({
            spreadsheetId: SHEET_IDS.INVENTAIRE,
            requestBody  : {
              requests: [{
                insertDimension: {
                  range: { sheetId: invSheetId, dimension: 'ROWS', startIndex: ROW.INS_ROW - 1, endIndex: ROW.INS_ROW },
                  inheritFromBefore: true,
                },
              }],
            },
          });
          veloRowNum = ROW.INS_ROW;
        }
      }

      if (veloRowNum > 0) {
        await sheets.spreadsheets.values.update({
          spreadsheetId   : SHEET_IDS.INVENTAIRE,
          range           : `${TAB.INVENTAIRE}!A${veloRowNum}:X${veloRowNum}`,
          valueInputOption: 'RAW',
          requestBody     : { values: [invPadded.slice(0, 24)] },
        });
        invRestoredCol = invPadded.length;
      }
    }

    return NextResponse.json({
      restored        : true,
      bdcId,
      backupRow,
      restoredBdcRows : padded.length,
      restoredInvCols : invRestoredCol,
      timestamp       : String(snap[0] ?? ''),
      sourceAction    : String(snap[1] ?? ''),
      overrideClient  : overrideClient || null,
    });
  } catch (err: any) {
    console.error('[restore-bdc]', err);
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}
