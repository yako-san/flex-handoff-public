/**
 * POST /api/admin/cleanup-vente-numbers
 * Body : { nextNumber: number, dryRun?: boolean }
 *
 * One-shot d'admin pour nettoyer le compteur facture vente après le bug de
 * pré-attribution (ancien comportement : prochainFactureNumero appelée à la
 * création des brouillons → trous dans la séquence).
 *
 * Action :
 *   1. Liste toutes les lignes de _VENTES_ où col I (factureNumero) est non
 *      vide ET col J (factureDate) est vide → ce sont des brouillons qui
 *      portaient un numéro non utilisé.
 *   2. Si !dryRun : efface col I pour ces lignes + remet B3 = (nextNumber - 1)
 *      pour que la prochaine facturation produise V{nextNumber}.
 *
 * Auth : NextAuth requise.
 *
 * Exemples :
 *   fetch('/api/admin/cleanup-vente-numbers', { method: 'POST',
 *     headers: { 'Content-Type': 'application/json' },
 *     body: JSON.stringify({ nextNumber: 8, dryRun: true }) }).then(r => r.json()).then(console.log)
 */
import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getSheetsClient, SHEET_IDS, TAB, ROW } from '@/lib/sheets/client';
import cache, { CACHE_KEYS } from '@/lib/cache';
import { parseBody } from '@/lib/validate';
import { CleanupVenteNumbersSchema } from '@/lib/schemas/admin';

interface CleanupRow {
  row          : number;
  venteId      : string;
  factureNumero: string;
  client       : string;
}

export async function POST(req: NextRequest) {
  // v1.1.2 — Item 1 : modifie compteur facture B3 + efface col I de
  // lignes _VENTES_. Trop destructif pour rester sur simple auth().
  const check = await requireAdmin();
  if (!check.ok) {
    return NextResponse.json(
      { error: check.error, code: 'ADMIN_REQUIRED' },
      { status: check.status },
    );
  }

  // v1.1.7 — Item 4 : validation zod
  const parsed = await parseBody(req, CleanupVenteNumbersSchema);
  if (!parsed.ok) return parsed.response;
  const { nextNumber } = parsed.data;
  // dryRun=true par défaut pour safety
  const dryRun = parsed.data.dryRun !== false;

  try {
    const sheets = getSheetsClient();

    // Lire toutes les lignes de _VENTES_ A:K (venteId/date/client/.../factureNumero/factureDate/url)
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : `${TAB.VENTES}!A2:K`,
      valueRenderOption: 'UNFORMATTED_VALUE',
    });
    const rows = res.data.values ?? [];

    const toClear: CleanupRow[] = [];
    const kept   : CleanupRow[] = [];

    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      const factureNumero = String(r[8] ?? '').trim();   // col I
      const factureDate   = String(r[9] ?? '').trim();   // col J
      if (!factureNumero) continue;
      const info: CleanupRow = {
        row          : i + 2,
        venteId      : String(r[0] ?? ''),
        factureNumero,
        client       : String(r[2] ?? ''),
      };
      if (!factureDate) toClear.push(info);
      else kept.push(info);
    }

    // Lire la valeur actuelle du compteur B3 (avant modif)
    const counterRange = `${TAB.PARAMS}!B${ROW.FACTURE_COUNTER_ROW}`;
    const counterRes = await sheets.spreadsheets.values.get({
      spreadsheetId    : SHEET_IDS.INVENTAIRE,
      range            : counterRange,
      valueRenderOption: 'UNFORMATTED_VALUE',
    });
    const counterBefore = parseInt(String(counterRes.data.values?.[0]?.[0] ?? '0'), 10) || 0;
    const counterAfter  = nextNumber - 1;

    if (dryRun) {
      return NextResponse.json({
        dryRun       : true,
        wouldClear   : toClear,
        keptFacturees: kept,
        counterBefore,
        counterAfter,
        nextWillBe   : `V${String(nextNumber).padStart(4, '0')}-{today}`,
      });
    }

    // Vraie exécution : effacer col I pour les lignes ciblées + reset B3
    const data: { range: string; values: unknown[][] }[] = toClear.map(c => ({
      range : `${TAB.VENTES}!I${c.row}`,
      values: [['']],
    }));
    data.push({ range: counterRange, values: [[counterAfter]] });

    if (data.length > 0) {
      await sheets.spreadsheets.values.batchUpdate({
        spreadsheetId: SHEET_IDS.INVENTAIRE,
        requestBody  : { valueInputOption: 'RAW', data },
      });
    }

    await cache.del(CACHE_KEYS.VENTES);

    return NextResponse.json({
      dryRun       : false,
      cleared      : toClear,
      keptFacturees: kept,
      counterBefore,
      counterAfter,
      nextWillBe   : `V${String(nextNumber).padStart(4, '0')}-{today}`,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? String(err) }, { status: 500 });
  }
}

