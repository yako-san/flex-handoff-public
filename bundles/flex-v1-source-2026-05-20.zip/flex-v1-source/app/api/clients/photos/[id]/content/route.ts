/**
 * GET /api/clients/photos/[id]/content
 *
 * Proxy qui stream le contenu d'un fichier Drive via le OAuth de la
 * session. Utilisé par <img src="…"> dans la grille photos.
 *
 * Cas spéciaux :
 * - HEIC / HEIF / TIFF / video : les browsers non-Safari ne les affichent
 *   pas. On sert alors le thumbnailLink (JPEG auto-généré par Drive).
 * - Sinon : on stream le contenu original tel quel (JPEG / PNG / WEBP).
 */
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { google } from 'googleapis';

const NON_WEB_FORMATS = /^(image\/(heic|heif|tiff|bmp|x-|vnd\.)|video\/)/i;

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } },
) {
  try {
    const session = await auth();
    if (!session) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
    const accessToken  = session.googleAccessToken  as string | undefined;
    const refreshToken = session.googleRefreshToken as string | undefined;
    if (!accessToken) return NextResponse.json({ error: 'Token Drive manquant' }, { status: 403 });
    if (!params.id) return NextResponse.json({ error: 'id requis' }, { status: 400 });

    const oauth2Client = new google.auth.OAuth2(
      process.env.AUTH_GOOGLE_ID,
      process.env.AUTH_GOOGLE_SECRET,
    );
    oauth2Client.setCredentials({ access_token: accessToken, refresh_token: refreshToken ?? null });

    const drive = google.drive({ version: 'v3', auth: oauth2Client });

    // 1. Lire le mimeType + thumbnailLink (un seul round-trip)
    const meta = await drive.files.get({ fileId: params.id, fields: 'mimeType,name,thumbnailLink' });
    const mime         = meta.data.mimeType ?? 'application/octet-stream';
    const thumbLink    = meta.data.thumbnailLink ?? '';

    // 2. Choix de la source :
    //    - format non-web (HEIC…) → thumbnailLink (JPEG généré par Drive)
    //    - sinon → fichier original via alt=media
    if (NON_WEB_FORMATS.test(mime) && thumbLink) {
      // Le thumbnailLink de Drive a une taille variable (s220). On
      // peut la monter via query param sz=… (s800 = 800 px).
      const sz   = req.nextUrl.searchParams.get('sz') || '800';
      const url  = thumbLink.replace(/=s\d+$/, `=s${sz}`);
      const resp = await fetch(url, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      if (!resp.ok) throw new Error(`Thumbnail Drive HTTP ${resp.status}`);
      const buf = Buffer.from(await resp.arrayBuffer());
      return new Response(buf, {
        status : 200,
        headers: {
          'Content-Type' : 'image/jpeg',
          'Cache-Control': 'private, max-age=300',
        },
      });
    }

    // 3. Contenu original
    const media = await drive.files.get(
      { fileId: params.id, alt: 'media' },
      { responseType: 'arraybuffer' },
    );
    const buf = Buffer.from(media.data as ArrayBuffer);
    return new Response(buf, {
      status : 200,
      headers: {
        'Content-Type' : mime,
        'Cache-Control': 'private, max-age=300',
      },
    });
  } catch (err: any) {
    console.warn('[photos/content]', err?.message);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
