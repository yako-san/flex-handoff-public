/**
 * DELETE /api/clients/photos/[id] → supprime un fichier Drive (photo client).
 */
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { deleteClientPhoto } from '@/lib/drive/clientFolders';
import { googleApiError } from '@/lib/google/apiErrorResponse';

export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } },
) {
  try {
    const session = await auth();
    if (!session) {
      return NextResponse.json(
        { error: 'Non authentifié — reconnecte-toi', code: 'GOOGLE_AUTH_EXPIRED', reconnect: true },
        { status: 401 },
      );
    }
    const accessToken  = session.googleAccessToken  as string | undefined;
    const refreshToken = session.googleRefreshToken as string | undefined;
    if (!accessToken) {
      return NextResponse.json(
        { error: 'Token Drive manquant — reconnecte-toi', code: 'GOOGLE_AUTH_EXPIRED', reconnect: true },
        { status: 401 },
      );
    }
    if (!params.id) return NextResponse.json({ error: 'id requis' }, { status: 400 });
    await deleteClientPhoto(params.id, accessToken, refreshToken);
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return googleApiError(err);
  }
}
