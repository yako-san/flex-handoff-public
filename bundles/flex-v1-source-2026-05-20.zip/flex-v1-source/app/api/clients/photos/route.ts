/**
 * GET  /api/clients/photos?client=Nom  → liste des photos dans le dossier Drive
 * POST /api/clients/photos?client=Nom  → upload (multipart/form-data: file)
 *
 * Utilise le OAuth token de la session utilisateur (les Service Accounts
 * n'ont pas de quota storage sur My Drive).
 */
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { listClientPhotos, uploadClientPhoto } from '@/lib/drive/clientFolders';
import { googleApiError } from '@/lib/google/apiErrorResponse';

async function getTokens() {
  const session = await auth();
  if (!session) return null;
  const accessToken  = session.googleAccessToken  as string | undefined;
  const refreshToken = session.googleRefreshToken as string | undefined;
  if (!accessToken) return null;
  return { accessToken, refreshToken };
}

export async function GET(req: NextRequest) {
  try {
    const tokens = await getTokens();
    if (!tokens) {
      return NextResponse.json(
        { error: 'Non authentifié — reconnecte-toi', code: 'GOOGLE_AUTH_EXPIRED', reconnect: true },
        { status: 401 },
      );
    }
    const client = req.nextUrl.searchParams.get('client') ?? '';
    if (!client) return NextResponse.json({ error: 'client requis' }, { status: 400 });
    const photos = await listClientPhotos(client, tokens.accessToken, tokens.refreshToken);
    return NextResponse.json({ photos });
  } catch (err: any) {
    return googleApiError(err);
  }
}

// Limite côté application : Drive perso accepte ~5 TB, mais Vercel serverless
// impose ~4.5 MB par body. On cap à 4 MB pour garder une marge.
const MAX_UPLOAD_BYTES = 4 * 1024 * 1024;

export async function POST(req: NextRequest) {
  try {
    const tokens = await getTokens();
    if (!tokens) return NextResponse.json({ error: 'Non authentifié — reconnectez-vous.' }, { status: 401 });
    const client = req.nextUrl.searchParams.get('client') ?? '';
    if (!client) return NextResponse.json({ error: 'client requis' }, { status: 400 });

    const form = await req.formData();
    const file = form.get('file');
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'Fichier manquant (champ "file")' }, { status: 400 });
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      const mb = (file.size / 1024 / 1024).toFixed(1);
      return NextResponse.json(
        { error: `Fichier trop volumineux (${mb} MB). Max : 4 MB — redimensionne la photo avant upload.` },
        { status: 413 },
      );
    }
    const buf = Buffer.from(await file.arrayBuffer());
    const res = await uploadClientPhoto(
      client,
      { name: file.name, mimeType: file.type || 'application/octet-stream', buffer: buf },
      tokens.accessToken,
      tokens.refreshToken,
    );
    return NextResponse.json(res, { status: 201 });
  } catch (err: any) {
    const msg = String(err?.message ?? '');
    if (/DRIVE_CLIENTS_FOLDER_ID/.test(msg)) {
      return NextResponse.json(
        { error: 'Drive non configuré (DRIVE_CLIENTS_FOLDER_ID manquant côté serveur).' },
        { status: 500 },
      );
    }
    // googleApiError gère 401 / GoogleAuthError + fallback 500
    return googleApiError(err);
  }
}
