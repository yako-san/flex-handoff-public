import { NextResponse } from 'next/server';
import { getVelosClient } from '@/lib/sheets/clients';

/** GET /api/clients/[nom]/velos */
export async function GET(_req: Request, { params }: { params: { nom: string } }) {
  try {
    const nom   = decodeURIComponent(params.nom);
    const velos = await getVelosClient(nom);
    return NextResponse.json(velos);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
