import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import {
  getClients,
  creerClient,
  patchClientLead,
  patchClient,
  deleteClient,
  retirerBDCIdByRow,
  setGoogleResourceName,
} from '@/lib/sheets/clients';
import { upsertContact, deleteContact } from '@/lib/google/contacts';
import type { ClientFormData } from '@/types/client';

/** GET /api/clients — 3 groupes : recents / actifs / autres
 *  ?fresh=1 invalide le cache serveur avant de lire */
export async function GET(req: Request) {
  try {
    const fresh   = new URL(req.url).searchParams.get('fresh') === '1';
    const grouped = await getClients(fresh);
    return NextResponse.json(grouped);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** PATCH /api/clients — mise à jour champ(s) d'un client.
 *  Body : { row, lead } (rétro-compat) OU { row, fields: { ... } } OU { row, removeBdcId } */
export async function PATCH(req: Request) {
  try {
    const body = await req.json() as {
      row: number;
      lead?: string;
      fields?: Record<string, any>;
      removeBdcId?: string;
    };
    if (!body.row) return NextResponse.json({ error: 'row manquant' }, { status: 400 });

    if (body.removeBdcId) {
      await retirerBDCIdByRow(body.row, body.removeBdcId);
    } else if (body.fields && typeof body.fields === 'object') {
      await patchClient(body.row, body.fields);
      // Sync Google Contacts (non-bloquant)
      syncContactAfterWrite(body.row).catch(e =>
        console.error('[contacts-sync] PATCH failed', e?.message || e)
      );
    } else if (body.lead !== undefined) {
      await patchClientLead(body.row, body.lead);
    } else {
      return NextResponse.json({ error: 'fields, lead ou removeBdcId requis' }, { status: 400 });
    }

    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** POST /api/clients — creerFicheClient + sync Google Contacts */
export async function POST(req: Request) {
  try {
    const body: ClientFormData = await req.json();
    if (!body.prenom || !body.nom) {
      return NextResponse.json({ error: 'Prénom et nom requis' }, { status: 400 });
    }
    const client = await creerClient(body);

    // Sync Google Contacts (non-bloquant : échec ne casse pas la création
    // du client côté sheet, mais on remonte l'info au client dans la
    // réponse pour qu'un toast alerte l'utilisateur). Causes fréquentes
    // d'échec : accessToken expiré, refresh token invalidé, scope contacts
    // manquant (besoin de se reconnecter).
    let contactSynced = false;
    let contactError: string | null = null;
    let contactReconnect = false;
    try {
      const session = await auth();
      const accessToken  = session?.googleAccessToken  as string | undefined;
      const refreshToken = session?.googleRefreshToken as string | undefined;
      if (!accessToken) {
        contactError     = 'Session Google expirée — contact non ajouté à Google Contacts';
        contactReconnect = true;
      } else {
        const resourceName = await upsertContact(
          {
            prenom    : client.prenom,
            nom       : client.nom,
            tel       : client.tel,
            indicatif : client.indicatif,
            courriel  : client.courriel,
            notes     : client.notes,
            lead      : client.lead,
            commPref  : client.commPref,
            lang      : client.lang,
          },
          undefined,
          accessToken,
          refreshToken,
        );
        await setGoogleResourceName(client._row, resourceName);
        client.googleResourceName = resourceName;
        contactSynced = true;
      }
    } catch (e: any) {
      const msg = e?.message || String(e);
      const isAuth = /invalid.?credentials|invalid.?grant|unauthoriz|expir/i.test(msg);
      contactError = isAuth
        ? 'Session Google expirée — reconnecte-toi puis utilise « Sync contacts » pour rattraper'
        : `Sync Google Contacts échouée : ${msg}`;
      contactReconnect = isAuth;
      console.error('[contacts-sync] POST failed', msg);
    }

    return NextResponse.json(
      { ...client, contactSynced, contactError, contactReconnect },
      { status: 201 },
    );
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** DELETE /api/clients — supprime une fiche client par numéro de ligne + contact Google
 *  v1.1.2 — Item 1 : suppression définitive (perte de l'historique vélos/BDT lié au client) → admin only. */
export async function DELETE(req: Request) {
  try {
    const check = await requireAdmin();
    if (!check.ok) {
      return NextResponse.json(
        { error: check.error, code: 'ADMIN_REQUIRED' },
        { status: check.status },
      );
    }
    const { row } = await req.json() as { row: number };
    if (!row) return NextResponse.json({ error: 'row manquant' }, { status: 400 });

    // Récupérer resourceName avant suppression (pour supprimer aussi côté Google)
    let resourceName: string | undefined;
    try {
      const grouped = await getClients(false);
      const all = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
      resourceName = all.find(c => c._row === row)?.googleResourceName;
    } catch { /* ignore */ }

    await deleteClient(row);

    if (resourceName) {
      try {
        const session = await auth();
        const accessToken  = session?.googleAccessToken  as string | undefined;
        const refreshToken = session?.googleRefreshToken as string | undefined;
        if (accessToken) await deleteContact(resourceName, accessToken, refreshToken);
      } catch (e: any) {
        console.error('[contacts-sync] DELETE failed', e?.message || e);
      }
    }

    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** Sync un client existant vers Google Contacts (upsert). Non-bloquant. */
async function syncContactAfterWrite(row: number): Promise<void> {
  const session = await auth();
  const accessToken  = session?.googleAccessToken  as string | undefined;
  const refreshToken = session?.googleRefreshToken as string | undefined;
  if (!accessToken) return;

  // Lookup client par row (force fresh pour avoir les nouvelles valeurs)
  const grouped = await getClients(true);
  const all = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
  const c = all.find(cl => cl._row === row);
  if (!c) return;

  const resourceName = await upsertContact(
    {
      prenom    : c.prenom,
      nom       : c.nom,
      tel       : c.tel,
      indicatif : c.indicatif,
      courriel  : c.courriel,
      notes     : c.notes,
      lead      : c.lead,
      commPref  : c.commPref,
      lang      : c.lang,
    },
    c.googleResourceName,
    accessToken,
    refreshToken,
  );
  if (!c.googleResourceName || c.googleResourceName !== resourceName) {
    await setGoogleResourceName(row, resourceName);
  }
}
