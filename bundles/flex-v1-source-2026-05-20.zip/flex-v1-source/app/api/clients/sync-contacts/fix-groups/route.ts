/**
 * POST /api/clients/sync-contacts/fix-groups
 *
 * Corrige l'appartenance au groupe « Clients » pour tous les contacts déjà
 * créés (ceux qui ont un googleResourceName en col H) sans toucher à leurs
 * champs. Utile quand les contacts ont été créés mais l'ajout au groupe a
 * échoué silencieusement lors d'une sync antérieure.
 *
 * 1 seule requête Google (addManyToClientsGroup) peu importe le nombre de
 * contacts — pas de rate limit à gérer, rapide.
 */
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { getClients } from '@/lib/sheets/clients';
import { addManyToClientsGroup } from '@/lib/google/contacts';

export const maxDuration = 60;

export async function POST() {
  try {
    const session      = await auth();
    const accessToken  = session?.googleAccessToken  as string | undefined;
    const refreshToken = session?.googleRefreshToken as string | undefined;
    if (!accessToken) {
      return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
    }

    const grouped = await getClients(true);
    const all     = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
    const resourceNames = all
      .map(c => c.googleResourceName)
      .filter((r): r is string => !!r);

    if (resourceNames.length === 0) {
      return NextResponse.json({
        ok       : true,
        processed: 0,
        added    : 0,
        message  : 'Aucun client n\'a de resourceName Google. Lance d\'abord « Synchroniser Contacts ».',
      });
    }

    const { added, notFound } = await addManyToClientsGroup(
      resourceNames,
      accessToken,
      refreshToken,
    );

    return NextResponse.json({
      ok       : true,
      processed: resourceNames.length,
      added,
      notFound : notFound.slice(0, 50),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
