/**
 * POST /api/clients/sync-contacts — batch upsert de tous les clients vers
 * Google Contacts (groupe « Clients »). Utilisé pour migrer les clients
 * existants après activation de la sync automatique (v5.10.0).
 *
 * Fonctionnement :
 *  - Récupère tous les clients (fresh)
 *  - Pour chacun : upsertContact (create si pas de resourceName, update sinon)
 *  - Écrit resourceName en col H pour les nouveaux
 *  - Retourne { total, created, updated, failed, errors[] }
 *
 * Rate-limit : People API = ~60 writes/min. Délai de 200ms entre chaque
 * requête pour rester large.
 *
 * Timeout : étendu à 60s (limite Vercel Pro). Si trop de clients,
 * on peut chunker via ?offset=N&limit=M.
 */
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { getClients, setGoogleResourceName } from '@/lib/sheets/clients';
import { upsertContact } from '@/lib/google/contacts';

export const maxDuration = 60;

const DELAY_MS = 200;

function sleep(ms: number) {
  return new Promise(r => setTimeout(r, ms));
}

export async function POST(req: Request) {
  try {
    const session      = await auth();
    const accessToken  = session?.googleAccessToken  as string | undefined;
    const refreshToken = session?.googleRefreshToken as string | undefined;
    if (!accessToken) {
      return NextResponse.json(
        {
          error    : 'Non authentifié — reconnecte-toi pour accorder le scope Contacts',
          code     : 'GOOGLE_AUTH_EXPIRED',
          reconnect: true,
        },
        { status: 401 },
      );
    }

    const url    = new URL(req.url);
    const offset = parseInt(url.searchParams.get('offset') ?? '0', 10) || 0;
    const limit  = parseInt(url.searchParams.get('limit')  ?? '0', 10) || 0;

    const grouped = await getClients(true);
    const all     = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
    const slice   = limit > 0 ? all.slice(offset, offset + limit) : all.slice(offset);

    let created = 0;
    let updated = 0;
    let failed  = 0;
    const errors: Array<{ nom: string; error: string }> = [];

    for (const c of slice) {
      try {
        const resourceName = await upsertContact(
          {
            prenom    : c.prenom,
            nom       : c.nom,
            tel       : c.tel,
            indicatif : c.indicatif,
            courriel  : c.courriel,
            notes     : c.notes,
            lead      : c.lead,
            commPref  : c.commPref,
            lang      : c.lang,
          },
          c.googleResourceName,
          accessToken,
          refreshToken,
        );
        if (!c.googleResourceName) {
          await setGoogleResourceName(c._row, resourceName);
          created++;
        } else if (c.googleResourceName !== resourceName) {
          // Recréé (contact supprimé manuellement côté Google)
          await setGoogleResourceName(c._row, resourceName);
          created++;
        } else {
          updated++;
        }
      } catch (err: any) {
        failed++;
        const msg = err?.message || String(err);
        errors.push({ nom: c.nomComplet, error: msg });
        console.error('[sync-contacts]', c.nomComplet, msg);
      }
      await sleep(DELAY_MS);
    }

    const nextOffset = limit > 0 && offset + limit < all.length ? offset + limit : null;

    return NextResponse.json({
      total     : all.length,
      processed : slice.length,
      created,
      updated,
      failed,
      nextOffset,
      errors    : errors.slice(0, 20),  // cap pour pas bloater la réponse
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
