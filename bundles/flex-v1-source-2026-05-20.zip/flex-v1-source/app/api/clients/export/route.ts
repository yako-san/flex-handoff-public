import { NextResponse } from 'next/server';
import { getClients } from '@/lib/sheets/clients';
import * as XLSX from 'xlsx';

/**
 * GET /api/clients/export — Exporte tous les clients en xlsx.
 */
export async function GET() {
  try {
    const grouped = await getClients(true);
    const all = [...grouped.recents, ...grouped.actifs, ...grouped.autres];

    const rows = all.map(c => ({
      'Prénom'     : c.prenom,
      'Nom'        : c.nom,
      'Téléphone'  : c.tel,
      'Courriel'   : c.courriel,
      'Comm. pref' : c.commPref,
      'Langue'     : c.lang,
      'Lead'       : c.lead,
      'BDT (ids)'  : (c.bdcIds ?? []).join('\n'),
      'Vélos'      : (c.velos ?? []).join('\n'),
      'Date IN'    : c.dateIn,
      'Date OUT'   : c.dateOut,
      'Notes'      : c.notes,
      'Resource Google': c.googleResourceName ?? '',
    }));

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, 'Clients');
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    return new NextResponse(buf, {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="clients-${new Date().toISOString().slice(0, 10)}.xlsx"`,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
