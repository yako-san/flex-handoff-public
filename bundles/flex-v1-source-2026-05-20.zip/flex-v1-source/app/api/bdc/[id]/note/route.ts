/**
 * PATCH /api/bdc/[id]/note
 * Persiste la note pour le client.
 * Body : { note: string, mode?: 'eval' | 'facture' }
 *  - mode 'eval'    (défaut) → col V ligne GAP (note évaluation)
 *  - mode 'facture'          → col W ligne GAP (note facture)
 */
import { NextRequest, NextResponse } from 'next/server';
import { setBDCNoteClient } from '@/lib/sheets/bdc';

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } },
) {
  try {
    const body = await req.json().catch(() => ({}));
    const note = String(body.note ?? '');
    const mode: 'eval' | 'facture' = body.mode === 'facture' ? 'facture' : 'eval';
    await setBDCNoteClient(params.id, note, mode);
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
