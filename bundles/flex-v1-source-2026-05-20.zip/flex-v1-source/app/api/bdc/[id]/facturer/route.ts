/**
 * POST /api/bdc/[id]/facturer
 *
 * Génère la facture PDF via le template Google Sheets (BASE-YC ou BASE-CF)
 * et crée un brouillon Gmail dans la boîte de l'utilisateur connecté.
 *
 * Body (JSON) : { noteClient?: string, remiseSvc?, remisePce? }
 */
import { NextRequest, NextResponse } from 'next/server';
import { auth }                      from '@/lib/auth';
import { getBDC }                    from '@/lib/sheets/bdc';
import { updateVelo }                from '@/lib/sheets/inventaire';
import { genererFactureEtDraft }     from '@/lib/sheets/factures';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';

async function _getClient(clientNom: string) {
  const { getClients } = await import('@/lib/sheets/clients');
  const grouped = await getClients();
  const all = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
  const seen = new Set<string>();
  const unique = all.filter(c => {
    if (seen.has(c.nomComplet)) return false;
    seen.add(c.nomComplet);
    return true;
  });
  return unique.find(c => c.nomComplet === clientNom) ?? null;
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await auth();
    if (!session) {
      return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
    }

    const accessToken  = session.googleAccessToken  as string | undefined;
    const refreshToken = session.googleRefreshToken as string | undefined;
    if (!accessToken) {
      return NextResponse.json(
        { error: 'Token Gmail manquant — veuillez vous déconnecter puis reconnecter votre compte Google.' },
        { status: 403 }
      );
    }

    const body       = await req.json().catch(() => ({}));
    const noteClient = String(body.noteClient ?? '').trim();
    const remiseSvc  = body.remiseSvc ?? { type: 'pct', value: 0 };
    const remisePce  = body.remisePce ?? { type: 'pct', value: 0 };

    const bdc = await getBDC(params.id);
    if (!bdc) {
      return NextResponse.json({ error: `BDC ${params.id} introuvable` }, { status: 404 });
    }

    // Snapshot engagement avant facturation (pour delta AB cohérent).
    // - APPROUVÉ → FACTURÉ : engaged inchangé (les 2 ∈ ENGAGED_STATUSES) → AB stable.
    // - ÉVAL./REFUSÉ → FACTURÉ : engaged augmente → AB -=qte (idempotent : recompute compare l'état réel).
    // - Re-facturation (FACTURÉ → FACTURÉ) : engaged inchangé → AB stable.
    const before = await snapshotStock();

    const client = await _getClient(bdc.clientNom);
    if (!client) {
      return NextResponse.json(
        { error: `Client "${bdc.clientNom}" introuvable` },
        { status: 404 }
      );
    }
    if (!client.courriel) {
      return NextResponse.json(
        { error: `Le client "${bdc.clientNom}" n'a pas de courriel enregistré.` },
        { status: 422 }
      );
    }

    const result = await genererFactureEtDraft(bdc, client, noteClient, accessToken, remiseSvc, remisePce, refreshToken);

    // Statut INVENTAIRE → FACTURÉ (persiste côté serveur, pas seulement client)
    await updateVelo(params.id, { status: 'FACTURÉ' })
      .catch(err => console.warn('[facturer] post-update:', err.message));

    // Recalcule AB delta + AC. v6.5.1 : invariant basé sur engagement
    // (FACTURÉ ∈ ENGAGED_STATUSES, ∉ RESERVED_STATUSES).
    await safeRecomputeStockState(before, 'BDT');

    return NextResponse.json(result, { status: 200 });

  } catch (err: any) {
    console.error('[facturer]', err);
    return NextResponse.json({ error: err.message ?? 'Erreur interne' }, { status: 500 });
  }
}
