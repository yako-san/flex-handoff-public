/**
 * POST /api/bdc/[id]/regenerer-facture
 *
 * Ré-génère le PDF facture + brouillon Gmail pour un BDT déjà facturé.
 * Cas d'usage (v1.1.13+) :
 *   - Refonte du template (col D insérée, bloc « à l'attention de »…)
 *   - Modif du nom/adresse client après facturation
 *   - PDF Drive original supprimé/perdu
 *
 * NE touche PAS :
 *   - Le journal `ENCAISSE BDT` (pas de double-ligne)
 *   - Le numéro de facture (préservé via le journal — pas de
 *     prochainFactureNumero qui incrémenterait B3)
 *   - Le statut du BDT (reste FACTURÉ)
 *   - Le stock / engagement (pas de delta)
 *
 * Crée :
 *   - Un nouveau PDF dans Drive (filename horodaté du jour, possible
 *     doublon avec l'original — à nettoyer manuellement si besoin)
 *   - Un nouveau brouillon Gmail (l'ancien reste, l'utilisateur peut
 *     supprimer l'ancien manuellement)
 *
 * Pré-condition : `bdc.checkBds === true` (BDT déjà facturé). Sinon 400.
 *
 * Body (JSON, optionnel) : { noteClient?, remiseSvc?, remisePce? }
 */
import { NextRequest, NextResponse } from 'next/server';
import { auth }                      from '@/lib/auth';
import { getBDC }                    from '@/lib/sheets/bdc';
import { genererFactureEtDraft }     from '@/lib/sheets/factures';

async function _getClient(clientNom: string) {
  const { getClients } = await import('@/lib/sheets/clients');
  const grouped = await getClients();
  const all = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
  const seen = new Set<string>();
  const unique = all.filter(c => {
    if (seen.has(c.nomComplet)) return false;
    seen.add(c.nomComplet);
    return true;
  });
  return unique.find(c => c.nomComplet === clientNom) ?? null;
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } },
) {
  try {
    const session = await auth();
    if (!session) {
      return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
    }
    const accessToken  = session.googleAccessToken;
    const refreshToken = session.googleRefreshToken;
    if (!accessToken) {
      return NextResponse.json(
        { error: 'Token Gmail manquant — déconnecte-toi puis reconnecte-toi avec ton compte Google.' },
        { status: 403 },
      );
    }

    const body       = await req.json().catch(() => ({}));
    const noteClient = String(body.noteClient ?? '').trim();
    const remiseSvc  = body.remiseSvc ?? { type: 'pct', value: 0 };
    const remisePce  = body.remisePce ?? { type: 'pct', value: 0 };

    const bdc = await getBDC(params.id);
    if (!bdc) {
      return NextResponse.json({ error: `BDT ${params.id} introuvable` }, { status: 404 });
    }
    if (!bdc.checkBds) {
      return NextResponse.json(
        { error: `BDT ${params.id} n'a pas été facturé — utilise « Facturer » au lieu de « Re-générer ».`, code: 'NOT_INVOICED' },
        { status: 400 },
      );
    }

    const client = await _getClient(bdc.clientNom);
    if (!client) {
      return NextResponse.json(
        { error: `Client "${bdc.clientNom}" introuvable` },
        { status: 404 },
      );
    }
    if (!client.courriel) {
      return NextResponse.json(
        { error: `Le client "${bdc.clientNom}" n'a pas de courriel — impossible de créer le brouillon Gmail.` },
        { status: 422 },
      );
    }

    const result = await genererFactureEtDraft(
      bdc, client, noteClient, accessToken,
      remiseSvc, remisePce, refreshToken,
      { skipJournalLog: true }, // v1.1.13 — ne PAS re-logger dans ENCAISSE BDT
    );

    return NextResponse.json({ ...result, regenerated: true }, { status: 200 });
  } catch (err: any) {
    console.error('[regenerer-facture]', err);
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}
