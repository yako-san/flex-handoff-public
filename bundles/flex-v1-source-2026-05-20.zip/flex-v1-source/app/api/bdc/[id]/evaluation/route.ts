/**
 * POST /api/bdc/[id]/evaluation
 *
 * Génère l'évaluation PDF via le template Google Sheets (BASE-YC ou BASE-CF)
 * et crée un brouillon Gmail dans la boîte de l'utilisateur connecté.
 *
 * Body (JSON) : { noteClient?: string }
 */
import { NextRequest, NextResponse } from 'next/server';
import { auth }                      from '@/lib/auth';
import { getBDC, setCheckEval }      from '@/lib/sheets/bdc';
import { updateVelo }                from '@/lib/sheets/inventaire';
import { genererEvaluationEtDraft }  from '@/lib/sheets/factures';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';

// Import client list helper
async function _getClient(clientNom: string) {
  const { getClients } = await import('@/lib/sheets/clients');
  const grouped = await getClients();
  const all = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
  // Éviter les doublons (un client peut être dans recents ET actifs)
  const seen = new Set<string>();
  const unique = all.filter(c => {
    if (seen.has(c.nomComplet)) return false;
    seen.add(c.nomComplet);
    return true;
  });
  return unique.find(c => c.nomComplet === clientNom) ?? null;
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // 1. Auth — récupérer le token Gmail de l'utilisateur connecté
    const session = await auth();
    if (!session) {
      return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
    }

    const accessToken  = session.googleAccessToken  as string | undefined;
    const refreshToken = session.googleRefreshToken as string | undefined;
    if (!accessToken) {
      return NextResponse.json(
        { error: 'Token Gmail manquant — veuillez vous déconnecter puis reconnecter votre compte Google.' },
        { status: 403 }
      );
    }

    // 2. Body
    const body       = await req.json().catch(() => ({}));
    const noteClient = String(body.noteClient ?? '').trim();
    const remiseSvc  = body.remiseSvc ?? { type: 'pct', value: 0 };
    const remisePce  = body.remisePce ?? { type: 'pct', value: 0 };

    // 3. Lire le BDC
    const bdc = await getBDC(params.id);
    if (!bdc) {
      return NextResponse.json({ error: `BDC ${params.id} introuvable` }, { status: 404 });
    }

    // 4. Lire le client
    const client = await _getClient(bdc.clientNom);
    if (!client) {
      return NextResponse.json(
        { error: `Client "${bdc.clientNom}" introuvable dans CLIENTS FLEX-REV` },
        { status: 404 }
      );
    }

    if (!client.courriel) {
      return NextResponse.json(
        { error: `Le client "${bdc.clientNom}" n'a pas de courriel enregistré.` },
        { status: 422 }
      );
    }

    // 5. Générer le PDF et créer le brouillon
    const result = await genererEvaluationEtDraft(bdc, client, noteClient, accessToken, remiseSvc, remisePce, refreshToken);

    // Snapshot engagement avant le passage forcé à ÉVAL. (peut désengager
    // un BDT précédemment APPROUVÉ — restitue AB + clear AC).
    const before = await snapshotStock();

    // 6. Marquer checkEval = TRUE dans le sheet BDC (col D) + statut INVENTAIRE → ÉVAL.
    await Promise.all([
      setCheckEval(params.id, true),
      updateVelo(params.id, { status: 'ÉVAL.' }),
    ]).catch(err => console.warn('[evaluation] post-update:', err.message));

    await safeRecomputeStockState(before, 'BDT');

    return NextResponse.json(result, { status: 200 });

  } catch (err: any) {
    console.error('[evaluation]', err);
    return NextResponse.json(
      { error: err.message ?? 'Erreur interne' },
      { status: 500 }
    );
  }
}
