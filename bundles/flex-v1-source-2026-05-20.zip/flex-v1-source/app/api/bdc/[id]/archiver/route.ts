import { NextResponse } from 'next/server';
import { archiverBDC, archiverBDCRefuse, getBDC } from '@/lib/sheets/bdc';
import { setDateOut } from '@/lib/sheets/clients';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';
import { todayStr } from '@/lib/utils/format';

/**
 * POST /api/bdc/[id]/archiver
 * Body : { refuse?: boolean } — si true, archive avec mention
 * « ÉVAL. REFUSÉE » au lieu du flux facture payée.
 * Déplace le BDC vers ARCHIVES 2026 + écrit dateOUT dans CLIENTS.
 */
export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const body = await req.json().catch(() => ({}));
    const refuse = body?.refuse === true;

    const bdc = await getBDC(params.id);
    if (!bdc) return NextResponse.json({ error: 'BDC introuvable' }, { status: 404 });

    // Snapshot AVANT archivage pour calcul du delta AB :
    //   - BDT FACTURÉ archivé : engaged_after = archives FACTURÉ → invariant ⇒ AB stable.
    //   - BDT pré-FACTURÉ archivé (ex. APPROUVÉ direct) : engaged_after exclut
    //     l'archive non-FACTURÉ → AB remonte (cancellation).
    //   - archiverBDCRefuse : pose REFUSÉ avant archive → engaged_after = 0 → AB remonte.
    const before = await snapshotStock();

    if (refuse) {
      await archiverBDCRefuse(params.id);
    } else {
      await archiverBDC(params.id);
    }

    if (bdc.clientNom) {
      await setDateOut(bdc.clientNom, todayStr()).catch(() => {
        // non bloquant — le BDC est archivé même si l'écriture du dateOut échoue
      });
    }

    // Applique delta AB + recalcul AC selon le statut d'archivage.
    await safeRecomputeStockState(before, 'ALL');

    return NextResponse.json({ archived: true, id: params.id, refuse });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
