import { NextResponse } from 'next/server';
import { updateBDCRemises, getBDC } from '@/lib/sheets/bdc';

/**
 * PATCH /api/bdc/[id]/remises
 * Body : { remiseSvc?: { type: 'pct'|'fixed'; value: number }, remisePce?: same }
 * Persiste les remises dans la col I de la ligne BON (JSON).
 * Retourne le BDC rafraîchi.
 */
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const body = await req.json();
    const remiseSvc = body.remiseSvc && typeof body.remiseSvc.value === 'number'
      ? { type: body.remiseSvc.type === 'fixed' ? 'fixed' as const : 'pct' as const, value: body.remiseSvc.value }
      : undefined;
    const remisePce = body.remisePce && typeof body.remisePce.value === 'number'
      ? { type: body.remisePce.type === 'fixed' ? 'fixed' as const : 'pct' as const, value: body.remisePce.value }
      : undefined;

    await updateBDCRemises(params.id, remiseSvc, remisePce);
    const bdc = await getBDC(params.id);
    return NextResponse.json(bdc, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
