import { NextResponse } from 'next/server';
import { updateBDCBonJson, getBDC } from '@/lib/sheets/bdc';

/**
 * PATCH /api/bdc/[id]/avance
 * Body : { montant: number, mode?: 'comptant'|'interac'|'cartes', note?: string }
 *        montant <= 0 ou null → efface l'avance.
 *
 * Persiste l'avance (acompte versé par le client + mode + note) dans le
 * JSON col I de la ligne BON. L'avance n'affecte pas le calcul des
 * taxes (toujours sur le HT complet), mais réduit le « reste à payer ».
 *
 * Retourne le BDC rafraîchi.
 */
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const body = await req.json();
    const montant = Number(body?.montant);

    if (!Number.isFinite(montant) || montant <= 0) {
      // Effacer
      await updateBDCBonJson(params.id, { avance: null });
    } else {
      const modeRaw = String(body?.mode ?? '').trim();
      const mode = (['comptant', 'interac', 'cartes'].includes(modeRaw) ? modeRaw : undefined) as
        'comptant' | 'interac' | 'cartes' | undefined;
      const note = String(body?.note ?? '').trim() || undefined;
      await updateBDCBonJson(params.id, { avance: { montant, mode, note } });
    }

    const bdc = await getBDC(params.id);
    return NextResponse.json(bdc, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
