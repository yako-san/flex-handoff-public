import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getBDC, setCheckOk, setCheckBds, setCheckEval, setCheckOut, setEvalStatus, deleteBDC, deleteArchivedBDC, getArchivedBDCs } from '@/lib/sheets/bdc';
import { updateVelo } from '@/lib/sheets/inventaire';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';
import type { PatchBDCBody } from '@/types/api';

/** GET /api/bdc/[id] */
export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const bdc = await getBDC(params.id);
    if (!bdc) return NextResponse.json({ error: 'Introuvable' }, { status: 404 });
    return NextResponse.json(bdc);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/**
 * PATCH /api/bdc/[id]
 * action: 'approuver'      → checkbox OK (E) + statut APPROUVÉ
 * action: 'bon-de-sortie'  → checkbox BDS (F) + statut FACTURER
 * action: 'reset-eval'     → checkEval = FALSE (permet régénération évaluation)
 * action: 'reset-facture'  → checkBds  = FALSE + statut ON BENCH (retour au travail)
 */
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const body: PatchBDCBody = await req.json();
    const { action } = body;

    // Capture l'état engagement AVANT mutation pour delta AB.
    const before = await snapshotStock();

    if (action === 'approuver') {
      await Promise.all([
        setCheckOk(params.id, true),
        setEvalStatus(params.id, 'APPROUVE'),
        updateVelo(params.id, { status: 'APPROUVÉ' }),
      ]);
    } else if (action === 'set-eval-status') {
      const value = body.evalStatus ?? '';
      // Map evalStatus → statut INVENTAIRE.
      const statusMap: Record<string, string> = {
        ''         : 'ÉVAL.',
        'APPROUVE' : 'APPROUVÉ',
        'REDUX'    : 'ON BENCH',  // saute Approuvé → démarre direct la séquence mécanique
        'ATTENTE'  : 'EN ATTENTE',
        'REFUSE'   : 'ÉVAL.',     // archivera ensuite côté client (déclenche archiver)
      };
      const newInvStatus = statusMap[value] ?? 'ÉVAL.';
      await Promise.all([
        setEvalStatus(params.id, value),
        updateVelo(params.id, { status: newInvStatus as any }),
      ]);
    } else if (action === 'bon-de-sortie') {
      await Promise.all([
        setCheckBds(params.id, true),
        updateVelo(params.id, { status: 'FACTURER' }),
      ]);
    } else if (action === 'reset-eval') {
      await setCheckEval(params.id, false);
    } else if (action === 'reset-facture') {
      await Promise.all([
        setCheckBds(params.id, false),
        updateVelo(params.id, { status: 'ON BENCH' }),
      ]);
    } else if (action === 'reset-archive') {
      // Décoche la checkbox Archiver (col G) — permet de re-cliquer
      // pour archiver à nouveau un BDT désarchivé bloqué.
      await setCheckOut(params.id, false);
    } else {
      return NextResponse.json({ error: `Action inconnue : ${action}` }, { status: 400 });
    }

    // Applique delta AB (stock physique) + recalcule AC (réservé).
    // Snapshot avant mutation → comparé à l'état après → invariant respecté.
    await safeRecomputeStockState(before, 'BDT');

    const bdc = await getBDC(params.id);
    return NextResponse.json(bdc);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/**
 * DELETE /api/bdc/[id] — suppression DÉFINITIVE d'un BDC.
 * Détection automatique : actif (INVENTAIRE + BDC sheet) ou archivé (ARCHIVES).
 * Snapshot systématique dans _BDC_BACKUPS_ avant toute modification.
 *
 * v1.1.2 — Item 1 : opération destructive (potentiellement sur un BDT
 * archivé / FACTURÉ → trace comptable). Admin only.
 */
export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  try {
    const check = await requireAdmin();
    if (!check.ok) {
      return NextResponse.json(
        { error: check.error, code: 'ADMIN_REQUIRED' },
        { status: check.status },
      );
    }
    const { id } = params;
    if (!id) return NextResponse.json({ error: 'id manquant' }, { status: 400 });

    const active = await getBDC(id);
    if (active) {
      const before = await snapshotStock();
      await deleteBDC(id);
      // Si le BDT supprimé était engagé (APPROUVÉ+) → AB remonte.
      await safeRecomputeStockState(before, 'BDT');
      return NextResponse.json({ ok: true, mode: 'active', id });
    }

    const archived = (await getArchivedBDCs()).find(b => b.id === id);
    if (archived) {
      const before = await snapshotStock();
      await deleteArchivedBDC(id, archived._bonRow);
      // Si le BDT archivé supprimé était FACTURÉ → AB remonte (pièce
      // « rendue » au stock puisqu'on efface la trace de la vente).
      await safeRecomputeStockState(before, 'BDT');
      return NextResponse.json({ ok: true, mode: 'archived', id });
    }

    return NextResponse.json({ error: `BDC ${id} introuvable (ni actif ni archivé)` }, { status: 404 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
