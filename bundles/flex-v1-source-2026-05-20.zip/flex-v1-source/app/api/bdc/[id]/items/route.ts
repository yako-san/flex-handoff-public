import { NextResponse } from 'next/server';
import { insertServices, insertPieces, getBDC, patchBDCItem, patchBDCItemFields, deleteBDCItem, patchBDCItemNote, patchBDCItemForfaitSubs } from '@/lib/sheets/bdc';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';
import type { AddServiceInput, AddPieceInput } from '@/types/bdc';

/**
 * POST /api/bdc/[id]/items
 * body: { type: 'service' | 'piece', items: [...] }
 * Équivalent de _insererServices / _insererPieces dans le GAS.
 */
export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const body = await req.json();
    const { type, items } = body as { type: 'service' | 'piece'; items: unknown[] };

    if (!type || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: 'Paramètres invalides' }, { status: 400 });
    }

    if (type === 'service') {
      await insertServices(params.id, items as AddServiceInput[]);
    } else if (type === 'piece') {
      const before = await snapshotStock();
      await insertPieces(params.id, items as AddPieceInput[]);
      // Si BDT engagé : pièces ajoutées → AB -=qte + AC +=qte.
      await safeRecomputeStockState(before, 'BDT');
    } else {
      return NextResponse.json({ error: `Type inconnu : ${type}` }, { status: 400 });
    }

    const bdc = await getBDC(params.id);
    return NextResponse.json(bdc, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/**
 * PATCH /api/bdc/[id]/items
 * Deux variantes :
 *   { row, fait?, cmd? }                         → statut FAIT / CMD
 *   { row, type: 'service'|'piece', prix?, qte?, sousTotal? } → montants
 */
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const body = await req.json();
    const { row } = body as { row: number };

    if (!row) {
      return NextResponse.json({ error: 'row manquant' }, { status: 400 });
    }

    // Snapshot AVANT toute mutation : nécessaire pour calculer le delta AB
    // si une qté/nom de pièce est modifiée sur un BDT engagé.
    const before = await snapshotStock();
    let pieceQtyOrNomMaybeChanged = false;

    if (body.type) {
      // Patch nom / prix / qté / durée
      const { type, nom, prix, qte, sousTotal, dureeOverride, serviceId } = body as {
        type: 'service' | 'piece';
        nom?: string;
        prix?: number;
        qte?: number;
        sousTotal?: number;
        dureeOverride?: string;
        serviceId?: string;
      };
      await patchBDCItemFields(params.id, row, type, { nom, prix, qte, sousTotal, dureeOverride, serviceId });
      if (type === 'piece' && (qte !== undefined || nom !== undefined)) {
        pieceQtyOrNomMaybeChanged = true;
      }
    } else if (body.subStates !== undefined) {
      // v1.0.7+ : patch des sous-items d'un forfait (col J + col L)
      const { subStates, fait } = body as { subStates: boolean[]; fait: boolean };
      if (!Array.isArray(subStates) || subStates.some(b => typeof b !== 'boolean')) {
        return NextResponse.json({ error: 'subStates invalide (doit être boolean[])' }, { status: 400 });
      }
      await patchBDCItemForfaitSubs(row, subStates, !!fait);
    } else {
      // Patch fait / cmd
      const { fait, cmd } = body as { fait?: boolean; cmd?: string };
      await patchBDCItem(row, { fait, cmd });
    }

    // Patch note commande (col W)
    if (body.cmdNote !== undefined) {
      await patchBDCItemNote(row, String(body.cmdNote));
    }

    if (pieceQtyOrNomMaybeChanged) {
      await safeRecomputeStockState(before, 'BDT');
    }

    const bdc = await getBDC(params.id);
    return NextResponse.json(bdc, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/**
 * DELETE /api/bdc/[id]/items
 * Body : { row: number }
 * Supprime la ligne ITEM et recalcule les totaux.
 */
export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try {
    const body        = await req.json();
    const { row }     = body as { row: number };
    if (!row) return NextResponse.json({ error: 'row manquant' }, { status: 400 });

    const before = await snapshotStock();
    await deleteBDCItem(params.id, row);
    // Pièce retirée d'un BDT engagé → AB +=qte + AC -=qte.
    await safeRecomputeStockState(before, 'BDT');
    const bdc = await getBDC(params.id);
    return NextResponse.json(bdc, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
