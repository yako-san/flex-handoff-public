/**
 * POST /api/bdc/[id]/suivi-courriel
 *
 * Génère un brouillon Gmail de courriel de SUIVI post-archivage pour
 * le client du BDC donné. Template courriel_suivi_{fr|en} depuis
 * _EMAIL_TEMPLATES_, avec fallbacks sur les anciens templates
 * sms_suivi_{fr|en} pour compat rétro.
 *
 * Retourne : { draftId, draftUrl, to, subject }
 */
import { NextRequest, NextResponse } from 'next/server';
import { auth }              from '@/lib/auth';
import { getBDC }            from '@/lib/sheets/bdc';
import { getClients }        from '@/lib/sheets/clients';
import { getEmailTemplates, saveEmailTemplates } from '@/lib/sheets/emailTemplates';
import { createSimpleDraft } from '@/lib/google/gmailDraft';

function renderBody(template: string, vars: Record<string, string>): string {
  return template.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, k) => vars[k] ?? '');
}

export async function POST(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await auth();
    if (!session) {
      return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
    }
    const accessToken  = session.googleAccessToken  as string | undefined;
    const refreshToken = session.googleRefreshToken as string | undefined;
    if (!accessToken) {
      return NextResponse.json(
        { error: 'Token Gmail manquant — reconnecte-toi à Google.' },
        { status: 403 }
      );
    }

    // Cherche le BDC actif ou archivé
    let bdc = await getBDC(params.id);
    if (!bdc) {
      // fallback archives
      const { getArchivedBDCs } = await import('@/lib/sheets/bdc');
      bdc = (await getArchivedBDCs()).find(b => b.id === params.id) ?? null;
    }
    if (!bdc) {
      return NextResponse.json({ error: `BDC ${params.id} introuvable` }, { status: 404 });
    }

    // Client
    const grouped = await getClients();
    const all = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
    const client = all.find(c => c.nomComplet === bdc!.clientNom);
    if (!client) {
      return NextResponse.json(
        { error: `Client "${bdc.clientNom}" introuvable` },
        { status: 404 }
      );
    }
    if (!client.courriel) {
      return NextResponse.json(
        { error: `Le client "${bdc.clientNom}" n'a pas de courriel enregistré.` },
        { status: 422 }
      );
    }

    // Template (avec fallback sur sms_suivi_* pour rétrocompat)
    const tpl = await getEmailTemplates();
    const lang = client.lang === 'EN' ? 'EN' : 'FR';
    const fallbackBodyFr =
      `Bonjour ${client.prenom || ''},\n\n` +
      `Je viens aux nouvelles concernant les travaux réalisés sur votre vélo. ` +
      `Tout fonctionne comme vous le souhaitez ?\n\n` +
      `N'hésitez pas à me contacter si jamais vous avez des questions.\n\n` +
      `Merci,\nCyclo Flex`;
    const fallbackBodyEn =
      `Hi ${client.prenom || ''},\n\n` +
      `Just checking in about the recent work done on your bike. ` +
      `Everything running smoothly?\n\n` +
      `Let me know if you have any questions.\n\n` +
      `Thanks,\nCyclo Flex`;
    const template = lang === 'EN'
      ? (tpl.courriel_suivi_en || tpl.sms_suivi_en || fallbackBodyEn)
      : (tpl.courriel_suivi_fr || tpl.sms_suivi_fr || fallbackBodyFr);

    const body = renderBody(template, {
      prenom   : client.prenom || '',
      nom      : client.nom    || '',
      id       : bdc.id,
      veloDesc : bdc.veloDesc || '',
    });

    // Objet : template éditable (courriel_suivi_subject_{fr|en}) avec
    // placeholders. Fallback sur valeur codée en dur si vide.
    const fallbackSubjectFr = `Suivi — Cyclo Flex (BDT ${bdc.id})`;
    const fallbackSubjectEn = `Follow-up — Cyclo Flex (BDT ${bdc.id})`;
    const subjectTemplate = lang === 'EN'
      ? (tpl.courriel_suivi_subject_en || fallbackSubjectEn)
      : (tpl.courriel_suivi_subject_fr || fallbackSubjectFr);
    const subject = renderBody(subjectTemplate, {
      prenom   : client.prenom || '',
      nom      : client.nom    || '',
      id       : bdc.id,
      veloDesc : bdc.veloDesc || '',
    });

    const { draftId, draftUrl } = await createSimpleDraft(
      { to: client.courriel, subject, body },
      accessToken,
      refreshToken,
    );

    // Marque le suivi comme fait côté serveur (sync entre tous les
    // navigateurs / domaines, contrairement au localStorage qui était
    // local au domaine localhost vs vercel).
    try {
      await saveEmailTemplates({
        [`suivi_done_${bdc.id}`]: new Date().toISOString(),
      });
    } catch (err: any) {
      console.warn('[suivi-courriel] mark done échec :', err?.message);
    }

    return NextResponse.json({
      ok      : true,
      draftId,
      draftUrl,
      to      : client.courriel,
      subject,
    });
  } catch (err: any) {
    console.error('[suivi-courriel]', err);
    return NextResponse.json({ error: err.message ?? 'Erreur interne' }, { status: 500 });
  }
}
