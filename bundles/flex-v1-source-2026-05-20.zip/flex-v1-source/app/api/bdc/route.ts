import { NextResponse } from 'next/server';
import { getBDCs } from '@/lib/sheets/bdc';

/** GET /api/bdc — tous les BDC actifs */
export async function GET() {
  try {
    const bdcs = await getBDCs();
    return NextResponse.json(bdcs);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
