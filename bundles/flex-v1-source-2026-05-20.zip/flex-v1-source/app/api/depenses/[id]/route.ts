/**
 * PATCH  /api/depenses/[id]  → met à jour une dépense (admin only)
 * DELETE /api/depenses/[id]  → soft-delete (pose dateOut, admin only)
 *
 * v1.1.7 — Item 4 audit : validation zod via `lib/schemas/depense.ts`
 * (DepenseUpdateSchema).
 */
import { NextResponse, type NextRequest } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { updateDepense, deleteDepense } from '@/lib/sheets/depenses';
import { logError } from '@/lib/log';
import { parseBody } from '@/lib/validate';
import { DepenseUpdateSchema } from '@/lib/schemas/depense';

export const maxDuration = 30;

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const check = await requireAdmin();
  if (!check.ok) return NextResponse.json({ error: check.error }, { status: check.status });

  const parsed = await parseBody(req, DepenseUpdateSchema);
  if (!parsed.ok) return parsed.response;

  try {
    await updateDepense(params.id, parsed.data);
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    logError('depenses-patch-failed', { id: params.id, error: err?.message });
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const check = await requireAdmin();
  if (!check.ok) return NextResponse.json({ error: check.error }, { status: check.status });

  try {
    await deleteDepense(params.id);
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    logError('depenses-delete-failed', { id: params.id, error: err?.message });
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}
