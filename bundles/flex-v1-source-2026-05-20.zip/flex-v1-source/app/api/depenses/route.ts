/**
 * GET  /api/depenses  → liste les dépenses (admin only)
 * POST /api/depenses  → crée une dépense (admin only)
 *   body : DepenseInput
 *
 * v1.1.7 — Item 4 audit : validation zod via `lib/schemas/depense.ts`.
 * Remplace l'ancienne fonction _validateInput maison (33 lignes de
 * cascade if-throw → 1 ligne parseBody + schéma déclaratif).
 */
import { type NextRequest } from 'next/server';
import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getDepenses, createDepense, prochainDepenseId, getPOsAsDepenses } from '@/lib/sheets/depenses';
import { logError } from '@/lib/log';
import { parseBody } from '@/lib/validate';
import { DepenseCreateSchema } from '@/lib/schemas/depense';

export const maxDuration = 30;

export async function GET(req: NextRequest) {
  const check = await requireAdmin();
  if (!check.ok) return NextResponse.json({ error: check.error }, { status: check.status });

  try {
    const includeArchived = req.nextUrl.searchParams.get('archived') === '1';
    // v1.0.27+ : query ?includePOs=1 → ajoute les PO finalisés/partiels
    // compilés en Depense virtuelle (read-only, id préfixé "PO-")
    const includePOs = req.nextUrl.searchParams.get('includePOs') === '1';
    const [depenses, posCompiles] = await Promise.all([
      getDepenses({ includeArchived }),
      includePOs ? getPOsAsDepenses() : Promise.resolve([]),
    ]);
    return NextResponse.json({ depenses, posCompiles });
  } catch (err: any) {
    logError('depenses-get-failed', { error: err?.message });
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const check = await requireAdmin();
  if (!check.ok) return NextResponse.json({ error: check.error }, { status: check.status });

  const parsed = await parseBody(req, DepenseCreateSchema);
  if (!parsed.ok) return parsed.response;

  try {
    const id = await prochainDepenseId();
    const depense = await createDepense(parsed.data, id);
    return NextResponse.json({ depense });
  } catch (err: any) {
    logError('depenses-post-failed', { error: err?.message });
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}
