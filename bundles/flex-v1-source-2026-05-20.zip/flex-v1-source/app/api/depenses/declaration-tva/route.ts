/**
 * GET /api/depenses/declaration-tva?periode=YYYY-Tn|YYYY-MM|YYYY
 *
 * v1.0.32+ : retourne le solde TPS/TVQ net pour une période donnée :
 *
 *   TPS perçue (ventes/BDT facturés)  ← ligne 105 FPZ-500
 *   − CTI (TPS sur dépenses × factor) ← ligne 108
 *   = solde TPS à remettre             ← ligne 109
 *
 *   TVQ perçue
 *   − CTP (TVQ sur dépenses × factor)
 *   = solde TVQ à remettre
 *
 * Admin only. Filtre `?includePOs=1` pour inclure les CTI/CTP des PO
 * compilés (Babac/HLC), default 1 (cohérent avec page /depenses).
 */
import { NextResponse, type NextRequest } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getDepenses, getPOsAsDepenses } from '@/lib/sheets/depenses';
import { getTaxesPercuesByPeriode } from '@/lib/sheets/factures';
import { deductibleFactor } from '@/lib/depenses-categories';
import { logError } from '@/lib/log';

export const maxDuration = 30;

/** Parse 'YYYY-Tn' | 'YYYY-MM' | 'YYYY' → { startDate, endDate, label } */
function _periodeToRange(periode: string): { startDate: string; endDate: string; label: string } | null {
  // YYYY-Tn (trimestre)
  const trim = periode.match(/^(\d{4})-T([1-4])$/);
  if (trim) {
    const year = parseInt(trim[1], 10);
    const tn   = parseInt(trim[2], 10);
    const startMonth = (tn - 1) * 3 + 1;
    const endMonth   = tn * 3;
    const start = `${year}-${String(startMonth).padStart(2, '0')}-01`;
    // Dernier jour du dernier mois du trimestre
    const lastDay = new Date(year, endMonth, 0).getDate();
    const end   = `${year}-${String(endMonth).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
    return { startDate: start, endDate: end, label: `T${tn} ${year}` };
  }
  // YYYY-MM (mois)
  const mois = periode.match(/^(\d{4})-(\d{2})$/);
  if (mois) {
    const year  = parseInt(mois[1], 10);
    const month = parseInt(mois[2], 10);
    const lastDay = new Date(year, month, 0).getDate();
    const start = `${year}-${mois[2]}-01`;
    const end   = `${year}-${mois[2]}-${String(lastDay).padStart(2, '0')}`;
    return { startDate: start, endDate: end, label: `${mois[1]}-${mois[2]}` };
  }
  // YYYY (année)
  if (/^\d{4}$/.test(periode)) {
    return { startDate: `${periode}-01-01`, endDate: `${periode}-12-31`, label: periode };
  }
  return null;
}

export async function GET(req: NextRequest) {
  const check = await requireAdmin();
  if (!check.ok) return NextResponse.json({ error: check.error }, { status: check.status });

  try {
    const periode = req.nextUrl.searchParams.get('periode') ?? '';
    if (!periode) return NextResponse.json({ error: 'periode requis (YYYY-Tn, YYYY-MM ou YYYY)' }, { status: 400 });
    const range = _periodeToRange(periode);
    if (!range) return NextResponse.json({ error: 'periode invalide' }, { status: 400 });

    const includePOs = req.nextUrl.searchParams.get('includePOs') !== '0';

    // Parallèle : taxes perçues + dépenses + PO compilés
    const [taxes, depenses, posCompiles] = await Promise.all([
      getTaxesPercuesByPeriode(range.startDate, range.endDate),
      getDepenses(),
      includePOs ? getPOsAsDepenses() : Promise.resolve([]),
    ]);

    // Calcul CTI/CTP — sur les dépenses du filtre (date dans [start, end])
    const inRange = (d: { date: string }) => d.date >= range.startDate && d.date <= range.endDate;
    const allDep  = [...depenses.filter(inRange), ...posCompiles.filter(inRange)];

    let cti = 0, ctp = 0, htDeductible = 0;
    for (const d of allDep) {
      const f = deductibleFactor(d.categorie, d.usagePct);
      cti          += d.tps * f;
      ctp          += d.tvq * f;
      htDeductible += d.sousTotalHT * f;
    }

    const round2 = (n: number) => Math.round(n * 100) / 100;
    const soldeTps = round2(taxes.tpsPercue - cti);
    const soldeTvq = round2(taxes.tvqPercue - ctp);

    return NextResponse.json({
      periode    : range.label,
      startDate  : range.startDate,
      endDate    : range.endDate,
      tpsPercue  : taxes.tpsPercue,
      tvqPercue  : taxes.tvqPercue,
      cti        : round2(cti),
      ctp        : round2(ctp),
      soldeTps,
      soldeTvq,
      htDeductible: round2(htDeductible),
      countDepenses: allDep.length,
      countFactures: taxes.count,
      parSource  : taxes.parSource,
    });
  } catch (err: any) {
    logError('declaration-tva-failed', { error: err?.message });
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}
