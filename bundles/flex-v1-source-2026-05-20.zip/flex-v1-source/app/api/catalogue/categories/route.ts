import { NextResponse } from 'next/server';
import { getCategories } from '@/lib/sheets/catalogue';
import cache, { CACHE_KEYS } from '@/lib/cache';

/** GET /api/catalogue/categories — ?refresh=1 invalide le cache
 *  (pieces + categories) avant de recalculer la liste. */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    if (searchParams.get('refresh') === '1') {
      await cache.del(CACHE_KEYS.PIECES);
      await cache.del(CACHE_KEYS.CATEGORIES);
    }
    const categories = await getCategories();
    return NextResponse.json({ categories });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
