import { NextRequest, NextResponse } from 'next/server';
import { getMarques, addMarque } from '@/lib/sheets/catalogue';

/** GET /api/catalogue/marques?refresh=1 — bypass cache si refresh=1 */
export async function GET(req: NextRequest) {
  try {
    const force = req.nextUrl.searchParams.get('refresh') === '1';
    const marques = await getMarques(force);
    return NextResponse.json({ marques });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** POST /api/catalogue/marques — ajouter une marque */
export async function POST(req: Request) {
  try {
    const { nom } = await req.json();
    if (!nom?.trim()) return NextResponse.json({ error: 'Nom requis' }, { status: 400 });
    await addMarque(nom.trim());
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
