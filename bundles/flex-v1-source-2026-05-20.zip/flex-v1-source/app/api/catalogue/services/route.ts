import { NextResponse } from 'next/server';
import { getServices, addService } from '@/lib/sheets/catalogue';
import cache, { CACHE_KEYS } from '@/lib/cache';

/** GET /api/catalogue/services — ?refresh=1 pour bypass le cache serveur. */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    if (searchParams.get('refresh') === '1') await cache.del(CACHE_KEYS.SERVICES);
    const services = await getServices();
    return NextResponse.json({ services });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** POST /api/catalogue/services — ajouter un nouveau service.
 *  Le prix est calculé par la formule de la sheet à partir de la durée. */
export async function POST(req: Request) {
  try {
    const { label, categorie, duree } = await req.json();
    if (!label?.trim()) {
      return NextResponse.json({ error: 'Nom du service requis' }, { status: 400 });
    }
    const result = await addService(label.trim(), categorie || '', duree || '');
    return NextResponse.json({ ok: true, ...result });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
