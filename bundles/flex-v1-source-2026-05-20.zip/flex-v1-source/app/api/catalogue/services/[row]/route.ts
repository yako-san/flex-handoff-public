import { NextResponse } from 'next/server';
import { updateServiceFields } from '@/lib/sheets/catalogue';
import { requireAdmin } from '@/lib/auth/requireAdmin';

/**
 * PATCH /api/catalogue/services/[row]
 *  - categoriePrio (col F) : ouvert à tout user authentifié (ré-ordering UI)
 *  - label (col B) / duree (col D) : RÉSERVÉ admin (modifie le catalogue
 *    de référence partagé par tout l'atelier).
 */
export async function PATCH(
  req: Request,
  { params }: { params: { row: string } }
) {
  const row  = parseInt(params.row, 10);
  if (isNaN(row)) return NextResponse.json({ error: 'row invalide' }, { status: 400 });

  const body = await req.json();
  // Si label/duree sont touchés → admin requis
  const touchesAdminFields = body.label !== undefined || body.duree !== undefined;
  if (touchesAdminFields) {
    const check = await requireAdmin();
    if (!check.ok) {
      return NextResponse.json(
        { error: check.error, code: 'ADMIN_REQUIRED' },
        { status: check.status },
      );
    }
  }

  try {
    const result = await updateServiceFields(row, {
      categoriePrio: body.categoriePrio,
      label        : body.label,
      duree        : body.duree,
    });
    // result.prix présent uniquement si la durée a changé (relu depuis col E)
    return NextResponse.json({ ok: true, ...result });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
