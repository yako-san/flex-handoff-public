import { NextResponse } from 'next/server';
import { getPieces } from '@/lib/sheets/catalogue';
import * as XLSX from 'xlsx';

/**
 * GET /api/catalogue/export — Exporte l'inventaire PIÈCES en xlsx.
 */
export async function GET() {
  try {
    const pieces = await getPieces();

    const rows = pieces.map(p => ({
      'ID': p.pieceId,
      'Nom': p.nom,
      'SKU': p.sku,
      'Fournisseur': p.fournisseur,
      'Catégorie': p.categorie,
      'Prix achat': p.prixAchat,
      'Prix base': p.prixBase,
      'Prix BDC': p.prixBDC,
      'Stock': p.stock,
      'Qté à commander': p.qteACommander,
      'Statut': p.flag,
    }));

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, 'Inventaire');
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    return new NextResponse(buf, {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="inventaire-${new Date().toISOString().slice(0, 10)}.xlsx"`,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
