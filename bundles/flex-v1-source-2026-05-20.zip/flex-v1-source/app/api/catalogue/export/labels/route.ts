import { NextResponse } from 'next/server';
import { getPieces } from '@/lib/sheets/catalogue';

/**
 * GET /api/catalogue/export/labels — Export CSV formaté pour impression
 * d'étiquettes (P-touch / Dymo) sur QL-600.
 *
 * Format :
 * - UTF-8 avec BOM (compatibilité Excel/Windows)
 * - En-têtes : SKU, Nom, Prix
 * - Séparateur virgule, guillemets doublés si valeur contient virgule/guillemet
 * - Une ligne par pièce ayant un SKU (sans SKU = pas d'étiquette pertinente)
 *
 * Query params (optionnels) :
 * - categorie=XXX : filtre sur la catégorie principale (ex. "Freins")
 * - withoutSku=1  : inclut aussi les pièces sans SKU (défaut : exclues)
 */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const filtreCategorie  = searchParams.get('categorie') ?? '';
    const includeSansSku   = searchParams.get('withoutSku') === '1';

    const pieces = await getPieces();

    // Filtrage
    let rows = pieces;
    if (!includeSansSku) {
      rows = rows.filter(p => !!p.sku && p.sku.trim() !== '');
    }
    if (filtreCategorie) {
      const lc = filtreCategorie.toLowerCase();
      rows = rows.filter(p => (p.categorie ?? '').toLowerCase().includes(lc));
    }

    // Tri : par catégorie puis nom pour cohérence à l'impression
    rows.sort((a, b) => {
      const c = (a.categorie ?? '').localeCompare(b.categorie ?? '', 'fr');
      if (c !== 0) return c;
      return (a.nom ?? '').localeCompare(b.nom ?? '', 'fr');
    });

    // Échappement CSV : si valeur contient ", , ou saut de ligne → guillemets
    // doublés autour, guillemets internes doublés.
    function esc(v: string | number | undefined | null): string {
      const s = v === undefined || v === null ? '' : String(v);
      if (s.includes(',') || s.includes('"') || s.includes('\n') || s.includes('\r')) {
        return `"${s.replace(/"/g, '""')}"`;
      }
      return s;
    }

    // Format prix : nombre simple "12.50" (pas de "$", lecteur P-touch peut
    // décider de préfixer via le template). 2 décimales.
    function fmtPrix(p: number): string {
      const v = typeof p === 'number' && isFinite(p) ? p : 0;
      return v.toFixed(2);
    }

    const header = ['SKU', 'Nom', 'Prix'].join(',');
    const lines  = rows.map(p => {
      // Fallback prix : prixBDC → prixBase → 0
      const prix = p.prixBDC ?? p.prixBase ?? 0;
      return [esc(p.sku), esc(p.nom), fmtPrix(prix)].join(',');
    });

    // BOM UTF-8 pour Excel/Windows qui décode en UTF-8 automatiquement
    const csv = '\uFEFF' + header + '\n' + lines.join('\n') + '\n';

    const today = new Date().toISOString().slice(0, 10);
    const suffix = filtreCategorie ? `-${filtreCategorie.replace(/[^a-zA-Z0-9]+/g, '_')}` : '';
    const filename = `etiquettes${suffix}-${today}.csv`;

    return new NextResponse(csv, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Cache-Control': 'no-store',
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
