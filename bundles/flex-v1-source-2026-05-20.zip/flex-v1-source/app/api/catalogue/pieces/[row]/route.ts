/**
 * PATCH /api/catalogue/pieces/[row]
 * Body (tous optionnels) : { flag, sku, fournisseur, categorie, prixBDC,
 *   qteACommander, notes, nom, prixAchat, codeBarre }
 * Met à jour les champs d'une pièce dans ACHATS.
 */
import { NextRequest, NextResponse } from 'next/server';
import { updatePieceFields } from '@/lib/sheets/catalogue';

export async function PATCH(
  req: NextRequest,
  { params }: { params: { row: string } },
) {
  try {
    const row    = parseInt(params.row, 10);
    if (isNaN(row) || row < 1) {
      return NextResponse.json({ error: 'row invalide' }, { status: 400 });
    }
    const body   = await req.json().catch(() => ({}));
    await updatePieceFields(row, {
      flag         : body.flag,
      sku          : body.sku,
      fournisseur  : body.fournisseur,
      categorie    : body.categorie,
      prixBDC      : body.prixBDC       !== undefined ? Number(body.prixBDC)       : undefined,
      qteACommander: body.qteACommander !== undefined ? Number(body.qteACommander) : undefined,
      notes        : body.notes,
      nom          : body.nom,
      prixAchat    : body.prixAchat     !== undefined ? Number(body.prixAchat)     : undefined,
      codeBarre    : body.codeBarre,
      oos          : body.oos           !== undefined ? Boolean(body.oos)          : undefined,
    });
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
