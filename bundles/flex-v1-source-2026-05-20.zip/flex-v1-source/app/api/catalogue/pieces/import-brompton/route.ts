/**
 * POST /api/catalogue/pieces/import-brompton
 *
 * Body : { rows: BromptonImportRow[] }
 * Pour chaque ligne :
 *   - Match par SKU contre le catalogue PIÈCES existant
 *   - Si trouvé → MAJ prixBDC (R), prixAchat (L), notes (AC), fournisseur='Flex',
 *     categorie='9. Brompton, {suffix}'
 *   - Sinon → création via addPieceToCatalogue + compléments (prixBDC, notes)
 *
 * Retourne un rapport {added, updated, skipped}.
 */
import { NextRequest, NextResponse }    from 'next/server';
import { bulkImportBromptonPieces }     from '@/lib/sheets/catalogue';
import type { BromptonImportRow }       from '@/lib/sheets/catalogue';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const rows = Array.isArray(body?.rows) ? body.rows as BromptonImportRow[] : null;
    if (!rows || !rows.length) {
      return NextResponse.json({ error: 'Aucune ligne à importer' }, { status: 400 });
    }
    const report = await bulkImportBromptonPieces(rows);
    return NextResponse.json(report, { status: 200 });
  } catch (err: any) {
    console.error('[import-brompton]', err);
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}
