/**
 * POST /api/square/link-to-bdc
 * Body : { squareBookingId: string, bdcId: string }
 *
 * v1.0.22+ : lie un RV Square (typiquement retrait/essayage qui ne crée
 * pas de BDT automatiquement, cf v1.0.20) à un BDT existant du même
 * client. Action :
 *  1. Récupère le booking Square
 *  2. Récupère le vélo correspondant au BDT (1 vélo = 1 BDT)
 *  3. Construit un en-tête de note interne :
 *       Pré-inscription Square — YYYY-MM-DD, HH h MM
 *       👋 Rencontre : retrait et essayage
 *       ──────────────────────
 *  4. Prepend l'en-tête à la note interne du vélo (si plusieurs RV liés
 *     successifs, ils s'empilent en tête, du plus récent au plus ancien,
 *     sur lignes séparées — cf décision UX Q4)
 *  5. Marque `sq_<bookingId>` → bdcId dans `_EMAIL_TEMPLATES_` (pour
 *     éviter de proposer à nouveau le lien au prochain refresh dashboard)
 *
 * Retourne : { veloId, alreadyLinked: boolean, note: string }
 */
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { getUpcomingBookings } from '@/lib/square/bookings';
import { getVelos, updateVelo } from '@/lib/sheets/inventaire';
import { getEmailTemplates, saveEmailTemplates } from '@/lib/sheets/emailTemplates';
import { isoToMontrealDateHeureInline } from '@/lib/utils/format';
import { logError } from '@/lib/log';

export const maxDuration = 30;

export async function POST(req: Request) {
  try {
    const session = await auth();
    if (!session) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

    const body = await req.json();
    const bookingId = String(body?.squareBookingId ?? '').trim();
    const bdcId     = String(body?.bdcId ?? '').trim();
    if (!bookingId || !bdcId) {
      return NextResponse.json({ error: 'squareBookingId et bdcId requis' }, { status: 400 });
    }

    // 1. Check si déjà lié
    const templates = await getEmailTemplates();
    const existing  = templates[`sq_${bookingId}`];
    if (existing && existing === bdcId) {
      return NextResponse.json({
        veloId       : bdcId,
        alreadyLinked: true,
        note         : '',
      });
    }
    if (existing && existing !== bdcId) {
      // Booking déjà lié à un AUTRE BDT — on refuse pour éviter une perte
      // d'historique (note interne du précédent BDT) silencieuse.
      return NextResponse.json({
        error: `Ce RV est déjà lié au BDT ${existing}. Désynchroniser d'abord (page admin) avant de re-lier.`,
      }, { status: 409 });
    }

    // 2. Récupère le booking
    const bookings = await getUpcomingBookings(180);
    const booking  = bookings.find(b => b.id === bookingId);
    if (!booking) {
      return NextResponse.json({ error: 'Booking Square introuvable' }, { status: 404 });
    }

    // 3. Récupère le vélo correspondant au BDT
    const velos = await getVelos();
    const velo  = velos.find(v => v.id === bdcId);
    if (!velo) {
      return NextResponse.json({ error: `BDT ${bdcId} introuvable` }, { status: 404 });
    }

    // 4. Construit le bloc à insérer en tête de note interne. Format
    //    cohérent avec la pré-inscription Square initiale du BDT, mais sans
    //    la ligne `Client : <nom>` (le client est déjà visible dans le BDT).
    const sepLine  = '──────────────────────';
    const newBlock = [
      `Pré-inscription Square — ${isoToMontrealDateHeureInline(booking.startAt)}`,
      booking.services || '',
      sepLine,
    ].filter(Boolean).join('\n');

    // 5. Prepend l'en-tête à la note interne existante. Si une note
    //    existe déjà, on ajoute un saut de ligne entre les blocs.
    const oldNotes = velo.notes && velo.notes !== '...' ? velo.notes : '';
    const newNotes = oldNotes ? `${newBlock}\n${oldNotes}` : newBlock;

    await updateVelo(velo.id, { notes: newNotes });

    // 6. Marque le booking comme lié (sq_<bookingId> → bdcId). Empêche le
    //    Dashboard de re-proposer le bouton « Lier au BDT » à ce booking.
    await saveEmailTemplates({ [`sq_${bookingId}`]: bdcId });

    return NextResponse.json({
      veloId       : bdcId,
      alreadyLinked: false,
      note         : newBlock,
    });
  } catch (err: any) {
    logError('square-link-to-bdc-failed', { error: err?.message ?? String(err) });
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}
