/**
 * POST /api/square/backfill-notes
 *
 * Pour chaque mapping sq_<bookingId> → veloId dans _EMAIL_TEMPLATES_,
 * récupère le booking Square et reconstruit la note interne (autoHeader
 * + séparation + customer_note + seller_note) puis met à jour la col U
 * (notes) du vélo dans INVENTAIRE — seulement si :
 *  - le booking Square existe encore
 *  - le vélo est encore en INVENTAIRE actif (pas archivé)
 *  - la note actuelle est vide ou '...' (ne pas écraser une note manuelle)
 *
 * Sécurisé via CRON_SECRET ou requireAdmin.
 *
 * Output : { updated: [...], skipped: [...], errors: [...] }
 */
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { getEmailTemplates } from '@/lib/sheets/emailTemplates';
import { getUpcomingBookings } from '@/lib/square/bookings';
import { getVelo, updateVelo } from '@/lib/sheets/inventaire';
import { getClients, patchClient } from '@/lib/sheets/clients';
import { isoToMontrealDateHeure, isoToMontrealDateHeureInline, telDigits } from '@/lib/utils/format';

export const maxDuration = 60;
export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  // Auth : session + admin (yako.cyclo)
  const session = await auth();
  const email   = (session?.user?.email ?? '').trim().toLowerCase();
  if (!email) {
    return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
  }
  if (email !== 'yako.cyclo@gmail.com') {
    return NextResponse.json({ error: 'Réservé admin' }, { status: 403 });
  }

  if (!process.env.SQUARE_ACCESS_TOKEN || !process.env.SQUARE_LOCATION_ID) {
    return NextResponse.json({ error: 'Square non configuré' }, { status: 503 });
  }

  // Parse body — peut contenir overwriteAll: true pour forcer la
  // réécriture même si une note existe déjà.
  const body = await req.json().catch(() => ({}));
  const overwriteAll = body?.overwriteAll === true;

  try {
    const templates = await getEmailTemplates();
    const sqKeys = Object.keys(templates).filter(k =>
      k.startsWith('sq_') && !k.startsWith('sq_cal_') && templates[k]
    );
    if (sqKeys.length === 0) {
      return NextResponse.json({ ok: true, updated: [], skipped: [], errors: [], message: 'Aucun mapping sq_*' });
    }

    // Charge tous les bookings (180j) une fois
    const bookings = await getUpcomingBookings(180);
    const bookingById = new Map(bookings.map(b => [b.id, b]));

    const updated: Array<{ bookingId: string; veloId: string; clientPatched?: string[] }> = [];
    const skipped: Array<{ bookingId: string; veloId: string; reason: string }> = [];
    const errors : Array<{ bookingId: string; error: string }> = [];

    // Précharge clients (1 seul fetch pour tous les bookings)
    const grouped    = await getClients(true);
    const allClients = [...grouped.recents, ...grouped.actifs, ...grouped.autres];

    for (const key of sqKeys) {
      const bookingId = key.replace(/^sq_/, '');
      const veloId    = String(templates[key] ?? '').trim();
      if (!veloId) { skipped.push({ bookingId, veloId, reason: 'mapping vide' }); continue; }

      const booking = bookingById.get(bookingId);
      if (!booking) {
        skipped.push({ bookingId, veloId, reason: 'booking Square introuvable (hors fenêtre 180j ou supprimé)' });
        continue;
      }

      try {
        const velo = await getVelo(veloId);
        if (!velo) { skipped.push({ bookingId, veloId, reason: 'vélo absent INVENTAIRE (archivé ?)' }); continue; }

        const currentNote = (velo.notes ?? '').trim();
        const isEmpty = !currentNote || currentNote === '...' || currentNote === '—';
        if (!isEmpty && !overwriteAll) {
          skipped.push({ bookingId, veloId, reason: 'note existante (utilise overwriteAll pour forcer)' });
          continue;
        }

        const clientNom = velo.client || '';
        const sepLine    = '──────────────────────';
        // v1.0.20+ : date inline + retrait préfixe « Services : »
        const autoHeader = [
          `Pré-inscription Square — ${isoToMontrealDateHeureInline(booking.startAt)}`,
          clientNom ? `Client : ${clientNom}` : '',
          booking.services || '',
        ].filter(Boolean).join('\n');
        const userNotes = [
          booking.customerNote ? `Note client : ${booking.customerNote}` : '',
          booking.sellerNote   ? `Note seller : ${booking.sellerNote}`   : '',
        ].filter(Boolean).join('\n\n');
        const noteInterne = `${autoHeader}\n${sepLine}\n${userNotes}`.trim();

        await updateVelo(veloId, { notes: noteInterne });

        // Backfill fiche CLIENTS — remplit les champs vides depuis Square
        // customer (tél, courriel). Match par nom complet ; ne touche
        // jamais une valeur déjà présente sauf si overwriteAll.
        const clientPatched: string[] = [];
        if (booking.customer && clientNom) {
          const cli = allClients.find(c => c.nomComplet === clientNom);
          if (cli) {
            const fields: Partial<{ tel: string; courriel: string }> = {};
            const sqTel   = (booking.customer.tel   ?? '').trim();
            const sqEmail = (booking.customer.email ?? '').trim();
            const curTel   = telDigits(cli.tel);
            const curEmail = (cli.courriel ?? '').trim();
            if (sqTel && (overwriteAll || !curTel)) {
              fields.tel = sqTel;
              clientPatched.push('tel');
            }
            if (sqEmail && (overwriteAll || !curEmail)) {
              fields.courriel = sqEmail;
              clientPatched.push('courriel');
            }
            if (Object.keys(fields).length > 0) {
              await patchClient(cli._row, fields).catch(err => {
                console.warn('[backfill] patchClient échec', err?.message);
              });
            }
          }
        }

        updated.push({ bookingId, veloId, clientPatched: clientPatched.length > 0 ? clientPatched : undefined });
      } catch (err: any) {
        errors.push({ bookingId, error: err?.message ?? 'erreur inconnue' });
      }
    }

    return NextResponse.json({
      ok      : true,
      ts      : new Date().toISOString(),
      updated,
      skipped,
      errors,
      stats   : {
        total    : sqKeys.length,
        updated  : updated.length,
        skipped  : skipped.length,
        errors   : errors.length,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}
