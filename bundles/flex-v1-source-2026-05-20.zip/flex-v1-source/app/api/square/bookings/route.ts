import { NextResponse } from 'next/server';
import { getUpcomingBookings, invalidateBookingsCache } from '@/lib/square/bookings';
import { getEmailTemplates } from '@/lib/sheets/emailTemplates';

export const maxDuration = 30;

/**
 * GET /api/square/bookings — retourne les RDV Square à venir.
 *
 * Query params :
 *  - ?days=N : fenêtre en jours depuis maintenant (défaut 30, max 180)
 *  - ?refresh=1 : invalide le cache (force re-fetch Square)
 *
 * Retourne 200 { bookings: SquareBooking[] } en cas de succès,
 * 503 { error, configMissing: true } si les env vars Square ne sont
 * pas configurées côté serveur.
 */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    if (searchParams.get('refresh') === '1') await invalidateBookingsCache();
    const daysRaw = parseInt(searchParams.get('days') ?? '30', 10);
    const days    = isFinite(daysRaw) ? Math.min(Math.max(1, daysRaw), 180) : 30;

    const bookings = await getUpcomingBookings(days);

    // Cross-reference avec les mappings sq_<bookingId> → veloId pour
    // indiquer si un BDT a déjà été créé pour chaque RDV (permet au
    // Dashboard de masquer le badge NEW et le bouton + quand c'est fait)
    let synced: Record<string, string> = {};
    try {
      const tpl = await getEmailTemplates();
      for (const [k, v] of Object.entries(tpl)) {
        // sq_<bookingId> → veloId (on exclut sq_cal_<bookingId> → eventId)
        if (k.startsWith('sq_') && !k.startsWith('sq_cal_') && v) {
          synced[k.slice(3)] = String(v);
        }
      }
    } catch { /* best-effort */ }

    const enriched = bookings.map(b => ({
      ...b,
      syncedVeloId: synced[b.id] || null,
    }));

    return NextResponse.json({ bookings: enriched });
  } catch (err: any) {
    const msg = err?.message ?? 'Erreur Square';
    if (/SQUARE_.*non configuré/.test(msg)) {
      return NextResponse.json(
        { error: msg, configMissing: true, bookings: [] },
        { status: 503 },
      );
    }
    return NextResponse.json({ error: msg, bookings: [] }, { status: 500 });
  }
}
