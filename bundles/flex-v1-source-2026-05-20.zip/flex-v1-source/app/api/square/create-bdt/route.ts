/**
 * POST /api/square/create-bdt
 * Body : { squareBookingId: string }
 *
 * Orchestration :
 *  1. Récupère le booking Square (+ customer)
 *  2. Cherche un client FLEX-REV par email ou téléphone normalisé
 *     - Si trouvé : utilise le nomComplet existant
 *     - Sinon : crée un nouveau client via creerClient
 *  3. Génère le prochain ID vélo
 *  4. Appelle addVelo avec status='RV', date1=date du RDV
 *  5. Appelle creerBon pour créer la structure BDC correspondante
 *  6. Stocke le mapping squareBookingId → veloId dans _EMAIL_TEMPLATES_
 *     (clé `sq_<bookingId>`) pour éviter les doublons au prochain sync
 *
 * Retourne : { veloId, clientCreated: boolean, alreadySynced: boolean }
 */
import { NextResponse } from 'next/server';
import { getUpcomingBookings } from '@/lib/square/bookings';
import { getClients, creerClient } from '@/lib/sheets/clients';
import { addVelo, updateVelo } from '@/lib/sheets/inventaire';
import { creerBon, insertServices } from '@/lib/sheets/bdc';
import { getServices } from '@/lib/sheets/catalogue';
import { prochainID } from '@/lib/sheets/counter';
import { getEmailTemplates, saveEmailTemplates } from '@/lib/sheets/emailTemplates';
import { telDigits, isoToMontrealDateHeure, isoToMontrealDateHeureInline } from '@/lib/utils/format';
import { auth } from '@/lib/auth';
import { createCalendarEvent } from '@/lib/google/calendar';

export const maxDuration = 30;

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const bookingId = String(body?.squareBookingId ?? '').trim();
    if (!bookingId) {
      return NextResponse.json({ error: 'squareBookingId requis' }, { status: 400 });
    }

    // 1. Check si déjà synchronisé
    const templates = await getEmailTemplates();
    const existingVeloId = templates[`sq_${bookingId}`];
    if (existingVeloId) {
      return NextResponse.json({
        veloId        : existingVeloId,
        alreadySynced : true,
        clientCreated : false,
      });
    }

    // 2. Récupère le booking dans la liste à venir
    const bookings = await getUpcomingBookings(180);
    const booking  = bookings.find(b => b.id === bookingId);
    if (!booking) {
      return NextResponse.json({ error: 'Booking Square introuvable' }, { status: 404 });
    }
    if (!booking.customer) {
      return NextResponse.json({ error: 'Booking sans client attaché' }, { status: 400 });
    }

    // 3. Matching client FLEX-REV par email ou téléphone normalisé
    const sqClient  = booking.customer;
    const grouped   = await getClients(false);
    const allClients = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
    const emailNorm = sqClient.email.toLowerCase().trim();
    const telNorm   = telDigits(sqClient.tel);
    const existing = allClients.find(c => {
      if (emailNorm && (c.courriel ?? '').toLowerCase() === emailNorm) return true;
      if (telNorm   && telDigits(c.tel) === telNorm) return true;
      return false;
    });

    let clientCreated = false;
    let clientNom = '';
    if (existing) {
      clientNom = existing.nomComplet;
    } else {
      // 4a. Création auto client
      const newClient = await creerClient({
        prenom  : sqClient.prenom || 'Client',
        nom     : sqClient.nom    || 'Square',
        tel     : sqClient.tel,
        courriel: sqClient.email,
        commPref: (templates.client_default_commpref as any) || 'Courriel,Texto',
        lang    : ((templates.client_default_lang === 'EN' ? 'EN' : 'FR') as any),
        lead    : 'yako.cyclo',
        notes   : `Pré-inscription Square · RDV ${new Date(booking.startAt).toLocaleString('fr-CA')}${booking.services ? ' · ' + booking.services : ''}`,
      } as any);
      clientCreated = true;
      clientNom = newClient.nomComplet;
    }

    // 5. Création vélo + BDC
    const veloId = await prochainID();
    // Note interne : auto avant séparation, notes Square (customer + seller)
    // après. Convention partagée avec sync.ts.
    const sepLine    = '──────────────────────';
    // v1.0.20+ : date inline + retrait préfixe « Services : »
    const autoHeader = [
      `Pré-inscription Square — ${isoToMontrealDateHeureInline(booking.startAt)}`,
      `Client : ${clientNom}`,
      booking.services || '',
    ].filter(Boolean).join('\n');
    const userNotes = [
      booking.customerNote ? `Note client : ${booking.customerNote}` : '',
      booking.sellerNote   ? `Note seller : ${booking.sellerNote}`   : '',
    ].filter(Boolean).join('\n\n');
    const noteInterne = `${autoHeader}\n${sepLine}\n${userNotes}`.trim();
    await addVelo(veloId, {
      client: clientNom,
      status: 'RV',
      date1 : isoToMontrealDateHeure(booking.startAt) || booking.startAt,
      notes : noteInterne,
    });
    await creerBon(veloId, clientNom, booking.services || 'À renseigner au RDV');

    // 6a. Auto-fill : si le booking Square correspond à un service du
    //     catalogue (match fuzzy sur le label), on injecte ce service dans
    //     le BDT pour que le mécano voie d'emblée la prestation prévue. Cas
    //     typique : "👋 Rencontre : ramassage et livraison" (S00092, 60 $).
    //     Robuste aux variations d'espaces / accents / emojis Square.
    if (booking.services) {
      try {
        const allServices = await getServices();
        const norm = (s: string) => s
          .normalize('NFD').replace(/[̀-ͯ]/g, '')
          .toLowerCase()
          .replace(/[^\p{L}\p{N}]+/gu, ' ')
          .trim();
        const target = norm(booking.services);
        const matched = allServices.find(s => {
          const n = norm(s.label);
          return n.length > 0 && (n === target || target.includes(n) || n.includes(target));
        });
        if (matched) {
          await insertServices(veloId, [{
            serviceId: matched.serviceId,
            nom      : matched.label,
            prix     : matched.prix,
          }]);
        }
      } catch (svcErr: any) {
        console.warn('[create-bdt] auto-fill service échoué :', svcErr?.message ?? svcErr);
      }
    }

    // 6b. Auto-fill : noteClient du BDT depuis la note Square du customer.
    //     La note est aussi déjà dans noteInterne (col W de INVENTAIRE), mais
    //     col V (noteClientEval) la rend visible côté client dans le PDF
    //     d'évaluation. Le mécano peut ensuite la modifier avant envoi.
    if (booking.customerNote) {
      try {
        await updateVelo(veloId, { noteClientEval: booking.customerNote });
      } catch (noteErr: any) {
        console.warn('[create-bdt] note client BDT échouée :', noteErr?.message ?? noteErr);
      }
    }

    // 7. Mémoriser le lien bookingId → veloId
    await saveEmailTemplates({ [`sq_${bookingId}`]: veloId });

    // 7. Créer l'événement Google Calendar. Best-effort mais on remonte
    //    l'erreur dans la réponse pour que l'UI puisse l'afficher (avant
    //    v7.0.31, l'échec était silencieusement loggé en console.warn et
    //    le user n'avait aucun feedback → calendar absent sans avertissement).
    let calendarEventId: string | null = null;
    let calendarError  : string | null = null;
    try {
      const session = await auth();
      const accessToken  = session?.googleAccessToken  as string | undefined;
      const refreshToken = session?.googleRefreshToken as string | undefined;
      if (!accessToken) {
        calendarError = 'Aucun token Google en session — déconnecte-toi puis reconnecte-toi pour autoriser Calendar.';
      } else {
        const eventId = await createCalendarEvent({
          summary       : `RDV ${booking.services || 'Éval.'} : ${clientNom}`,
          startAtIso    : booking.startAt,
          durationMin   : booking.durationMin || 60,
          description   : [
            `Client : ${clientNom}`,
            sqClient.email ? `Courriel : ${sqClient.email}` : '',
            sqClient.tel ? `Tél : ${sqClient.tel}` : '',
            `Services : ${booking.services || 'À renseigner au RDV'}`,
            '',
            `BDT FLEX-REV : #${veloId}`,
          ].filter(Boolean).join('\n'),
          attendeeEmail : sqClient.email || undefined,
          attendeeName  : clientNom,
        }, accessToken, refreshToken);
        calendarEventId = eventId;
        await saveEmailTemplates({ [`sq_cal_${bookingId}`]: eventId });
      }
    } catch (calErr: any) {
      const msg = calErr?.message ?? String(calErr);
      console.warn('[create-bdt] Calendar event creation failed :', msg);
      // Indices typiques quand le scope `calendar.events` n'est pas accordé.
      const looksLikeScope = /insufficient|invalid_grant|invalid_scope|forbidden|permission/i.test(msg);
      calendarError = looksLikeScope
        ? `Calendar refusé (scope manquant ?). Déconnecte-toi puis reconnecte-toi. Détail : ${msg}`
        : msg;
    }

    return NextResponse.json({
      veloId, clientCreated, calendarEventId, calendarError,
      alreadySynced: false,
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Erreur' }, { status: 500 });
  }
}
