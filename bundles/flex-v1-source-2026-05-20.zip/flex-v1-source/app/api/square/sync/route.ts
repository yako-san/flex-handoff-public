/**
 * GET /api/square/sync — endpoint cron + manuel.
 *
 * Appelé automatiquement par Vercel Cron (cf. vercel.json) toutes les
 * 15 min. Peut aussi être lancé manuellement (depuis un script ou un
 * bouton admin).
 *
 * Sécurité :
 *  - Les appels Vercel Cron portent l'en-tête
 *    `Authorization: Bearer <CRON_SECRET>` (doc Vercel). On le vérifie.
 *  - On accepte aussi `?secret=<CRON_SECRET>` pour test manuel depuis
 *    le navigateur.
 *  - Si `CRON_SECRET` n'est pas configuré côté serveur → mode ouvert
 *    (dev). En prod il FAUT le configurer dans Vercel env vars.
 *
 * Output : JSON résumé { created, cancelled, skipped, errors }.
 */
import { NextResponse } from 'next/server';
import { syncUpcomingBookings, syncCancellations } from '@/lib/square/sync';
import { invalidateBookingsCache } from '@/lib/square/bookings';

export const maxDuration = 60;  // peut être long si beaucoup de RDV à créer
export const dynamic    = 'force-dynamic';

function isAuthorized(req: Request): boolean {
  const secret = process.env.CRON_SECRET;
  if (!secret) return true; // pas configuré → on laisse passer (dev)

  const auth = req.headers.get('authorization') ?? '';
  if (auth === `Bearer ${secret}`) return true;

  try {
    const url = new URL(req.url);
    if (url.searchParams.get('secret') === secret) return true;
  } catch { /* ignore */ }

  return false;
}

export async function GET(req: Request) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // Square non configuré (ex. localhost sans env vars) → no-op silencieux
  // pour ne pas spammer 500 dans la console / Dashboard auto-sync.
  if (!process.env.SQUARE_ACCESS_TOKEN || !process.env.SQUARE_LOCATION_ID) {
    return NextResponse.json({
      ok            : true,
      ts            : new Date().toISOString(),
      created       : [],
      cancelled     : [],
      skipped       : 0,
      errors        : [],
      configMissing : true,
    });
  }

  try {
    // Force re-fetch Square (bypass cache 2 min) pour avoir la vue fraîche
    await invalidateBookingsCache();

    const createdResult = await syncUpcomingBookings(180);
    const cancelResult  = await syncCancellations(180);

    return NextResponse.json({
      ok        : true,
      ts        : new Date().toISOString(),
      created   : createdResult.created,
      cancelled : cancelResult.cancelled,
      skipped   : createdResult.skipped,
      errors    : [...createdResult.errors, ...cancelResult.errors],
      // Statut Calendar (best-effort, séparé des errors[] qui blocaient
      // la création BDT) — permet de diagnostiquer un token revoke ou
      // un scope manquant sans laisser le user dans le flou.
      ownerTokenStatus: createdResult.ownerTokenStatus,
      calendarErrors  : createdResult.calendarErrors ?? [],
    });
  } catch (err: any) {
    return NextResponse.json(
      { ok: false, error: err?.message ?? 'Erreur sync' },
      { status: 500 },
    );
  }
}
