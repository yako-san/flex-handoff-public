/**
 * POST /api/square/webhook
 *
 * Endpoint webhook Square. Configure cet URL dans le Square Dashboard
 * Developer → Webhooks et abonne-toi aux events 'booking.created' et
 * 'booking.updated'.
 *
 * NOTE : Square n'a pas d'event 'booking.canceled' séparé. Les
 * annulations arrivent comme 'booking.updated' avec status
 * CANCELLED_BY_CUSTOMER ou CANCELLED_BY_SELLER. Le handler updated
 * détecte ce cas et délègue à syncCancellations.
 *
 * Sécurité : Square signe chaque payload avec HMAC-SHA256 dans le
 * header `x-square-hmacsha256-signature`. On vérifie la signature
 * avec la clé `SQUARE_WEBHOOK_SIGNATURE_KEY` (env var). Si la clé
 * n'est pas configurée → mode permissif (dev), sinon vérification
 * stricte.
 *
 * Output : { ok: true, event, bookingId } ou 401 si signature invalide.
 */
import { NextResponse } from 'next/server';
import crypto from 'crypto';
import {
  handleBookingCreated,
  handleBookingUpdated,
} from '@/lib/square/webhookHandlers';

export const maxDuration = 30;
export const dynamic = 'force-dynamic';

/** Vérifie la signature HMAC-SHA256 du webhook Square. */
function verifySquareSignature(
  rawBody  : string,
  notificationUrl: string,
  signature: string | null,
  signatureKey: string,
): boolean {
  if (!signature) return false;
  const hmac = crypto.createHmac('sha256', signatureKey);
  hmac.update(notificationUrl + rawBody);
  const computed = hmac.digest('base64');
  // Comparaison constant-time
  try {
    return crypto.timingSafeEqual(Buffer.from(computed), Buffer.from(signature));
  } catch { return false; }
}

export async function POST(req: Request) {
  // Lit le body brut pour la signature (avant parse JSON)
  const rawBody = await req.text();

  const signatureKey = process.env.SQUARE_WEBHOOK_SIGNATURE_KEY;
  const notificationUrl = process.env.SQUARE_WEBHOOK_URL
    ?? `https://${req.headers.get('host')}/api/square/webhook`;

  if (signatureKey) {
    const sig = req.headers.get('x-square-hmacsha256-signature');
    const ok  = verifySquareSignature(rawBody, notificationUrl, sig, signatureKey);
    if (!ok) {
      console.warn('[webhook] Signature invalide', {
        url      : notificationUrl,
        sigHeader: sig ? `${sig.slice(0, 8)}...` : '(absent)',
        keyLen   : signatureKey.length,
        bodyLen  : rawBody.length,
      });
      return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
    }
  }
  // Sinon mode permissif (dev sans clé configurée)

  let payload: any;
  try { payload = JSON.parse(rawBody); }
  catch { return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 }); }

  const eventType = String(payload?.type ?? '').trim();
  const booking   = payload?.data?.object?.booking ?? {};
  const bookingId = String(booking?.id ?? payload?.data?.id ?? '').trim();

  if (!eventType || !bookingId) {
    return NextResponse.json({ error: 'event ou bookingId manquant' }, { status: 400 });
  }

  // Gestion async best-effort. On répond immédiatement à Square pour
  // éviter timeout (Square attend < 3s pour 200 OK).
  try {
    if (eventType === 'booking.created') {
      // pas await — on lance et on répond
      handleBookingCreated(bookingId).catch(err =>
        console.warn('[webhook] booking.created handler échec', err?.message)
      );
    } else if (eventType === 'booking.updated') {
      // booking.updated couvre aussi les annulations (status CANCELLED_*)
      handleBookingUpdated(bookingId).catch(err =>
        console.warn('[webhook] booking.updated handler échec', err?.message)
      );
    } else {
      // Event non géré → 200 quand même pour ne pas que Square retry
      return NextResponse.json({ ok: true, ignored: true, eventType });
    }
  } catch (err: any) {
    console.error('[webhook] erreur', err);
    return NextResponse.json({ ok: false, error: err?.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true, eventType, bookingId, dispatched: true });
}
