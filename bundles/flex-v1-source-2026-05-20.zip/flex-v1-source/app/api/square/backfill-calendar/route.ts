/**
 * POST /api/square/backfill-calendar
 *
 * Pour chaque mapping sq_<bookingId> → veloId qui n'a PAS de
 * sq_cal_<bookingId> associé, crée l'évènement Calendar manquant
 * (yako.cyclo@gmail.com via GOOGLE_OWNER_REFRESH_TOKEN).
 *
 * Best-effort : skip si booking hors fenêtre 180j, vélo absent, ou
 * pas d'owner token configuré.
 *
 * Output : { created, skipped, errors }
 */
import { NextResponse } from 'next/server';
import { auth }                    from '@/lib/auth';
import { getEmailTemplates,
         saveEmailTemplates }      from '@/lib/sheets/emailTemplates';
import { getUpcomingBookings }     from '@/lib/square/bookings';
import { getVelo }                 from '@/lib/sheets/inventaire';
import { getOwnerAccessToken,
         NoOwnerTokenError }       from '@/lib/google/ownerToken';
import { createCalendarEvent }     from '@/lib/google/calendar';

export const maxDuration = 60;
export const dynamic = 'force-dynamic';

export async function POST() {
  const session = await auth();
  const email   = (session?.user?.email ?? '').trim().toLowerCase();
  if (!email) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
  if (email !== 'yako.cyclo@gmail.com') {
    return NextResponse.json({ error: 'Réservé admin' }, { status: 403 });
  }

  // Owner token requis pour créer les events
  let ownerToken: { accessToken: string; refreshToken: string };
  try {
    ownerToken = await getOwnerAccessToken();
  } catch (err) {
    if (err instanceof NoOwnerTokenError) {
      return NextResponse.json({
        error: 'GOOGLE_OWNER_REFRESH_TOKEN non configuré (cf. /parametres/owner-token)',
      }, { status: 503 });
    }
    throw err;
  }

  if (!process.env.SQUARE_ACCESS_TOKEN || !process.env.SQUARE_LOCATION_ID) {
    return NextResponse.json({ error: 'Square non configuré' }, { status: 503 });
  }

  try {
    const tpl = await getEmailTemplates();
    const sqKeys = Object.keys(tpl).filter(k =>
      k.startsWith('sq_') && !k.startsWith('sq_cal_') && tpl[k]
    );

    const bookings    = await getUpcomingBookings(180);
    const bookingById = new Map(bookings.map(b => [b.id, b]));

    const created: Array<{ bookingId: string; eventId: string }> = [];
    const skipped: Array<{ bookingId: string; reason: string }> = [];
    const errors : Array<{ bookingId: string; error: string }> = [];

    for (const key of sqKeys) {
      const bookingId = key.replace(/^sq_/, '');
      const veloId    = String(tpl[key] ?? '').trim();
      if (!veloId) { skipped.push({ bookingId, reason: 'mapping vide' }); continue; }

      // Si l'event Calendar existe déjà → skip
      if (tpl[`sq_cal_${bookingId}`]) {
        skipped.push({ bookingId, reason: 'Calendar event déjà créé' });
        continue;
      }

      const booking = bookingById.get(bookingId);
      if (!booking) {
        skipped.push({ bookingId, reason: 'booking Square introuvable (hors fenêtre 180j)' });
        continue;
      }
      if (!booking.customer) {
        skipped.push({ bookingId, reason: 'booking sans client' });
        continue;
      }
      // Skip si déjà annulé
      if (booking.status && /CANCEL/i.test(booking.status)) {
        skipped.push({ bookingId, reason: `booking status ${booking.status}` });
        continue;
      }

      try {
        const velo = await getVelo(veloId);
        if (!velo) { skipped.push({ bookingId, reason: 'vélo archivé / absent' }); continue; }

        const clientNom = velo.client || `${booking.customer.prenom} ${booking.customer.nom}`.trim();
        const eventId = await createCalendarEvent({
          summary     : `RDV ${booking.services || 'Éval.'} : ${clientNom}`,
          startAtIso  : booking.startAt,
          durationMin : booking.durationMin || 60,
          description : [
            `Client : ${clientNom}`,
            booking.customer.email ? `Courriel : ${booking.customer.email}` : '',
            booking.customer.tel ? `Tél : ${booking.customer.tel}` : '',
            `Services : ${booking.services || 'À renseigner au RDV'}`,
            '',
            `BDT FLEX-REV : #${veloId}`,
          ].filter(Boolean).join('\n'),
          attendeeEmail: booking.customer.email || undefined,
          attendeeName : clientNom,
        }, ownerToken.accessToken, ownerToken.refreshToken);

        await saveEmailTemplates({ [`sq_cal_${bookingId}`]: eventId });
        created.push({ bookingId, eventId });
      } catch (err: any) {
        errors.push({ bookingId, error: err?.message ?? 'erreur inconnue' });
      }
    }

    return NextResponse.json({
      ok      : true,
      ts      : new Date().toISOString(),
      created,
      skipped,
      errors,
      stats   : {
        total   : sqKeys.length,
        created : created.length,
        skipped : skipped.length,
        errors  : errors.length,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}
