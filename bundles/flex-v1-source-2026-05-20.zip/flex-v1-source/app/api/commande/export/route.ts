/**
 * GET /api/commande/export?fournisseur=HLC
 *
 * Exporte en xlsx les pièces flaggées '$' (en commande) pour un fournisseur
 * donné. Utile pour envoyer la commande au fournisseur avant de créer le PO.
 *
 * Colonnes : SKU | Item | Qté | Prix unit | S/total
 * Prix formaté "00,00 $"
 */
import { NextResponse } from 'next/server';
import { getPieces }    from '@/lib/sheets/catalogue';
import * as XLSX        from 'xlsx';

function isExcluded(nom: string): boolean {
  if (!nom || nom.trim() === '') return true;
  const n = nom.trim().toLowerCase();
  if (n === 'nom item' || n === 'item') return true;
  if (nom.startsWith('FIN DE')) return true;
  return false;
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const fournisseur      = searchParams.get('fournisseur') ?? '';
    if (!fournisseur) {
      return NextResponse.json({ error: 'Paramètre ?fournisseur requis' }, { status: 400 });
    }

    const pieces = await getPieces();
    const items  = pieces.filter(p =>
      !isExcluded(p.nom) && p.flag === '$' && (p.fournisseur || 'Autres') === fournisseur
    );

    const fmtPrix = (n: number) => `${n.toFixed(2).replace('.', ',')} $`;

    // Format spécifique HLC : colonnes fixes imposées par le fournisseur
    const isHLC = fournisseur.toUpperCase() === 'HLC';

    const rows = items.map(p => {
      const qte  = p.qteACommander || 1;
      const prix = p.prixAchat || p.prixBase || 0;
      if (isHLC) {
        return {
          "No d'article, UPC ou EAN"       : p.sku || '',
          'Quantité'                       : qte,
          'Prix sur les étiquettes'        : prix.toFixed(2),  // ex "75.00"
          "Votre numéro d'article"         : p.pieceId || '',
          'Description sur les étiquettes' : p.nom,
        };
      }
      return {
        'SKU'       : p.sku || '',
        'Item'      : p.nom,
        'Qté'       : qte,
        'Prix unit' : fmtPrix(prix),
        'S/total'   : fmtPrix(qte * prix),
      };
    });

    // Ligne total — seulement pour le format générique
    if (!isHLC && rows.length > 0) {
      const total = items.reduce((s, p) => s + (p.qteACommander || 1) * (p.prixAchat || p.prixBase || 0), 0);
      rows.push({ 'SKU': '', 'Item': 'TOTAL', 'Qté': 0, 'Prix unit': '', 'S/total': fmtPrix(total) } as any);
    }

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, fournisseur.slice(0, 31)); // nom onglet xlsx max 31 chars
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    const today     = new Date().toISOString().slice(0, 10);
    const fournSlug = fournisseur.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9]/g, '') || 'fournisseur';
    const fileName  = `commande-${fournSlug}-${today}.xlsx`;

    return new NextResponse(buf, {
      headers: {
        'Content-Type'       : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="${fileName}"`,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
