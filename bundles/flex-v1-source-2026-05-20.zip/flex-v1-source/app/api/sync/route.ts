import { NextResponse } from 'next/server';
import { smartSync, invalidateAllCaches } from '@/lib/sync';
import { SHEET_IDS } from '@/lib/sheets/client';

/**
 * POST /api/sync — sync intelligent.
 * Compare les timestamps des documents Sheets et invalide uniquement
 * les caches des documents modifiés.
 *
 * ?force=1 → invalide tout sans vérifier les timestamps.
 */
export async function POST(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const force = searchParams.get('force') === '1';

    // v1.1.5 — Item 12 audit : DEV_ID auparavant en clair dans la source.
    // Maintenant lu depuis l'env (SHEETS_PIECES_DEV_ID) — laisse null si
    // non configuré, auquel cas le flag `isDev` reste indéterminé (false).
    const DEV_ID = process.env.SHEETS_PIECES_DEV_ID || null;
    const debug = {
      active_piecesId : SHEET_IDS.PIECES,
      env_PIECES_ID   : process.env.SHEETS_PIECES_ID || null,
      env_ACHATS_ID   : process.env.SHEETS_ACHATS_ID || null,
      inventaireId    : SHEET_IDS.INVENTAIRE,
      isDev           : DEV_ID !== null && SHEET_IDS.PIECES === DEV_ID,
    };

    if (force) {
      const keys = invalidateAllCaches();
      return NextResponse.json({ changed: ['ALL (forced)'], invalidated: keys, unchanged: [], debug });
    }

    const result = await smartSync();
    return NextResponse.json({ ...result, debug });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
