import { NextResponse } from 'next/server';
import { getArchivedVentes, desarchiverVente, deleteArchivedVente } from '@/lib/sheets/ventes';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import cache, { CACHE_KEYS } from '@/lib/cache';

/** GET /api/ventes/archives — liste des ventes archivées. ?refresh=1 pour bypass cache. */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    if (searchParams.get('refresh') === '1') await cache.del(CACHE_KEYS.VENTES_ARCHIVES);
    const ventes = await getArchivedVentes();
    return NextResponse.json(ventes);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** POST /api/ventes/archives — désarchiver une vente (la replacer dans _VENTES_). */
export async function POST(req: Request) {
  try {
    const { venteId } = await req.json();
    if (!venteId) {
      return NextResponse.json({ error: 'venteId requis' }, { status: 400 });
    }
    await desarchiverVente(venteId);
    return NextResponse.json({ ok: true, venteId });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/**
 * DELETE /api/ventes/archives — suppression définitive d'une vente archivée.
 * Réservé aux admins (action irréversible, pas de snapshot).
 */
export async function DELETE(req: Request) {
  try {
    const check = await requireAdmin();
    if (!check.ok) {
      return NextResponse.json(
        { error: check.error, code: 'ADMIN_REQUIRED' },
        { status: check.status },
      );
    }
    const { venteId } = await req.json();
    if (!venteId) {
      return NextResponse.json({ error: 'venteId requis' }, { status: 400 });
    }
    await deleteArchivedVente(venteId);
    return NextResponse.json({ ok: true, venteId });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
