import { NextResponse } from 'next/server';
import { getVentes, createVente } from '@/lib/sheets/ventes';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';
import cache, { CACHE_KEYS } from '@/lib/cache';
import { parseBody } from '@/lib/validate';
import { VenteCreateSchema } from '@/lib/schemas/vente';

/** GET /api/ventes — liste des ventes. ?refresh=1 pour bypass cache */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    if (searchParams.get('refresh') === '1') await cache.del(CACHE_KEYS.VENTES);
    const ventes = await getVentes();
    return NextResponse.json(ventes);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** POST /api/ventes — créer une nouvelle vente.
 *  Modèle engagement (v6.6.0) : la vente brouillon engage les pièces
 *  → AB baisse, AC monte (mêmes deltas qu'un BDT APPROUVÉ).
 *  v1.1.7 — Item 4 : validation zod. */
export async function POST(req: Request) {
  const parsed = await parseBody(req, VenteCreateSchema);
  if (!parsed.ok) return parsed.response;
  try {
    const before = await snapshotStock();
    const result = await createVente({
      date  : parsed.data.date,
      client: parsed.data.client,
      items : parsed.data.items,
    });
    await safeRecomputeStockState(before, 'VENTE');
    return NextResponse.json({ ok: true, ...result });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
