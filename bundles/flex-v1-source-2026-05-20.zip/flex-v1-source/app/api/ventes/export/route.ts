/**
 * GET /api/ventes/export?from=2026-01-01&to=2026-12-31&statut=all
 *
 * Exporte les ventes en xlsx sur une plage de dates.
 * Paramètres :
 *   from   : date ISO début (inclus). Défaut : 30 jours avant aujourd'hui.
 *   to     : date ISO fin (inclus). Défaut : aujourd'hui.
 *   statut : 'all' | 'pending' | 'done'. Défaut : 'all'.
 *
 * Colonnes : N° facture | Date | Client | Item | SKU | Qté | Prix unit. | S/total | Remise | Total net
 */
import { NextResponse } from 'next/server';
import { getVentes }    from '@/lib/sheets/ventes';
import * as XLSX        from 'xlsx';

function frNum(n: number): string {
  return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' $';
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const today = new Date().toISOString().slice(0, 10);
    const from  = searchParams.get('from') || (() => {
      const d = new Date(); d.setDate(d.getDate() - 30);
      return d.toISOString().slice(0, 10);
    })();
    const to     = searchParams.get('to')     || today;
    const statut = searchParams.get('statut') || 'all';

    let ventes = await getVentes();

    // Filtre dates
    ventes = ventes.filter(v => v.date >= from && v.date <= to);
    // Filtre statut
    if (statut === 'pending') ventes = ventes.filter(v => !v.factureDate);
    if (statut === 'done')    ventes = ventes.filter(v => !!v.factureDate);

    // Construire les lignes : une par item, regroupées par vente
    const rows: Record<string, string | number>[] = [];
    for (const v of ventes) {
      const montantRemise = v.remiseValue && v.remiseValue > 0
        ? (v.remiseType === 'fixed'
          ? Math.min(v.remiseValue, v.total)
          : Math.round(v.total * v.remiseValue) / 100)
        : 0;
      const netTotal = Math.max(0, v.total - montantRemise);
      const remiseLabel = v.remiseValue && v.remiseValue > 0
        ? (v.remiseType === 'fixed' ? frNum(v.remiseValue) : `${v.remiseValue} %`)
        : '';

      for (let i = 0; i < v.items.length; i++) {
        const it = v.items[i];
        rows.push({
          'N° facture'  : v.factureNumero || '',
          'Date'        : v.date,
          'Client'      : v.client || '',
          'Item'        : it.nom,
          'SKU'         : it.sku || '',
          'Qté'         : it.qte,
          'Prix unit.'  : it.prixUnit,
          'S/total'     : it.sousTotal,
          // Remise + total net seulement sur la 1ʳᵉ ligne du groupe
          'Remise'      : i === 0 ? remiseLabel : '',
          'Total net'   : i === 0 ? netTotal : '',
          'Statut'      : i === 0 ? (v.factureDate ? 'Facturée' : 'À facturer') : '',
        });
      }
    }

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Ventes');
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    const filename = `ventes-${from}-${to}.xlsx`;
    return new Response(buf, {
      status : 200,
      headers: {
        'Content-Type'       : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="${filename}"`,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
