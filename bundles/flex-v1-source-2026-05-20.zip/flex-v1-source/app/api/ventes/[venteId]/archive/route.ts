import { NextResponse } from 'next/server';
import { archiverVente, getVentes } from '@/lib/sheets/ventes';

/**
 * POST /api/ventes/[venteId]/archive — archive une vente.
 *
 * Pattern miroir de l'archivage BDT : déplace les lignes de _VENTES_ vers
 * _VENTES_ARCHIVES_. La vente disparaît de la page Ventes mais reste
 * consultable via /archives (vue Ventes archivées).
 *
 * Pas de delta stock : la vente est facturée (AB déjà décrémenté de manière
 * définitive). Seul le déplacement de lignes a lieu.
 *
 * Brouillon (factureDate vide) refusé : on supprime un brouillon, on ne
 * l'archive pas.
 */
export async function POST(_req: Request, { params }: { params: { venteId: string } }) {
  try {
    const ventes = await getVentes();
    const vente = ventes.find(v => v.venteId === params.venteId);
    if (!vente) {
      return NextResponse.json({ error: `Vente ${params.venteId} introuvable` }, { status: 404 });
    }
    if (!vente.factureDate) {
      return NextResponse.json(
        { error: 'Brouillon non archivable (utiliser DELETE)' },
        { status: 400 },
      );
    }

    await archiverVente(params.venteId);
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
