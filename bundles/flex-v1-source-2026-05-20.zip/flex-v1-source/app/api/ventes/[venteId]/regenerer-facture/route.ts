/**
 * POST /api/ventes/[venteId]/regenerer-facture
 *
 * Ré-génère le PDF facture + brouillon Gmail pour une vente déjà facturée.
 * Symétrique de `/api/bdc/[id]/regenerer-facture` (v1.1.13) — même
 * sémantique : pas de double-ligne journal, pas de nouveau numéro de
 * facture, pas de mutation stock/statut.
 *
 * Cas d'usage (v1.1.16+) :
 *   - Refonte du template (col D « à l'attention de »…)
 *   - Modif de l'adresse client / employeur après facturation
 *   - PDF Drive original perdu
 *
 * Pré-condition : `vente.factureDate` non-vide (= vente déjà facturée).
 *
 * Body (JSON, optionnel) : { noteClient?, remisePce?, modePaiement?, lang? }
 */
import { NextRequest, NextResponse } from 'next/server';
import { auth }                      from '@/lib/auth';
import { getVentes }                 from '@/lib/sheets/ventes';
import { genererFactureVente }       from '@/lib/sheets/factures';

async function _getClient(clientNom: string) {
  const { getClients } = await import('@/lib/sheets/clients');
  const grouped = await getClients();
  const all = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
  const seen = new Set<string>();
  const unique = all.filter(c => {
    if (seen.has(c.nomComplet)) return false;
    seen.add(c.nomComplet);
    return true;
  });
  return unique.find(c => c.nomComplet === clientNom) ?? null;
}

export async function POST(
  req: NextRequest,
  { params }: { params: { venteId: string } },
) {
  try {
    const session = await auth();
    if (!session) {
      return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
    }
    const accessToken  = session.googleAccessToken;
    const refreshToken = session.googleRefreshToken;
    if (!accessToken) {
      return NextResponse.json(
        { error: 'Token Gmail manquant — déconnecte-toi puis reconnecte-toi avec ton compte Google.' },
        { status: 403 },
      );
    }

    const body       = await req.json().catch(() => ({}));
    const noteClient = String(body.noteClient ?? '').trim();
    const remisePce  = body.remisePce ?? { type: 'pct', value: 0 };
    const langOverride: 'FR' | 'EN' | undefined =
      body.lang === 'FR' || body.lang === 'EN' ? body.lang : undefined;
    const modePaiement: 'comptant' | 'interac' | 'cartes' =
      body.modePaiement === 'cartes' || body.modePaiement === 'interac'
        ? body.modePaiement
        : 'comptant';

    const ventes = await getVentes();
    const vente  = ventes.find(v => v.venteId === params.venteId);
    if (!vente) {
      return NextResponse.json({ error: `Vente ${params.venteId} introuvable` }, { status: 404 });
    }
    if (!vente.factureDate) {
      return NextResponse.json(
        { error: `Vente ${params.venteId} n'est pas encore facturée — utilise « Facturer » au lieu de « Re-générer ».`, code: 'NOT_INVOICED' },
        { status: 400 },
      );
    }
    if (!vente.factureNumero) {
      return NextResponse.json(
        { error: `Vente ${params.venteId} n'a pas de numéro de facture — état incohérent (factureDate sans factureNumero).` },
        { status: 500 },
      );
    }
    if (!vente.client) {
      return NextResponse.json(
        { error: `Vente ${params.venteId} sans client — impossible de re-générer un PDF.` },
        { status: 422 },
      );
    }

    const client = await _getClient(vente.client);
    if (!client) {
      return NextResponse.json(
        { error: `Client "${vente.client}" introuvable` },
        { status: 404 },
      );
    }
    if (!client.courriel) {
      return NextResponse.json(
        { error: `Le client "${vente.client}" n'a pas de courriel — impossible de créer le brouillon Gmail.` },
        { status: 422 },
      );
    }

    const clientForFacture = langOverride ? { ...client, lang: langOverride } : client;

    // Re-génère avec MÊME numéro de facture + skipJournalLog (pas de double
    // ligne dans VENTES sheet). Pas d'update vente, pas de stock recompute.
    const result = await genererFactureVente(
      vente,
      clientForFacture,
      noteClient,
      accessToken,
      remisePce,
      refreshToken,
      vente.factureNumero,
      modePaiement,
      'ÉMIS',  // statut ne sert pas — pas de log écrit
      true,    // skipJournalLog
    );

    return NextResponse.json(
      { ...result, factureNumero: vente.factureNumero, regenerated: true },
      { status: 200 },
    );
  } catch (err: any) {
    console.error('[ventes/regenerer-facture]', err);
    return NextResponse.json({ error: err?.message ?? 'Erreur interne' }, { status: 500 });
  }
}
