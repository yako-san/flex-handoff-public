import { NextResponse } from 'next/server';
import { deleteVente, getVentes, snapshotVente } from '@/lib/sheets/ventes';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';
import { requireAdmin } from '@/lib/auth/requireAdmin';

/**
 * DELETE /api/ventes/[venteId] — supprime une vente.
 *
 * Brouillon (factureDate vide) : supprimable par tout user authentifié.
 *   AB remonte + AC redescend (engagement levé).
 *
 * Vente facturée (factureDate remplie) :
 *   - Réservé aux admins (requireAdmin).
 *   - Snapshot append-only dans _BDC_BACKUPS_ avant suppression
 *     (pour pouvoir retrouver la trace si besoin).
 *   - AB remonte. La trace comptable reste dans l'onglet VENTES du
 *     sheet FACTURES (log à part, pas touché par cette suppression).
 */
export async function DELETE(_req: Request, { params }: { params: { venteId: string } }) {
  try {
    const ventes = await getVentes();
    const vente = ventes.find(v => v.venteId === params.venteId);
    if (!vente) {
      return NextResponse.json({ error: `Vente ${params.venteId} introuvable` }, { status: 404 });
    }

    // Vente facturée → réservé admin + snapshot
    if (vente.factureDate) {
      const check = await requireAdmin();
      if (!check.ok) {
        return NextResponse.json(
          { error: check.error, code: 'ADMIN_REQUIRED' },
          { status: check.status }
        );
      }
      await snapshotVente(
        params.venteId,
        'delete-vente-facturee',
        `Facture ${vente.factureNumero ?? ''} supprimée par ${check.email}`,
      );
    }

    const before = await snapshotStock();
    await deleteVente(params.venteId);
    await safeRecomputeStockState(before, 'VENTE');
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
