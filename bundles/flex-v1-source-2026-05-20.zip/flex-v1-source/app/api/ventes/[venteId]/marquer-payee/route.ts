/**
 * POST /api/ventes/[venteId]/marquer-payee  — marque payée (body: { paye: true })
 * POST /api/ventes/[venteId]/marquer-payee  — annule (body: { paye: false })
 *
 * Pré-condition : la vente doit être facturée (factureDate présent).
 * Sans ça : 400.
 *
 * Effet sheet : écrit 'payé' (ou '') dans col P de la 1ʳᵉ ligne du groupe
 * _VENTES_. La vente devient archivable depuis l'UI quand payeStatus === 'payé'.
 *
 * v1.1.5+ (cluster 4 item m).
 */
import { NextResponse } from 'next/server';
import { markVentePayee } from '@/lib/sheets/ventes';

export async function POST(req: Request, { params }: { params: { venteId: string } }) {
  try {
    const body = await req.json().catch(() => ({}));
    const paye = body?.paye !== false;  // défaut = true (marquer payée)
    await markVentePayee(params.venteId, paye);
    return NextResponse.json({ ok: true, venteId: params.venteId, payeStatus: paye ? 'payé' : '' });
  } catch (err: any) {
    const msg = err?.message ?? 'Erreur interne';
    const status = msg.includes('introuvable') ? 404
                 : msg.includes('pas encore facturée') ? 400
                 : 500;
    return NextResponse.json({ error: msg }, { status });
  }
}
