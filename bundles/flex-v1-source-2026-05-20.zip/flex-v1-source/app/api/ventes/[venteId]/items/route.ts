/**
 * POST /api/ventes/[venteId]/items
 * Ajoute des items à une vente existante non facturée.
 * Body : { items: [{pieceId, sku, nom, qte, prixUnit}, …] }
 */
import { NextRequest, NextResponse } from 'next/server';
import { appendItemsToVente }        from '@/lib/sheets/ventes';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';

export async function POST(
  req: NextRequest,
  { params }: { params: { venteId: string } },
) {
  try {
    const body  = await req.json().catch(() => ({}));
    const items = Array.isArray(body.items) ? body.items : [];
    if (!params.venteId) return NextResponse.json({ error: 'venteId manquant' }, { status: 400 });
    if (!items.length)   return NextResponse.json({ error: 'Au moins 1 item requis' }, { status: 400 });
    const before = await snapshotStock();
    const result = await appendItemsToVente(params.venteId, items);
    await safeRecomputeStockState(before, 'VENTE');
    return NextResponse.json(result, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? 'Erreur interne' }, { status: 500 });
  }
}
