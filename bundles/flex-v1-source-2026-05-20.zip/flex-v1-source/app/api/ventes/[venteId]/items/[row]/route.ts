/**
 * DELETE /api/ventes/[venteId]/items/[row]
 * Supprime une seule ligne d'item d'une vente (row = numéro de ligne _VENTES_).
 * Refuse si la vente est déjà facturée.
 */
import { NextRequest, NextResponse } from 'next/server';
import { deleteVenteItem, patchVenteItemQte } from '@/lib/sheets/ventes';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';

export async function DELETE(
  _req: NextRequest,
  { params }: { params: { venteId: string; row: string } },
) {
  try {
    const row = parseInt(params.row, 10);
    if (!params.venteId || isNaN(row) || row < 2) {
      return NextResponse.json({ error: 'Paramètres invalides' }, { status: 400 });
    }
    const before = await snapshotStock();
    await deleteVenteItem(params.venteId, row);
    await safeRecomputeStockState(before, 'VENTE');
    return NextResponse.json({ ok: true }, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? 'Erreur interne' }, { status: 500 });
  }
}

/** PATCH /api/ventes/[venteId]/items/[row] — body { qte: number }
 *  Met à jour la qté d'une ligne ITEM d'une vente brouillon. Le snapshot
 *  + recompute applique le delta sur AB (stock physique) et AC (réservé). */
export async function PATCH(
  req: NextRequest,
  { params }: { params: { venteId: string; row: string } },
) {
  try {
    const row = parseInt(params.row, 10);
    if (!params.venteId || isNaN(row) || row < 2) {
      return NextResponse.json({ error: 'Paramètres invalides' }, { status: 400 });
    }
    const body = await req.json().catch(() => ({}));
    const qte = Number(body.qte);
    if (!Number.isFinite(qte) || qte < 1) {
      return NextResponse.json({ error: 'qte doit être un entier >= 1' }, { status: 400 });
    }
    const before = await snapshotStock();
    await patchVenteItemQte(params.venteId, row, qte);
    await safeRecomputeStockState(before, 'VENTE');
    return NextResponse.json({ ok: true }, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? 'Erreur interne' }, { status: 500 });
  }
}
