/**
 * POST /api/ventes/[venteId]/facture
 *
 * Génère une facture PDF pour une vente directe (sans BDC/vélo)
 * et crée un brouillon Gmail. Log dans l'onglet FACTURES.
 *
 * Body (JSON) : { noteClient?: string, remisePce?: { type, value } }
 */
import { NextRequest, NextResponse } from 'next/server';
import { auth }                      from '@/lib/auth';
import { getVentes, markVenteFacturee } from '@/lib/sheets/ventes';
import { genererFactureVente, comptabiliserVenteSansPdf } from '@/lib/sheets/factures';
import { prochainFactureNumero }     from '@/lib/sheets/counter';
import { snapshotStock, safeRecomputeStockState } from '@/lib/sheets/reservation';

async function _getClient(clientNom: string) {
  const { getClients } = await import('@/lib/sheets/clients');
  const grouped = await getClients();
  const all = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
  const seen = new Set<string>();
  const unique = all.filter(c => {
    if (seen.has(c.nomComplet)) return false;
    seen.add(c.nomComplet);
    return true;
  });
  return unique.find(c => c.nomComplet === clientNom) ?? null;
}

export async function POST(
  req: NextRequest,
  { params }: { params: { venteId: string } }
) {
  try {
    const session = await auth();
    if (!session) {
      return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
    }

    const accessToken  = session.googleAccessToken  as string | undefined;
    const refreshToken = session.googleRefreshToken as string | undefined;
    if (!accessToken) {
      return NextResponse.json(
        { error: 'Token Gmail manquant — veuillez vous déconnecter puis reconnecter votre compte Google.' },
        { status: 403 }
      );
    }

    const body       = await req.json().catch(() => ({}));
    const noteClient = String(body.noteClient ?? '').trim();
    const remisePce  = body.remisePce ?? { type: 'pct', value: 0 };
    const langOverride: 'FR' | 'EN' | undefined =
      body.lang === 'FR' || body.lang === 'EN' ? body.lang : undefined;
    // Mode de paiement (default 'comptant' si non fourni). Tracé au
    // journal pour rapprochement bancaire — n'influence PAS le calcul des
    // taxes (toujours appliquées, LTA art. 165 + LTVQ art. 16).
    const modePaiement: 'comptant' | 'interac' | 'cartes' =
      body.modePaiement === 'cartes' || body.modePaiement === 'interac'
        ? body.modePaiement
        : 'comptant';
    // Walk-in : l'UI peut demander de skip la génération PDF (vente
    // comptabilisée sans reçu papier). Default true pour les autres.
    const generatePdf: boolean = body.generatePdf !== false;
    // v1.0.25+ : si l'UI a coché « Payé maintenant » (cas Walk-in cash
    // typique), le statut initial du journal est 'PAYÉ' au lieu d'ÉMIS.
    // Évite l'aller-retour mise-à-jour manuelle après facturation.
    const statut: 'ÉMIS' | 'PAYÉ' = body.payeMaintenant === true ? 'PAYÉ' : 'ÉMIS';

    const ventes = await getVentes();
    const vente  = ventes.find(v => v.venteId === params.venteId);
    if (!vente) {
      return NextResponse.json({ error: `Vente ${params.venteId} introuvable` }, { status: 404 });
    }

    // ⚠ v6.3.1 — Lazy assign : le factureNumero n'est PLUS attribué à la
    // création de la vente. Il est généré ici, à la 1ʳᵉ facturation, puis
    // réutilisé tel quel sur les re-facturations (idempotence).
    // Évite les trous dans la séquence des factures pour les brouillons abandonnés.

    if (!vente.client) {
      return NextResponse.json(
        { error: 'Cette vente n\'a pas de client associé — impossible de facturer.' },
        { status: 422 }
      );
    }

    const client = await _getClient(vente.client);
    if (!client) {
      return NextResponse.json(
        { error: `Client "${vente.client}" introuvable dans CLIENTS FLEX-REV` },
        { status: 404 }
      );
    }
    if (!client.courriel) {
      return NextResponse.json(
        { error: `Le client "${vente.client}" n'a pas de courriel enregistré.` },
        { status: 422 }
      );
    }

    // Override lang du client si l'UI a demandé FR/EN explicitement
    const clientForFacture = langOverride ? { ...client, lang: langOverride } : client;

    // Lazy assign : si le brouillon n'a pas encore de factureNumero,
    // on en alloue un maintenant. Sinon on réutilise (re-facturation idempotente).
    const factureNumero = vente.factureNumero || await prochainFactureNumero();

    // 1. Génère PDF + draft Gmail + log FACTURES, OU log seul si !generatePdf.
    const result = generatePdf
      ? await genererFactureVente(
          vente, clientForFacture, noteClient, accessToken, remisePce, refreshToken, factureNumero, modePaiement, statut,
        )
      : {
          ...(await comptabiliserVenteSansPdf(vente, clientForFacture, remisePce, factureNumero, modePaiement, statut)),
          draftId : '',
          draftUrl: '',
          pdfUrl  : '',
        };

    // 2. Persiste date/url/remise sur la 1ʳᵉ ligne du groupe _VENTES_
    //    Le factureNumero (col I) est posé pour la 1ʳᵉ fois à la facturation
    //    (lazy assign v6.3.1).
    //    Snapshot AVANT pour laisser le recompute appliquer la transition
    //    brouillon→facturée (AC redescend à 0, AB stable).
    const factureDate = new Date().toISOString().slice(0, 10);
    const before = await snapshotStock();
    try {
      await markVenteFacturee(params.venteId, {
        numero      : factureNumero,
        date        : factureDate,
        url         : result.pdfUrl ?? '',
        remiseType  : remisePce?.type,
        remiseValue : remisePce?.value,
        modePaiement,
      });
    } catch (err: any) {
      console.warn('[ventes/facture] markVenteFacturee failed:', err?.message);
    }
    await safeRecomputeStockState(before, 'VENTE');

    return NextResponse.json(
      { ...result, factureNumero, factureDate, factureUrl: result.pdfUrl ?? '' },
      { status: 200 },
    );

  } catch (err: any) {
    console.error('[ventes/facture]', err);
    return NextResponse.json({ error: err.message ?? 'Erreur interne' }, { status: 500 });
  }
}
