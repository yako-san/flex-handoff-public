'use client';
import { signIn } from 'next-auth/react';
import Image from 'next/image';

export default function LoginPage() {
  return (
    <div
      className="min-h-screen flex items-center justify-center"
      style={{ backgroundColor: '#929292', padding: '20px' }}
    >
      <div className="flex flex-col items-center">

        {/* Carte login */}
        <div
          className="flex flex-col items-center text-center"
          style={{
            backgroundColor: '#fff056',
            borderRadius: '50px',
            padding: '40px 48px',
            width: '100%',
            maxWidth: '420px',
            boxShadow: '0 12px 32px rgba(0,0,0,0.25)',
          }}
        >
          <Image
            src="/logo-flex-rev-trans-brun.svg"
            alt="FLEX-REV"
            width={180}
            height={180}
            priority
            style={{ marginBottom: '50px' }}
          />

          <button
            onClick={() =>
              signIn('google', {
                callbackUrl: '/dashboard',
                // prompt=consent force Google à renvoyer un refresh_token
                // à chaque connexion — nécessaire car Google ne le donne
                // qu'à la première autorisation sinon, et son absence
                // empêche le refresh automatique des tokens expirés.
                authorizationParams: { prompt: 'consent', access_type: 'offline' },
              } as any)
            }
            className="flex items-center justify-center gap-3 transition-colors"
            style={{
              width: '100%',
              padding: '14px 20px',
              borderRadius: '40px',
              backgroundColor: '#9a7b4f',
              color: '#fff056',
              fontSize: '14px',
              fontWeight: 900,
              textTransform: 'uppercase',
              letterSpacing: '0.1em',
              border: 'none',
              cursor: 'pointer',
            }}
            onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#7d6440')}
            onMouseLeave={e => (e.currentTarget.style.backgroundColor = '#9a7b4f')}
          >
            <svg className="h-5 w-5" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
            </svg>
            Connexion avec Google
          </button>

          <p style={{ marginTop: '20px', fontSize: '12px', color: 'rgba(0,0,0,0.55)' }}>
            Accès restreint aux membres de l&apos;atelier.
          </p>
        </div>

      </div>
    </div>
  );
}
