'use client';
import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock, UtilButton } from '@/components/layout/PageHeader';
import BDCPanel from '@/components/bdc/BDCPanel';
import BDCHeader from '@/components/bdc/BDCHeader';
import ClientForm from '@/components/clients/ClientForm';
import VeloPhotos from '@/components/inventaire/VeloPhotos';
import FactureStatusPanel from '@/components/bdc/FactureStatusPanel';
import VeloHistory from '@/components/bdc/VeloHistory';
import { useInventaire } from '@/hooks/useInventaire';
import { useBDC } from '@/hooks/useBDC';
import { useMarques } from '@/hooks/useCatalogue';
import { useClients } from '@/hooks/useClients';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { ArrowLeftIcon, LockClosedIcon, LockOpenIcon } from '@heroicons/react/24/outline';
import type { Remise } from '@/components/bdc/BDCHeader';
import { useVeloTailles } from '@/hooks/useVeloTailles';
import { formatTel, telE164 } from '@/lib/utils/format';

/** Gabarit pré-rempli du bloc Note interne. */
const NOTE_SEPARATOR    = '────────────────────';   // 20 chars, style box-drawing
const NOTE_INTERNE_TEMPLATE =
  `reçu par : \néval par : \nwork par : \nqc par : \n${NOTE_SEPARATOR}\n`;

// Labels synchronisés avec les dropdowns du BDT
const LABEL_RECU = 'reçu par : ';
const LABEL_EVAL = 'éval par : ';
const LABEL_WORK = 'work par : ';
const LABEL_QC   = 'qc par : ';
const LABELS_ORDER = [LABEL_RECU, LABEL_EVAL, LABEL_WORK, LABEL_QC] as const;

/** Regex qui match la ligne commençant par le label, avec ou sans ":" suivant. */
function _labelRegex(label: string): RegExp {
  const baseLabel = label.replace(/\s*:\s*$/, '');
  const esc       = baseLabel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp('^' + esc + '\\s*:?\\s*(.*)$', 'im');
}

/** Lit la valeur actuelle sur la ligne du label (ou null si ligne absente). */
function getNoteLine(note: string, label: string): string | null {
  const re = _labelRegex(label);
  const m  = note.match(re);
  if (!m) return null;
  return (m[1] ?? '').trim();
}

/** Insère la ligne manquante avant le séparateur (ou à la fin si pas de
 *  séparateur). Respecte l'ordre LABELS_ORDER pour un rendu cohérent. */
function insertNoteLine(note: string, label: string, value: string): string {
  const line    = label + (value ?? '');
  // Détermine où insérer : avant le 1er label d'ordre supérieur, sinon avant
  // le séparateur, sinon à la fin.
  const idx       = LABELS_ORDER.indexOf(label as any);
  const afterLabels = LABELS_ORDER.slice(idx + 1);
  for (const nextLabel of afterLabels) {
    const m = note.match(_labelRegex(nextLabel));
    if (m && m.index !== undefined) {
      return note.slice(0, m.index) + line + '\n' + note.slice(m.index);
    }
  }
  const sepIdx = note.indexOf(NOTE_SEPARATOR);
  if (sepIdx >= 0) {
    return note.slice(0, sepIdx) + line + '\n' + note.slice(sepIdx);
  }
  // Pas de séparateur : on insère avant le dernier saut de ligne existant,
  // ou on append avec un newline.
  if (note.endsWith('\n')) return note + line + '\n';
  return (note ? note + '\n' : '') + line + '\n';
}

/** S'assure qu'une ligne labellisée existe avec la valeur donnée.
 *  Si absente → insérée. Si présente mais valeur vide ET `value` fourni
 *  → remplie. Si présente et non vide → laissée telle quelle sauf si
 *  `force=true`. */
function ensureNoteLine(note: string, label: string, value: string, force: boolean): string {
  const cur = getNoteLine(note, label);
  if (cur === null) return insertNoteLine(note, label, value);
  if (force || !cur) {
    return note.replace(_labelRegex(label), label + (value ?? ''));
  }
  // Normalise au passage : si la ligne existe sans ":" (ancien format),
  // on la réécrit avec le label normalisé et la valeur actuelle.
  if (!new RegExp('^' + label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).test(note)) {
    return note.replace(_labelRegex(label), label + cur);
  }
  return note;
}

/** S'assure que le séparateur est présent après les 4 lignes labellisées.
 *  Normalise aussi les anciennes versions (ex. 22 chars box-drawing) vers
 *  la version actuelle de NOTE_SEPARATOR pour éviter les doublons. */
function ensureSeparator(note: string): string {
  // 1. Remplace toute séquence de ≥5 tirets box-drawing consécutifs par le
  //    séparateur courant (20 chars).
  note = note.replace(/─{5,}/g, NOTE_SEPARATOR);
  // 2. Collapse les séparateurs dupliqués (deux lignes identiques consécutives,
  //    avec ou sans espaces/lignes vides entre) — cas des BDT déjà corrompus
  //    par le bug antérieur qui empilait l'ancien 22-chars + nouveau 20-chars.
  const dupRe = new RegExp(`${NOTE_SEPARATOR}(\\s*\\n\\s*${NOTE_SEPARATOR})+`, 'g');
  note = note.replace(dupRe, NOTE_SEPARATOR);
  if (note.includes(NOTE_SEPARATOR)) return note;
  // Cherche la dernière ligne labellisée connue
  let lastIdx = -1;
  for (const label of LABELS_ORDER) {
    const m = note.match(_labelRegex(label));
    if (m && m.index !== undefined) {
      const lineEnd = note.indexOf('\n', m.index);
      const end = lineEnd >= 0 ? lineEnd + 1 : note.length;
      if (end > lastIdx) lastIdx = end;
    }
  }
  if (lastIdx < 0) return note + (note.endsWith('\n') ? '' : '\n') + NOTE_SEPARATOR + '\n';
  return note.slice(0, lastIdx) + NOTE_SEPARATOR + '\n' + note.slice(lastIdx);
}

// ── Champ texte éditable inline ──────────────────────────────────
// ── Dropdown éditable inline (pour la marque) ───────────────────
/** Ligne label+value dans la fiche client (lecture seule). */
function FicheRow({ label, value, bold = false }: { label: string; value: React.ReactNode; bold?: boolean }) {
  return (
    <div className="flex gap-2 items-baseline">
      <dt className="legende w-16 shrink-0" style={{ color: 'rgba(0,0,0,0.4)' }}>{label}</dt>
      <dd className="flex-1 text-sm" style={{ color: 'rgba(0,0,0,0.8)', fontWeight: bold ? 700 : 400 }}>{value}</dd>
    </div>
  );
}

function InlineSelect({
  label, value, options, onSave, onAddNew,
}: {
  label: string;
  value: string;
  options: string[];
  onSave: (v: string) => void;
  /** Si défini, ajoute un choix "＋ Ajouter ..." qui déclenche ce callback. */
  onAddNew?: () => void;
}) {
  const ADD_NEW_TOKEN = '__add_new__';
  return (
    <div className="flex gap-2 items-center">
      <dt className="legende w-16 shrink-0" style={{ color: 'rgba(0,0,0,0.4)' }}>{label}</dt>
      <dd className="flex-1">
        <select
          value={value}
          onChange={e => {
            if (e.target.value === ADD_NEW_TOKEN) {
              onAddNew?.();
              return;
            }
            onSave(e.target.value);
          }}
          className="text-sm font-bold border-none focus:outline-none focus:ring-2 focus:ring-yellow-400 w-full px-3 py-1.5 cursor-pointer"
          style={{ color: 'rgba(0,0,0,0.8)', backgroundColor: 'rgba(255,255,255,0.7)', borderRadius: '0px' }}
        >
          {value && !options.includes(value) && <option value={value}>{value}</option>}
          {onAddNew && <option value={ADD_NEW_TOKEN}>＋ Ajouter {label.toLowerCase()}</option>}
          {options.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      </dd>
    </div>
  );
}

function InlineText({
  label, value, onSave,
}: { label: string; value: string; onSave: (v: string) => void }) {
  const [local, setLocal] = useState(value);
  useEffect(() => { setLocal(value); }, [value]);
  return (
    <div className="flex gap-2 items-center">
      <dt className="legende w-16 shrink-0" style={{ color: 'rgba(0,0,0,0.4)' }}>{label}</dt>
      <dd className="flex-1">
        <input
          type="text"
          value={local}
          onChange={e => setLocal(e.target.value)}
          onBlur={() => { if (local.trim() !== value) onSave(local.trim()); }}
          className="text-sm font-bold border-none focus:outline-none focus:ring-2 focus:ring-yellow-400 w-full px-3 py-1.5"
          style={{ color: 'rgba(0,0,0,0.8)', backgroundColor: 'rgba(255,255,255,0.7)', borderRadius: '0px' }}
        />
      </dd>
    </div>
  );
}

export default function VeloDetailPage({ params }: { params: { id: string } }) {
  const router                                         = useRouter();
  const { data: session }                              = useSession();
  const { velos, isLoading, patchVelo }                = useInventaire();
  const { bdc, isLoading: bdcLoading, patchNote, patchRemises, patchAvance } = useBDC(params.id);
  const { tailles: veloTailles }                       = useVeloTailles();
  const { marques, addMarque }                         = useMarques();
  const { allNoms, grouped: clientsGrouped, patchClient, mutate: mutateClients } = useClients();
  // Match strict, puis tolérant aux différences de format (zéros de tête,
   // string vs number) car Sheets peut stocker l'ID en numérique pour
   // certaines lignes et en texte pour d'autres.
   const velo                                           = velos.find(v => v.id === params.id)
                                                       ?? velos.find(v => String(v.id).replace(/^0+/, '') === String(params.id).replace(/^0+/, ''));

  /** Prénom déduit de l'email de l'utilisateur courant (yako.cyclo@gmail → yako). */
  const currentUser = useMemo(() => {
    const email = session?.user?.email ?? '';
    if (!email) return '';
    const local = email.split('@')[0];
    return local.split('.')[0] || local;
  }, [session?.user?.email]);

  // Liste enrichie des clients (allNoms + ceux déjà présents en inventaire)
  // Tri alphabétique par NOM DE FAMILLE (dernier mot du nomComplet)
  const enrichedNoms = useMemo(() => {
    const set = new Set(allNoms);
    for (const v of velos) {
      if (v.client && v.client !== 'Sélection →') set.add(v.client);
    }
    const lastName = (full: string) => {
      const parts = full.trim().split(/\s+/);
      return parts.length > 1 ? parts[parts.length - 1] : full;
    };
    return [...set].sort((a, b) => {
      const cmp = lastName(a).localeCompare(lastName(b), 'fr');
      return cmp !== 0 ? cmp : a.localeCompare(b, 'fr');
    });
  }, [allNoms, velos]);

  const [showClientForm, setShowClientForm] = useState(false);
  // Mode du ClientForm : null = nouveau client, Client = édition
  const [editClientMode, setEditClientMode] = useState(false);

  // Note interne — velo.notes
  const [noteInterne, setNoteInterne] = useState('');
  const [notesDirty,  setNotesDirty]  = useState(false);
  const [notesSaving, setNotesSaving] = useState(false);

  // Notes client — partagées BDCHeader + BDCPanel.
  //  - noteClient        : persistée col V (note ÉVALUATION)
  //  - noteClientFacture : persistée col W (note FACTURE)
  // Toggle UI dans BDCPanel pour switcher entre les 2.
  const [noteClient, setNoteClient]                 = useState('');
  const [noteClientFacture, setNoteClientFacture]   = useState('');
  const noteClientInitRef        = useRef(false);
  const noteClientFactureInitRef = useRef(false);

  // Remises — partagées BDCHeader (eval call) + BDCPanel (display).
  // Persistées côté sheet (col I ligne BON, JSON). Init depuis bdc au
  // premier chargement, puis sauvegarde auto (debounced) à chaque change.
  const [remiseSvc, setRemiseSvc] = useState<Remise>({ type: 'pct', value: 0 });
  const [remisePce, setRemisePce] = useState<Remise>({ type: 'pct', value: 0 });
  const remisesInitRef = useRef(false);
  const remisesSaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Init depuis bdc (une seule fois)
  useEffect(() => {
    if (remisesInitRef.current) return;
    if (!bdc) return;
    if (bdc.remiseSvc) setRemiseSvc(bdc.remiseSvc);
    if (bdc.remisePce) setRemisePce(bdc.remisePce);
    remisesInitRef.current = true;
  }, [bdc]);

  // Avance : pas de state local — la source de vérité est bdc.avance (SWR).
  // Le modal dans BDCTotaux émet onAvanceChange → patchAvance direct.
  const handleAvanceChange = useCallback(
    (v: { montant: number; mode?: 'comptant' | 'interac' | 'cartes'; note?: string }) => {
      patchAvance(v).catch(() => { /* rollback SWR auto */ });
    },
    [patchAvance],
  );

  // Auto-save debounced 500 ms après un changement manuel de remise
  useEffect(() => {
    if (!remisesInitRef.current) return; // pas encore initialisé depuis bdc
    if (remisesSaveTimerRef.current) clearTimeout(remisesSaveTimerRef.current);
    remisesSaveTimerRef.current = setTimeout(() => {
      // Envoie undefined si value = 0 pour qu'une remise nulle nettoie
      // le JSON côté sheet (évite d'accumuler des zéros inutiles).
      const svcToSave = remiseSvc.value > 0 ? remiseSvc : undefined;
      const pceToSave = remisePce.value > 0 ? remisePce : undefined;
      patchRemises(svcToSave, pceToSave).catch(() => { /* rollback SWR auto */ });
    }, 500);
    return () => { if (remisesSaveTimerRef.current) clearTimeout(remisesSaveTimerRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [remiseSvc.type, remiseSvc.value, remisePce.type, remisePce.value]);

  // Bloc Vélo : ouvert / fermé via cadenas (fermé par défaut)
  const [veloOpen, setVeloOpen] = useState(false);
  // Toggle pills Client / Vélo dans le bloc fiche.
  // null = bloc fermé (défaut au chargement de la page BDT).
  const [ficheTab, setFicheTab] = useState<'client' | 'velo' | null>(null);

  /** Construit le contenu attendu de la note interne en fusionnant :
   *   - le contenu stocké dans le sheet (ou le template si vide)
   *   - la valeur courante des 3 dropdowns (éval / méca / ctrl)
   *   - le prénom de l'utilisateur courant pour "reçu par" (seulement si
   *     le stored est vide — on ne l'écrase jamais après coup).
   *  Préserve tout ce que l'utilisateur a ajouté sous le séparateur.
   */
  const expectedNote = useMemo(() => {
    if (!velo) return '';
    const stored = velo.notes === '...' ? '' : velo.notes ?? '';
    let base = stored || NOTE_INTERNE_TEMPLATE;

    // reçu par : seulement rempli si vide (jamais écrasé après coup)
    base = ensureNoteLine(base, LABEL_RECU, currentUser, /* force */ false);
    // éval / work / qc : dropdowns = source de vérité → force à la valeur courante
    base = ensureNoteLine(base, LABEL_EVAL, velo.eval ?? '', true);
    base = ensureNoteLine(base, LABEL_WORK, velo.meca ?? '', true);
    base = ensureNoteLine(base, LABEL_QC,   velo.ctrl ?? '', true);
    base = ensureSeparator(base);
    return base;
  }, [velo?.notes, velo?.eval, velo?.meca, velo?.ctrl, currentUser]);

  // Synchronise le state local avec expectedNote. Ne clobber pas l'édition
  // en cours (notesDirty = true).
  useEffect(() => {
    if (!velo || !expectedNote) return;
    if (notesDirty) return;
    if (expectedNote === noteInterne) return;
    setNoteInterne(expectedNote);
    // Si ça diffère du stored, on persiste silencieusement.
    const stored = velo.notes === '...' ? '' : velo.notes ?? '';
    if (expectedNote !== stored) {
      patchVelo(velo.id, { notes: expectedNote }).catch(() => { /* rollback SWR */ });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expectedNote]);

  // Init noteClient (éval) une seule fois depuis Sheets
  useEffect(() => {
    if (!noteClientInitRef.current && bdc?.noteClient !== undefined) {
      setNoteClient(bdc.noteClient);
      noteClientInitRef.current = true;
    }
  }, [bdc?.noteClient]);

  // Init noteClientFacture une seule fois depuis Sheets
  useEffect(() => {
    if (!noteClientFactureInitRef.current && bdc?.noteClientFacture !== undefined) {
      setNoteClientFacture(bdc.noteClientFacture);
      noteClientFactureInitRef.current = true;
    }
  }, [bdc?.noteClientFacture]);

  async function saveNoteInterne() {
    if (!velo || !notesDirty) return;
    setNotesSaving(true);
    try {
      await patchVelo(velo.id, { notes: noteInterne || '...' });
      setNotesDirty(false);
    } catch { /* rollback SWR */ } finally {
      setNotesSaving(false);
    }
  }

  async function saveNoteClient() {
    try {
      await patchNote(noteClient, 'eval');
    } catch (err) {
      console.error('[saveNoteClient]', err);
    }
  }

  async function saveNoteClientFacture() {
    try {
      await patchNote(noteClientFacture, 'facture');
    } catch (err) {
      console.error('[saveNoteClientFacture]', err);
    }
  }

  return (
    <AppShell>
      <div className="h-full flex flex-col p-0 md:p-5 md:pt-[50px]">

        {/* ── HEADER MOBILE : titre + bouton retour ── */}
        <div
          className="md:hidden flex items-center gap-3"
          style={{
            position: 'sticky',
            top: 0,
            zIndex: 20,
            paddingTop: '0px',
            paddingBottom: '0px',
            marginBottom: '20px',
          }}
        >
          <div className="flex flex-col flex-1 min-w-0" style={{ gap: '4px' }}>
            <p style={{ color: '#fff', fontSize: '13px', fontWeight: 700, marginBottom: '2px' }}>vélos en atelier</p>
            <div className="flex items-center gap-2 min-w-0">
              <h1 style={{
                color: '#fff056',
                fontFamily: "'HelveticaNeue-Thin', 'Helvetica Neue Thin', 'Helvetica Neue', Helvetica, Arial, sans-serif",
                fontWeight: 300,
                fontSize: '28px',
                lineHeight: 1,
                marginBottom: 0,
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
              }}>{velo ? `BDT #${params.id}` : ''}</h1>
              {velo?.status && (
                <span
                  className="inline-flex items-center whitespace-nowrap shrink-0"
                  style={{
                    padding: '2px 10px',
                    borderRadius: '999px',
                    backgroundColor: 'rgba(0,0,0,0.25)',
                    color: 'rgba(255,255,255,0.85)',
                    fontSize: '10px',
                    fontWeight: 700,
                    letterSpacing: '0.04em',
                    textTransform: 'uppercase',
                  }}
                >
                  {velo.status}
                </span>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={() => router.back()}
            title="Retour"
            className="flex items-center justify-center shrink-0"
            style={{
              width: '44px', height: '44px', borderRadius: '50%',
              backgroundColor: 'transparent',
              color: '#fff056',
              border: '2px solid #fff056',
              cursor: 'pointer',
              padding: 0,
            }}
          >
            <ArrowLeftIcon style={{ width: '18px', height: '18px', strokeWidth: 2.5 }} />
          </button>
        </div>

        {/* ── HEADER DESKTOP ── */}
        <div className="hidden md:block">
        <PageHeader
          subtitle="vélos en atelier"
          title={velo ? `Bon de travail #${params.id}` : ''}
          titleAfterHelp={velo ? [velo.marque, velo.modele].filter(Boolean).join(' ') : ''}
          helpTopic="05-workflow-bdt"
          helpTitle="Workflow BDT"
          helpHint="Le BDT en détail : client/vélo, services, pièces, note interne, et 4 cases d'avancement (Évaluation → Approuvé → Bon de sortie → Archiver)."
        >
          <UtilButton onClick={() => router.back()} title="Retour inventaire">
            <ArrowLeftIcon style={{ width: '100%', height: '100%' }} />
          </UtilButton>
        </PageHeader>
        </div>

        {/* Spinner UNIQUEMENT au tout premier chargement (pas de velo et
            pas de bdc encore en cache). Pendant les revalidations
            ultérieures (clic checkbox d'avancement, mutation), `velo` et
            `bdc` restent en cache via keepPreviousData → la page reste
            visible au lieu de basculer en blank. */}
        {!velo && (isLoading || bdcLoading) && <LoadingSpinner className="py-20" />}

        {velo && (
          <div className="flex flex-col md:flex-row flex-1 min-h-0" style={{ gap: '20px' }}>

            {/* ── Bloc colonne gauche : stacké mobile, 1/4 desktop ── */}
            <div
              className="w-full md:w-1/4 md:shrink-0 md:overflow-y-auto md:bg-black/15 md:rounded-[50px] md:p-5"
            >
              <div className="flex flex-col min-h-full" style={{ gap: '20px' }}>

                {/* Bloc contenu: BON DE COMMANDE */}
                {bdc && (
                  <BDCHeader
                    bdc={bdc}
                    status={velo.status}
                    noteClient={noteClient}
                    noteClientFacture={noteClientFacture}
                    remiseSvc={remiseSvc}
                    remisePce={remisePce}
                    onArchived={() => router.push('/inventaire')}
                    onApproved={() => router.push('/inventaire')}
                  />
                )}

                {/* Bloc fiche : toggle pills Client / Vélo (même espace) */}
                {(() => {
                  // Lookup client lié au vélo (pour le tab Client)
                  const allClients = [
                    ...(clientsGrouped?.recents ?? []),
                    ...(clientsGrouped?.actifs  ?? []),
                    ...(clientsGrouped?.autres  ?? []),
                  ];
                  const clientObj = allClients.find(c => c.nomComplet === velo.client);

                  const pillStyle = (active: boolean) => ({
                    padding: '4px 14px',
                    height: '28px',
                    borderRadius: '14px',
                    backgroundColor: active ? '#fff056' : 'rgba(255,255,255,0.5)',
                    color: 'rgba(0,0,0,0.7)',
                    border: 'none',
                    cursor: 'pointer' as const,
                    fontSize: '13px',
                    fontWeight: 700 as const,
                    letterSpacing: '0.04em',
                    textTransform: 'uppercase' as const,
                  });

                  return (
                    <div style={{ backgroundColor: 'rgba(255,255,255,0.50)', borderRadius: '30px', padding: '20px' }}>
                      {/* Header : pills toggle à gauche + actions (Modifier / Fermer) à droite */}
                      <div className="flex items-center justify-between" style={{ marginBottom: ficheTab ? '12px' : '0' }}>
                        <div className="flex items-center" style={{ gap: '6px' }}>
                          <button type="button" onClick={() => setFicheTab(t => t === 'client' ? null : 'client')} style={pillStyle(ficheTab === 'client')}>
                            Client
                          </button>
                          <button type="button" onClick={() => setFicheTab(t => t === 'velo' ? null : 'velo')} style={pillStyle(ficheTab === 'velo')}>
                            Vélo
                          </button>
                        </div>
                        <div className="flex items-center" style={{ gap: '6px' }}>
                          {ficheTab === 'client' && clientObj && (
                            <button
                              type="button"
                              onClick={() => { setEditClientMode(true); setShowClientForm(true); }}
                              title="Modifier le client"
                              style={{
                                width: '28px', height: '28px',
                                borderRadius: '14px',
                                backgroundColor: '#fff056',
                                color: 'rgba(0,0,0,0.7)',
                                border: 'none', cursor: 'pointer',
                                fontSize: '14px',
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                padding: 0,
                              }}
                            >
                              ✎
                            </button>
                          )}
                          {ficheTab !== null && (
                            <button
                              type="button"
                              onClick={() => setFicheTab(null)}
                              title="Fermer"
                              style={{
                                width: '28px', height: '28px',
                                borderRadius: '14px',
                                backgroundColor: 'rgba(255,255,255,0.5)',
                                color: 'rgba(0,0,0,0.6)',
                                border: 'none', cursor: 'pointer',
                                fontSize: '16px', lineHeight: 1,
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                padding: 0,
                              }}
                            >
                              ×
                            </button>
                          )}
                        </div>
                      </div>

                      {/* ── Tab VÉLO ── */}
                      {ficheTab === 'velo' && (
                        <dl className="space-y-2">
                          <InlineSelect
                            label="Marque"
                            value={velo.marque}
                            options={marques.map(m => m.nom)}
                            onSave={v => patchVelo(velo.id, { marque: v })}
                            onAddNew={async () => {
                              const nom = prompt('Nom de la nouvelle marque ?');
                              if (!nom || !nom.trim()) return;
                              try {
                                await addMarque(nom.trim());
                                patchVelo(velo.id, { marque: nom.trim() });
                              } catch (err: any) {
                                alert(`Erreur : ${err.message}`);
                              }
                            }}
                          />
                          <InlineText label="Modèle"  value={velo.modele}  onSave={v => patchVelo(velo.id, { modele:  v })} />
                          <InlineText label="Couleur" value={velo.couleur} onSave={v => patchVelo(velo.id, { couleur: v })} />
                          <InlineSelect label="Taille" value={velo.taille} options={veloTailles.filter(Boolean)} onSave={v => patchVelo(velo.id, { taille: v })} />
                          <InlineText label="# Série" value={velo.serie}   onSave={v => patchVelo(velo.id, { serie:   v })} />
                          <div>
                            <dt className="legende" style={{ color: 'rgba(0,0,0,0.4)', marginBottom: '4px' }}>Note</dt>
                            <textarea
                              key={velo._row}
                              rows={2}
                              defaultValue={velo.noteVelo ?? ''}
                              onBlur={e => {
                                const v = e.target.value;
                                if (v !== (velo.noteVelo ?? '')) {
                                  patchVelo(velo.id, { noteVelo: v });
                                }
                              }}
                              placeholder="Note libre sur le vélo (visible partout)…"
                              className="text-sm border-none focus:outline-none focus:ring-2 focus:ring-yellow-400 w-full px-3 py-2 resize-y"
                              style={{ color: 'rgba(0,0,0,0.8)', backgroundColor: 'rgba(255,255,255,0.7)', borderRadius: '0px' }}
                            />
                          </div>
                          {/* v1.0.10+ : photos par vélo (Drive CLIENTS/{nom}/BDT-{id}/)
                              au lieu de par client. Les photos d'un BDT précédent
                              du même client restent dans leur sous-dossier BDT-<oldId>. */}
                          {velo.id && <VeloPhotos bdcId={velo.id} />}

                          {/* v1.0.15+ : statut + mode paiement post-facturation. Visible
                              uniquement si le BDT est FACTURÉ (sinon factureRef = bdcId
                              n'est pas dans le journal ENCAISSE BDT). Pills toggle. */}
                          {velo.id && (velo.status === 'FACTURÉ' || velo.status === 'LIVRÉ') && (
                            <FactureStatusPanel factureRef={velo.id} docType="facture" />
                          )}
                        </dl>
                      )}

                      {/* ── Tab CLIENT ── */}
                      {ficheTab === 'client' && (
                        <dl className="space-y-2">
                          {/* Sélecteur du client (changement = patchVelo client) */}
                          <div className="flex gap-2 items-center">
                            <dt className="legende w-16 shrink-0" style={{ color: 'rgba(0,0,0,0.4)' }}>Client</dt>
                            <dd className="flex-1">
                              <select
                                value={enrichedNoms.includes(velo.client) ? velo.client : '__other__'}
                                onChange={e => {
                                  const v = e.target.value;
                                  if (v === '__new__') { setShowClientForm(true); return; }
                                  if (v && v !== '__other__' && v !== velo.client) {
                                    patchVelo(velo.id, { client: v });
                                  }
                                }}
                                className="text-sm font-bold border-none focus:outline-none focus:ring-2 focus:ring-yellow-400 w-full px-3 py-1.5 cursor-pointer"
                                style={{ color: 'rgba(0,0,0,0.8)', backgroundColor: 'rgba(255,255,255,0.7)', borderRadius: '0px' }}
                              >
                                {!enrichedNoms.includes(velo.client) && velo.client && (
                                  <option value="__other__">{velo.client}</option>
                                )}
                                <option value="__new__">＋ Nouveau client</option>
                                {enrichedNoms.map(n => <option key={n} value={n}>{n}</option>)}
                              </select>
                            </dd>
                          </div>

                          {/* Détails (lecture seule, click "✎" haut-droite → ClientForm) */}
                          {clientObj && (
                            <>
                              <FicheRow label="Tél" bold value={clientObj.tel ? (() => {
                                const e164 = telE164(clientObj.tel, clientObj.indicatif);
                                // Pref Texto → href = sms: au lieu de tel: (cohérent avec page Clients)
                                const isTexto = /texto/i.test(clientObj.commPref ?? '');
                                const href = e164 ? (isTexto ? `sms:${e164}` : `tel:${e164}`) : '#';
                                const display = (clientObj.indicatif && clientObj.indicatif !== '+1' ? `${clientObj.indicatif} ` : '') + formatTel(clientObj.tel);
                                return (
                                  <a href={href} style={{ color: '#1a73e8', textDecoration: 'underline' }}>
                                    {display}
                                  </a>
                                );
                              })() : '—'} />
                              <FicheRow label="Courriel" bold value={clientObj.courriel ? (
                                <a href={`mailto:${clientObj.courriel}`} style={{ color: '#1a73e8', textDecoration: 'underline' }}>
                                  {clientObj.courriel}
                                </a>
                              ) : '—'} />
                              <FicheRow label="Comm." value={clientObj.commPref || '—'} />
                              <FicheRow label="Langue" value={clientObj.lang || 'FR'} />
                              <FicheRow label="Lead" value={clientObj.lead || '—'} />
                              {/* Adresse postale — éditable inline (multi-ligne) */}
                              <div>
                                <dt className="legende" style={{ color: 'rgba(0,0,0,0.4)', marginBottom: '4px' }}>Adresse</dt>
                                <textarea
                                  key={`client-adresse-${clientObj._row}`}
                                  rows={2}
                                  defaultValue={clientObj.adressePostale ?? ''}
                                  onBlur={async e => {
                                    const v = e.target.value;
                                    if (v !== (clientObj.adressePostale ?? '')) {
                                      try { await patchClient(clientObj._row, { adressePostale: v }); }
                                      catch (err) { console.error('[saveClientAdresse]', err); }
                                    }
                                  }}
                                  placeholder="Adresse postale (livraison/ramassage)…"
                                  className="text-sm border-none focus:outline-none focus:ring-2 focus:ring-yellow-400 w-full px-3 py-2 resize-y"
                                  style={{ color: 'rgba(0,0,0,0.8)', backgroundColor: 'rgba(255,255,255,0.7)', borderRadius: '0px' }}
                                />
                              </div>
                              <div>
                                <dt className="legende" style={{ color: 'rgba(0,0,0,0.4)', marginBottom: '4px' }}>Notes</dt>
                                <textarea
                                  key={`client-notes-${clientObj._row}`}
                                  rows={2}
                                  defaultValue={clientObj.notes ?? ''}
                                  onBlur={async e => {
                                    const v = e.target.value;
                                    if (v !== (clientObj.notes ?? '')) {
                                      try { await patchClient(clientObj._row, { notes: v }); }
                                      catch (err) { console.error('[saveClientNotes]', err); }
                                    }
                                  }}
                                  placeholder="Notes sur le client (visible partout)…"
                                  className="text-sm border-none focus:outline-none focus:ring-2 focus:ring-yellow-400 w-full px-3 py-2 resize-y"
                                  style={{ color: 'rgba(0,0,0,0.8)', backgroundColor: 'rgba(255,255,255,0.7)', borderRadius: '0px' }}
                                />
                              </div>
                            </>
                          )}
                          {!clientObj && velo.client && velo.client !== 'Sélection →' && (
                            <p className="text-xs italic" style={{ color: 'rgba(0,0,0,0.4)' }}>
                              Détails du client introuvables (fiche non créée).
                            </p>
                          )}

                          {/* Historique BDT (lié au client) — Photos retirées sur demande */}
                          {velo.client && <VeloHistory client={velo.client} currentBdtId={velo.id} />}
                        </dl>
                      )}
                    </div>
                  );
                })()}

                {/* Bloc contenu: Note interne — remplit toute la hauteur disponible */}
                <div
                  className="flex flex-col flex-1 min-h-0"
                  style={{ backgroundColor: 'rgba(255,255,255,0.50)', borderRadius: '30px', padding: '20px' }}
                >
                  <h4 style={{ color: 'rgba(0,0,0,0.4)', letterSpacing: '0.1em', marginBottom: '8px' }}>
                    Note interne{notesSaving ? ' …' : ''}
                  </h4>
                  <textarea
                    value={noteInterne}
                    onChange={e => { setNoteInterne(e.target.value); setNotesDirty(true); }}
                    onBlur={() => { if (notesDirty) saveNoteInterne(); }}
                    placeholder="Notes pour l'équipe (non visibles par le client)…"
                    className="w-full px-3 py-2 text-sm flex-1 min-h-[140px] focus:outline-none focus:ring-2 focus:ring-yellow-400 resize-none"
                    style={{ borderRadius: '0px', border: 'none', backgroundColor: 'rgba(255,255,255,0.7)', color: 'rgba(0,0,0,0.8)' }}
                  />
                </div>
              </div>
            </div>

            {/* ── Bloc colonne droite ─────────────────────── */}
            <div
              className="flex-1 min-w-0 flex flex-col md:overflow-hidden"
              style={{ gap: '20px' }}
            >
              {/* Bloc contenu: Services + Pièces (géré par BDCPanel) */}
              <div
                className="flex-1 md:overflow-y-auto md:bg-black/15 md:rounded-[50px] md:p-5"
              >
                <BDCPanel
                  bdcId={params.id}
                  hideHeader
                  status={velo.status}
                  noteClient={noteClient}
                  onNoteClientChange={setNoteClient}
                  onNoteClientBlur={saveNoteClient}
                  noteClientFacture={noteClientFacture}
                  onNoteClientFactureChange={setNoteClientFacture}
                  onNoteClientFactureBlur={saveNoteClientFacture}
                  remiseSvc={remiseSvc}
                  onRemiseSvcChange={setRemiseSvc}
                  remisePce={remisePce}
                  onRemisePceChange={setRemisePce}
                  avance={bdc?.avance}
                  onAvanceChange={handleAvanceChange}
                  onArchived={() => router.push('/inventaire')}
                />
              </div>
            </div>

          </div>
        )}

        {!isLoading && !velo && (
          <p className="text-gray-500">Vélo {params.id} introuvable.</p>
        )}
      </div>

      <ClientForm
        open={showClientForm}
        onClose={() => { setShowClientForm(false); setEditClientMode(false); }}
        editClient={editClientMode && velo
          ? [
              ...(clientsGrouped?.recents ?? []),
              ...(clientsGrouped?.actifs  ?? []),
              ...(clientsGrouped?.autres  ?? []),
            ].find(c => c.nomComplet === velo.client) ?? null
          : null}
        onCreated={nom => {
          mutateClients();
          if (velo) patchVelo(velo.id, { client: nom });
        }}
      />
    </AppShell>
  );
}
