'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock, AddButton, UtilButton } from '@/components/layout/PageHeader';
import VeloTable from '@/components/inventaire/VeloTable';
import VeloForm from '@/components/inventaire/VeloForm';
import { PlusIcon, ArrowPathIcon, Squares2X2Icon } from '@heroicons/react/24/outline';
import { useInventaire } from '@/hooks/useInventaire';
import { toast } from '@/components/ui/Toast';

export default function InventairePage() {
  const router                  = useRouter();
  const [showForm, setShowForm] = useState(false);
  const [syncing,  setSyncing]  = useState(false);
  const { mutate, isLoading }   = useInventaire();

  async function handleSync() {
    setSyncing(true);
    try {
      const res = await fetch('/api/sync', { method: 'POST' });
      const data = await res.json();
      const n = data.changed?.length ?? 0;
      if (n > 0) {
        toast(`Sync : ${data.changed.join(', ')} mis à jour`);
      } else {
        toast('Sync : tout est à jour');
      }
      await mutate();
    } catch {
      toast('Erreur de synchronisation', 'error');
    } finally {
      setSyncing(false);
    }
  }

  return (
    <AppShell>
      <div className="p-0 md:p-5 md:pt-[50px]">
        {/* ── HEADER MOBILE : titre+(+) en haut, pill toolbar en dessous ── */}
        <div
          className="md:hidden flex flex-col"
          style={{
            position: 'sticky',
            top: 0,
            zIndex: 20,
            paddingTop: '0px',
            paddingBottom: '0px',
            marginBottom: '20px',
            gap: '12px',
          }}
        >
          {/* Titre + (+) gros */}
          <div className="flex items-center gap-3">
            <div className="flex flex-col flex-1 min-w-0">
              <p style={{ color: '#fff', fontSize: '13px', fontWeight: 700, marginBottom: '2px' }}>vélos en atelier</p>
              <h1 style={{
                color: '#fff056',
                fontFamily: "'HelveticaNeue-Thin', 'Helvetica Neue Thin', 'Helvetica Neue', Helvetica, Arial, sans-serif",
                fontWeight: 300,
                fontSize: '42px',
                lineHeight: 1,
                marginBottom: 0,
              }}>Inventaire</h1>
            </div>
            <button
              type="button"
              onClick={() => setShowForm(true)}
              title="Nouveau vélo"
              className="flex items-center justify-center shrink-0"
              style={{
                width: '56px', height: '56px', borderRadius: '50%',
                backgroundColor: '#fff056',
                color: '#000',
                fontSize: '36px',
                fontWeight: 700,
                lineHeight: 1,
                border: 'none',
                cursor: 'pointer',
                padding: 0,
              }}
            >
              <span style={{ position: 'relative', top: '-2px' }}>+</span>
            </button>
          </div>

        </div>

        {/* ── HEADER DESKTOP ── */}
        <div className="hidden md:block">
          <PageHeader
            subtitle="vélos en atelier"
            title="Inventaire"
            helpTopic="06-statut-bdt"
            helpTitle="Inventaire"
            helpHint="Tous les vélos en atelier, regroupés par statut (NOUVEAU, ÉVAL., APPROUVÉ, ON BENCH, etc.). Clique sur le tutoriel pour la légende des couleurs."
          >
            <ToolbarBlock>
              <UtilButton onClick={handleSync} title="Sync">
                <ArrowPathIcon className={syncing ? 'animate-spin' : ''} style={{ width: '100%', height: '100%' }} />
              </UtilButton>
            </ToolbarBlock>
            <AddButton onClick={() => setShowForm(true)} title="Nouveau vélo" />
          </PageHeader>
        </div>

        {/* Container : fond blanc/50% desktop uniquement */}
        <div className="overflow-hidden md:rounded-[50px] md:bg-white/50 md:p-5">
          <VeloTable />
        </div>
      </div>

      <VeloForm
        open={showForm}
        onClose={() => setShowForm(false)}
        onCreated={(veloId) => {
          setShowForm(false);
          if (veloId) router.push(`/inventaire/${veloId}`);
        }}
      />
    </AppShell>
  );
}
