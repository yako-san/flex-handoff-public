'use client';
import { useState, useMemo } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock, AddButton, SearchInput, UtilButton } from '@/components/layout/PageHeader';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import ClientForm from '@/components/clients/ClientForm';
import CommPrefIcons from '@/components/clients/CommPrefIcons';
import ArchiveDetailModal from '@/components/archives/ArchiveDetailModal';
import { useClients } from '@/hooks/useClients';
import { useInventaire } from '@/hooks/useInventaire';
import { useArchives } from '@/hooks/useArchives';
import { normSearch, formatTel, telE164 } from '@/lib/utils/format';
import { STATUTS } from '@/lib/utils/statuts';
import { TrashIcon, ArrowPathIcon } from '@heroicons/react/24/outline';
import { toast } from '@/components/ui/Toast';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import type { Client } from '@/types/client';
import type { BDC } from '@/types/bdc';

const ALPHA_BLOCKS = ['ABC', 'DEF', 'GHI', 'JKL', 'MNO', 'PQR', 'STU', 'VWX', 'YZ', '#'] as const;

const LINK_BLUE = '#1d4ed8';

// Largeurs partagées entre la légende et les lignes
const COL = {
  nom      : '220px',
  courriel : '220px',
  tel      : '140px',
  comm     : '80px',
  lead     : '90px',
} as const;

function blockFor(letter: string): string {
  const L = letter.toUpperCase();
  if (!L || !/[A-Z]/.test(L)) return '#';
  for (const b of ALPHA_BLOCKS) { if (b !== '#' && b.includes(L)) return b; }
  return '#';
}

interface BdcInfo { status: string; marque: string; isActive: boolean; }

export default function ClientsPage() {
  const { grouped, isLoading, removeClient, refreshClients } = useClients();
  const { velos } = useInventaire();
  const { bdcs: archivedBdcs } = useArchives();
  const [search, setSearch] = useState('');
  const [editTarget, setEditTarget] = useState<Client | null>(null);
  const [archiveDetail, setArchiveDetail] = useState<BDC | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncConfirmOpen, setSyncConfirmOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Client | null>(null);
  const [deleting, setDeleting] = useState(false);

  const totalClients = grouped ? [...grouped.recents, ...grouped.actifs, ...grouped.autres].length : 0;

  async function runSyncContacts() {
    setSyncConfirmOpen(false);
    setSyncing(true);
    try {
      // 1. Rattrape d'abord l'appartenance au groupe pour les contacts déjà créés
      //    (rapide, idempotent, ne touche pas aux champs du contact)
      const fixRes = await fetch('/api/clients/sync-contacts/fix-groups', { method: 'POST' });
      const fix    = await fixRes.json();
      if (fixRes.ok && fix.processed > 0) {
        console.log('[fix-groups]', fix);
      }

      // 2. Puis upsert complet (crée les manquants, met à jour les existants)
      const res  = await fetch('/api/clients/sync-contacts', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Échec');

      const addedToGroup = fix?.added ?? 0;
      toast(
        `Sync OK — ${data.created} créés · ${data.updated} mis à jour · ${data.failed} échecs`
        + (addedToGroup > 0 ? ` · ${addedToGroup} ajoutés au groupe Clients` : ''),
      );
      if (data.errors?.length) console.error('[sync-contacts] erreurs :', data.errors);
      await refreshClients();
    } catch (err: any) {
      toast(err.message || 'Échec de la synchronisation', 'error');
    } finally {
      setSyncing(false);
    }
  }

  // bdcId → { status, marque, isActive }
  // ⚠ Priorité ARCHIVES > ACTIVE : on prend l'état terminal (archivé)
  // si le BDT existe dans les deux sources (data corrompue). Sinon on
  // affichait WIP vert pour un BDT en réalité archivé.
  const bdcInfoMap = useMemo(() => {
    const m = new Map<string, { status: string; marque: string; isActive: boolean }>();
    for (const b of archivedBdcs) {
      if (b.id && !m.has(b.id)) {
        const marque = (b.veloDesc || '').split(',')[0].trim();
        m.set(b.id, { status: b.archiveStatus || 'ARCHIVÉ', marque, isActive: false });
      }
    }
    for (const v of velos) {
      if (v.id && !m.has(v.id)) m.set(v.id, { status: v.status, marque: v.marque || '', isActive: true });
    }
    return m;
  }, [velos, archivedBdcs]);

  // Fusionne les 3 buckets en une seule liste dédupliquée
  const allClients = useMemo<Client[]>(() => {
    if (!grouped) return [];
    const arr = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
    const seen = new Set<number>();
    return arr.filter(c => {
      if (seen.has(c._row)) return false;
      seen.add(c._row);
      return true;
    });
  }, [grouped]);

  // Filtrage recherche
  const filtered = useMemo<Client[]>(() => {
    if (!search) return allClients;
    const q = normSearch(search);
    const qDigits = search.replace(/\D/g, '');
    return allClients.filter(c =>
      normSearch(c.nom     ?? '').includes(q) ||
      normSearch(c.prenom  ?? '').includes(q) ||
      normSearch(c.courriel ?? '').includes(q) ||
      (qDigits.length >= 3 && (c.tel ?? '').replace(/\D/g, '').includes(qDigits))
    );
  }, [allClients, search]);

  // Regroupement par bloc alphabétique (tri par NOM de famille)
  const groups = useMemo<Record<string, Client[]>>(() => {
    const out: Record<string, Client[]> = {};
    for (const b of ALPHA_BLOCKS) out[b] = [];
    for (const c of filtered) {
      const firstLetter = (c.nom?.trim() || c.prenom?.trim() || '#').charAt(0);
      const block = blockFor(firstLetter);
      out[block].push(c);
    }
    for (const b of ALPHA_BLOCKS) {
      out[b].sort((a, b2) => (a.nom + a.prenom).localeCompare(b2.nom + b2.prenom, 'fr'));
    }
    return out;
  }, [filtered]);

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader
          subtitle={allClients.length ? `${allClients.length} client${allClients.length > 1 ? 's' : ''}` : 'clients'}
          title="Clients"
          helpTopic="01-recevoir-velo"
          helpTitle="Clients"
          helpHint="Liste alpha des clients avec leurs BDT (pills colorées). Click sur un client = fiche complète. Click sur pill BDT = ouvre l'archive ou le BDT actif."
        >
          <ToolbarBlock>
            <SearchInput
              value={search}
              onChange={setSearch}
              placeholder="Nom, prénom, courriel, tél…"
            />
            <UtilButton
              onClick={() => setSyncConfirmOpen(true)}
              title={syncing ? 'Synchronisation…' : 'Synchroniser tous les clients vers Google Contacts'}
            >
              <ArrowPathIcon
                className={syncing ? 'animate-spin' : ''}
                style={{ width: '100%', height: '100%' }}
              />
            </UtilButton>
          </ToolbarBlock>
          <AddButton onClick={() => setShowNew(true)} title="Nouveau client" />
        </PageHeader>

        {isLoading && <LoadingSpinner className="py-20" />}

        {!isLoading && (
          <div style={{ backgroundColor: 'rgba(0,0,0,0.2)', borderRadius: '50px', padding: '20px' }}>
            {filtered.length === 0 && (
              <p className="text-center py-16" style={{ color: 'rgba(255,255,255,0.5)' }}>
                {search ? 'Aucun client ne correspond à la recherche.' : 'Aucun client. Cliquez sur « + » pour en créer un.'}
              </p>
            )}

            <div className="flex flex-col" style={{ gap: '18px' }}>
              {ALPHA_BLOCKS.map(block => {
                const list = groups[block] ?? [];
                if (list.length === 0) return null;
                return (
                  <div key={block}>
                    <div
                      className="flex items-center"
                      style={{
                        padding: '2px 18px 4px',
                        color: 'rgba(255,255,255,0.55)',
                        fontSize: '11px',
                        fontWeight: 400,
                        letterSpacing: '0.04em',
                      }}
                    >
                      {block} <span style={{ marginLeft: '6px', color: 'rgba(255,255,255,0.35)', fontSize: '10px' }}>{list.length}</span>
                    </div>
                    <div style={{ borderRadius: '24px', overflow: 'hidden' }}>
                      <LegendRow />
                      {list.map((c, i) => (
                        <ClientRow
                          key={c._row}
                          client={c}
                          index={i}
                          bdcInfoMap={bdcInfoMap}
                          archivedBdcs={archivedBdcs}
                          onEdit={() => setEditTarget(c)}
                          onOpenArchive={(b) => setArchiveDetail(b)}
                          onDelete={() => {
                            if (c.bdcIds.length > 0) {
                              toast(`Impossible : ${c.nomComplet} a ${c.bdcIds.length} BDT. Retirez-les d'abord.`, 'error');
                              return;
                            }
                            setDeleteTarget(c);
                          }}
                        />
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Création */}
      <ClientForm
        open={showNew}
        onClose={() => setShowNew(false)}
      />

      {/* Édition */}
      <ClientForm
        open={editTarget !== null}
        onClose={() => setEditTarget(null)}
        editClient={editTarget}
      />

      {/* Détail BDT archivé (lecture seule) */}
      <ArchiveDetailModal
        open={archiveDetail !== null}
        bdc={archiveDetail}
        onClose={() => setArchiveDetail(null)}
      />

      {/* Confirmation sync Contacts */}
      <ConfirmDialog
        open={syncConfirmOpen}
        title="Synchroniser Google Contacts"
        message={`Synchroniser les ${totalClients} clients vers Google Contacts (groupe « Clients ») ?\n\nPeut prendre plusieurs minutes.`}
        confirmLabel={syncing ? 'Sync…' : 'Synchroniser'}
        onConfirm={runSyncContacts}
        onCancel={() => setSyncConfirmOpen(false)}
      />

      {/* Confirmation suppression client */}
      <ConfirmDialog
        open={deleteTarget !== null}
        title="Supprimer le client ?"
        message={deleteTarget
          ? `Supprimer DÉFINITIVEMENT ${deleteTarget.nomComplet} ?\n\n• Retiré de la fiche CLIENTS\n• Le contact Google sera aussi supprimé`
          : ''}
        confirmLabel={deleting ? 'Suppression…' : 'Supprimer'}
        danger
        onConfirm={async () => {
          if (!deleteTarget) return;
          setDeleting(true);
          try {
            await removeClient(deleteTarget._row);
            toast(`${deleteTarget.nomComplet} supprimé`);
            setDeleteTarget(null);
          } catch (err: any) {
            toast(err.message || 'Échec', 'error');
          } finally {
            setDeleting(false);
          }
        }}
        onCancel={() => { if (!deleting) setDeleteTarget(null); }}
      />
    </AppShell>
  );
}

// ─── Légende colonnes ────────────────────────────────────────────────

function LegendRow() {
  const cellStyle = {
    fontSize: '11px',
    fontWeight: 700,
    color: 'rgba(0,0,0,0.5)',
    letterSpacing: '0.04em',
  };
  return (
    <div
      className="flex items-center"
      style={{
        padding: '3px 20px',
        backgroundColor: '#ffffff',
        gap: '14px',
        borderBottom: '1px solid rgba(0,0,0,0.08)',
        lineHeight: 1.1,
      }}
    >
      <div style={{ width: '28px', ...cellStyle }}></div>
      <div style={{ width: COL.nom,      ...cellStyle }}>nom</div>
      <div style={{ width: COL.courriel, ...cellStyle }}>courriel</div>
      <div style={{ width: COL.tel,      ...cellStyle }}>tél.</div>
      <div style={{ width: COL.comm,     ...cellStyle }}>comm.</div>
      <div style={{ width: COL.lead,     ...cellStyle }}>lead</div>
      <div style={{ flex: '1 1 auto',    ...cellStyle, textAlign: 'right' }}>bdt</div>
    </div>
  );
}

// ─── Ligne client ───────────────────────────────────────────────────

interface RowProps {
  client: Client;
  index: number;
  bdcInfoMap: Map<string, BdcInfo>;
  archivedBdcs: BDC[];
  onEdit: () => void;
  onDelete: () => void;
  onOpenArchive: (b: BDC) => void;
}

function ClientRow({ client: c, index, bdcInfoMap, archivedBdcs, onEdit, onDelete, onOpenArchive }: RowProps) {
  const rowBg = index % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)';
  const telFmt = formatTel(c.tel);
  const telE   = telE164(c.tel, c.indicatif);
  const isTexto = /texto/i.test(c.commPref || '');
  const telHref = telE ? (isTexto ? `sms:${telE}` : `tel:${telE}`) : '';

  return (
    <div
      className="flex items-center hover:bg-yellow-100 transition-colors"
      style={{
        padding: '4px 20px',
        backgroundColor: rowBg,
        gap: '14px',
        borderBottom: '1px solid rgba(0,0,0,0.04)',
        lineHeight: 1.2,
      }}
    >
      {/* Poubelle début de ligne */}
      <button
        type="button"
        onClick={e => { e.stopPropagation(); onDelete(); }}
        title={`Supprimer ${c.nomComplet}`}
        className="flex items-center justify-center hover:opacity-100 transition-opacity"
        style={{
          width: '28px',
          height: '28px',
          border: 'none',
          backgroundColor: 'transparent',
          color: 'rgba(0,0,0,0.4)',
          opacity: 0.5,
          cursor: 'pointer',
          flexShrink: 0,
          padding: 0,
        }}
      >
        <TrashIcon style={{ width: '15px', height: '15px' }} />
      </button>

      {/* Nom : affiche "Prénom Nom", classement par nom de famille */}
      <button
        type="button"
        onClick={onEdit}
        className="text-left cursor-pointer bg-transparent"
        style={{
          width: COL.nom,
          minWidth: 0,
          fontSize: '15px',
          fontWeight: 700,
          color: 'rgba(0,0,0,0.8)',
          border: 'none',
          padding: 0,
        }}
      >
        <span className="whitespace-nowrap overflow-hidden text-ellipsis block" title={`${c.prenom} ${c.nom}`}>
          {c.prenom} {c.nom}
        </span>
      </button>

      <div style={{ width: COL.courriel, minWidth: 0, fontSize: '15px' }}>
        {c.courriel ? (
          <a
            href={`mailto:${c.courriel}`}
            className="whitespace-nowrap overflow-hidden text-ellipsis block hover:underline"
            style={{ color: LINK_BLUE }}
            title={c.courriel}
            onClick={e => e.stopPropagation()}
          >
            {c.courriel}
          </a>
        ) : (
          <span style={{ color: 'rgba(0,0,0,0.35)' }}>—</span>
        )}
      </div>

      <div style={{ width: COL.tel, fontSize: '15px', fontFamily: 'monospace' }}>
        {telFmt ? (
          <a
            href={telHref}
            className="hover:underline"
            style={{ color: LINK_BLUE }}
            title={isTexto ? 'Envoyer un texto' : 'Appeler'}
            onClick={e => e.stopPropagation()}
          >
            {telFmt}
          </a>
        ) : (
          <span style={{ color: 'rgba(0,0,0,0.35)' }}>—</span>
        )}
      </div>

      <div style={{ width: COL.comm }}>
        <CommPrefIcons value={c.commPref} size={16} />
      </div>

      <div style={{ width: COL.lead, fontSize: '15px', color: 'rgba(0,0,0,0.55)' }}>
        {c.lead || '—'}
      </div>

      {/* Bloc droit : pills BDT (prend tout l'espace restant, aligné à droite) */}
      <div
        className="flex flex-wrap items-center"
        style={{ flex: '1 1 auto', gap: '6px', minWidth: 0, justifyContent: 'flex-end' }}
      >
        {c.bdcIds.length === 0 ? (
          <span style={{ color: 'rgba(0,0,0,0.25)', fontSize: '12px', fontStyle: 'italic' }}>—</span>
        ) : (
          // Dédoublonne pour éviter d'afficher 2 fois le même ID
          [...new Set(c.bdcIds)].map(id => {
            const info = bdcInfoMap.get(id);
            const isGhost = !info;
            const status  = info?.status ?? '';
            const norm = status.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().trim();
            // Couleurs simplifiées : gris (archivé/fantôme), rouge (refusé),
            // jaune (RV/REÇU), vert (en cours)
            let bg: string, fg: string;
            if (isGhost) {
              bg = 'rgba(0,0,0,0.08)'; fg = 'rgba(0,0,0,0.45)';
            } else if (!info!.isActive && /REFUS/.test(norm)) {
              bg = '#ffcdd2'; fg = '#b71c1c';
            } else if (!info!.isActive) {
              bg = '#e0e0e0'; fg = 'rgba(0,0,0,0.55)';
            } else if (norm === 'RV' || norm === 'RECU') {
              bg = '#fff056'; fg = '#000000';
            } else {
              bg = '#88fa4e'; fg = '#000000';
            }
            // Marque affichée : si le BDT est encore en RV ou REÇU et que
            // la marque n'est pas encore renseignée (placeholder
            // 'Sélection →' ou vide), on affiche 'RdV*' à la place pour
            // signaler qu'il s'agit d'un rendez-vous pas encore évalué.
            let marque = info?.marque || '';
            const isPreEval = !!info?.isActive && (norm === 'RV' || norm === 'RECU');
            if (isPreEval && (marque === '' || marque === 'Sélection →' || marque === '...')) {
              marque = 'RdV*';
            }
            const label  = isGhost ? '(orphelin)' : (status || '—');
            // Comportement clic : actif → /inventaire/[id], archivé →
            // ouvre modal détail (pas de navigation), fantôme → fiche client
            const handleClick = (e: React.MouseEvent) => {
              e.stopPropagation();
              if (isGhost) { onEdit(); return; }
              if (info!.isActive) {
                window.location.href = `/inventaire/${id}`;
                return;
              }
              const arch = archivedBdcs.find(a => a.id === id);
              if (arch) onOpenArchive(arch);
            };
            return (
              <span
                key={id}
                onClick={handleClick}
                title={`${label}${marque ? ' — ' + marque : ''}`}
                style={{
                  backgroundColor: bg,
                  color: fg,
                  fontSize: '12px',
                  fontWeight: 700,
                  padding: '3px 10px',
                  borderRadius: '999px',
                  whiteSpace: 'nowrap',
                  fontStyle: isGhost ? 'italic' : 'normal',
                  cursor: 'pointer',
                }}
              >
                {id}{marque ? ` · ${marque}` : ''}
              </span>
            );
          })
        )}
      </div>
    </div>
  );
}
