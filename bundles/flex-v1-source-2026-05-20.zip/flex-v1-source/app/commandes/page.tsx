'use client';
import { useState, useMemo } from 'react';
import useSWR from 'swr';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock } from '@/components/layout/PageHeader';
import PiecesTabs from '@/components/catalogue/PiecesTabs';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import DragTh from '@/components/ui/DragTh';
import { useColOrder } from '@/hooks/useColOrder';
import { frPrix } from '@/lib/utils/format';
import { CheckCircleIcon, ExclamationTriangleIcon, TrashIcon, CubeIcon } from '@heroicons/react/24/outline';
import { usePieces } from '@/hooks/useCatalogue';
import type { CommandeItem } from '@/app/api/commandes/route';
import { CMD_OPTIONS, CMD_STYLE, CMD_TOOLTIP, STATUTS } from '@/lib/utils/statuts';
import { useInventaire } from '@/hooks/useInventaire';

import { jsonFetcher as fetcher } from '@/lib/swr';

const COLS = [
  { id: 'piece',     header: 'pièce',      width: '',      hCls: 'px-3 py-2',                   cCls: 'px-3 py-2' },
  { id: 'fourni',    header: 'fournisseur', width: '140px', hCls: 'px-2 py-2',                   cCls: 'px-2 py-1.5' },
  { id: 'sku',       header: 'sku',         width: '110px', hCls: 'px-2 py-2',                   cCls: 'px-2 py-1.5' },
  { id: 'prix',      header: 'prix',        width: '70px',  hCls: 'px-2 py-2 text-right',        cCls: 'px-2 py-2 text-right text-gray-600' },
  { id: 'qte',       header: 'qté',         width: '90px',  hCls: 'px-2 py-2 text-center',       cCls: 'px-2 py-1.5 text-center' },
  { id: 'sousTotal', header: 's/total',     width: '70px',  hCls: 'px-2 py-2 text-right',        cCls: 'px-2 py-2 text-right font-semibold text-gray-800' },
  { id: 'statut',    header: 'statut',      width: '70px',  hCls: 'px-2 py-2 text-center',       cCls: 'px-2 py-1.5 text-center' },
  { id: 'action',    header: 'action',      width: '180px', hCls: 'px-3 py-2',                   cCls: 'px-3 py-1.5' },
] as const;

type ColId = typeof COLS[number]['id'];

// ── Cellule Fournisseur (composant pour gérer son propre état) ──────
function FournisseurCell({
  item, fournisseurValue, fournisseurs, onSave,
}: {
  item: CommandeItem;
  fournisseurValue: string;
  fournisseurs: string[];
  onSave: (val: string) => void;
}) {
  return (
    <select
      value={fournisseurValue}
      onChange={e => onSave(e.target.value)}
      className="w-full border rounded px-1.5 py-0.5 text-xs focus:outline-none focus:ring-1 focus:ring-yellow-400 bg-white"
    >
      <option value="">—</option>
      {fournisseurs.map(f => <option key={f} value={f}>{f}</option>)}
    </select>
  );
}

// ── Cellule SKU (composant pour gérer son propre état) ──────────────
function SkuCell({
  item, catMap, onSave,
}: {
  item: CommandeItem;
  catMap: Map<string, { _row: number; fournisseur: string; sku: string; flag: string }>;
  onSave: (val: string) => void;
}) {
  const cat = catMap.get(item.nom);
  const [val, setVal] = useState(cat?.sku ?? '');
  // Sync si le catMap change (ex. mise à jour depuis la page Pièces)
  const catSku = cat?.sku ?? '';
  if (val !== catSku && document.activeElement?.tagName !== 'INPUT') {
    // non-bloquant : met à jour hors focus
  }
  return (
    <input
      type="text"
      value={val}
      onChange={e => setVal(e.target.value)}
      onBlur={e => { if (e.target.value !== (cat?.sku ?? '')) onSave(e.target.value); }}
      placeholder="SKU…"
      className="w-full border rounded px-1.5 py-0.5 text-xs focus:outline-none focus:ring-1 focus:ring-yellow-400 font-mono"
    />
  );
}

export default function CommandesPage() {
  const { data, error, isLoading, mutate } = useSWR<{ commandes: CommandeItem[] }>(
    '/api/commandes', fetcher
  );
  const { pieces: catalogue, patchPiece } = usePieces();
  const { velos } = useInventaire();
  const { orderedCols, dragProps, dragOverId } = useColOrder('commandes', COLS as any);

  // Map bdcId → statut vélo
  const veloStatusMap = useMemo(() => {
    const m = new Map<string, string>();
    velos.forEach(v => m.set(v.id, v.status));
    return m;
  }, [velos]);

  type CatEntry = { _row: number; fournisseur: string; sku: string; flag: string; nom: string };

  const catMap = useMemo(() => {
    const m = new Map<string, CatEntry>();
    catalogue.forEach(p => {
      const entry: CatEntry = { _row: p._row, fournisseur: p.fournisseur, sku: p.sku, flag: p.flag, nom: p.nom };
      m.set(p.nom, entry);
      const key = p.nom.toLowerCase().replace(/\s+/g, ' ').trim();
      if (!m.has(key)) m.set(key, entry);
    });
    return m;
  }, [catalogue]);

  /** Trouve une pièce du catalogue par nom — exact, normalisé, puis inclusion */
  function findCatEntry(nom: string): CatEntry | undefined {
    const exact = catMap.get(nom);
    if (exact) return exact;
    const normalized = catMap.get(nom.toLowerCase().replace(/\s+/g, ' ').trim());
    if (normalized) return normalized;
    // Fallback : chercher par inclusion (le nom BDC contenu dans le nom catalogue ou vice-versa)
    const lc = nom.toLowerCase().replace(/\s+/g, ' ').trim();
    for (const p of catalogue) {
      const plc = p.nom.toLowerCase().replace(/\s+/g, ' ').trim();
      if (plc.includes(lc) || lc.includes(plc)) {
        return { _row: p._row, fournisseur: p.fournisseur, sku: p.sku, flag: p.flag, nom: p.nom };
      }
    }
    return undefined;
  }

  const fournisseurs = useMemo(() =>
    [...new Set(
      catalogue
        .map(p => p.fournisseur)
        .filter(f => !!f && f.toLowerCase() !== 'fournisseur'),
    )].sort(),
  [catalogue]);

  const commandes = data?.commandes ?? [];
  const [busy,  setBusy]  = useState<Set<number>>(new Set());
  const [notes, setNotes] = useState<Record<number, string>>({});

  // Séparer en 3 groupes : à commander (√/$), reçues (@)
  const { urgent, received, grouped } = useMemo(() => {
    const urgent: CommandeItem[]   = [];
    const received: CommandeItem[] = [];
    const rest: CommandeItem[]     = [];
    commandes.forEach(c => {
      if (c.cmd === '√' || c.cmd === '$') urgent.push(c);
      else if (c.cmd === '@') received.push(c);
      else rest.push(c);
    });
    const grouped = urgent.reduce<Record<string, CommandeItem[]>>((acc, c) => {
      (acc[c.bdcId] ||= []).push(c);
      return acc;
    }, {});
    return { urgent, received, grouped };
  }, [commandes]);

  async function patchBdcCmd(item: CommandeItem, cmd: string) {
    setBusy(prev => new Set(prev).add(item._row));
    try {
      await fetch(`/api/bdc/${item.bdcId}/items`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ row: item._row, cmd }),
      });
      await mutate();
    } finally {
      setBusy(prev => { const s = new Set(prev); s.delete(item._row); return s; });
    }
  }

  // Statut → écrit dans ACHATS (flag global) + BDC (cmd local)
  async function patchStatut(item: CommandeItem, val: string) {
    const cat = catMap.get(item.nom);
    if (cat) await patchPiece(cat._row, { flag: val });
    await patchBdcCmd(item, val);
  }

  async function patchQte(item: CommandeItem, qte: number) {
    if (qte < 1) return;
    setBusy(prev => new Set(prev).add(item._row));
    try {
      await fetch(`/api/bdc/${item.bdcId}/items`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ row: item._row, type: 'piece', qte, sousTotal: item.prix * qte }),
      });
      await mutate();
    } finally {
      setBusy(prev => { const s = new Set(prev); s.delete(item._row); return s; });
    }
  }

  async function handleDelete(item: CommandeItem) {
    setBusy(prev => new Set(prev).add(item._row));
    try {
      await fetch(`/api/bdc/${item.bdcId}/items`, {
        method: 'DELETE', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ row: item._row }),
      });
      await mutate();
    } finally {
      setBusy(prev => { const s = new Set(prev); s.delete(item._row); return s; });
    }
  }

  async function saveNote(item: CommandeItem, note: string) {
    await fetch(`/api/bdc/${item.bdcId}/items`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ row: item._row, cmdNote: note }),
    });
  }

  async function saveFournisseur(item: CommandeItem, fournisseur: string) {
    const cat = findCatEntry(item.nom);
    if (!cat) return;
    await patchPiece(cat._row, { fournisseur });
  }

  async function saveSku(item: CommandeItem, sku: string) {
    const cat = findCatEntry(item.nom);
    if (!cat) return;
    await patchPiece(cat._row, { sku });
  }

  function renderCell(id: ColId, item: CommandeItem) {
    const isBusy   = busy.has(item._row);
    const cat      = findCatEntry(item.nom);
    const note     = notes[item._row] ?? (item as any).cmdNote ?? '';
    const statut   = cat?.flag ?? item.cmd;
    const cmdStyle = CMD_STYLE[statut] ?? CMD_STYLE['...'];

    switch (id) {
      case 'piece':
        return <span className="font-medium text-gray-800">⚙️ {item.nom}</span>;

      case 'fourni':
        return (
          <FournisseurCell
            item={item} fournisseurValue={cat?.fournisseur ?? ''} fournisseurs={fournisseurs}
            onSave={val => saveFournisseur(item, val)}
          />
        );

      case 'sku': {
        const catPiece = catalogue.find(p => p.nom === item.nom || p.nom.toLowerCase().replace(/\s+/g, ' ').trim() === item.nom.toLowerCase().replace(/\s+/g, ' ').trim());
        const sku    = cat?.sku ?? '';
        const skuUrl = catPiece?.skuUrl ?? '';
        return skuUrl ? (
          <a href={skuUrl} target="_blank" rel="noopener noreferrer"
            className="text-xs font-mono text-blue-500 hover:underline truncate block" title={skuUrl}>
            {sku || skuUrl}
          </a>
        ) : (
          <span className="text-xs font-mono text-gray-500 truncate block" title={sku}>
            {sku || '—'}
          </span>
        );
      }

      case 'prix':
        return frPrix(item.prix);

      case 'qte':
        return (
          <div className="flex items-center justify-center gap-1">
            <button
              onClick={() => patchQte(item, item.qte - 1)}
              disabled={item.qte <= 1 || isBusy}
              className="w-5 h-5 flex items-center justify-center border rounded text-xs font-bold hover:bg-gray-100 disabled:opacity-30"
            >−</button>
            <span className="w-6 text-center font-medium">{item.qte}</span>
            <button
              onClick={() => patchQte(item, item.qte + 1)}
              disabled={isBusy}
              className="w-5 h-5 flex items-center justify-center border rounded text-xs font-bold hover:bg-gray-100 disabled:opacity-30"
            >+</button>
          </div>
        );

      case 'sousTotal':
        return frPrix(item.sousTotal);

      case 'statut':
        return (
          <select
            value={CMD_OPTIONS.includes(statut as any) ? statut : '...'}
            onChange={e => patchStatut(item, e.target.value)}
            disabled={isBusy}
            title={CMD_TOOLTIP}
            className="text-xs border rounded px-1 py-0.5 font-bold w-full focus:outline-none focus:ring-1 focus:ring-yellow-400"
            style={{ backgroundColor: cmdStyle.bg, color: cmdStyle.fg }}
          >
            {CMD_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
          </select>
        );

      case 'action':
        return (
          <div className="flex items-center gap-2">
            <label className="flex items-center gap-1.5 cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={statut === '$'}
                onChange={e => patchStatut(item, e.target.checked ? '$' : '√')}
                disabled={isBusy}
                className="h-3.5 w-3.5 rounded"
              />
              <span className="text-xs text-gray-500">{statut === '$' ? 'En commande' : 'À commander'}</span>
            </label>
            <input
              type="text"
              value={note}
              onChange={e => setNotes(prev => ({ ...prev, [item._row]: e.target.value }))}
              onBlur={e => saveNote(item, e.target.value)}
              placeholder="Note…"
              className="flex-1 min-w-0 border rounded px-1.5 py-0.5 text-xs focus:outline-none focus:ring-1 focus:ring-yellow-400"
            />
          </div>
        );
    }
  }

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader
          subtitle={
            (urgent.length > 0 ? `${urgent.length} à commander` : '') +
            (urgent.length > 0 && received.length > 0 ? ' · ' : '') +
            (received.length > 0 ? `${received.length} reçue${received.length > 1 ? 's' : ''}` : '') +
            (urgent.length === 0 && received.length === 0 ? 'commandes' : '')
          }
          title="Pièces" titleSuffix="/bons de travail"
        >
          <ToolbarBlock>
            <PiecesTabs />
          </ToolbarBlock>
        </PageHeader>

        {isLoading && <LoadingSpinner className="py-20" />}
        {error    && <p className="text-red-600 text-sm">Erreur : {error.message}</p>}

        {!isLoading && commandes.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <CheckCircleIcon className="h-12 w-12 mb-3 text-green-400" />
            <p className="text-lg font-medium">Aucune commande en attente</p>
            <p className="text-sm mt-1">Toutes les pièces sont reçues ou en stock.</p>
          </div>
        )}

        {!isLoading && commandes.length > 0 && (
          <div className="md:bg-black/20 md:rounded-[50px] md:p-5">
           <div className="flex flex-col" style={{ gap: '20px' }}>
            {Object.entries(grouped).map(([bdcId, items]) => {
              const first  = items[0];
              const status = veloStatusMap.get(bdcId) ?? '';
              const st     = STATUTS[status];
              const bgCol  = st?.bg ?? '#f5f5f5';
              const fgCol  = st?.fg ?? '#333333';
              return (
                <div key={bdcId} className="overflow-hidden" style={{ borderRadius: '30px' }}>
                  <div
                    className="flex items-center gap-3"
                    style={{ backgroundColor: bgCol, height: '64px', paddingLeft: '30px', paddingRight: '30px' }}
                  >
                    <CubeIcon style={{ width: '30px', height: '30px', color: 'rgba(0,0,0,0.5)' }} />
                    <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '30px', fontWeight: 700, lineHeight: 1 }}>{bdcId}</span>
                    <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '22px', fontWeight: 700, lineHeight: 1 }}>{status}</span>
                    <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '18px', fontWeight: 400, lineHeight: 1 }}>
                      {first.veloDesc} ({first.clientNom})
                    </span>
                  </div>
                  {/* ── Vue desktop : table classique (hidden md+) ── */}
                  <div className="hidden md:block overflow-x-auto">
                    <table className="w-full text-left text-sm table-fixed">
                      <colgroup>
                        <col style={{ width: '36px' }} />
                        {orderedCols.map(col => (
                          <col key={col.id} style={{ width: (col as any).width || undefined }} />
                        ))}
                      </colgroup>
                      <thead>
                        <tr className="list-header">
                          <th className="px-2 py-2 w-9"></th>
                          {orderedCols.map(col => (
                            <DragTh key={col.id} className={col.hCls} isDragOver={dragOverId === col.id} {...dragProps(col.id)}>
                              {col.header}
                            </DragTh>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {items.map((item, i) => {
                          const isBusy = busy.has(item._row);
                          const baseBg = i % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)';
                          return (
                            <tr key={item._row} className={`text-sm ${isBusy ? 'opacity-60' : ''}`} style={{ backgroundColor: baseBg }}>
                              <td className="px-2 py-1.5 text-center align-top">
                                <button
                                  onClick={() => handleDelete(item)}
                                  disabled={isBusy}
                                  className="hover:text-red-500 transition-colors disabled:opacity-30"
                                  style={{ color: 'rgba(0,0,0,0.5)' }}
                                >
                                  <TrashIcon style={{ width: '20px', height: '20px' }} />
                                </button>
                              </td>
                              {orderedCols.map(col => (
                                <td key={col.id} className={col.cCls}>
                                  {renderCell(col.id as ColId, item)}
                                </td>
                              ))}
                            </tr>
                          );
                        })}
                        {/* Ligne total — même style que légende */}
                        <tr className="list-header">
                          <td className="px-2 py-1.5"></td>
                          {orderedCols.map(col => {
                            let content: React.ReactNode = '';
                            if (col.id === 'piece') content = `${items.length} pièces`;
                            if (col.id === 'sousTotal') content = <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '15px' }}>{frPrix(items.reduce((s, x) => s + ((x.prix || 0) * (x.qte || 0)), 0))}</span>;
                            return <td key={col.id} className={col.cCls}>{content}</td>;
                          })}
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* ── Vue mobile : cards stack vertical (md:hidden) ── */}
                  <div className="md:hidden flex flex-col" style={{ backgroundColor: 'rgba(255,255,255,0.85)' }}>
                    {items.map((item, i) => {
                      const isBusy = busy.has(item._row);
                      return (
                        <div
                          key={item._row}
                          className={`${isBusy ? 'opacity-60' : ''}`}
                          style={{
                            padding: '14px 16px',
                            borderBottom: '1px solid rgba(0,0,0,0.06)',
                          }}
                        >
                          {/* Ligne 1 : nom + sous-total + trash */}
                          <div className="flex items-start justify-between gap-3" style={{ marginBottom: '10px' }}>
                            <div className="flex-1 min-w-0">
                              <div className="font-semibold" style={{ fontSize: '15px', color: 'rgba(0,0,0,0.85)', wordBreak: 'break-word' }}>
                                ⚙️ {item.nom}
                              </div>
                            </div>
                            <div className="shrink-0 text-right">
                              <div style={{ fontSize: '15px', fontWeight: 700, color: 'rgba(0,0,0,0.85)' }}>{frPrix(item.sousTotal)}</div>
                              <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)' }}>{item.qte} × {frPrix(item.prix)}</div>
                            </div>
                            <button
                              onClick={() => handleDelete(item)}
                              disabled={isBusy}
                              className="hover:text-red-500 transition-colors disabled:opacity-30 shrink-0"
                              style={{ color: 'rgba(0,0,0,0.4)', padding: '4px' }}
                              title="Supprimer"
                            >
                              <TrashIcon style={{ width: '20px', height: '20px' }} />
                            </button>
                          </div>
                          {/* Ligne 2 : qté +/- | statut CMD */}
                          <div className="flex items-center gap-3" style={{ marginBottom: '10px' }}>
                            <div className="shrink-0">{renderCell('qte', item)}</div>
                            <div className="flex-1 min-w-0">{renderCell('statut', item)}</div>
                          </div>
                          {/* Ligne 3 : fournisseur | sku */}
                          <div className="flex items-center gap-2" style={{ marginBottom: '10px' }}>
                            <div className="flex-1 min-w-0">{renderCell('fourni', item)}</div>
                            <div className="flex-1 min-w-0">{renderCell('sku', item)}</div>
                          </div>
                          {/* Ligne 4 : action (note + checkbox) */}
                          <div>{renderCell('action', item)}</div>
                        </div>
                      );
                    })}
                    {/* Pied total */}
                    <div className="list-header flex items-center justify-between" style={{ padding: '10px 16px' }}>
                      <span>{items.length} pièces</span>
                      <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '15px' }}>
                        {frPrix(items.reduce((s, x) => s + ((x.prix || 0) * (x.qte || 0)), 0))}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}

            {/* ── Bloc Pièces reçues (@) ── */}
            {received.length > 0 && (
              <div className="overflow-hidden" style={{ borderRadius: '30px' }}>
                <div
                  className="flex items-center gap-3"
                  style={{ backgroundColor: '#fff056', height: '64px', paddingLeft: '30px', paddingRight: '30px' }}
                >
                  <CubeIcon style={{ width: '30px', height: '30px', color: 'rgba(0,0,0,0.5)' }} />
                  <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '24px', fontWeight: 700, lineHeight: 1 }}>
                    Pièces reçues
                  </span>
                  <span style={{ color: 'rgba(0,0,0,0.4)', fontSize: '14px' }}>({received.length})</span>
                </div>
                {/* ── Vue desktop ── */}
                <div className="hidden md:block overflow-x-auto">
                  <table className="w-full text-left text-sm table-fixed">
                    <colgroup>
                      {orderedCols.map(col => (
                        <col key={col.id} style={{ width: (col as any).width || undefined }} />
                      ))}
                    </colgroup>
                    <thead>
                      <tr className="list-header">
                        {orderedCols.map(col => (
                          <DragTh key={col.id} className={col.hCls} isDragOver={dragOverId === col.id} {...dragProps(col.id)}>
                            {col.header}
                          </DragTh>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {received.map((item, i) => (
                        <tr key={item._row} className="text-sm" style={{ backgroundColor: i % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)' }}>
                          {orderedCols.map(col => (
                            <td key={col.id} className={col.cCls}>
                              {renderCell(col.id as ColId, item)}
                            </td>
                          ))}
                        </tr>
                      ))}
                      <tr className="list-header">
                        {orderedCols.map(col => {
                          let content: React.ReactNode = '';
                          if (col.id === 'piece') content = `${received.length} pièces reçues`;
                          if (col.id === 'sousTotal') content = <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '15px' }}>{frPrix(received.reduce((s, x) => s + ((x.prix || 0) * (x.qte || 0)), 0))}</span>;
                          return <td key={col.id} className={col.cCls}>{content}</td>;
                        })}
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* ── Vue mobile ── */}
                <div className="md:hidden flex flex-col" style={{ backgroundColor: 'rgba(255,255,255,0.85)' }}>
                  {received.map(item => (
                    <div
                      key={item._row}
                      style={{ padding: '14px 16px', borderBottom: '1px solid rgba(0,0,0,0.06)' }}
                    >
                      <div className="flex items-start justify-between gap-3" style={{ marginBottom: '8px' }}>
                        <div className="flex-1 min-w-0 font-semibold" style={{ fontSize: '15px', color: 'rgba(0,0,0,0.85)', wordBreak: 'break-word' }}>
                          ⚙️ {item.nom}
                        </div>
                        <div className="shrink-0 text-right">
                          <div style={{ fontSize: '15px', fontWeight: 700 }}>{frPrix(item.sousTotal)}</div>
                          <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)' }}>{item.qte} × {frPrix(item.prix)}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2" style={{ fontSize: '12px', color: 'rgba(0,0,0,0.6)' }}>
                        {(() => {
                          const cat = catalogue.find(p => p.nom === item.nom);
                          return (
                            <>
                              {cat?.fournisseur && <span>{cat.fournisseur}</span>}
                              {cat?.sku && <span className="font-mono">{cat.sku}</span>}
                            </>
                          );
                        })()}
                      </div>
                    </div>
                  ))}
                  <div className="list-header flex items-center justify-between" style={{ padding: '10px 16px' }}>
                    <span>{received.length} pièces reçues</span>
                    <span style={{ color: 'rgba(0,0,0,0.7)', fontSize: '15px' }}>
                      {frPrix(received.reduce((s, x) => s + ((x.prix || 0) * (x.qte || 0)), 0))}
                    </span>
                  </div>
                </div>
              </div>
            )}
           </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
