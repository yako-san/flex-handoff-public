'use client';
import { useState } from 'react';
import Link from 'next/link';
import AppShell from '@/components/layout/AppShell';
import PriceLookupModal from '@/components/catalogue/PriceLookupModal';
import QuickScanFlow from '@/components/scan/QuickScanFlow';
import { useVentes } from '@/hooks/useVentes';
import {
  BanknotesIcon,
  ChartBarSquareIcon,
  ClipboardDocumentListIcon,
  InboxArrowDownIcon,
  QrCodeIcon,
  MagnifyingGlassIcon,
} from '@heroicons/react/24/outline';
import type { ComponentType, SVGProps } from 'react';

/**
 * Menu d'accueil app-like (iOS home screen). Grid d'icônes carrées
 * squircle, label dessous. Cible mobile-first.
 *
 * v1.0.3+ : focus sur les flux opérationnels du mécano sur iPhone —
 * Ventes / Commandes / Réception / Prix (scan) / Scan rapide. Dashboard
 * et Clients sont sur desktop (sidebar) — pas pertinent en mobilité.
 * Inventaire (BDT) accessible via long-press du logo ou via desktop.
 */

interface MenuItem {
  href      ?: string;
  onClick   ?: () => void;
  label     : string;
  icon      : ComponentType<SVGProps<SVGSVGElement>>;
  /** Compteur affiché en badge ; couleur selon le contexte. */
  badge    ?: { count: number; color: string; title?: string };
  /** Si true, item disabled (feature pas encore livrée). */
  disabled ?: boolean;
  badgeLabel ?: string;
}

export default function MenuPage() {
  const [priceLookupOpen, setPriceLookupOpen] = useState(false);
  const [quickScanOpen,   setQuickScanOpen]   = useState(false);
  const { ventes } = useVentes();

  const venteNonFactCount = ventes.filter(v => !v.factureDate).length;

  const items: MenuItem[] = [
    {
      href: '/dashboard',
      label: 'Dashboard',
      icon: ChartBarSquareIcon,
    },
    {
      href: '/catalogue/ventes',
      label: 'Ventes',
      icon: BanknotesIcon,
      badge: venteNonFactCount > 0
        ? { count: venteNonFactCount, color: '#e53935', title: `${venteNonFactCount} vente(s) non facturée(s)` }
        : undefined,
    },
    {
      href: '/commandes',
      label: 'Commandes',
      icon: ClipboardDocumentListIcon,
    },
    {
      href: '/catalogue/reception',
      label: 'Réception',
      icon: InboxArrowDownIcon,
    },
    {
      onClick: () => setPriceLookupOpen(true),
      label: 'Prix (scan)',
      icon: MagnifyingGlassIcon,
    },
    {
      onClick: () => setQuickScanOpen(true),
      label: 'Scan rapide',
      icon: QrCodeIcon,
    },
  ];

  function renderCard(item: MenuItem) {
    const Icon = item.icon;
    return (
      <div
        className="flex flex-col items-center justify-center transition-colors relative"
        style={{
          aspectRatio: '1 / 1',
          borderRadius: '32px',
          backgroundColor: item.disabled ? 'rgba(0,0,0,0.10)' : 'rgba(0,0,0,0.20)',
          padding: '20px',
          gap: '12px',
          cursor: item.disabled ? 'not-allowed' : 'pointer',
          opacity: item.disabled ? 0.55 : 1,
        }}
      >
        <Icon
          style={{
            width: '48px',
            height: '48px',
            color: '#fff056',
            strokeWidth: 1.5,
          }}
        />
        <span
          style={{
            color: '#fff',
            fontSize: '0.9rem',
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
            textAlign: 'center',
          }}
        >
          {item.label}
        </span>
        {item.badgeLabel && (
          <span
            style={{
              color: 'rgba(255,255,255,0.5)',
              fontSize: '0.65rem',
              fontWeight: 600,
              letterSpacing: '0.04em',
              textTransform: 'lowercase',
            }}
          >
            {item.badgeLabel}
          </span>
        )}
        {item.badge && (
          <span
            title={item.badge.title}
            style={{
              position: 'absolute',
              top: '12px',
              right: '12px',
              minWidth: '24px',
              height: '24px',
              padding: '0 7px',
              borderRadius: '12px',
              backgroundColor: item.badge.color,
              color: item.badge.color === '#e53935' ? '#fff' : 'rgba(0,0,0,0.7)',
              fontSize: '12px',
              fontWeight: 700,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 2px 6px rgba(0,0,0,0.30)',
              border: '2px solid #fff',
              lineHeight: 1,
            }}
          >
            {item.badge.count > 99 ? '99+' : item.badge.count}
          </span>
        )}
      </div>
    );
  }

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px] flex flex-col items-center">
        <div
          className="w-full"
          style={{
            maxWidth: '720px',
            display: 'grid',
            gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
            gap: '20px',
            paddingTop: '20px',
          }}
        >
          {items.map(item => {
            if (item.disabled || (!item.href && !item.onClick)) {
              return <div key={item.label}>{renderCard(item)}</div>;
            }
            if (item.onClick) {
              return (
                <button
                  key={item.label}
                  type="button"
                  onClick={item.onClick}
                  style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', textAlign: 'inherit' }}
                >
                  {renderCard(item)}
                </button>
              );
            }
            return (
              <Link
                key={item.label}
                href={item.href!}
                style={{ textDecoration: 'none' }}
              >
                {renderCard(item)}
              </Link>
            );
          })}
        </div>
      </div>
      <PriceLookupModal open={priceLookupOpen} onClose={() => setPriceLookupOpen(false)} />
      <QuickScanFlow open={quickScanOpen} onClose={() => setQuickScanOpen(false)} />
    </AppShell>
  );
}
