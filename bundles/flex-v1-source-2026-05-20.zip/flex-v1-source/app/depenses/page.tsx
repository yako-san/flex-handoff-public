'use client';
import React, { useState, useMemo, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { AddButton, UtilButton, SearchInput } from '@/components/layout/PageHeader';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import { useDepenses } from '@/hooks/useDepenses';
import { useIsAdmin } from '@/hooks/useIsAdmin';
import DepenseFormModal from '@/components/depenses/DepenseFormModal';
import { DEPENSE_CATEGORIES, deductibleFactor, t2125LineFor } from '@/lib/depenses-categories';
import { useEmailTemplates } from '@/hooks/useEmailTemplates';
import { frPrix } from '@/lib/utils/format';
import { toast } from '@/components/ui/Toast';
import { PencilSquareIcon, TrashIcon, ArrowDownTrayIcon, LinkIcon, PrinterIcon } from '@heroicons/react/24/outline';
import type { Depense } from '@/types/depense';

/**
 * v1.0.26+ : page Dépenses (admin only).
 *
 * Compile les dépenses business pour déclaration TPS/TVQ trimestrielle +
 * T2125 fin d'année. Modal CRUD, filtres mois/catégorie/fournisseur,
 * totaux pied de page, export CSV.
 */
export default function DepensesPage() {
  const router = useRouter();
  const { isAdmin, loading: adminLoading } = useIsAdmin();
  // v1.0.30+ : lecture des settings fiscaux (TPS/TVQ/NEQ/raison sociale)
  const { tpl } = useEmailTemplates();
  const fiscalRaisonSociale = tpl('fiscal_raison_sociale');
  const fiscalNeq           = tpl('fiscal_neq');
  const fiscalTpsNumber     = tpl('fiscal_tps_number');
  const fiscalTvqNumber     = tpl('fiscal_tvq_number');
  // v1.0.27+ : toggle pour inclure les PO compilés dans les totaux comptables
  const [includePOs, setIncludePOs] = useState<boolean>(true);
  const { depenses, posCompiles, isLoading, error, createDepense, updateDepense, deleteDepense } = useDepenses({ includePOs });

  const [showForm,       setShowForm]      = useState(false);
  const [editTarget,     setEditTarget]    = useState<Depense | null>(null);
  const [deleteTarget,   setDeleteTarget]  = useState<Depense | null>(null);
  // v1.0.28+ : filtre période enrichi — mois | trimestre | année | tous |
  // valeur spécifique (YYYY-MM, YYYY-Tn, YYYY)
  const [filterPeriode,  setFilterPeriode] = useState<string>('current-mois');
  const [filterCat,      setFilterCat]     = useState<string>('all');
  const [search,         setSearch]        = useState('');

  // Redirige les non-admin vers /dashboard
  if (!adminLoading && !isAdmin) {
    if (typeof window !== 'undefined') router.replace('/dashboard');
    return null;
  }

  // ── Filtres ────────────────────────────────────────────────────
  // v1.0.28+ : génère les options du dropdown période. Combine :
  //   - 3 entrées dynamiques (mois courant, trimestre courant, année courante)
  //   - Tous
  //   - séparateur
  //   - trimestres distincts présents (récents en haut)
  //   - mois distincts présents (récents en haut)
  const periodeOptions = useMemo(() => {
    const moisSet = new Set<string>();           // YYYY-MM
    const trimSet = new Set<string>();           // YYYY-Tn
    const anneeSet = new Set<string>();          // YYYY
    for (const d of [...depenses, ...posCompiles]) {
      const date = d.date || '';
      if (date.length < 7) continue;
      const yyyy = date.slice(0, 4);
      const mm   = parseInt(date.slice(5, 7), 10) || 0;
      const tn   = Math.ceil(mm / 3);  // 1..4
      moisSet.add(`${yyyy}-${date.slice(5, 7)}`);
      trimSet.add(`${yyyy}-T${tn}`);
      anneeSet.add(yyyy);
    }
    // Inclure la période courante (même si pas de dépense)
    const now    = new Date();
    const curMois  = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const curTrim  = `${now.getFullYear()}-T${Math.ceil((now.getMonth() + 1) / 3)}`;
    const curAnnee = String(now.getFullYear());
    moisSet.add(curMois);
    trimSet.add(curTrim);
    anneeSet.add(curAnnee);
    return {
      moisList  : Array.from(moisSet).sort().reverse(),
      trimList  : Array.from(trimSet).sort().reverse(),
      anneeList : Array.from(anneeSet).sort().reverse(),
    };
  }, [depenses, posCompiles]);

  // v1.0.27+ : merge dépenses manuelles + PO compilés (read-only). Les
  // PO sont préfixés "PO-" sur leur ID — utilisé pour distinguer dans l'UI
  // (badge bleu, pas de boutons modifier/archiver, lien vers /catalogue/reception).
  const merged = useMemo<Depense[]>(() => {
    return [...depenses, ...posCompiles].sort((a, b) =>
      // Tri par date desc (plus récent en haut). Égalité → ID décroissant
      (b.date ?? '').localeCompare(a.date ?? '') || b.id.localeCompare(a.id)
    );
  }, [depenses, posCompiles]);

  /** Vérifie si une date YYYY-MM-DD tombe dans la période sélectionnée.
   *  Périodes supportées :
   *    - 'all'                  → tout
   *    - 'current-mois'         → mois courant
   *    - 'current-trim'         → trimestre courant
   *    - 'current-annee'        → année courante
   *    - 'YYYY-MM'              → mois spécifique
   *    - 'YYYY-Tn'              → trimestre spécifique (n=1..4)
   *    - 'YYYY'                 → année spécifique
   */
  function matchPeriode(date: string, periode: string): boolean {
    if (!date || periode === 'all') return true;
    const now    = new Date();
    const curY   = String(now.getFullYear());
    const curM   = String(now.getMonth() + 1).padStart(2, '0');
    const curT   = Math.ceil((now.getMonth() + 1) / 3);
    const yyyy   = date.slice(0, 4);
    const mm     = parseInt(date.slice(5, 7), 10) || 0;
    const tn     = Math.ceil(mm / 3);
    switch (periode) {
      case 'current-mois':  return date.startsWith(`${curY}-${curM}`);
      case 'current-trim':  return yyyy === curY && tn === curT;
      case 'current-annee': return yyyy === curY;
    }
    // Pattern YYYY-Tn (trimestre)
    const trimMatch = periode.match(/^(\d{4})-T([1-4])$/);
    if (trimMatch) return yyyy === trimMatch[1] && tn === parseInt(trimMatch[2], 10);
    // Pattern YYYY-MM (mois)
    if (/^\d{4}-\d{2}$/.test(periode)) return date.startsWith(periode);
    // Pattern YYYY (année)
    if (/^\d{4}$/.test(periode)) return yyyy === periode;
    return true;
  }

  const filtered = useMemo(() => {
    let list = merged;
    if (filterPeriode !== 'all') {
      list = list.filter(d => matchPeriode(d.date || '', filterPeriode));
    }
    if (filterCat && filterCat !== 'all') {
      list = list.filter(d => d.categorie === filterCat);
    }
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(d =>
        d.fournisseur.toLowerCase().includes(q) ||
        d.description.toLowerCase().includes(q) ||
        d.id.toLowerCase().includes(q)
      );
    }
    return list;
  }, [merged, filterPeriode, filterCat, search]);

  /** Libellé lisible de la période courante (pour totaux + export). */
  const periodeLabel = useMemo(() => {
    const now = new Date();
    const curY = String(now.getFullYear());
    const curT = Math.ceil((now.getMonth() + 1) / 3);
    switch (filterPeriode) {
      case 'all':           return 'Toutes périodes';
      case 'current-mois':  return `Mois courant (${now.toLocaleDateString('fr-CA', { month: 'long', year: 'numeric' })})`;
      case 'current-trim':  return `Trimestre courant (T${curT} ${curY})`;
      case 'current-annee': return `Année courante (${curY})`;
    }
    if (/^\d{4}-T[1-4]$/.test(filterPeriode)) return `Trimestre ${filterPeriode.replace('-', ' ')}`;
    if (/^\d{4}-\d{2}$/.test(filterPeriode))  return `Mois ${filterPeriode}`;
    if (/^\d{4}$/.test(filterPeriode))        return `Année ${filterPeriode}`;
    return filterPeriode;
  }, [filterPeriode]);

  const isPOCompile = (d: Depense) => d.id.startsWith('PO-');

  /** v1.0.29+ : top 10 fournisseurs par fréquence (dépenses manuelles +
   *  PO compilés). Sert au datalist autocomplete dans le modal. */
  const topFournisseurs = useMemo(() => {
    const counts = new Map<string, number>();
    for (const d of [...depenses, ...posCompiles]) {
      const f = d.fournisseur?.trim();
      if (!f) continue;
      counts.set(f, (counts.get(f) ?? 0) + 1);
    }
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
      .slice(0, 10)
      .map(([nom]) => nom);
  }, [depenses, posCompiles]);

  // v1.0.30+ : totaux du filtre — versions PAYÉ et DÉDUCTIBLE
  // - Payé : montants bruts sur le reçu (col du sheet)
  // - Déductible : montants × factor (catégorie 50%/100% × usagePct)
  const totals = useMemo(() => {
    let ht = 0, tps = 0, tvq = 0, ttc = 0;
    let htDed = 0, tpsCti = 0, tvqCtp = 0;
    let hasReducedFactor = false;
    for (const d of filtered) {
      ht  += d.sousTotalHT;
      tps += d.tps;
      tvq += d.tvq;
      ttc += d.totalTTC;
      const f = deductibleFactor(d.categorie, d.usagePct);
      if (f < 1) hasReducedFactor = true;
      htDed  += d.sousTotalHT * f;
      tpsCti += d.tps * f;
      tvqCtp += d.tvq * f;
    }
    return {
      ht, tps, tvq, ttc,
      htDed: round2(htDed),
      tpsCti: round2(tpsCti),
      tvqCtp: round2(tvqCtp),
      hasReducedFactor,
    };
  }, [filtered]);

  function round2(n: number): number { return Math.round(n * 100) / 100; }

  /** v1.0.32+ : déclaration TPS/TVQ pour la période courante (trimestre,
   *  mois ou année). Fetch /api/depenses/declaration-tva qui agrège TPS/TVQ
   *  perçues (depuis FactureLog ventes+BDT) et calcule le solde net contre
   *  les CTI/CTP des dépenses. */
  type Declaration = {
    periode: string;
    startDate: string;
    endDate: string;
    tpsPercue: number;
    tvqPercue: number;
    cti: number;
    ctp: number;
    soldeTps: number;
    soldeTvq: number;
    htDeductible: number;
    countDepenses: number;
    countFactures: number;
    parSource: {
      bdt: { tpsPercue: number; tvqPercue: number; count: number };
      vente: { tpsPercue: number; tvqPercue: number; count: number };
    };
  };
  const [declaration, setDeclaration] = useState<Declaration | null>(null);
  const [declLoading, setDeclLoading] = useState(false);

  /** Convertit le filterPeriode UI vers le format `periode` attendu par
   *  /api/depenses/declaration-tva (YYYY-Tn | YYYY-MM | YYYY). */
  const declarationPeriode = useMemo<string | null>(() => {
    const now = new Date();
    const y   = now.getFullYear();
    const m   = String(now.getMonth() + 1).padStart(2, '0');
    const t   = Math.ceil((now.getMonth() + 1) / 3);
    switch (filterPeriode) {
      case 'current-mois':  return `${y}-${m}`;
      case 'current-trim':  return `${y}-T${t}`;
      case 'current-annee': return String(y);
      case 'all':           return null;
    }
    if (/^\d{4}(-T[1-4]|-\d{2})?$/.test(filterPeriode)) return filterPeriode;
    return null;
  }, [filterPeriode]);

  useEffect(() => {
    if (!declarationPeriode || !isAdmin) {
      setDeclaration(null);
      return;
    }
    let cancelled = false;
    setDeclLoading(true);
    const url = `/api/depenses/declaration-tva?periode=${encodeURIComponent(declarationPeriode)}&includePOs=${includePOs ? '1' : '0'}`;
    fetch(url)
      .then(r => r.ok ? r.json() : null)
      .then(d => { if (!cancelled) setDeclaration(d); })
      .catch(() => { if (!cancelled) setDeclaration(null); })
      .finally(() => { if (!cancelled) setDeclLoading(false); });
    return () => { cancelled = true; };
  }, [declarationPeriode, includePOs, isAdmin]);

  /** v1.0.31+ : récap par ligne T2125 (pour rapport comptable / fin d'année).
   *  Groupe les dépenses du filtre courant par ligne T2125, somme HT déductible
   *  par groupe. Utile dans la vue imprimable et l'écran. */
  const t2125Recap = useMemo(() => {
    const map = new Map<string, { ligne: string; libelle: string; htDed: number; count: number }>();
    for (const d of filtered) {
      const f      = deductibleFactor(d.categorie, d.usagePct);
      const t      = t2125LineFor(d.categorie);
      const key    = t.ligne;
      const acc    = map.get(key) ?? { ligne: t.ligne, libelle: t.libelle, htDed: 0, count: 0 };
      acc.htDed   += d.sousTotalHT * f;
      acc.count   += 1;
      map.set(key, acc);
    }
    return Array.from(map.values())
      .map(r => ({ ...r, htDed: round2(r.htDed) }))
      .sort((a, b) => a.ligne.localeCompare(b.ligne));
  }, [filtered]);

  // ── Export CSV ──────────────────────────────────────────────────
  // v1.0.30+ : ajout colonnes NE fournisseur, Usage %, HT déductible, CTI, CTP
  // v1.0.31+ : ajout colonne T2125 ligne (pour comptable fin d'année)
  function exportCSV() {
    const header = 'ID,Date,Fournisseur,NE fournisseur,Categorie,T2125 ligne,Description,HT paye,HT deductible,TPS payee,CTI,TVQ payee,CTP,TTC,Usage%,Mode,Recu URL,Notes';
    const rows = filtered.map(d => {
      const f       = deductibleFactor(d.categorie, d.usagePct);
      const t2125   = t2125LineFor(d.categorie);
      const htDed   = (d.sousTotalHT * f).toFixed(2);
      const tpsCti  = (d.tps * f).toFixed(2);
      const tvqCtp  = (d.tvq * f).toFixed(2);
      return [
        d.id,
        d.date,
        `"${d.fournisseur.replace(/"/g, '""')}"`,
        `"${(d.numeroEntreprise ?? '').replace(/"/g, '""')}"`,
        `"${d.categorie.replace(/"/g, '""')}"`,
        t2125.ligne,
        `"${d.description.replace(/"/g, '""')}"`,
        d.sousTotalHT.toFixed(2),
        htDed,
        d.tps.toFixed(2),
        tpsCti,
        d.tvq.toFixed(2),
        tvqCtp,
        d.totalTTC.toFixed(2),
        d.usagePct ?? 100,
        d.modePaiement,
        d.recuUrl ?? '',
        `"${(d.notes ?? '').replace(/"/g, '""')}"`,
      ].join(',');
    });
    const csv = [header, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    // v1.0.28+ : nom de fichier dérivé de la période active
    const now = new Date();
    const curY = String(now.getFullYear());
    const curM = String(now.getMonth() + 1).padStart(2, '0');
    const curT = Math.ceil((now.getMonth() + 1) / 3);
    const dateLabel = filterPeriode === 'current-mois'  ? `${curY}-${curM}`
                    : filterPeriode === 'current-trim'  ? `${curY}-T${curT}`
                    : filterPeriode === 'current-annee' ? curY
                    : filterPeriode;
    a.href = url;
    a.download = `depenses-${dateLabel}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast(`${rows.length} dépenses exportées en CSV`);
  }

  // ── Save (create ou update) ────────────────────────────────────
  async function handleSave(input: any) {
    if (editTarget) {
      await updateDepense(editTarget.id, input);
    } else {
      await createDepense(input);
      // v1.1.10 — auto-switch filtre période si la dépense créée tombe
      // hors du filtre actuel (sinon elle disparaît silencieusement de la
      // liste et l'utilisateur croit qu'elle n'a pas été enregistrée).
      const newDate = String(input?.date ?? '').trim();
      if (newDate && !matchPeriode(newDate, filterPeriode)) {
        const now    = new Date();
        const curY   = String(now.getFullYear());
        const curM   = String(now.getMonth() + 1).padStart(2, '0');
        const yyyy   = newDate.slice(0, 4);
        const mm     = newDate.slice(5, 7);
        // Si la date est dans le mois courant → 'current-mois' (préserve
        // le filtre dynamique). Sinon → bascule sur la valeur YYYY-MM
        // exacte (UX cohérente avec le dropdown des options).
        const newPeriode = (yyyy === curY && mm === curM)
          ? 'current-mois'
          : `${yyyy}-${mm}`;
        setFilterPeriode(newPeriode);
        const dateFr = new Date(`${newDate}T00:00:00`).toLocaleDateString('fr-CA', { month: 'long', year: 'numeric' });
        toast(`Dépense enregistrée — filtre période bascule sur ${dateFr}`);
      }
    }
    setEditTarget(null);
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    try {
      await deleteDepense(deleteTarget.id);
      toast('Dépense archivée');
      setDeleteTarget(null);
    } catch (err: any) {
      toast(err.message, 'error');
    }
  }

  return (
    <AppShell>
      <PageHeader
        subtitle="comptabilité"
        title="Dépenses"
        helpTopic="14-depenses"
        helpHint="Compile les dépenses business hors PO (taxi, repas, abonnements, fournitures) pour déclaration TPS/TVQ trimestrielle + T2125 fin d'année. Catégorisation Revenu Canada, taxes éditables, export CSV pour comptable."
      >
        <SearchInput value={search} onChange={setSearch} placeholder="ID, fournisseur, desc…" />
        <UtilButton onClick={() => window.print()} title="Imprimer (vue compilée — utile pour comptable)">
          <PrinterIcon style={{ width: '18px', height: '18px' }} />
        </UtilButton>
        <UtilButton onClick={exportCSV} title="Exporter CSV (filtre courant)">
          <ArrowDownTrayIcon style={{ width: '18px', height: '18px' }} />
        </UtilButton>
        <AddButton onClick={() => { setEditTarget(null); setShowForm(true); }} title="Nouvelle dépense" />
      </PageHeader>

      {/* v1.0.28+ : styles spécifiques impression. Cache la sidebar, header,
          filtres et boutons d'action — garde uniquement bandeau récap +
          tableau + totaux. Format paysage suggéré dans la boîte de dialogue
          d'impression du navigateur. */}
      <style jsx global>{`
        @media print {
          @page { size: landscape; margin: 12mm; }
          body { background: white !important; }
          /* Cache la sidebar AppShell */
          aside, nav, header, .no-print { display: none !important; }
          /* Cache les contrôles interactifs */
          .print-hide { display: none !important; }
          /* Conteneur main sans fond gris */
          main { background: white !important; padding: 0 !important; }
          /* Couleur noire forcée pour lisibilité */
          * { color: #000 !important; background-color: transparent !important; box-shadow: none !important; }
          .print-show { display: block !important; }
          table { font-size: 11px !important; }
          th, td { padding: 4px 6px !important; }
          /* Totaux pied : fond gris léger pour ressortir */
          .print-totaux { background-color: #f0f0f0 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
        .print-show { display: none; }
      `}</style>

      {/* Bandeau imprimable — caché à l'écran, visible seulement à l'impression.
          v1.0.30+ : enrichi avec identité fiscale du déclarant (raison sociale,
          NEQ, n° TPS, n° TVQ — depuis /parametres/atelier section fiscal). */}
      <div className="print-show" style={{ padding: '0 0 20px', borderBottom: '2px solid #000', marginBottom: '20px' }}>
        <h1 style={{ fontSize: '24px', fontWeight: 700, margin: 0 }}>
          Compilation des dépenses
          {fiscalRaisonSociale && <> — {fiscalRaisonSociale}</>}
          {!fiscalRaisonSociale && <> — yako.cyclo</>}
        </h1>
        {(fiscalNeq || fiscalTpsNumber || fiscalTvqNumber) && (
          <p style={{ fontSize: '11px', marginTop: '6px', color: '#444' }}>
            {fiscalNeq       && <>NEQ : <strong>{fiscalNeq}</strong> · </>}
            {fiscalTpsNumber && <>TPS : <strong>{fiscalTpsNumber}</strong> · </>}
            {fiscalTvqNumber && <>TVQ : <strong>{fiscalTvqNumber}</strong></>}
          </p>
        )}
        <p style={{ fontSize: '14px', marginTop: '8px' }}>
          Période : <strong>{periodeLabel}</strong>
          {filterCat !== 'all' && <> · Catégorie : <strong>{filterCat}</strong></>}
          {includePOs && <> · <em>achats PO inclus</em></>}
        </p>
        <p style={{ fontSize: '11px', color: '#666', marginTop: '4px' }}>
          Imprimé le {new Date().toLocaleString('fr-CA', { dateStyle: 'long', timeStyle: 'short' })}
        </p>
      </div>

      <div className="p-5 md:p-[30px] md:bg-black/20 md:rounded-[50px]" style={{ minHeight: 'calc(100vh - 200px)' }}>

        {/* Filtres — cachés à l'impression */}
        <div className="flex flex-wrap items-center mb-4 print-hide" style={{ gap: '10px' }}>
          {/* v1.0.28+ : sélecteur période enrichi (mois / trimestre / année / spécifique) */}
          <select
            value={filterPeriode}
            onChange={e => setFilterPeriode(e.target.value)}
            className="input-system"
            style={{ width: 'auto', minWidth: '180px' }}
            title="Filtre période — utile pour déclarations TPS/TVQ trimestrielles"
          >
            <optgroup label="Période actuelle">
              <option value="current-mois">Mois courant</option>
              <option value="current-trim">Trimestre courant</option>
              <option value="current-annee">Année courante</option>
            </optgroup>
            <option value="all">Toutes périodes</option>
            <optgroup label="Trimestres">
              {periodeOptions.trimList.map(t => <option key={t} value={t}>{t.replace('-', ' ')}</option>)}
            </optgroup>
            <optgroup label="Mois">
              {periodeOptions.moisList.map(m => <option key={m} value={m}>{m}</option>)}
            </optgroup>
            <optgroup label="Années">
              {periodeOptions.anneeList.map(y => <option key={y} value={y}>{y}</option>)}
            </optgroup>
          </select>
          <select
            value={filterCat}
            onChange={e => setFilterCat(e.target.value)}
            className="input-system"
            style={{ width: 'auto', minWidth: '180px' }}
          >
            <option value="all">Toutes catégories</option>
            {DEPENSE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          {/* v1.0.27+ : toggle achats PO inclus dans les totaux */}
          <label
            className="flex items-center cursor-pointer"
            style={{ gap: '8px', userSelect: 'none', color: 'rgba(255,255,255,0.85)', fontSize: '13px', fontWeight: 600 }}
            title="Inclure les PO finalisés/partiels (Babac, HLC, etc.) dans les totaux. Taxes calculées au taux QC standard depuis le prix d'achat HT."
          >
            <input
              type="checkbox"
              checked={includePOs}
              onChange={e => setIncludePOs(e.target.checked)}
              className="custom-checkbox"
            />
            Inclure achats PO
            {posCompiles.length > 0 && (
              <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.55)', fontWeight: 500 }}>
                ({posCompiles.length} dispo)
              </span>
            )}
          </label>
        </div>

        {/* Loading / Empty / Table */}
        {isLoading ? (
          <LoadingSpinner />
        ) : error ? (
          <div style={{ padding: '14px 16px', borderRadius: '12px', backgroundColor: '#fef2f2', color: '#991b1b' }}>
            Erreur : {error.message}
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ padding: '40px 20px', textAlign: 'center', color: 'rgba(255,255,255,0.7)', fontSize: '14px' }}>
            Aucune dépense pour les filtres courants. Clique « + » pour en ajouter une.
          </div>
        ) : (
          <>
            <div className="overflow-x-auto" style={{ borderRadius: '12px', overflow: 'hidden' }}>
              <table className="w-full" style={{ borderCollapse: 'collapse', fontSize: '13px' }}>
                <thead className="list-header">
                  <tr>
                    <th style={{ padding: '8px 10px', textAlign: 'left' }}>ID</th>
                    <th style={{ padding: '8px 10px', textAlign: 'left' }}>Date</th>
                    <th style={{ padding: '8px 10px', textAlign: 'left' }}>Fournisseur</th>
                    <th style={{ padding: '8px 10px', textAlign: 'left' }}>Catégorie</th>
                    <th style={{ padding: '8px 10px', textAlign: 'left' }}>Description</th>
                    <th style={{ padding: '8px 10px', textAlign: 'right' }}>HT</th>
                    <th style={{ padding: '8px 10px', textAlign: 'right' }}>TPS</th>
                    <th style={{ padding: '8px 10px', textAlign: 'right' }}>TVQ</th>
                    <th style={{ padding: '8px 10px', textAlign: 'right' }}>TTC</th>
                    <th style={{ padding: '8px 10px', textAlign: 'center' }}>Mode</th>
                    <th className="print-hide" style={{ padding: '8px 10px', textAlign: 'center', width: '90px' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((d, i) => {
                    const isPO = isPOCompile(d);
                    // PO compilé : extraire le poNumber pour le lien
                    const poNumber = isPO ? d.id.replace(/^PO-/, '') : '';
                    // v1.0.29+ : séparateur mensuel — affiche une ligne header
                    // quand le mois change entre 2 entrées (tri date desc, donc
                    // le séparateur apparaît au-dessus du 1er item du mois).
                    const prevMois = i > 0 ? (filtered[i - 1].date || '').slice(0, 7) : '';
                    const curMois  = (d.date || '').slice(0, 7);
                    const showSep  = curMois && curMois !== prevMois;
                    const moisLabel = curMois
                      ? new Date(`${curMois}-15`).toLocaleDateString('fr-CA', { month: 'long', year: 'numeric' })
                      : '';
                    return (
                    <React.Fragment key={d.id}>
                    {showSep && (
                      <tr className="list-subcategory">
                        <td colSpan={11} style={{ padding: '8px 14px', fontSize: '13px', fontWeight: 700, letterSpacing: '0.05em', textTransform: 'uppercase' }}>
                          {moisLabel}
                        </td>
                      </tr>
                    )}
                    <tr className={i % 2 === 0 ? 'list-row-even' : 'list-row-odd'}>
                      <td style={{ padding: '8px 10px', fontFamily: 'monospace', fontWeight: 700 }}>
                        {isPO ? (
                          <span
                            style={{
                              display: 'inline-block',
                              padding: '2px 8px',
                              borderRadius: '999px',
                              backgroundColor: 'rgba(37,99,235,0.15)',
                              color: '#2563eb',
                              fontSize: '11px',
                              fontWeight: 700,
                              letterSpacing: '0.04em',
                            }}
                            title="PO compilé (lecture seule) — modifier via /catalogue/reception"
                          >
                            {d.id}
                          </span>
                        ) : d.id}
                      </td>
                      <td style={{ padding: '8px 10px', color: 'rgba(0,0,0,0.7)' }}>{d.date}</td>
                      <td style={{ padding: '8px 10px', fontWeight: 600 }}>{d.fournisseur}</td>
                      <td style={{ padding: '8px 10px', fontSize: '12px', color: 'rgba(0,0,0,0.6)' }}>{d.categorie}</td>
                      <td style={{ padding: '8px 10px', fontSize: '12px', color: 'rgba(0,0,0,0.7)', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={d.description}>
                        {d.description}
                      </td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{frPrix(d.sousTotalHT)}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', fontVariantNumeric: 'tabular-nums', color: 'rgba(0,0,0,0.6)' }}>{frPrix(d.tps)}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', fontVariantNumeric: 'tabular-nums', color: 'rgba(0,0,0,0.6)' }}>{frPrix(d.tvq)}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>{frPrix(d.totalTTC)}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'center', fontSize: '11px', color: 'rgba(0,0,0,0.5)', textTransform: 'uppercase' }}>{d.modePaiement}</td>
                      <td className="print-hide" style={{ padding: '8px 10px', textAlign: 'center' }}>
                        <div className="flex items-center justify-center" style={{ gap: '4px' }}>
                          {isPO ? (
                            /* PO compilé : lien direct vers /catalogue/reception (édition là-bas) */
                            <a
                              href={`/catalogue/reception?po=${encodeURIComponent(poNumber)}`}
                              title="Ouvrir le PO dans Réception (édition là-bas)"
                              style={{ color: '#2563eb', padding: '4px' }}
                            >
                              <LinkIcon style={{ width: '16px', height: '16px' }} />
                            </a>
                          ) : (
                            <>
                              {d.recuUrl && (
                                <a
                                  href={d.recuUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  title="Voir le reçu"
                                  style={{ color: 'rgba(0,0,0,0.5)', padding: '4px' }}
                                >
                                  <LinkIcon style={{ width: '16px', height: '16px' }} />
                                </a>
                              )}
                              <button
                                type="button"
                                onClick={() => { setEditTarget(d); setShowForm(true); }}
                                title="Modifier"
                                style={{ color: 'rgba(0,0,0,0.5)', background: 'transparent', border: 'none', cursor: 'pointer', padding: '4px' }}
                              >
                                <PencilSquareIcon style={{ width: '16px', height: '16px' }} />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteTarget(d)}
                                title="Archiver"
                                style={{ color: 'rgba(0,0,0,0.5)', background: 'transparent', border: 'none', cursor: 'pointer', padding: '4px' }}
                              >
                                <TrashIcon style={{ width: '16px', height: '16px' }} />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                    </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Totaux pied — print-totaux pour fond gris léger à l'impression */}
            <div className="print-totaux" style={{
              marginTop: '20px',
              padding: '16px 20px',
              backgroundColor: 'rgba(0,0,0,0.20)',
              borderRadius: '16px',
              color: '#fff',
              display: 'flex',
              flexWrap: 'wrap',
              gap: '24px',
              justifyContent: 'space-between',
            }}>
              <div>
                <div style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'rgba(255,255,255,0.6)' }}>
                  {periodeLabel}
                  {filterCat !== 'all' && ` · ${filterCat}`}
                </div>
                <div style={{ fontSize: '13px', color: 'rgba(255,255,255,0.55)', marginTop: '2px' }}>
                  {filtered.length} dépense{filtered.length > 1 ? 's' : ''}
                </div>
              </div>
              {totals.hasReducedFactor ? (
                /* v1.0.30+ : affichage enrichi quand au moins une dépense
                    a un facteur < 100% (catégorie 50% ou usagePct < 100). */
                <div className="flex flex-col" style={{ gap: '10px' }}>
                  <div className="flex flex-wrap" style={{ gap: '20px' }}>
                    <Stat label="HT payé"  value={frPrix(totals.ht)}  hint="brut sur reçus" />
                    <Stat label="HT déductible" value={frPrix(totals.htDed)} hint="net (T2125)" color="#88fa4e" />
                    <Stat label="TPS payée" value={frPrix(totals.tps)} hint="brut" />
                    <Stat label="CTI" value={frPrix(totals.tpsCti)} hint="ligne 108 FPZ-500" color="#88fa4e" />
                    <Stat label="TVQ payée" value={frPrix(totals.tvq)} hint="brut" />
                    <Stat label="CTP" value={frPrix(totals.tvqCtp)} hint="ligne 208" color="#88fa4e" />
                    <Stat label="TTC" value={frPrix(totals.ttc)} hint="cash sorti" color="#fff056" />
                  </div>
                </div>
              ) : (
                /* Cas standard : 100% déductible partout — 1 ligne classique */
                <div className="flex flex-wrap" style={{ gap: '20px' }}>
                  <Stat label="Total HT"  value={frPrix(totals.ht)}  hint="déductible" />
                  <Stat label="Total TPS" value={frPrix(totals.tps)} hint="CTI (ligne 108)" color="#88fa4e" />
                  <Stat label="Total TVQ" value={frPrix(totals.tvq)} hint="CTP (ligne 208)" color="#88fa4e" />
                  <Stat label="Total TTC" value={frPrix(totals.ttc)} hint="cash sorti" color="#fff056" />
                </div>
              )}
            </div>

            {/* v1.0.32+ : Bloc Déclaration TPS/TVQ — affiché quand la période
                est convertible en YYYY-Tn / YYYY-MM / YYYY (donc pas si filtre
                'Toutes périodes'). C'est l'objet du formulaire FPZ-500
                trimestriel Revenu Québec : TPS perçue − CTI = solde net. */}
            {declaration && (
              <div className="print-totaux" style={{
                marginTop: '16px',
                padding: '16px 20px',
                backgroundColor: 'rgba(255,240,86,0.10)',
                border: '1px solid rgba(255,240,86,0.30)',
                borderRadius: '16px',
                color: '#fff',
              }}>
                <div className="flex items-center justify-between" style={{ marginBottom: '12px' }}>
                  <h3 style={{ fontSize: '14px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#fff056' }}>
                    Déclaration TPS / TVQ — {declaration.periode}
                  </h3>
                  <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.55)' }}>
                    {declaration.countFactures} factures · {declaration.countDepenses} dépenses · {declaration.startDate} → {declaration.endDate}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2" style={{ gap: '16px' }}>

                  {/* Colonne TPS — fédéral ARC */}
                  <div style={{ backgroundColor: 'rgba(0,0,0,0.20)', padding: '12px 14px', borderRadius: '12px' }}>
                    <div style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'rgba(255,255,255,0.55)', marginBottom: '6px' }}>
                      TPS (ARC fédéral) — FPZ-500
                    </div>
                    <DeclLine label="TPS perçue (ventes + BDT facturés)" sub="ligne 105" value={declaration.tpsPercue} />
                    <DeclLine label="CTI réclamé (TPS sur dépenses × usage)" sub="ligne 108" value={-declaration.cti} />
                    <div style={{ borderTop: '1px solid rgba(255,255,255,0.20)', marginTop: '6px', paddingTop: '6px' }}>
                      <DeclLine
                        label="Solde TPS à remettre"
                        sub={declaration.soldeTps >= 0 ? 'ligne 109 — à payer' : 'remboursement à recevoir'}
                        value={declaration.soldeTps}
                        bold
                        color={declaration.soldeTps >= 0 ? '#fff056' : '#88fa4e'}
                      />
                    </div>
                  </div>

                  {/* Colonne TVQ — provincial Revenu Québec */}
                  <div style={{ backgroundColor: 'rgba(0,0,0,0.20)', padding: '12px 14px', borderRadius: '12px' }}>
                    <div style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'rgba(255,255,255,0.55)', marginBottom: '6px' }}>
                      TVQ (Revenu Québec)
                    </div>
                    <DeclLine label="TVQ perçue (ventes + BDT facturés)" sub="ligne 205" value={declaration.tvqPercue} />
                    <DeclLine label="CTP réclamé (TVQ sur dépenses × usage)" sub="ligne 208" value={-declaration.ctp} />
                    <div style={{ borderTop: '1px solid rgba(255,255,255,0.20)', marginTop: '6px', paddingTop: '6px' }}>
                      <DeclLine
                        label="Solde TVQ à remettre"
                        sub={declaration.soldeTvq >= 0 ? 'ligne 209 — à payer' : 'remboursement à recevoir'}
                        value={declaration.soldeTvq}
                        bold
                        color={declaration.soldeTvq >= 0 ? '#fff056' : '#88fa4e'}
                      />
                    </div>
                  </div>
                </div>

                <p style={{ fontSize: '10px', color: 'rgba(255,255,255,0.5)', marginTop: '10px', fontStyle: 'italic' }}>
                  ⓘ Source : ENCAISSE BDT ({declaration.parSource.bdt.count}) + VENTES ({declaration.parSource.vente.count}) du journal facturation
                  · Statut ANNULÉ exclus · CTI/CTP = TPS/TVQ × facteur (catégorie × usage)
                </p>
              </div>
            )}
            {declLoading && !declaration && (
              <div style={{ marginTop: '16px', padding: '12px', textAlign: 'center', color: 'rgba(255,255,255,0.55)', fontSize: '12px' }}>
                Calcul déclaration TPS/TVQ…
              </div>
            )}

            {/* v1.0.31+ : Récap par ligne T2125 — utile pour T2125 fin d'année.
                Affichage compact desktop / list mobile. Visible aussi à
                l'impression. */}
            {t2125Recap.length > 0 && (
              <div style={{
                marginTop: '16px',
                padding: '16px 20px',
                backgroundColor: 'rgba(0,0,0,0.10)',
                borderRadius: '16px',
              }}>
                <h3 style={{ fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'rgba(255,255,255,0.6)', marginBottom: '10px' }}>
                  Récapitulatif par ligne T2125 (T4002 Revenu Canada)
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full" style={{ borderCollapse: 'collapse', fontSize: '12px', color: '#fff' }}>
                    <thead>
                      <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.2)' }}>
                        <th style={{ padding: '6px 8px', textAlign: 'left', fontWeight: 700, color: 'rgba(255,255,255,0.7)' }}>Ligne</th>
                        <th style={{ padding: '6px 8px', textAlign: 'left', fontWeight: 700, color: 'rgba(255,255,255,0.7)' }}>Libellé T2125</th>
                        <th style={{ padding: '6px 8px', textAlign: 'right', fontWeight: 700, color: 'rgba(255,255,255,0.7)' }}>Nb</th>
                        <th style={{ padding: '6px 8px', textAlign: 'right', fontWeight: 700, color: 'rgba(255,255,255,0.7)' }}>HT déductible</th>
                      </tr>
                    </thead>
                    <tbody>
                      {t2125Recap.map(r => (
                        <tr key={r.ligne} style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
                          <td style={{ padding: '5px 8px', fontFamily: 'monospace', fontWeight: 700, color: '#fff056' }}>{r.ligne}</td>
                          <td style={{ padding: '5px 8px' }}>{r.libelle}</td>
                          <td style={{ padding: '5px 8px', textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{r.count}</td>
                          <td style={{ padding: '5px 8px', textAlign: 'right', fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>{frPrix(r.htDed)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}

      </div>

      {/* Modal CRUD */}
      <DepenseFormModal
        open={showForm}
        onClose={() => { setShowForm(false); setEditTarget(null); }}
        depense={editTarget}
        onSave={handleSave}
        suggestedFournisseurs={topFournisseurs}
      />

      {/* Confirmation suppression */}
      <ConfirmDialog
        open={!!deleteTarget}
        title="Archiver la dépense ?"
        message={deleteTarget
          ? `Archiver « ${deleteTarget.fournisseur} » du ${deleteTarget.date} (${frPrix(deleteTarget.totalTTC)}) ?\n\nLa dépense ne sera plus comptée dans les totaux mais reste dans le sheet (col M dateOut posée).`
          : ''}
        danger
        confirmLabel="Archiver"
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </AppShell>
  );
}

function DeclLine({
  label, sub, value, bold, color,
}: { label: string; sub?: string; value: number; bold?: boolean; color?: string }) {
  const formatted = (Math.abs(value)).toFixed(2).replace('.', ',') + ' $';
  const display   = value < 0 ? `− ${formatted}` : formatted;
  return (
    <div className="flex items-start justify-between" style={{ padding: '4px 0', gap: '12px' }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: '12px', color: 'rgba(255,255,255,0.85)', fontWeight: bold ? 700 : 500 }}>{label}</div>
        {sub && <div style={{ fontSize: '10px', color: 'rgba(255,255,255,0.45)', fontStyle: 'italic' }}>{sub}</div>}
      </div>
      <div style={{
        fontSize: bold ? '18px' : '13px',
        fontVariantNumeric: 'tabular-nums',
        fontWeight: bold ? 700 : 600,
        color: color ?? '#fff',
        whiteSpace: 'nowrap',
      }}>
        {display}
      </div>
    </div>
  );
}

function Stat({ label, value, hint, color }: { label: string; value: string; hint?: string; color?: string }) {
  return (
    <div>
      <div style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'rgba(255,255,255,0.6)' }}>
        {label}
      </div>
      <div style={{ fontSize: '20px', fontWeight: 700, color: color ?? '#fff', marginTop: '2px' }}>
        {value}
      </div>
      {hint && (
        <div style={{ fontSize: '11px', color: 'rgba(255,255,255,0.45)', fontStyle: 'italic' }}>
          {hint}
        </div>
      )}
    </div>
  );
}
