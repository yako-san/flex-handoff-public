'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

/**
 * Page d'accueil — redirige vers le big menu app-like (Phase 1, v7.0.33+).
 *
 * Avant : /dashboard sur desktop, /catalogue/ventes sur mobile.
 * Maintenant : /menu pour tous — c'est la home par défaut iOS app, et
 * le grid d'icônes du menu permet de naviguer vers Dashboard/Clients/
 * Ventes/Commandes/Réception/Scan rapide. La sidebar desktop reste
 * disponible pour navigation directe vers les autres pages.
 */
export default function Home() {
  const router = useRouter();
  useEffect(() => {
    router.replace('/menu');
  }, [router]);
  return null;
}
