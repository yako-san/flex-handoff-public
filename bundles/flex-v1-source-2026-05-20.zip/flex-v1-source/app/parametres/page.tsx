'use client';
import Link from 'next/link';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';
import {
  EnvelopeIcon,
  UserGroupIcon,
  BuildingStorefrontIcon,
  QrCodeIcon,
  CheckBadgeIcon,
  Cog6ToothIcon,
  CubeIcon,
  ArchiveBoxIcon,
  ArrowUpTrayIcon,
  TrashIcon,
} from '@heroicons/react/24/outline';

/** Chaque tuile = une sous-section de Paramètres. */
const TILES: {
  href: string;
  title: string;
  desc: string;
  icon: typeof Cog6ToothIcon;
}[] = [
  {
    href : '/parametres/emails',
    title: 'Modèles de messages',
    desc : 'Templates courriels (évaluation, facture, vente) + SMS rappel et suivi',
    icon : EnvelopeIcon,
  },
  {
    href : '/parametres/equipe',
    title: 'Équipe atelier',
    desc : 'Liste des mécaniciens affichée dans les dropdowns de BDT',
    icon : UserGroupIcon,
  },
  {
    href : '/parametres/atelier',
    title: 'Infos atelier',
    desc : 'Nom, adresse, téléphone, URL Google Reviews, Instagram',
    icon : BuildingStorefrontIcon,
  },
  {
    href : '/parametres/catalogue',
    title: 'Catalogue vélo',
    desc : 'Tailles disponibles dans les dropdowns (marques via VeloForm)',
    icon : CubeIcon,
  },
  {
    href : '/parametres/scans',
    title: 'Historique scans',
    desc : 'Log local des 200 derniers codes scannés + export CSV',
    icon : QrCodeIcon,
  },
  {
    href : '/parametres/sante',
    title: 'Santé APIs Google',
    desc : 'Statut détaillé Sheets / Drive / Gmail / Contacts + sync forcée',
    icon : CheckBadgeIcon,
  },
  {
    href : '/parametres/backup',
    title: 'Backup / Export',
    desc : 'Snapshots xlsx : pièces, clients, archives BDC, ventes',
    icon : ArchiveBoxIcon,
  },
  {
    href : '/parametres/import-clients',
    title: 'Import clients (CSV)',
    desc : 'Import massif depuis un CSV/xlsx, détection auto des colonnes, anti-doublons',
    icon : ArrowUpTrayIcon,
  },
  {
    href : '/parametres/admin',
    title: 'Admin — opérations destructives',
    desc : 'Supprimer un BDT par ID, consolider les fantômes',
    icon : TrashIcon,
  },
];

export default function ParametresHubPage() {
  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader subtitle="configuration de l'atelier" title="Paramètres" />

        <div className="md:bg-black/20 md:rounded-[50px] md:p-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4" style={{ padding: '8px' }}>
            {TILES.map(({ href, title, desc, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                className="flex items-start gap-4 transition-colors hover:bg-yellow-50"
                style={{
                  padding: '20px 24px',
                  borderRadius: '30px',
                  backgroundColor: 'rgba(255,255,255,0.85)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <div
                  className="flex items-center justify-center shrink-0"
                  style={{
                    width: '48px',
                    height: '48px',
                    borderRadius: '50%',
                    backgroundColor: '#fff056',
                    color: 'rgba(0,0,0,0.65)',
                  }}
                >
                  <Icon style={{ width: '24px', height: '24px' }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div style={{ fontSize: '18px', fontWeight: 700, color: 'rgba(0,0,0,0.85)', marginBottom: '4px' }}>
                    {title}
                  </div>
                  <div style={{ fontSize: '13px', color: 'rgba(0,0,0,0.55)', lineHeight: 1.4 }}>
                    {desc}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
