'use client';
import { useState, useEffect, useRef } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader, { ToolbarBlock } from '@/components/layout/PageHeader';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { toast } from '@/components/ui/Toast';
import { EMAIL_TEMPLATE_DEFAULTS as DEFAULTS } from '@/lib/emailTemplateDefaults';

type DocType = 'eval' | 'facture' | 'vente' | 'sms' | 'suivi';

/** Sections par type de document (FR + EN côte à côte). */
const SECTIONS: {
  label: string;
  suffix: string;
  rows?: number;
}[] = [
  { label: 'Sujet',   suffix: 'subject' },
  { label: 'Message', suffix: 'message', rows: 12 },
];

export default function EmailTemplatesPage() {
  const [templates, setTemplates] = useState<Record<string, string>>({});
  const [loading,   setLoading]   = useState(true);
  const [saving,    setSaving]    = useState(false);
  const [docType,   setDocType]   = useState<DocType>('eval');
  // Suit les clés modifiées depuis le dernier save pour n'envoyer
  // qu'un payload minimal (évite les timeouts Vercel sur PUT massif).
  const dirtyKeys = useRef<Set<string>>(new Set());
  const initialTemplates = useRef<Record<string, string>>({});

  useEffect(() => {
    fetch('/api/parametres/emails')
      .then(r => r.json())
      .then(data => {
        setTemplates(data);
        initialTemplates.current = { ...data };
        setLoading(false);
      })
      .catch(() => {
        setTemplates({ ...DEFAULTS });
        initialTemplates.current = { ...DEFAULTS };
        setLoading(false);
      });
  }, []);

  function val(key: string): string {
    return templates[key] ?? DEFAULTS[key] ?? '';
  }

  function set(key: string, value: string) {
    setTemplates(prev => ({ ...prev, [key]: value }));
    // Marque la clé dirty si elle diffère de la valeur initiale.
    if (initialTemplates.current[key] !== value) {
      dirtyKeys.current.add(key);
    } else {
      dirtyKeys.current.delete(key);
    }
  }

  async function handleSave() {
    // Ne pas envoyer si rien n'a changé
    if (dirtyKeys.current.size === 0) {
      toast('Aucun changement à sauvegarder');
      return;
    }
    // Construit un payload minimal : seulement les clés modifiées
    const payload: Record<string, string> = {};
    for (const k of dirtyKeys.current) payload[k] = templates[k] ?? '';

    setSaving(true);
    try {
      const res = await fetch('/api/parametres/emails', {
        method : 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify(payload),
      });
      if (!res.ok) {
        // Session expirée → rediriger vers /login en conservant le retour
        if (res.status === 401) {
          toast('Session expirée — redirection vers la connexion', 'error');
          setTimeout(() => {
            window.location.href = `/login?callbackUrl=${encodeURIComponent(window.location.pathname)}`;
          }, 1200);
          return;
        }
        let msg = `${res.status} ${res.statusText || 'Erreur'}`;
        try {
          const body = await res.json();
          if (body?.error) msg = body.error;
        } catch { /* body non-JSON — on garde le fallback */ }
        throw new Error(msg);
      }
      const n = dirtyKeys.current.size;
      // Reset dirty + nouveau baseline
      initialTemplates.current = { ...templates };
      dirtyKeys.current.clear();
      toast(`${n} template${n > 1 ? 's' : ''} sauvegardé${n > 1 ? 's' : ''}`);
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  }

  /** Clés du tab courant qui doivent être restaurées depuis DEFAULTS. */
  function keysForDocType(dt: DocType): string[] {
    switch (dt) {
      case 'eval':    return ['eval_subject_fr', 'eval_subject_en', 'eval_message_fr', 'eval_message_en'];
      case 'facture': return ['facture_subject_fr', 'facture_subject_en', 'facture_message_fr', 'facture_message_en'];
      case 'vente':   return ['vente_subject_fr', 'vente_subject_en', 'vente_message_fr', 'vente_message_en'];
      case 'sms':     return ['sms_rappel_fr', 'sms_rappel_en'];
      case 'suivi':   return ['courriel_suivi_subject_fr', 'courriel_suivi_subject_en', 'courriel_suivi_fr', 'courriel_suivi_en'];
    }
  }

  async function handleResetTab() {
    const keys = keysForDocType(docType);
    const labels: Record<DocType, string> = {
      eval: 'Évaluation', facture: 'Facture', vente: 'Vente',
      sms: 'SMS rappel', suivi: 'Courriel suivi',
    };
    const ok = window.confirm(
      `Réinitialiser le modèle « ${labels[docType]} » aux valeurs par défaut ?\n\n` +
      `Les modifications custom (FR + EN) seront écrasées et sauvegardées immédiatement.`
    );
    if (!ok) return;

    // Restaure les valeurs DEFAULTS dans le state + payload pour PUT
    const payload: Record<string, string> = {};
    for (const k of keys) payload[k] = DEFAULTS[k] ?? '';

    setSaving(true);
    try {
      const res = await fetch('/api/parametres/emails', {
        method : 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify(payload),
      });
      if (!res.ok) {
        let msg = `${res.status} ${res.statusText || 'Erreur'}`;
        try { const b = await res.json(); if (b?.error) msg = b.error; } catch {}
        throw new Error(msg);
      }
      // Update state local + reset dirty pour ces clés
      setTemplates(prev => ({ ...prev, ...payload }));
      initialTemplates.current = { ...initialTemplates.current, ...payload };
      for (const k of keys) dirtyKeys.current.delete(k);
      toast(`Modèle « ${labels[docType]} » réinitialisé`);
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  }

  const tabStyle = (active: boolean) => ({
    padding: '0 14px',
    height: '32px',
    borderRadius: '32px',
    fontSize: '13px',
    fontWeight: 700 as const,
    letterSpacing: '0.02em',
    backgroundColor: active ? '#fff056' : 'rgba(255,255,255,0.3)',
    color: 'rgba(0,0,0,0.5)',
    border: 'none' as const,
    cursor: 'pointer' as const,
  });

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader subtitle="paramètres" title="Modèles de messages">
          <ToolbarBlock>
            <button onClick={() => setDocType('eval')} className="flex items-center whitespace-nowrap" style={tabStyle(docType === 'eval')}>Évaluation</button>
            <button onClick={() => setDocType('facture')} className="flex items-center whitespace-nowrap" style={tabStyle(docType === 'facture')}>Facture</button>
            <button onClick={() => setDocType('vente')} className="flex items-center whitespace-nowrap" style={tabStyle(docType === 'vente')}>Vente</button>
            <button onClick={() => setDocType('sms')} className="flex items-center whitespace-nowrap" style={tabStyle(docType === 'sms')}>SMS rappel</button>
            <button onClick={() => setDocType('suivi')} className="flex items-center whitespace-nowrap" style={tabStyle(docType === 'suivi')}>Courriel suivi</button>
          </ToolbarBlock>
        </PageHeader>

        {loading && <LoadingSpinner className="py-20" />}

        {!loading && (
          <div className="md:bg-black/20 md:rounded-[50px] md:p-[30px]">
            <div className="flex flex-col" style={{ gap: '24px' }}>

              {/* Templates (eval/facture/vente) — exclut sms rappel + suivi */}
              {docType !== 'sms' && docType !== 'suivi' && (
              <>
              <div className="text-sm" style={{ color: 'rgba(255,255,255,0.6)', marginBottom: '8px' }}>
                Placeholders : <code>{'{{prenom}}'}</code> <code>{'{{clientNom}}'}</code>
                {docType !== 'vente' && <> <code>{'{{veloDesc}}'}</code></>}
                {' '}<code>{'{{id}}'}</code> <code>{'{{date}}'}</code> <code>{'{{noteClient}}'}</code>
                {docType !== 'vente' && <> <code>{'{{services}}'}</code></>}
                {' '}<code>{'{{pieces}}'}</code>
                <span style={{ color: 'rgba(255,255,255,0.4)', marginLeft: '8px' }}>
                  ({'{{services}}'} et {'{{pieces}}'} sur leur propre ligne → rendus en liste)
                </span>
              </div>

              {SECTIONS.map(sec => {
                const keyFR = `${docType}_${sec.suffix}_fr`;
                const keyEN = `${docType}_${sec.suffix}_en`;
                const isSubject = sec.suffix === 'subject';
                return (
                  <div key={sec.suffix}>
                    <label className="text-sm font-bold uppercase" style={{ color: 'rgba(255,255,255,0.7)', marginBottom: '8px', display: 'block' }}>
                      {sec.label}
                    </label>
                    <div className="grid grid-cols-2 gap-4" style={{ maxWidth: isSubject ? '600pt' : '1300pt' }}>
                      <div>
                        <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>FR</span>
                        {isSubject ? (
                          <input
                            type="text"
                            value={val(keyFR)}
                            onChange={e => set(keyFR, e.target.value)}
                            className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                            style={{ backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', borderRadius: '12px', border: 'none', height: '36px', width: '300pt' }}
                          />
                        ) : (
                          <textarea
                            value={val(keyFR)}
                            onChange={e => set(keyFR, e.target.value)}
                            rows={sec.rows ?? 1}
                            className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                            style={{ backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', borderRadius: '12px', border: 'none', resize: 'vertical', width: '650pt', maxWidth: '100%' }}
                          />
                        )}
                      </div>
                      <div>
                        <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>EN</span>
                        {isSubject ? (
                          <input
                            type="text"
                            value={val(keyEN)}
                            onChange={e => set(keyEN, e.target.value)}
                            className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                            style={{ backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', borderRadius: '12px', border: 'none', height: '36px', width: '300pt' }}
                          />
                        ) : (
                          <textarea
                            value={val(keyEN)}
                            onChange={e => set(keyEN, e.target.value)}
                            rows={sec.rows ?? 1}
                            className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                            style={{ backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', borderRadius: '12px', border: 'none', resize: 'vertical', width: '650pt', maxWidth: '100%' }}
                          />
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}

              </>
              )}

              {/* SMS rappel (onglet dédié) */}
              {docType === 'sms' && (
              <div>
                <div className="text-sm" style={{ color: 'rgba(255,255,255,0.6)', marginBottom: '8px' }}>
                  Template du rappel SMS envoyé via le lien Dashboard / Inventaire quand un BDT passe en FINI / FACTURÉ / LIVRÉ.
                  <br />
                  Placeholders : <code>{'{{prenom}}'}</code> <code>{'{{veloDesc}}'}</code> <code>{'{{id}}'}</code> <code>{'{{montantFacture}}'}</code>
                </div>
                <div className="grid grid-cols-2 gap-4" style={{ maxWidth: '1300pt' }}>
                  <div>
                    <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>FR</span>
                    <textarea
                      value={val('sms_rappel_fr')}
                      onChange={e => set('sms_rappel_fr', e.target.value)}
                      rows={10}
                      className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                      style={{ backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', borderRadius: '12px', border: 'none', resize: 'vertical', width: '650pt', maxWidth: '100%' }}
                    />
                  </div>
                  <div>
                    <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>EN</span>
                    <textarea
                      value={val('sms_rappel_en')}
                      onChange={e => set('sms_rappel_en', e.target.value)}
                      rows={10}
                      className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                      style={{ backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', borderRadius: '12px', border: 'none', resize: 'vertical', width: '650pt', maxWidth: '100%' }}
                    />
                  </div>
                </div>
              </div>
              )}

              {/* Courriel suivi (onglet dédié) — brouillon Gmail post-archivage (2j) */}
              {docType === 'suivi' && (
              <div>
                <div className="text-sm" style={{ color: 'rgba(255,255,255,0.6)', marginBottom: '8px' }}>
                  Titre (objet du courriel) + corps du brouillon Gmail généré
                  depuis le bloc « Suivi » du Dashboard (2 jours après l'archivage).
                  <br />
                  Placeholders : <code>{'{{prenom}}'}</code> <code>{'{{veloDesc}}'}</code> <code>{'{{id}}'}</code>
                </div>
                <div className="grid grid-cols-2 gap-4" style={{ maxWidth: '1300pt' }}>
                  <div className="flex flex-col" style={{ gap: '8px' }}>
                    <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>FR — objet</span>
                    <input
                      type="text"
                      value={val('courriel_suivi_subject_fr')}
                      onChange={e => set('courriel_suivi_subject_fr', e.target.value)}
                      placeholder="ex. Suivi — Cyclo Flex (BDT {{id}})"
                      className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                      style={{ backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', borderRadius: '12px', border: 'none', width: '650pt', maxWidth: '100%' }}
                    />
                    <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>FR — corps</span>
                    <textarea
                      value={val('courriel_suivi_fr') || val('sms_suivi_fr')}
                      onChange={e => set('courriel_suivi_fr', e.target.value)}
                      rows={12}
                      className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                      style={{ backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', borderRadius: '12px', border: 'none', resize: 'vertical', width: '650pt', maxWidth: '100%' }}
                    />
                  </div>
                  <div className="flex flex-col" style={{ gap: '8px' }}>
                    <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>EN — subject</span>
                    <input
                      type="text"
                      value={val('courriel_suivi_subject_en')}
                      onChange={e => set('courriel_suivi_subject_en', e.target.value)}
                      placeholder="ex. Follow-up — Cyclo Flex (BDT {{id}})"
                      className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                      style={{ backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', borderRadius: '12px', border: 'none', width: '650pt', maxWidth: '100%' }}
                    />
                    <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>EN — body</span>
                    <textarea
                      value={val('courriel_suivi_en') || val('sms_suivi_en')}
                      onChange={e => set('courriel_suivi_en', e.target.value)}
                      rows={12}
                      className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                      style={{ backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', borderRadius: '12px', border: 'none', resize: 'vertical', width: '650pt', maxWidth: '100%' }}
                    />
                  </div>
                </div>
              </div>
              )}

            </div>
          </div>
        )}

        {/* Boutons Réinitialiser + Sauvegarder en bas */}
        {!loading && (
          <div className="flex justify-between items-center" style={{ paddingTop: '24px', gap: '12px' }}>
            <button
              type="button"
              onClick={handleResetTab}
              disabled={saving}
              className="btn-secondary"
              title="Restaure les valeurs par défaut (FR + EN) pour cet onglet — sauvegarde immédiate"
            >
              ↺ Réinitialiser ce modèle
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="btn-primary"
            >
              {saving ? 'Sauvegarde…' : 'Sauvegarder'}
            </button>
          </div>
        )}
      </div>
    </AppShell>
  );
}
