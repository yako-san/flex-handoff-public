'use client';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';
import { ArrowDownTrayIcon, ArchiveBoxIcon } from '@heroicons/react/24/outline';

const EXPORTS: { href: string; label: string; desc: string }[] = [
  { href: '/api/catalogue/export',     label: 'Pièces (catalogue)',       desc: 'Toutes les pièces avec SKU, EAN, prix, stock, catégorie' },
  { href: '/api/clients/export',       label: 'Clients',                  desc: 'Nom, téléphone, courriel, pref comm, langue, BDT, vélos' },
  { href: '/api/archives/export',      label: 'Archives (BDC)',           desc: 'Tous les BDC archivés — ID, dates, vélo, client, totaux' },
  { href: '/api/ventes/export',        label: 'Ventes directes',          desc: 'Historique ventes pièces (non facturées + facturées)' },
  { href: '/api/commande/export',      label: 'Commandes en attente',     desc: 'Pièces flaggées $ à commander' },
];

export default function BackupPage() {
  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader subtitle="paramètres" title="Backup / Export" />

        <div className="md:bg-black/20 md:rounded-[50px] md:p-[30px]">
          <p className="text-sm" style={{ color: 'rgba(255,255,255,0.65)', marginBottom: '20px' }}>
            Téléchargement de l'état courant des données au format xlsx. À faire
            régulièrement pour garder un snapshot en dehors de Google Sheets.
            Chaque clic déclenche une génération fraîche (pas de cache).
          </p>

          <div className="flex flex-col" style={{ gap: '10px' }}>
            {EXPORTS.map(({ href, label, desc }) => (
              <a
                key={href}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start gap-4 transition-colors hover:bg-yellow-50"
                style={{
                  padding: '16px 20px',
                  borderRadius: '16px',
                  backgroundColor: 'rgba(255,255,255,0.85)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <div
                  className="flex items-center justify-center shrink-0"
                  style={{
                    width: '40px', height: '40px', borderRadius: '50%',
                    backgroundColor: '#fff056', color: 'rgba(0,0,0,0.65)',
                  }}
                >
                  <ArchiveBoxIcon style={{ width: '20px', height: '20px' }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div style={{ fontSize: '15px', fontWeight: 700, color: 'rgba(0,0,0,0.85)', marginBottom: '2px' }}>
                    {label}
                  </div>
                  <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.55)' }}>
                    {desc}
                  </div>
                </div>
                <ArrowDownTrayIcon style={{ width: '18px', height: '18px', color: 'rgba(0,0,0,0.55)', flexShrink: 0, marginTop: '6px' }} />
              </a>
            ))}
          </div>

          <div style={{ marginTop: '24px', padding: '14px 16px', borderRadius: '12px', backgroundColor: 'rgba(255,240,86,0.15)', border: '1px solid rgba(255,240,86,0.30)' }}>
            <div style={{ fontSize: '12px', fontWeight: 700, color: 'rgba(0,0,0,0.75)', marginBottom: '4px' }}>
              💡 Conseil
            </div>
            <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.65)' }}>
              Le sheet Google est déjà sauvegardé automatiquement par Google Drive.
              Ces exports sont utiles pour un archivage externe (email, disque local),
              pour un partage ponctuel (comptable), ou comme snapshot avant une
              modification risquée.
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
