'use client';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';
import ParametresNav from '@/components/layout/ParametresNav';
import { useIsAdmin } from '@/hooks/useIsAdmin';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import Link from 'next/link';
import { LockClosedIcon } from '@heroicons/react/24/outline';

/**
 * Layout protégé pour toute la section /parametres/*.
 *
 * Seuls les utilisateurs dans `admin_emails` (sheet _EMAIL_TEMPLATES_)
 * peuvent voir les sous-pages. yako.cyclo@gmail.com est toujours admin
 * par fail-safe (voir useIsAdmin). Les autres voient un écran de refus
 * d'accès avec le courriel connecté pour contexte.
 */
export default function ParametresLayout({ children }: { children: React.ReactNode }) {
  const { isAdmin, loading, userEmail } = useIsAdmin();

  if (loading) {
    return (
      <AppShell>
        <div className="p-5 md:pt-[50px]">
          <LoadingSpinner className="py-20" />
        </div>
      </AppShell>
    );
  }

  if (!isAdmin) {
    return (
      <AppShell>
        <div className="p-5 md:pt-[50px]">
          <PageHeader subtitle="accès refusé" title="Paramètres" />
          <div className="md:bg-black/20 md:rounded-[50px] md:p-[30px]">
            <div
              className="flex items-start gap-4"
              style={{
                padding: '20px 24px',
                borderRadius: '30px',
                backgroundColor: 'rgba(239,68,68,0.12)',
                border: '1.5px solid rgba(239,68,68,0.30)',
              }}
            >
              <LockClosedIcon style={{ width: '32px', height: '32px', color: '#b91c1c', flexShrink: 0 }} />
              <div className="flex-1">
                <div style={{ fontSize: '18px', fontWeight: 700, color: '#b91c1c', marginBottom: '6px' }}>
                  Accès réservé aux administrateurs
                </div>
                <p style={{ fontSize: '14px', color: 'rgba(0,0,0,0.7)', marginBottom: '8px' }}>
                  Tu es connecté en tant que <strong>{userEmail || 'anonyme'}</strong>.
                  Cette section est réservée aux comptes désignés comme admin.
                </p>
                <p style={{ fontSize: '13px', color: 'rgba(0,0,0,0.55)' }}>
                  Demande à un administrateur de t'ajouter via{' '}
                  <em>Paramètres → Équipe atelier → Administrateurs</em>.
                </p>
                <Link href="/dashboard" className="btn-primary inline-flex items-center" style={{ marginTop: '14px' }}>
                  Retour au Dashboard
                </Link>
              </div>
            </div>
          </div>
        </div>
      </AppShell>
    );
  }

  return (
    <>
      {children}
      <ParametresNav />
    </>
  );
}
