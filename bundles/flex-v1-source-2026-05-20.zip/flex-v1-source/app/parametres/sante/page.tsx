'use client';
import { useEffect, useState } from 'react';
import { signOut } from 'next-auth/react';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';
import { toast } from '@/components/ui/Toast';
import { ArrowPathIcon } from '@heroicons/react/24/outline';

type Status = 'ok' | 'expired' | 'error' | 'loading';
type Report = {
  sheets  : Status;
  drive   : Status;
  gmail   : Status;
  contacts: Status;
  details?: Record<string, string>;
};

const SERVICES: { key: keyof Omit<Report, 'details'>; label: string; desc: string }[] = [
  { key: 'sheets',   label: 'Sheets',   desc: 'Accès au sheet de données (service account)' },
  { key: 'drive',    label: 'Drive',    desc: 'Upload/lecture photos clients (OAuth user)' },
  { key: 'gmail',    label: 'Gmail',    desc: 'Création brouillons facture/évaluation (OAuth user)' },
  { key: 'contacts', label: 'Contacts', desc: 'Sync carnet Google (OAuth user)' },
];

function colorFor(s: Status): string {
  if (s === 'ok')      return '#22c55e';
  if (s === 'loading') return 'rgba(0,0,0,0.3)';
  if (s === 'expired') return '#ef4444';
  return '#f59e0b';
}

export default function SantePage() {
  const [report,  setReport]  = useState<Report>({ sheets: 'loading', drive: 'loading', gmail: 'loading', contacts: 'loading' });
  const [syncing, setSyncing] = useState(false);
  const [checking, setChecking] = useState(false);

  async function fetchHealth() {
    setChecking(true);
    try {
      const res  = await fetch('/api/health/google');
      const data = await res.json();
      setReport({
        sheets  : data.sheets   ?? 'error',
        drive   : data.drive    ?? 'error',
        gmail   : data.gmail    ?? 'error',
        contacts: data.contacts ?? 'error',
        details : data.details,
      });
    } catch {
      setReport({ sheets: 'error', drive: 'error', gmail: 'error', contacts: 'error' });
    } finally {
      setChecking(false);
    }
  }

  async function handleForceSync() {
    setSyncing(true);
    try {
      const res  = await fetch('/api/sync?force=1', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      toast(`Sync forcée — ${(data.invalidated ?? []).length} caches vidés`);
    } catch (err: any) {
      toast(err.message || 'Erreur sync', 'error');
    } finally {
      setSyncing(false);
    }
  }

  useEffect(() => { fetchHealth(); }, []);

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader subtitle="paramètres" title="Santé APIs Google" />

        <div className="md:bg-black/20 md:rounded-[50px] md:p-[30px]">
          <p className="text-sm" style={{ color: 'rgba(255,255,255,0.65)', marginBottom: '16px' }}>
            Statut des 4 APIs Google utilisées par l'app. Sheets utilise un service
            account (config serveur), les 3 autres utilisent ton OAuth personnel.
          </p>

          <div className="flex items-center gap-3" style={{ marginBottom: '20px' }}>
            <button
              type="button"
              onClick={fetchHealth}
              disabled={checking}
              className="flex items-center gap-2"
              style={{
                padding: '8px 16px', borderRadius: '999px',
                backgroundColor: 'rgba(255,255,255,0.85)', color: 'rgba(0,0,0,0.7)',
                border: 'none', fontSize: '13px', fontWeight: 700, cursor: checking ? 'wait' : 'pointer',
              }}
            >
              <ArrowPathIcon className={checking ? 'animate-spin' : ''} style={{ width: '14px', height: '14px' }} />
              {checking ? 'Vérification…' : 'Re-vérifier maintenant'}
            </button>
            <button
              type="button"
              onClick={handleForceSync}
              disabled={syncing}
              className="flex items-center gap-2"
              style={{
                padding: '8px 16px', borderRadius: '999px',
                backgroundColor: '#fff056', color: '#000',
                border: 'none', fontSize: '13px', fontWeight: 700, cursor: syncing ? 'wait' : 'pointer',
              }}
            >
              {syncing ? 'Sync en cours…' : 'Forcer sync complète (vide cache serveur)'}
            </button>
          </div>

          <div className="flex flex-col" style={{ gap: '10px' }}>
            {SERVICES.map(({ key, label, desc }) => {
              const status = report[key];
              const detail = report.details?.[key];
              const isExpired = status === 'expired';
              return (
                <div
                  key={key}
                  className="flex items-center gap-4"
                  style={{
                    padding: '14px 18px',
                    borderRadius: '16px',
                    backgroundColor: 'rgba(255,255,255,0.85)',
                  }}
                >
                  <span aria-hidden style={{
                    width: '18px', height: '18px', borderRadius: '50%',
                    backgroundColor: colorFor(status),
                    boxShadow: status === 'ok' ? '0 0 0 3px rgba(34,197,94,0.20)' : undefined,
                  }} />
                  <div className="flex-1 min-w-0">
                    <div style={{ fontSize: '16px', fontWeight: 700, color: 'rgba(0,0,0,0.85)' }}>{label}</div>
                    <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.55)' }}>{desc}</div>
                    {detail && (
                      <div style={{ fontSize: '11px', color: '#b91c1c', fontStyle: 'italic', marginTop: '4px' }}>
                        {detail}
                      </div>
                    )}
                  </div>
                  <span
                    className="inline-flex items-center whitespace-nowrap shrink-0"
                    style={{
                      padding: '4px 12px', borderRadius: '999px',
                      backgroundColor: 'rgba(0,0,0,0.08)',
                      color: 'rgba(0,0,0,0.65)',
                      fontSize: '11px', fontWeight: 700,
                      letterSpacing: '0.04em', textTransform: 'uppercase',
                    }}
                  >
                    {status}
                  </span>
                  {isExpired && key !== 'sheets' && (
                    <button
                      type="button"
                      onClick={() => signOut({ callbackUrl: '/login' })}
                      className="shrink-0"
                      style={{
                        padding: '6px 12px', borderRadius: '999px',
                        backgroundColor: '#b91c1c', color: '#fff',
                        border: 'none', fontSize: '11px', fontWeight: 700,
                        letterSpacing: '0.04em', textTransform: 'uppercase',
                        cursor: 'pointer',
                      }}
                    >
                      Reconnecter
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
