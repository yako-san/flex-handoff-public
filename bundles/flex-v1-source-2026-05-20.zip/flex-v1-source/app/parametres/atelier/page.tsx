'use client';
import { useEffect, useState } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { toast } from '@/components/ui/Toast';
import { useEmailTemplates } from '@/hooks/useEmailTemplates';

type FieldKind = 'text' | 'email' | 'url' | 'select';
interface Field {
  key        : string;
  label      : string;
  placeholder: string;
  type?      : FieldKind | 'number';
  options?   : string[];
  section    : 'atelier' | 'client' | 'stock' | 'fiscal';
  hint?      : string;
}

const FIELDS: Field[] = [
  { section: 'atelier', key: 'atelier_nom',       label: 'Nom de l\'atelier',   placeholder: 'Cyclo Flex' },
  { section: 'atelier', key: 'atelier_adresse',   label: 'Adresse',             placeholder: '4109, St-Denis, Montréal' },
  { section: 'atelier', key: 'atelier_tel',       label: 'Téléphone',           placeholder: '514 995-3445' },
  { section: 'atelier', key: 'atelier_email',     label: 'Courriel',            placeholder: 'yako.cyclo@gmail.com', type: 'email' },
  { section: 'atelier', key: 'atelier_reviews',   label: 'URL Google Reviews',  placeholder: 'https://www.google.com/search?q=yako.cyclo', type: 'url' },
  { section: 'atelier', key: 'atelier_instagram', label: 'URL Instagram',       placeholder: 'https://www.instagram.com/…', type: 'url' },
  // v1.0.30+ : identité fiscale du déclarant — utilisée dans la page
  // /depenses (bandeau imprimable, futurs exports déclaration TPS/TVQ).
  { section: 'fiscal', key: 'fiscal_raison_sociale', label: 'Raison sociale légale',
    placeholder: 'Yako Cyclo',
    hint: 'Nom légal de l\'entreprise (peut différer du nom commercial). Apparaît sur les rapports fiscaux.' },
  { section: 'fiscal', key: 'fiscal_neq',            label: 'NEQ',
    placeholder: '1234567890',
    hint: 'Numéro d\'entreprise du Québec (10 chiffres). Obligatoire pour facturer + auditer Revenu Québec.' },
  { section: 'fiscal', key: 'fiscal_tps_number',     label: 'Numéro TPS (ARC)',
    placeholder: '123456789 RT0001',
    hint: 'Format ARC : 9 chiffres + suffixe RT0001. Obligatoire pour réclamer le CTI.' },
  { section: 'fiscal', key: 'fiscal_tvq_number',     label: 'Numéro TVQ (Revenu Québec)',
    placeholder: '1234567890 TQ0001',
    hint: 'Format RQ : 10 chiffres + suffixe TQ0001. Obligatoire pour réclamer le CTP.' },
  { section: 'client', key: 'client_default_commpref', label: 'Pref. comm défaut',   placeholder: 'Courriel,Texto', type: 'select',
    options: ['Courriel,Texto', 'Texto,Courriel', 'Courriel', 'Texto', 'Téléphone'] },
  { section: 'client', key: 'client_default_lang',    label: 'Langue défaut',       placeholder: 'FR', type: 'select',
    options: ['FR', 'EN'] },
  { section: 'stock', key: 'stock_min_default', label: 'Seuil alerte stock', placeholder: '2', type: 'number',
    hint: 'Une pièce avec stock ≤ ce seuil (et > 0) apparaît dans "Stock à commander" du Dashboard. 0 = désactivé.' },
];

export default function AtelierPage() {
  const { tpl, mutate, isLoading } = useEmailTemplates();
  const [values, setValues] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (isLoading) return;
    const init: Record<string, string> = {};
    for (const f of FIELDS) init[f.key] = tpl(f.key);
    setValues(init);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoading]);

  function set(key: string, v: string) {
    setValues(prev => ({ ...prev, [key]: v }));
  }

  async function handleSave() {
    setSaving(true);
    try {
      const res = await fetch('/api/parametres/emails', {
        method : 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify(values),
      });
      if (!res.ok) {
        let msg = `${res.status} ${res.statusText || 'Erreur'}`;
        try { const b = await res.json(); if (b?.error) msg = b.error; } catch {}
        throw new Error(msg);
      }
      await mutate();
      toast('Infos atelier sauvegardées');
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  }

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader subtitle="paramètres" title="Infos atelier" />

        {isLoading && <LoadingSpinner className="py-20" />}

        {!isLoading && (
          <div className="md:bg-black/20 md:rounded-[50px] md:p-[30px]">
            <p className="text-sm" style={{ color: 'rgba(255,255,255,0.65)', marginBottom: '16px' }}>
              Ces infos alimentent les signatures, les PDFs d'évaluation / facture,
              les liens Google Reviews / Instagram dans les templates SMS, et les
              valeurs par défaut pour les nouveaux clients.
            </p>

            {(['atelier', 'fiscal', 'client', 'stock'] as const).map(section => (
              <div key={section} style={{ marginBottom: '24px' }}>
                <h3 className="legende" style={{ color: 'rgba(255,255,255,0.7)', marginBottom: '10px', textTransform: 'uppercase', fontSize: '11px', letterSpacing: '0.1em' }}>
                  {section === 'atelier' ? 'Atelier'
                    : section === 'fiscal'  ? 'Identité fiscale (TPS / TVQ / NEQ)'
                    : section === 'client' ? 'Nouveau client — valeurs par défaut'
                    : 'Stock — seuils d\'alerte'}
                </h3>
                <div className="flex flex-col" style={{ gap: '14px', maxWidth: '600pt' }}>
                  {FIELDS.filter(f => f.section === section).map(f => (
                    <div key={f.key}>
                      <label className="text-xs font-bold uppercase" style={{ color: 'rgba(255,255,255,0.5)', display: 'block', marginBottom: '4px', letterSpacing: '0.04em' }}>
                        {f.label}
                      </label>
                      {f.type === 'select' ? (
                        <select
                          value={values[f.key] ?? f.placeholder}
                          onChange={e => set(f.key, e.target.value)}
                          className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                          style={{
                            width: '100%', backgroundColor: 'rgba(255,255,255,0.85)',
                            color: '#222', borderRadius: '12px', border: 'none', height: '40px',
                          }}
                        >
                          {f.options?.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      ) : (
                        <input
                          type={f.type || 'text'}
                          value={values[f.key] ?? ''}
                          onChange={e => set(f.key, e.target.value)}
                          placeholder={f.placeholder}
                          className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                          style={{
                            width: '100%', backgroundColor: 'rgba(255,255,255,0.85)',
                            color: '#222', borderRadius: '12px', border: 'none', height: '40px',
                          }}
                        />
                      )}
                      {f.hint && (
                        <p className="text-xs" style={{ color: 'rgba(255,255,255,0.5)', marginTop: '4px', fontStyle: 'italic' }}>
                          {f.hint}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}

            <div className="flex justify-end" style={{ paddingTop: '8px' }}>
              <button type="button" onClick={handleSave} disabled={saving} className="btn-primary">
                {saving ? 'Sauvegarde…' : 'Sauvegarder'}
              </button>
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
