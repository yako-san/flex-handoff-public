'use client';
/**
 * Page /parametres/admin — opérations destructives (admin only).
 *
 * Protégée par le layout /parametres (useIsAdmin).
 *
 * Actions disponibles :
 *  - Supprimer un BDT par ID (actif ou archivé, auto-détection)
 *  - Consolider les BDT fantômes (référencés dans CLIENTS mais absents
 *    du sheet BDC/INVENTAIRE/ARCHIVES)
 */
import { useState } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';
import { toast } from '@/components/ui/Toast';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import { TrashIcon, WrenchIcon, ArrowPathIcon, ArchiveBoxIcon, DocumentTextIcon } from '@heroicons/react/24/outline';

interface Snapshot {
  backupRow : number;
  timestamp : string;
  action    : string;
  bdcId     : string;
  clientNom : string;
  veloDesc  : string;
  itemCount : number;
  note      : string;
}

export default function AdminPage() {
  const [bdtId, setBdtId]       = useState('');
  const [deleting, setDeleting] = useState(false);
  const [consolidating, setConsolidating] = useState(false);
  const [log, setLog]           = useState<string[]>([]);

  // Restore state
  const [restoreId, setRestoreId] = useState('');
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [loadingSnapshots, setLoadingSnapshots] = useState(false);
  const [restoring, setRestoring] = useState(false);

  // Archive forcée
  const [forceArchiveId, setForceArchiveId] = useState('');
  const [forceArchiving, setForceArchiving] = useState(false);

  // Restore : réassignation client optionnelle
  const [overrideClient, setOverrideClient] = useState('');

  // Backfill notes Square
  const [backfilling, setBackfilling] = useState(false);
  // Backfill Calendar
  const [backfillingCal, setBackfillingCal] = useState(false);

  // Confirmation centralisée — remplace les window.confirm() natifs
  // (style sombre OS) par notre Modal blanc.
  const [confirmDialog, setConfirmDialog] = useState<{
    title  : string;
    message: string;
    danger ?: boolean;
    confirmLabel ?: string;
    onConfirm: () => void;
  } | null>(null);
  function ask(opts: {
    title: string; message: string; danger?: boolean; confirmLabel?: string;
    onConfirm: () => void;
  }) { setConfirmDialog(opts); }

  function addLog(msg: string) {
    setLog(prev => [...prev, `${new Date().toLocaleTimeString('fr-CA')} — ${msg}`]);
  }

  async function doDeleteBDT(id: string) {
    setDeleting(true);
    try {
      const res  = await fetch(`/api/bdc/${id}`, { method: 'DELETE' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || `${res.status}`);
      toast(`BDT ${id} supprimé (${data.mode ?? 'ok'})`);
      addLog(`✓ Supprimé ${id} (${data.mode ?? 'ok'})`);
      setBdtId('');
    } catch (err: any) {
      toast(`Échec : ${err.message}`, 'error');
      addLog(`✗ Échec ${id} : ${err.message}`);
    } finally {
      setDeleting(false);
    }
  }
  function handleDeleteBDT() {
    const id = bdtId.trim();
    if (!id) { toast('Entre un ID de BDT', 'error'); return; }
    ask({
      title  : `Supprimer le BDT ${id}`,
      message: `Supprimer définitivement le BDT ${id} ?\n\nUn snapshot est sauvegardé dans _BDC_BACKUPS_ avant suppression.`,
      danger : true,
      confirmLabel: 'Supprimer',
      onConfirm: () => doDeleteBDT(id),
    });
  }

  async function handleListSnapshots() {
    const id = restoreId.trim();
    setLoadingSnapshots(true);
    try {
      const url = id ? `/api/admin/restore-bdc?id=${encodeURIComponent(id)}` : '/api/admin/restore-bdc';
      const res = await fetch(url);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `${res.status}`);
      setSnapshots(data.snapshots || []);
      addLog(`✓ ${(data.snapshots || []).length} snapshot(s) chargés${id ? ` pour ${id}` : ''}`);
    } catch (err: any) {
      toast(`Échec : ${err.message}`, 'error');
      addLog(`✗ List snapshots : ${err.message}`);
    } finally {
      setLoadingSnapshots(false);
    }
  }

  async function doRestoreSnapshot(snap: Snapshot, ovc: string) {
    setRestoring(true);
    try {
      const res = await fetch('/api/admin/restore-bdc', {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({
          id: snap.bdcId,
          backupRow: snap.backupRow,
          ...(ovc ? { overrideClient: ovc } : {}),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `${res.status}`);
      toast(`BDT ${snap.bdcId} restauré${data.overrideClient ? ` → ${data.overrideClient}` : ''}`);
      addLog(`✓ Restauré ${snap.bdcId} : ${data.restoredBdcRows} BDC rows + ${data.restoredInvCols} inv cols${data.overrideClient ? ` (client → ${data.overrideClient})` : ''}`);
    } catch (err: any) {
      toast(`Échec : ${err.message}`, 'error');
      addLog(`✗ Restauration ${snap.bdcId} : ${err.message}`);
    } finally {
      setRestoring(false);
    }
  }
  function handleRestoreSnapshot(snap: Snapshot) {
    const ovc = overrideClient.trim();
    const clientMsg = ovc ? `\n\nClient réassigné à : « ${ovc} »` : '';
    ask({
      title  : `Restaurer BDT ${snap.bdcId}`,
      message: `Restaurer depuis snapshot ${snap.timestamp} (${snap.action}, ${snap.itemCount} items) ?\n\nLes données actuelles du BDC (s'il existe) seront remplacées.${clientMsg}`,
      confirmLabel: 'Restaurer',
      onConfirm: () => doRestoreSnapshot(snap, ovc),
    });
  }

  async function doForceArchive(id: string, refuse: boolean) {
    setForceArchiving(true);
    try {
      const res = await fetch(`/api/bdc/${id}/archiver`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ refuse }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || `${res.status}`);
      const mode = refuse ? 'ÉVAL. REFUSÉE' : 'facture payée';
      toast(`BDT ${id} archivé (${mode})`);
      addLog(`✓ Archivé ${id} (${mode})`);
      setForceArchiveId('');
    } catch (err: any) {
      toast(`Échec : ${err.message}`, 'error');
      addLog(`✗ Force archive ${id} : ${err.message}`);
    } finally {
      setForceArchiving(false);
    }
  }
  function handleForceArchive(refuse: boolean) {
    const id = forceArchiveId.trim();
    if (!id) { toast('Entre un ID de BDT', 'error'); return; }
    const mode = refuse ? 'ÉVAL. REFUSÉE' : 'facture payée';
    ask({
      title  : `Forcer archivage ${id}`,
      message: `Forcer l'archivage du BDT ${id} (mode : ${mode}) ?\n\nLe BDT sera déplacé de INVENTAIRE vers ARCHIVES sans passer par les checkboxes du BDT.`,
      danger : refuse,
      confirmLabel: 'Archiver',
      onConfirm: () => doForceArchive(id, refuse),
    });
  }

  async function doBackfillSquareNotes(overwriteAll: boolean) {
    setBackfilling(true);
    try {
      const res  = await fetch('/api/square/backfill-notes', {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ overwriteAll }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `${res.status}`);
      const s = data.stats || {};
      toast(`${s.updated ?? 0} mis à jour · ${s.skipped ?? 0} skip · ${s.errors ?? 0} err`);
      addLog(`✓ Backfill Square : updated=${s.updated} skipped=${s.skipped} errors=${s.errors}`);
      if (Array.isArray(data.errors) && data.errors.length > 0) {
        for (const e of data.errors.slice(0, 5)) {
          addLog(`   ✗ ${e.bookingId} : ${e.error}`);
        }
      }
    } catch (err: any) {
      toast(`Échec : ${err.message}`, 'error');
      addLog(`✗ Backfill Square : ${err.message}`);
    } finally {
      setBackfilling(false);
    }
  }
  function handleBackfillSquareNotes(overwriteAll: boolean) {
    ask({
      title  : 'Backfill notes Square',
      message: overwriteAll
        ? 'Réécrire la note interne de TOUS les BDT Square existants ?\n\nÉcrasera les notes manuelles si présentes.'
        : 'Remplir la note interne des BDT Square dont la note est vide ?\n\n(Notes existantes préservées.)',
      danger : overwriteAll,
      confirmLabel: overwriteAll ? 'Réécrire tout' : 'Remplir',
      onConfirm: () => doBackfillSquareNotes(overwriteAll),
    });
  }

  async function doBackfillCalendar() {
    setBackfillingCal(true);
    try {
      const res  = await fetch('/api/square/backfill-calendar', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `${res.status}`);
      const s = data.stats || {};
      toast(`${s.created ?? 0} créés · ${s.skipped ?? 0} skip · ${s.errors ?? 0} err`);
      addLog(`✓ Backfill Calendar : created=${s.created} skipped=${s.skipped} errors=${s.errors}`);
    } catch (err: any) {
      toast(`Échec : ${err.message}`, 'error');
      addLog(`✗ Backfill Calendar : ${err.message}`);
    } finally {
      setBackfillingCal(false);
    }
  }
  function handleBackfillCalendar() {
    ask({
      title  : 'Backfill Calendar',
      message: 'Créer les évènements Calendar manquants pour les BDT Square existants (180j à venir) ?\n\nN\'écrase rien — saute les bookings qui ont déjà un event.',
      confirmLabel: 'Créer',
      onConfirm: () => doBackfillCalendar(),
    });
  }

  async function doConsolidateGhosts() {
    setConsolidating(true);
    try {
      const res  = await fetch('/api/archives', {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ action: 'consolidate' }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || `${res.status}`);
      const n = data.consolidated?.length ?? 0;
      toast(`${n} fantôme(s) consolidé(s)`);
      addLog(`✓ Consolidation : ${n} fantôme(s) (${(data.consolidated ?? []).join(', ') || '—'})`);
    } catch (err: any) {
      toast(`Échec : ${err.message}`, 'error');
      addLog(`✗ Consolidation échec : ${err.message}`);
    } finally {
      setConsolidating(false);
    }
  }
  function handleConsolidateGhosts() {
    ask({
      title  : 'Consolider les fantômes',
      message: 'Lancer la consolidation des BDT fantômes ?\n\nLes IDs référencés dans CLIENTS mais absents ailleurs seront recréés dans ARCHIVES avec le statut ARCHIVÉ.',
      confirmLabel: 'Consolider',
      onConfirm: () => doConsolidateGhosts(),
    });
  }

  const boxStyle: React.CSSProperties = {
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: '16px',
    padding: '20px',
    color: '#fff',
  };

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader title="Admin" subtitle="opérations destructives" />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">

          {/* ── Colonne gauche : Restaurer (gros bloc) ── */}
          <div className="flex flex-col" style={{ gap: '20px' }}>
            <section style={boxStyle}>
              <h2 className="flex items-center gap-2" style={{ fontSize: '16px', fontWeight: 700, marginBottom: '12px' }}>
                <ArrowPathIcon style={{ width: '20px', height: '20px', color: '#60a5fa' }} />
                Restaurer un BDT depuis snapshot
              </h2>
              <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.7)', marginBottom: '12px' }}>
                Restaure un BDT perdu à partir d'un snapshot de <code>_BDC_BACKUPS_</code>.
                Fonctionne même si le BDT a complètement disparu d'INVENTAIRE et d'ARCHIVES
                (ex. désarchivage + crash).
              </p>
              <div className="flex gap-2 mb-3">
                <input
                  type="text"
                  value={restoreId}
                  onChange={e => setRestoreId(e.target.value)}
                  placeholder="ID BDT (ex. 0120) — vide = tous"
                  style={{
                    flex: 1, padding: '10px', borderRadius: '8px',
                    fontSize: '14px', fontFamily: 'monospace',
                    backgroundColor: '#111', color: '#fff',
                    border: '1px solid rgba(255,255,255,0.15)',
                  }}
                />
                <button onClick={handleListSnapshots} disabled={loadingSnapshots} className="btn-primary">
                  {loadingSnapshots ? 'Chargement…' : 'Lister snapshots'}
                </button>
              </div>
              <div className="mb-3">
                <input
                  type="text"
                  value={overrideClient}
                  onChange={e => setOverrideClient(e.target.value)}
                  placeholder="(optionnel) Réassigner au client : ex. Samuel Montigne"
                  style={{
                    width: '100%', padding: '10px', borderRadius: '8px',
                    fontSize: '13px',
                    backgroundColor: '#111', color: '#fff',
                    border: '1px solid rgba(255,255,255,0.15)',
                  }}
                />
                <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', marginTop: '4px' }}>
                  Si rempli, le client du BDT restauré sera remplacé par cette valeur (col H d'INVENTAIRE + ligne GAP du BDC).
                </p>
              </div>
              {snapshots.length > 0 && (
                <div style={{ maxHeight: '500px', overflowY: 'auto', backgroundColor: '#111', borderRadius: '8px', padding: '8px' }}>
                  {snapshots.map((s, i) => (
                    <div
                      key={`${s.backupRow}-${i}`}
                      className="flex items-center gap-2"
                      style={{
                        padding: '8px 10px', borderRadius: '6px', marginBottom: '4px',
                        backgroundColor: 'rgba(255,255,255,0.05)',
                      }}
                    >
                      <div style={{ flex: 1, fontSize: '12px', fontFamily: 'monospace' }}>
                        <div style={{ color: '#88fa4e' }}>
                          #{s.bdcId} · {s.action} · {s.itemCount} items
                        </div>
                        <div style={{ color: 'rgba(255,255,255,0.55)', fontSize: '11px' }}>
                          {s.timestamp} · {s.clientNom || '—'} · {s.veloDesc || '—'}
                        </div>
                      </div>
                      <button
                        onClick={() => handleRestoreSnapshot(s)}
                        disabled={restoring}
                        style={{
                          padding: '6px 10px', fontSize: '11px', fontWeight: 600,
                          borderRadius: '6px', backgroundColor: '#2563eb', color: '#fff',
                          border: 'none', cursor: restoring ? 'wait' : 'pointer',
                        }}
                      >
                        {restoring ? '…' : 'Restaurer'}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>

          {/* ── Colonne droite : Supprimer + Consolider + Journal ── */}
          <div className="flex flex-col" style={{ gap: '20px' }}>

            {/* Suppression BDT par ID */}
            <section style={boxStyle}>
              <h2 className="flex items-center gap-2" style={{ fontSize: '16px', fontWeight: 700, marginBottom: '12px' }}>
                <TrashIcon style={{ width: '20px', height: '20px', color: '#f87171' }} />
                Supprimer un BDT par ID
              </h2>
              <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.7)', marginBottom: '12px' }}>
                Supprime définitivement un BDT (actif ou archivé, auto-détection).
                Un snapshot est sauvegardé dans <code>_BDC_BACKUPS_</code> avant toute opération.
              </p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={bdtId}
                  onChange={e => setBdtId(e.target.value)}
                  placeholder="ex. 0122"
                  style={{
                    flex: 1, padding: '10px', borderRadius: '8px',
                    fontSize: '14px', fontFamily: 'monospace',
                    backgroundColor: '#111', color: '#fff',
                    border: '1px solid rgba(255,255,255,0.15)',
                  }}
                  disabled={deleting}
                />
                <button
                  onClick={handleDeleteBDT}
                  disabled={deleting || !bdtId.trim()}
                  className="btn-primary"
                  style={{ backgroundColor: '#dc2626', color: '#fff', opacity: deleting ? 0.5 : 1 }}
                >
                  {deleting ? 'Suppression…' : 'Supprimer'}
                </button>
              </div>
            </section>

            {/* Forcer archive */}
            <section style={boxStyle}>
              <h2 className="flex items-center gap-2" style={{ fontSize: '16px', fontWeight: 700, marginBottom: '12px' }}>
                <ArchiveBoxIcon style={{ width: '20px', height: '20px', color: '#34d399' }} />
                Forcer l'archivage d'un BDT
              </h2>
              <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.7)', marginBottom: '12px' }}>
                Archive un BDT directement (bypass checkboxes du BDT). Utile si
                le flux normal bloque (ex. après désarchivage répété). Appelle
                la même fonction serveur que le checkbox Archiver.
              </p>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  value={forceArchiveId}
                  onChange={e => setForceArchiveId(e.target.value)}
                  placeholder="ex. 0120"
                  style={{
                    flex: 1, padding: '10px', borderRadius: '8px',
                    fontSize: '14px', fontFamily: 'monospace',
                    backgroundColor: '#111', color: '#fff',
                    border: '1px solid rgba(255,255,255,0.15)',
                  }}
                  disabled={forceArchiving}
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleForceArchive(false)}
                  disabled={forceArchiving || !forceArchiveId.trim()}
                  className="btn-primary"
                  style={{ flex: 1, backgroundColor: '#16a34a', color: '#fff', opacity: forceArchiving ? 0.5 : 1 }}
                >
                  {forceArchiving ? '…' : 'Facture payée'}
                </button>
                <button
                  onClick={() => handleForceArchive(true)}
                  disabled={forceArchiving || !forceArchiveId.trim()}
                  className="btn-primary"
                  style={{ flex: 1, backgroundColor: '#dc2626', color: '#fff', opacity: forceArchiving ? 0.5 : 1 }}
                >
                  {forceArchiving ? '…' : 'Éval. refusée'}
                </button>
              </div>
            </section>

            {/* Backfill notes Square */}
            <section style={boxStyle}>
              <h2 className="flex items-center gap-2" style={{ fontSize: '16px', fontWeight: 700, marginBottom: '12px' }}>
                <DocumentTextIcon style={{ width: '20px', height: '20px', color: '#60a5fa' }} />
                Backfill notes Square (anciens BDT)
              </h2>
              <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.7)', marginBottom: '12px' }}>
                Pour chaque BDT créé via Square, remplit la note interne avec
                l'auto-header + customer_note + seller_note du booking. Saute
                les BDT déjà notés (sauf si « réécrire tout »).
              </p>
              <div className="flex gap-2 mb-3">
                <button
                  onClick={() => handleBackfillSquareNotes(false)}
                  disabled={backfilling}
                  className="btn-primary"
                  style={{ flex: 1 }}
                >
                  {backfilling ? '…' : 'Remplir vides'}
                </button>
                <button
                  onClick={() => handleBackfillSquareNotes(true)}
                  disabled={backfilling}
                  className="btn-primary"
                  style={{ flex: 1, backgroundColor: '#dc2626', color: '#fff' }}
                >
                  {backfilling ? '…' : 'Réécrire tout'}
                </button>
              </div>
              <button
                onClick={handleBackfillCalendar}
                disabled={backfillingCal}
                className="btn-primary"
                style={{ width: '100%', backgroundColor: '#2563eb' }}
              >
                {backfillingCal ? '…' : 'Backfill Calendar (events manquants)'}
              </button>
            </section>

            {/* Consolidation fantômes */}
            <section style={boxStyle}>
              <h2 className="flex items-center gap-2" style={{ fontSize: '16px', fontWeight: 700, marginBottom: '12px' }}>
                <WrenchIcon style={{ width: '20px', height: '20px', color: '#fbbf24' }} />
                Consolider les fantômes
              </h2>
              <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.7)', marginBottom: '12px' }}>
                Détecte les BDT référencés dans CLIENTS (col I) mais absents
                du sheet BDC, INVENTAIRE et ARCHIVES. Les recrée dans ARCHIVES
                avec statut « ARCHIVÉ » pour qu'ils ne soient plus orphelins.
              </p>
              <button
                onClick={handleConsolidateGhosts}
                disabled={consolidating}
                className="btn-primary"
              >
                {consolidating ? 'En cours…' : 'Lancer la consolidation'}
              </button>
            </section>

            {/* Log */}
            {log.length > 0 && (
              <section style={boxStyle}>
                <h3 style={{ fontSize: '14px', fontWeight: 700, marginBottom: '8px' }}>
                  Journal
                </h3>
                <div style={{
                  fontFamily: 'monospace', fontSize: '12px', color: 'rgba(255,255,255,0.8)',
                  backgroundColor: '#111', padding: '10px', borderRadius: '8px',
                  maxHeight: '250px', overflowY: 'auto',
                }}>
                  {log.map((l, i) => (
                    <div key={i}>{l}</div>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>
      </div>

      {/* Confirmation modale (remplace les window.confirm() natifs) */}
      <ConfirmDialog
        open={confirmDialog !== null}
        title={confirmDialog?.title ?? ''}
        message={confirmDialog?.message ?? ''}
        confirmLabel={confirmDialog?.confirmLabel ?? 'Confirmer'}
        danger={confirmDialog?.danger}
        onConfirm={() => {
          const c = confirmDialog;
          setConfirmDialog(null);
          c?.onConfirm();
        }}
        onCancel={() => setConfirmDialog(null)}
      />
    </AppShell>
  );
}
