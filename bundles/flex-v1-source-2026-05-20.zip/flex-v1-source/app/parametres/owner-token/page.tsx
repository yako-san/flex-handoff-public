'use client';
/**
 * Page /parametres/owner-token — affiche le refresh_token Google de la
 * session courante pour pouvoir le copier dans Vercel env var
 * GOOGLE_OWNER_REFRESH_TOKEN.
 *
 * Full client-side pour éviter tout problème de rendu SSR. On fetch
 * la session via /api/auth/session (qui inclut googleRefreshToken
 * grâce au callback `session` dans lib/auth.ts).
 */
import { useEffect, useState } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';

export default function OwnerTokenPage() {
  const [refreshToken, setRefreshToken] = useState<string | null>(null);
  const [loading, setLoading]           = useState(true);
  const [error, setError]               = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res  = await fetch('/api/auth/session', { cache: 'no-store' });
        const data = await res.json().catch(() => ({}));
        if (cancelled) return;
        const rt = data?.googleRefreshToken as string | undefined;
        setRefreshToken(rt ?? null);
      } catch (err: any) {
        if (!cancelled) setError(err?.message ?? 'Erreur de chargement de la session');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader title="Owner token Google" subtitle="Pour configurer le cron Calendar" />

        <div className="flex flex-col" style={{ gap: '20px', maxWidth: '800px' }}>
          <section
            style={{
              backgroundColor: 'rgba(0,0,0,0.2)',
              borderRadius: '16px',
              padding: '20px',
              color: '#fff',
            }}
          >
            <h2 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '12px' }}>
              refresh_token
            </h2>

            {loading && (
              <div style={{ fontSize: '13px', color: 'rgba(255,255,255,0.6)' }}>
                Chargement de la session…
              </div>
            )}

            {!loading && error && (
              <div
                style={{
                  backgroundColor: 'rgba(255, 60, 60, 0.15)',
                  borderLeft: '3px solid #ff4040',
                  padding: '12px',
                  borderRadius: '8px',
                  fontSize: '13px',
                }}
              >
                Erreur : {error}
              </div>
            )}

            {!loading && !error && refreshToken && (
              <>
                <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.7)', marginBottom: '8px' }}>
                  Copie cette chaîne dans Vercel → Settings → Environment Variables →
                  nouvelle variable <strong>GOOGLE_OWNER_REFRESH_TOKEN</strong>, puis redéploie.
                </p>
                <textarea
                  readOnly
                  value={refreshToken}
                  onClick={(e) => e.currentTarget.select()}
                  style={{
                    width: '100%',
                    minHeight: '80px',
                    padding: '10px',
                    borderRadius: '8px',
                    fontSize: '12px',
                    fontFamily: 'monospace',
                    backgroundColor: '#111',
                    color: '#88fa4e',
                    border: '1px solid rgba(255,255,255,0.1)',
                    resize: 'vertical',
                  }}
                />
                <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', marginTop: '8px' }}>
                  Clique dessus pour sélectionner toute la chaîne, puis Cmd+C.
                </p>
              </>
            )}

            {!loading && !error && !refreshToken && (
              <div
                style={{
                  backgroundColor: 'rgba(255, 60, 60, 0.15)',
                  borderLeft: '3px solid #ff4040',
                  padding: '12px',
                  borderRadius: '8px',
                  fontSize: '13px',
                  lineHeight: 1.5,
                }}
              >
                <strong>Aucun refresh_token dans la session actuelle.</strong>
                <br />
                <br />
                Depuis la v5.24.76, <code>prompt=consent</code> est forcé lors du login,
                donc Google doit émettre un refresh_token à chaque nouvelle connexion.
                <br />
                <br />
                Si tu vois encore ce message :
                <ol style={{ marginLeft: '20px', marginTop: '8px' }}>
                  <li>Déconnecte-toi de FLEX-REV (avatar → Déconnexion)</li>
                  <li>Reconnecte-toi avec yako.cyclo@gmail.com</li>
                  <li>Google affichera l'écran de consent — accepte tous les scopes</li>
                  <li>Reviens sur cette page → le token apparaît</li>
                </ol>
                <br />
                <em>
                  Si l'écran de consent ne s'affiche toujours pas : va sur{' '}
                  <a
                    href="https://myaccount.google.com/permissions"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ color: '#88fa4e', textDecoration: 'underline' }}
                  >
                    myaccount.google.com/permissions
                  </a>
                  , supprime l'accès FLEX-REV, puis reconnecte-toi à l'app.
                </em>
              </div>
            )}
          </section>

          <section
            style={{
              backgroundColor: 'rgba(0,0,0,0.15)',
              borderRadius: '16px',
              padding: '20px',
              color: 'rgba(255,255,255,0.8)',
              fontSize: '13px',
              lineHeight: 1.6,
            }}
          >
            <h3 style={{ fontSize: '14px', fontWeight: 700, marginBottom: '8px', color: '#fff' }}>
              Étapes complètes
            </h3>
            <ol style={{ marginLeft: '20px' }}>
              <li>Active la <strong>Google Calendar API</strong> dans Google Cloud Console (APIs & Services → Library).</li>
              <li>Déconnecte-toi + reconnecte-toi (scope Calendar consent).</li>
              <li>Copie le <code>refresh_token</code> ci-dessus.</li>
              <li>Vercel → Settings → Environment Variables → ajoute <code>GOOGLE_OWNER_REFRESH_TOKEN</code> avec cette valeur.</li>
              <li>Redéploie (ou attends le prochain push).</li>
              <li>Le cron quotidien (7h Montréal) créera les évènements Calendar automatiquement.</li>
            </ol>
          </section>
        </div>
      </div>
    </AppShell>
  );
}
