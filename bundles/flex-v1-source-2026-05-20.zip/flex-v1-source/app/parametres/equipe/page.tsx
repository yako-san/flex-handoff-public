'use client';
import { useEffect, useState } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { toast } from '@/components/ui/Toast';
import { useEquipe } from '@/hooks/useEquipe';
import { useEmailTemplates } from '@/hooks/useEmailTemplates';
import { useIsAdmin } from '@/hooks/useIsAdmin';
import { TrashIcon, PlusIcon, ShieldCheckIcon } from '@heroicons/react/24/outline';
import type { EquipeMember } from '@/types/equipe';

const INDICATIFS = [
  { value: '+1',  label: '🇨🇦 +1' },
  { value: '+1',  label: '🇺🇸 +1' },
  { value: '+33', label: '🇫🇷 +33' },
  { value: '+32', label: '🇧🇪 +32' },
  { value: '+41', label: '🇨🇭 +41' },
  { value: '+44', label: '🇬🇧 +44' },
  { value: '+49', label: '🇩🇪 +49' },
];

export default function EquipePage() {
  const { members, isLoading, createMember, updateMember, removeMember } = useEquipe();
  const { tpl, mutate: mutateTemplates } = useEmailTemplates();
  const { adminEmails, save: saveAdmins } = useIsAdmin();

  // Nom + Localisation de l'équipe (stockés dans _EMAIL_TEMPLATES_)
  const [equipeNom, setEquipeNom] = useState('');
  const [equipeLoc, setEquipeLoc] = useState('');
  useEffect(() => {
    const n = tpl('equipe_nom');         if (n) setEquipeNom(n);
    const l = tpl('equipe_localisation'); if (l) setEquipeLoc(l);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoading]);

  async function saveEquipeField(key: 'equipe_nom' | 'equipe_localisation', value: string) {
    if (value === tpl(key)) return;
    try {
      const res = await fetch('/api/parametres/emails', {
        method : 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ [key]: value }),
      });
      if (!res.ok) throw new Error((await res.json()).error || 'Erreur');
      await mutateTemplates();
      toast(`Sauvegardé : ${value || '(vide)'}`);
    } catch (err: any) { toast(err.message, 'error'); }
  }

  // Section admin emails (inchangée vs ancienne version)
  const [admins, setAdmins]           = useState<string[]>([]);
  const [adminDraft, setAdminDraft]   = useState('');
  const [savingAdmin, setSavingAdmin] = useState(false);

  // Création nouveau membre
  const [showNew, setShowNew]       = useState(false);
  const [newPrenom, setNewPrenom]   = useState('');
  const [newNom, setNewNom]         = useState('');

  useEffect(() => { setAdmins(adminEmails); /* eslint-disable-next-line */ }, [adminEmails.join(',')]);

  async function patchField(m: EquipeMember, fields: Partial<EquipeMember>) {
    try {
      await updateMember(m._row, fields as any);
    } catch (err: any) {
      toast(err.message || 'Erreur', 'error');
    }
  }

  async function addNew() {
    if (!newPrenom.trim()) return;
    try {
      await createMember({
        prenom: newPrenom.trim(), nom: newNom.trim(),
        surnom: '', courriel: '', tel: '', indicatif: '+1',
        lang: 'FR', role: 'Mécanicien', active: true, notes: '',
      });
      setNewPrenom(''); setNewNom(''); setShowNew(false);
      toast(`Membre ${newPrenom.trim()} ${newNom.trim()}`.trim() + ' ajouté');
    } catch (err: any) {
      toast(err.message || 'Erreur', 'error');
    }
  }

  async function doRemove(m: EquipeMember) {
    const fullName = `${m.prenom} ${m.nom}`.trim();
    if (!confirm(`Retirer ${fullName} de l'équipe ?`)) return;
    try {
      await removeMember(m._row);
      toast(`${fullName} retiré`);
    } catch (err: any) {
      toast(err.message || 'Erreur', 'error');
    }
  }

  function addAdmin() {
    const v = adminDraft.trim().toLowerCase();
    if (!v) return;
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v)) { toast('Courriel invalide', 'error'); return; }
    if (admins.includes(v)) { toast('Déjà admin', 'error'); return; }
    setAdmins(prev => [...prev, v]);
    setAdminDraft('');
  }
  function removeAdmin(e: string) { setAdmins(prev => prev.filter(x => x !== e)); }
  async function handleSaveAdmins() {
    setSavingAdmin(true);
    try { await saveAdmins(admins); toast('Administrateurs mis à jour'); }
    catch (err: any) { toast(err.message || 'Erreur', 'error'); }
    finally { setSavingAdmin(false); }
  }

  const cellStyle = { padding: '6px 4px' };

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader subtitle="paramètres" title="Équipe atelier" titleAfterHelp={equipeNom} />

        {isLoading && <LoadingSpinner className="py-20" />}

        {!isLoading && (
          <div className="md:bg-black/20 md:rounded-[50px] md:p-[30px]">
            {/* Nom de l'équipe + Localisation atelier (côte à côte) */}
            <div className="flex flex-wrap items-center gap-4" style={{ marginBottom: '20px' }}>
              <div className="flex items-center gap-3">
                <label className="legende" style={{ color: 'rgba(255,255,255,0.7)' }}>
                  Nom de l'équipe
                </label>
                <input
                  type="text"
                  value={equipeNom}
                  onChange={e => setEquipeNom(e.target.value)}
                  onBlur={e => saveEquipeField('equipe_nom', e.target.value.trim())}
                  placeholder="ex. Flex"
                  className="input-system"
                  style={{ width: '180px' }}
                />
              </div>
              <div className="flex items-center gap-3">
                <label className="legende" style={{ color: 'rgba(255,255,255,0.7)' }}>
                  Localisation atelier
                </label>
                <input
                  type="text"
                  value={equipeLoc}
                  onChange={e => setEquipeLoc(e.target.value)}
                  onBlur={e => saveEquipeField('equipe_localisation', e.target.value.trim())}
                  placeholder="ex. Montréal"
                  className="input-system"
                  style={{ width: '180px' }}
                />
              </div>
            </div>

            <p className="text-sm" style={{ color: 'rgba(255,255,255,0.65)', marginBottom: '16px' }}>
              Liste des mécaniciens et leurs coordonnées. Modifie un champ inline (sauvegarde au blur).
              Décoche « Active » pour retirer un membre des dropdowns sans le supprimer.
            </p>

            {/* Tableau membres */}
            <div className="overflow-x-auto" style={{ marginBottom: '20px' }}>
              <table style={{ width: '100%', borderCollapse: 'separate', borderSpacing: '0 8px' }}>
                <thead>
                  <tr style={{ color: 'rgba(255,255,255,0.6)', fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                    <th style={{ textAlign: 'left',  padding: '4px 12px' }}>Prénom</th>
                    <th style={{ textAlign: 'left',  padding: '4px 8px' }}>Nom</th>
                    <th style={{ textAlign: 'left',  padding: '4px 8px' }}>Surnom</th>
                    <th style={{ textAlign: 'left',  padding: '4px 8px' }}>Rôle</th>
                    <th style={{ textAlign: 'left',  padding: '4px 8px' }}>Courriel</th>
                    <th style={{ textAlign: 'left',  padding: '4px 8px', minWidth: '90px' }}>Indic.</th>
                    <th style={{ textAlign: 'left',  padding: '4px 8px' }}>Tél</th>
                    <th style={{ textAlign: 'left',  padding: '4px 8px' }}>Lang</th>
                    <th style={{ textAlign: 'center', padding: '4px 8px' }}>Active</th>
                    <th style={{ width: '40px' }}></th>
                  </tr>
                </thead>
                <tbody>
                  {members.length === 0 && (
                    <tr><td colSpan={10} style={{ textAlign: 'center', padding: '20px', color: 'rgba(255,255,255,0.4)', fontSize: '13px' }}>
                      Aucun membre. Ajoute-en un ci-dessous.
                    </td></tr>
                  )}
                  {members.map(m => (
                    <tr key={m._row} style={{ backgroundColor: 'rgba(255,255,255,0.85)' }}>
                      <td style={{ ...cellStyle, borderTopLeftRadius: '40px', borderBottomLeftRadius: '40px', paddingLeft: '12px' }}>
                        <input defaultValue={m.prenom} onBlur={e => e.target.value !== m.prenom && patchField(m, { prenom: e.target.value })} className="input-system" style={{ fontWeight: 700 }} />
                      </td>
                      <td style={cellStyle}>
                        <input defaultValue={m.nom} onBlur={e => e.target.value !== m.nom && patchField(m, { nom: e.target.value })} className="input-system" placeholder="Nom de famille" />
                      </td>
                      <td style={cellStyle}>
                        <input defaultValue={m.surnom} onBlur={e => e.target.value !== m.surnom && patchField(m, { surnom: e.target.value })} className="input-system" placeholder="ex. yako" />
                      </td>
                      <td style={cellStyle}>
                        <input defaultValue={m.role} onBlur={e => e.target.value !== m.role && patchField(m, { role: e.target.value })} className="input-system" placeholder="ex. Mécanicien" />
                      </td>
                      <td style={cellStyle}>
                        <input type="email" defaultValue={m.courriel} onBlur={e => e.target.value !== m.courriel && patchField(m, { courriel: e.target.value })} className="input-system" placeholder="…@cycloflex.ca" />
                      </td>
                      <td style={cellStyle}>
                        <select defaultValue={m.indicatif} onChange={e => patchField(m, { indicatif: e.target.value })} className="input-system">
                          {INDICATIFS.map((i, idx) => <option key={`${i.value}-${idx}`} value={i.value}>{i.label}</option>)}
                        </select>
                      </td>
                      <td style={cellStyle}>
                        <input type="tel" defaultValue={m.tel} onBlur={e => e.target.value !== m.tel && patchField(m, { tel: e.target.value })} className="input-system" placeholder="514…" />
                      </td>
                      <td style={cellStyle}>
                        <select defaultValue={m.lang} onChange={e => patchField(m, { lang: e.target.value as 'FR' | 'EN' })} className="input-system">
                          <option value="FR">FR</option>
                          <option value="EN">EN</option>
                        </select>
                      </td>
                      <td style={{ ...cellStyle, textAlign: 'center' }}>
                        <input type="checkbox" defaultChecked={m.active} onChange={e => patchField(m, { active: e.target.checked })} className="custom-checkbox" />
                      </td>
                      <td style={{ ...cellStyle, borderTopRightRadius: '40px', borderBottomRightRadius: '40px', paddingRight: '12px' }}>
                        <button type="button" onClick={() => doRemove(m)}
                          className="flex items-center justify-center transition-colors hover:bg-red-100"
                          style={{ width: '28px', height: '28px', borderRadius: '50%', border: 'none', backgroundColor: 'transparent', color: '#b91c1c', cursor: 'pointer' }}
                          title={`Retirer ${m.prenom} ${m.nom}`.trim()}>
                          <TrashIcon style={{ width: '14px', height: '14px' }} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Ajout nouveau membre */}
            {!showNew ? (
              <div className="flex justify-start" style={{ marginBottom: '30px' }}>
                <button type="button" onClick={() => setShowNew(true)} className="btn-primary flex items-center gap-2">
                  <PlusIcon style={{ width: '18px', height: '18px' }} />
                  Nouveau membre
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-3" style={{ marginBottom: '30px' }}>
                <input
                  type="text"
                  autoFocus
                  value={newNom}
                  onChange={e => setNewNom(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') addNew(); if (e.key === 'Escape') { setShowNew(false); setNewNom(''); } }}
                  placeholder="Nom du nouveau membre…"
                  className="flex-1 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                  style={{ padding: '10px 14px', borderRadius: '12px', border: 'none', backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', fontSize: '14px' }}
                />
                <button type="button" onClick={addNew} disabled={!newNom.trim()} className="btn-primary">
                  Ajouter
                </button>
                <button type="button" onClick={() => { setShowNew(false); setNewNom(''); }} className="btn-secondary">
                  Annuler
                </button>
              </div>
            )}

            {/* ── Administrateurs ──────────────────────────── */}
            <div style={{ borderTop: '1px solid rgba(255,255,255,0.15)', paddingTop: '24px', marginTop: '20px' }}>
              <h3 className="legende flex items-center gap-2" style={{ color: 'rgba(255,255,255,0.7)', marginBottom: '8px' }}>
                <ShieldCheckIcon style={{ width: '16px', height: '16px' }} />
                Administrateurs
              </h3>
              <p className="text-sm" style={{ color: 'rgba(255,255,255,0.55)', marginBottom: '16px' }}>
                Comptes Google autorisés à accéder aux Paramètres. <strong>yako.cyclo@gmail.com</strong> est
                toujours admin en fail-safe (ne peut pas être verrouillé hors).
              </p>

              <div className="flex flex-col" style={{ gap: '8px', marginBottom: '16px', maxWidth: '500pt' }}>
                {admins.length === 0 && (
                  <p className="text-center py-4" style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px' }}>
                    Aucun admin — yako.cyclo@gmail.com reste admin par défaut.
                  </p>
                )}
                {admins.map((email) => (
                  <div key={email} className="flex items-center gap-2" style={{ padding: '10px 14px', borderRadius: '12px', backgroundColor: 'rgba(255,255,255,0.85)' }}>
                    <span style={{ flex: 1, fontSize: '13px', fontFamily: 'monospace', color: 'rgba(0,0,0,0.8)' }}>
                      {email}
                    </span>
                    {email === 'yako.cyclo@gmail.com' && (
                      <span style={{ padding: '2px 8px', borderRadius: '999px', backgroundColor: 'rgba(34,197,94,0.15)', color: '#166534', fontSize: '10px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                        fail-safe
                      </span>
                    )}
                    <button type="button" onClick={() => removeAdmin(email)}
                      disabled={email === 'yako.cyclo@gmail.com'}
                      className="flex items-center justify-center transition-colors hover:bg-red-100 disabled:opacity-25"
                      style={{ width: '32px', height: '32px', borderRadius: '50%', border: 'none', backgroundColor: 'transparent', color: '#b91c1c', cursor: email === 'yako.cyclo@gmail.com' ? 'not-allowed' : 'pointer' }}
                      title={email === 'yako.cyclo@gmail.com' ? 'Admin fail-safe non supprimable' : 'Retirer admin'}>
                      <TrashIcon style={{ width: '14px', height: '14px' }} />
                    </button>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-3" style={{ marginBottom: '16px', maxWidth: '500pt' }}>
                <input
                  type="email"
                  value={adminDraft}
                  onChange={e => setAdminDraft(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') addAdmin(); }}
                  placeholder="nouveau.admin@gmail.com"
                  className="flex-1 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                  style={{ padding: '10px 14px', borderRadius: '12px', border: 'none', backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', fontSize: '14px' }}
                />
                <button type="button" onClick={addAdmin} disabled={!adminDraft.trim()} className="btn-primary flex items-center gap-2">
                  <PlusIcon style={{ width: '18px', height: '18px' }} />
                  Ajouter admin
                </button>
              </div>

              <div className="flex justify-end">
                <button type="button" onClick={handleSaveAdmins} disabled={savingAdmin} className="btn-primary">
                  {savingAdmin ? 'Sauvegarde…' : 'Sauvegarder les admins'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
