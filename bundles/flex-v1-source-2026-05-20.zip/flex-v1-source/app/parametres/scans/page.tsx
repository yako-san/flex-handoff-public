'use client';
import { useEffect, useState } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';
import { getScanLog, clearScanLog, scanLogToCsv, type ScanLogEntry } from '@/lib/utils/scanLog';
import { ArrowDownTrayIcon, TrashIcon } from '@heroicons/react/24/outline';

const ACTION_LABEL: Record<ScanLogEntry['action'], { label: string; color: string }> = {
  'matched-barcode'   : { label: 'Match EAN',   color: '#22c55e' },
  'matched-sku'       : { label: 'Match SKU',   color: '#3b82f6' },
  'mapped-existing'   : { label: 'Associé',     color: '#fff056' },
  'created-new'       : { label: 'Pièce créée', color: '#a855f7' },
  'unknown-cancelled' : { label: 'Annulé',      color: 'rgba(0,0,0,0.3)' },
  'unknown'           : { label: 'Inconnu',     color: '#ef4444' },
};

export default function ScansPage() {
  const [entries, setEntries] = useState<ScanLogEntry[]>([]);

  useEffect(() => {
    setEntries(getScanLog());
  }, []);

  function handleExport() {
    const csv  = scanLogToCsv();
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `scan-log-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  function handleClear() {
    if (!window.confirm('Effacer tout le log des scans ? Cette action est irréversible.')) return;
    clearScanLog();
    setEntries([]);
  }

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader subtitle="paramètres" title={`Historique scans (${entries.length})`} />

        <div className="md:bg-black/20 md:rounded-[50px] md:p-[30px]">
          <div className="flex items-center justify-between" style={{ gap: '10px', marginBottom: '16px' }}>
            <p className="text-sm" style={{ color: 'rgba(255,255,255,0.65)', margin: 0, maxWidth: '600pt' }}>
              Log local (localStorage, navigateur courant) des 200 derniers scans —
              pour rattrapage si une synchro sheet échoue. Ce log ne quitte jamais
              ton appareil.
            </p>
            <div className="flex items-center shrink-0" style={{ gap: '8px' }}>
              <button
                type="button"
                onClick={handleExport}
                disabled={!entries.length}
                title="Exporter en CSV"
                className="flex items-center gap-1 disabled:opacity-40"
                style={{
                  padding: '8px 14px', borderRadius: '999px',
                  backgroundColor: 'rgba(255,255,255,0.85)', color: 'rgba(0,0,0,0.7)',
                  border: 'none', fontSize: '13px', fontWeight: 700,
                  cursor: entries.length ? 'pointer' : 'not-allowed',
                }}
              >
                <ArrowDownTrayIcon style={{ width: '14px', height: '14px' }} />
                CSV
              </button>
              <button
                type="button"
                onClick={handleClear}
                disabled={!entries.length}
                title="Effacer le log"
                className="flex items-center gap-1 disabled:opacity-40"
                style={{
                  padding: '8px 14px', borderRadius: '999px',
                  backgroundColor: 'rgba(239,68,68,0.18)', color: '#fff',
                  border: 'none', fontSize: '13px', fontWeight: 700,
                  cursor: entries.length ? 'pointer' : 'not-allowed',
                }}
              >
                <TrashIcon style={{ width: '14px', height: '14px' }} />
                Effacer
              </button>
            </div>
          </div>

          {entries.length === 0 ? (
            <p className="text-center py-16" style={{ color: 'rgba(255,255,255,0.45)', fontSize: '13px' }}>
              Aucun scan enregistré pour l'instant.
            </p>
          ) : (
            <div
              style={{
                border: '1.5px solid rgba(255,255,255,0.15)',
                borderRadius: '16px',
                overflow: 'hidden',
                backgroundColor: 'rgba(255,255,255,0.85)',
              }}
            >
              {entries.map((e, i) => {
                const meta = ACTION_LABEL[e.action] ?? ACTION_LABEL['unknown'];
                const time = new Date(e.timestamp).toLocaleString('fr-CA', { hour12: false });
                return (
                  <div
                    key={i}
                    className="flex items-start gap-3"
                    style={{
                      padding: '10px 16px',
                      borderBottom: '1px solid rgba(0,0,0,0.06)',
                      backgroundColor: i % 2 === 0 ? 'rgba(0,0,0,0.02)' : 'transparent',
                    }}
                  >
                    <div className="shrink-0" style={{ fontSize: '11px', color: 'rgba(0,0,0,0.45)', minWidth: '140px' }}>
                      {time}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div style={{ fontFamily: 'monospace', fontSize: '13px', color: 'rgba(0,0,0,0.85)', wordBreak: 'break-all' }}>
                        {e.code}
                      </div>
                      {e.pieceName && (
                        <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.6)', marginTop: '2px' }}>
                          → {e.pieceName}{e.pieceId ? ` (${e.pieceId})` : ''}
                        </div>
                      )}
                      {e.note && (
                        <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.45)', fontStyle: 'italic', marginTop: '2px' }}>
                          {e.note}
                        </div>
                      )}
                    </div>
                    <span
                      className="shrink-0 inline-flex items-center whitespace-nowrap"
                      style={{
                        padding: '2px 8px', borderRadius: '999px',
                        backgroundColor: meta.color,
                        color: meta.color === '#fff056' ? '#000' : '#fff',
                        fontSize: '10px', fontWeight: 700,
                        letterSpacing: '0.04em', textTransform: 'uppercase',
                      }}
                    >
                      {meta.label}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
