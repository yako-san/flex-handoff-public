'use client';
import { useEffect, useState } from 'react';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { toast } from '@/components/ui/Toast';
import { useVeloTailles } from '@/hooks/useVeloTailles';
import { TrashIcon, PlusIcon, ArrowUpIcon, ArrowDownIcon } from '@heroicons/react/24/outline';

export default function CatalogueParamPage() {
  const { tailles, save, isLoading } = useVeloTailles();
  const [list,  setList]  = useState<string[]>([]);
  const [draft, setDraft] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isLoading) setList(tailles.filter(Boolean));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoading]);

  function add() {
    const v = draft.trim();
    if (!v) return;
    if (list.includes(v)) { toast('Déjà présent', 'error'); return; }
    setList(prev => [...prev, v]);
    setDraft('');
  }
  function remove(i: number) { setList(prev => prev.filter((_, idx) => idx !== i)); }
  function move(i: number, dir: -1 | 1) {
    setList(prev => {
      const next = [...prev];
      const j = i + dir;
      if (j < 0 || j >= next.length) return prev;
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });
  }
  async function handleSave() {
    setSaving(true);
    try {
      await save(list);
      toast('Tailles mises à jour');
    } catch (err: any) {
      toast(err.message || 'Erreur', 'error');
    } finally {
      setSaving(false);
    }
  }

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader subtitle="paramètres" title="Catalogue vélo" />

        {isLoading && <LoadingSpinner className="py-20" />}

        {!isLoading && (
          <div className="md:bg-black/20 md:rounded-[50px] md:p-[30px]">
            <h3 className="legende" style={{ color: 'rgba(255,255,255,0.7)', marginBottom: '12px' }}>Tailles de vélo</h3>
            <p className="text-sm" style={{ color: 'rgba(255,255,255,0.55)', marginBottom: '16px' }}>
              Apparaît dans le dropdown de création / édition de vélo.
              Une option "—" est automatiquement ajoutée en tête.
            </p>

            <div className="flex flex-col" style={{ gap: '8px', marginBottom: '16px', maxWidth: '500pt' }}>
              {list.map((t, i) => (
                <div key={i} className="flex items-center gap-2" style={{
                  padding: '10px 14px', borderRadius: '12px', backgroundColor: 'rgba(255,255,255,0.85)',
                }}>
                  <span style={{ fontFamily: 'monospace', color: 'rgba(0,0,0,0.4)', minWidth: '28px', fontSize: '12px' }}>{i + 1}.</span>
                  <span style={{ flex: 1, fontSize: '14px', fontWeight: 700, color: 'rgba(0,0,0,0.8)' }}>{t}</span>
                  <button type="button" onClick={() => move(i, -1)} disabled={i === 0}
                    className="flex items-center justify-center transition-colors hover:bg-black/10 disabled:opacity-30"
                    style={{ width: '32px', height: '32px', borderRadius: '50%', border: 'none', backgroundColor: 'transparent', color: 'rgba(0,0,0,0.6)', cursor: i === 0 ? 'not-allowed' : 'pointer' }}
                    title="Monter"><ArrowUpIcon style={{ width: '14px', height: '14px' }} /></button>
                  <button type="button" onClick={() => move(i, 1)} disabled={i === list.length - 1}
                    className="flex items-center justify-center transition-colors hover:bg-black/10 disabled:opacity-30"
                    style={{ width: '32px', height: '32px', borderRadius: '50%', border: 'none', backgroundColor: 'transparent', color: 'rgba(0,0,0,0.6)', cursor: i === list.length - 1 ? 'not-allowed' : 'pointer' }}
                    title="Descendre"><ArrowDownIcon style={{ width: '14px', height: '14px' }} /></button>
                  <button type="button" onClick={() => remove(i)}
                    className="flex items-center justify-center transition-colors hover:bg-red-100"
                    style={{ width: '32px', height: '32px', borderRadius: '50%', border: 'none', backgroundColor: 'transparent', color: '#b91c1c', cursor: 'pointer' }}
                    title="Retirer"><TrashIcon style={{ width: '14px', height: '14px' }} /></button>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-3" style={{ marginBottom: '20px', maxWidth: '500pt' }}>
              <input
                type="text"
                value={draft}
                onChange={e => setDraft(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') add(); }}
                placeholder="Nouvelle taille (ex. XXL, 24, 27.5…)"
                className="flex-1 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                style={{
                  padding: '10px 14px', borderRadius: '12px', border: 'none',
                  backgroundColor: 'rgba(255,255,255,0.85)', color: '#222', fontSize: '14px',
                }}
              />
              <button type="button" onClick={add} disabled={!draft.trim()} className="btn-primary flex items-center gap-2">
                <PlusIcon style={{ width: '18px', height: '18px' }} />
                Ajouter
              </button>
            </div>

            <div className="flex justify-end">
              <button type="button" onClick={handleSave} disabled={saving} className="btn-primary">
                {saving ? 'Sauvegarde…' : 'Sauvegarder'}
              </button>
            </div>

            <div className="text-sm" style={{ color: 'rgba(255,255,255,0.45)', marginTop: '24px', fontStyle: 'italic', maxWidth: '500pt' }}>
              Marques : gérées directement via la création de vélo (bouton "+ nouvelle marque" dans le dropdown marque).
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
