'use client';
import { useMemo, useState } from 'react';
import * as XLSX from 'xlsx';
import AppShell from '@/components/layout/AppShell';
import PageHeader from '@/components/layout/PageHeader';
import { toast } from '@/components/ui/Toast';
import { useClients } from '@/hooks/useClients';
import { useEmailTemplates } from '@/hooks/useEmailTemplates';
import { ArrowUpTrayIcon, CheckCircleIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';

/** Clés de champ cible avec leur label pour le mapping manuel. */
const FIELDS = [
  { key: 'prenom',   label: 'Prénom *',     required: true  },
  { key: 'nom',      label: 'Nom *',        required: true  },
  { key: 'tel',      label: 'Téléphone',    required: false },
  { key: 'courriel', label: 'Courriel',     required: false },
  { key: 'notes',    label: 'Notes',        required: false },
  { key: 'lead',     label: 'Lead',         required: false },
  { key: 'commPref', label: 'Pref. comm',   required: false },
  { key: 'lang',     label: 'Langue',       required: false },
] as const;

type FieldKey = typeof FIELDS[number]['key'];
type ColMap = Partial<Record<FieldKey, number>>;

const AUTO_NAMES: Record<FieldKey, string[]> = {
  prenom  : ['prénom', 'prenom', 'first name', 'first', 'firstname'],
  nom     : ['nom', 'last name', 'last', 'lastname', 'surname'],
  tel     : ['téléphone', 'telephone', 'tel', 'tél', 'phone', 'mobile'],
  courriel: ['courriel', 'email', 'e-mail', 'mail'],
  notes   : ['notes', 'note', 'comments', 'remarques'],
  lead    : ['lead', 'responsable', 'mécanicien'],
  commPref: ['comm', 'pref', 'preference', 'communication'],
  lang    : ['lang', 'langue', 'language'],
};

function autoDetect(headers: string[]): ColMap {
  const result: ColMap = {};
  headers.forEach((h, i) => {
    const norm = h.toLowerCase().trim();
    for (const f of FIELDS) {
      if (result[f.key] !== undefined) continue;
      if (AUTO_NAMES[f.key].some(c => norm === c || norm.includes(c))) {
        result[f.key] = i;
        return;
      }
    }
  });
  return result;
}

interface Row {
  values: Record<FieldKey, string>;
  raw   : unknown[];
  status?: 'pending' | 'ok' | 'skipped' | 'error';
  error?: string;
}

export default function ImportClientsPage() {
  const { grouped, creerClient } = useClients();
  const { tpl } = useEmailTemplates();

  const [headers, setHeaders]   = useState<string[]>([]);
  const [rawRows, setRawRows]   = useState<unknown[][]>([]);
  const [colMap,  setColMap]    = useState<ColMap>({});
  const [fileName, setFileName] = useState('');
  const [importing, setImporting] = useState(false);
  const [statuses, setStatuses] = useState<Row['status'][]>([]);
  const [errors,   setErrors]   = useState<(string | undefined)[]>([]);

  // Ligne mappée = rawRows × colMap
  const rows = useMemo<Row[]>(() =>
    rawRows.map((r, i) => {
      const values: Record<FieldKey, string> = {
        prenom: '', nom: '', tel: '', courriel: '', notes: '', lead: '', commPref: '', lang: '',
      };
      for (const f of FIELDS) {
        const idx = colMap[f.key];
        if (idx != null) values[f.key] = String(r[idx] ?? '').trim();
      }
      return { values, raw: r, status: statuses[i], error: errors[i] };
    }),
  [rawRows, colMap, statuses, errors]);

  async function onFile(file: File) {
    try {
      const buf = await file.arrayBuffer();
      const wb  = XLSX.read(buf, { type: 'array' });
      const ws  = wb.Sheets[wb.SheetNames[0]];
      const arr = XLSX.utils.sheet_to_json<unknown[]>(ws, { header: 1, raw: false, defval: '' });
      if (arr.length < 2) { toast('Fichier vide ou sans données', 'error'); return; }
      const hdr = (arr[0] as string[]).map(s => String(s ?? ''));
      const data = (arr.slice(1) as unknown[][]).filter(r => r.some(c => String(c ?? '').trim()));
      setHeaders(hdr);
      setRawRows(data);
      setColMap(autoDetect(hdr));
      setFileName(file.name);
      setStatuses(new Array(data.length).fill('pending'));
      setErrors(new Array(data.length).fill(undefined));
      toast(`${data.length} ligne(s) détectées · ${hdr.length} colonne(s)`);
    } catch (err: any) {
      toast(err.message || 'Erreur lecture fichier', 'error');
    }
  }

  function setMapping(key: FieldKey, colIdx: string) {
    setColMap(prev => {
      const next = { ...prev };
      if (colIdx === '') delete next[key];
      else next[key] = parseInt(colIdx, 10);
      return next;
    });
  }

  function existing(courriel: string, prenom: string, nom: string): boolean {
    if (!grouped) return false;
    const all = [...grouped.recents, ...grouped.actifs, ...grouped.autres];
    const mailNorm = courriel.toLowerCase().trim();
    return all.some(c => {
      if (mailNorm && (c.courriel ?? '').toLowerCase() === mailNorm) return true;
      if (prenom && nom) {
        return c.prenom?.trim() === prenom && c.nom?.trim() === nom;
      }
      return false;
    });
  }

  async function handleImport() {
    if (colMap.prenom == null || colMap.nom == null) {
      toast('Prénom et nom sont obligatoires — mappe ces colonnes avant l\'import', 'error');
      return;
    }
    setImporting(true);
    const defaults = {
      commPref: tpl('client_default_commpref') || 'Courriel,Texto',
      lang    : (tpl('client_default_lang') === 'EN' ? 'EN' : 'FR') as 'FR' | 'EN',
      lead    : 'Cyclo Flex' as const,
    };
    try {
      for (let i = 0; i < rows.length; i++) {
        const v = rows[i].values;
        if (!v.prenom || !v.nom) {
          setStatuses(s => { const n = [...s]; n[i] = 'error'; return n; });
          setErrors(e  => { const n = [...e]; n[i] = 'Prénom + Nom requis'; return n; });
          continue;
        }
        if (existing(v.courriel, v.prenom, v.nom)) {
          setStatuses(s => { const n = [...s]; n[i] = 'skipped'; return n; });
          setErrors(e  => { const n = [...e]; n[i] = 'Doublon (existe déjà)'; return n; });
          continue;
        }
        try {
          const lang: 'FR' | 'EN' = v.lang.toUpperCase().startsWith('EN') ? 'EN'
            : v.lang.toUpperCase().startsWith('FR') ? 'FR' : defaults.lang;
          const lead: 'Cyclo Flex' | 'yako.cyclo' = v.lead === 'yako.cyclo' ? 'yako.cyclo' : 'Cyclo Flex';
          await creerClient({
            prenom  : v.prenom,
            nom     : v.nom,
            tel     : v.tel,
            courriel: v.courriel,
            notes   : v.notes,
            commPref: v.commPref || defaults.commPref,
            lead,
            lang,
          } as any);
          setStatuses(s => { const n = [...s]; n[i] = 'ok'; return n; });
        } catch (err: any) {
          setStatuses(s => { const n = [...s]; n[i] = 'error'; return n; });
          setErrors(e  => { const n = [...e]; n[i] = err?.message ?? 'Erreur'; return n; });
        }
      }
      const ok      = statuses.filter(s => s === 'ok').length;
      toast(`Import terminé — vérifie le tableau pour le détail`);
    } finally {
      setImporting(false);
    }
  }

  function reset() {
    setHeaders([]); setRawRows([]); setColMap({}); setFileName('');
    setStatuses([]); setErrors([]);
  }

  return (
    <AppShell>
      <div className="p-5 md:pt-[50px]">
        <PageHeader subtitle="paramètres" title="Import clients (CSV / xlsx)" />

        <div className="md:bg-black/20 md:rounded-[50px] md:p-[30px]">
          {!rawRows.length && (
            <label
              className="flex flex-col items-center justify-center gap-3 transition-colors"
              style={{
                padding: '48px 24px', borderRadius: '24px',
                border: '2px dashed rgba(255,255,255,0.35)',
                backgroundColor: 'rgba(255,255,255,0.08)', cursor: 'pointer',
              }}
            >
              <ArrowUpTrayIcon style={{ width: '40px', height: '40px', color: 'rgba(255,255,255,0.7)' }} />
              <div style={{ fontSize: '16px', fontWeight: 700, color: 'rgba(255,255,255,0.85)' }}>
                Déposer un fichier CSV ou xlsx
              </div>
              <div style={{ fontSize: '12px', color: 'rgba(255,255,255,0.55)', textAlign: 'center', maxWidth: '420pt' }}>
                La première ligne doit contenir les en-têtes. Les colonnes sont
                détectées automatiquement mais tu peux les réajuster à l'étape suivante.
              </div>
              <input type="file" accept=".csv,.xlsx,.xls"
                onChange={e => e.target.files?.[0] && onFile(e.target.files[0])}
                style={{ display: 'none' }} />
              <span className="btn-primary">Choisir un fichier</span>
            </label>
          )}

          {rawRows.length > 0 && (
            <div className="flex flex-col" style={{ gap: '20px' }}>
              <div className="flex items-center justify-between">
                <div>
                  <div style={{ fontSize: '14px', fontWeight: 700, color: 'rgba(255,255,255,0.85)' }}>{fileName}</div>
                  <div style={{ fontSize: '12px', color: 'rgba(255,255,255,0.55)' }}>
                    {rawRows.length} ligne(s) · {headers.length} colonne(s) · {Object.keys(colMap).length} champ(s) mappé(s)
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button type="button" onClick={reset} className="btn-secondary">Changer de fichier</button>
                  <button type="button" onClick={handleImport} disabled={importing || colMap.prenom == null || colMap.nom == null} className="btn-primary">
                    {importing ? 'Import en cours…' : `Importer ${rawRows.length} client(s)`}
                  </button>
                </div>
              </div>

              {/* Mapping des colonnes */}
              <div style={{ padding: '16px 20px', borderRadius: '16px', backgroundColor: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)' }}>
                <h3 className="legende" style={{ color: 'rgba(255,255,255,0.7)', marginBottom: '10px', textTransform: 'uppercase', fontSize: '11px', letterSpacing: '0.1em' }}>
                  Mapping des colonnes
                </h3>
                <p className="text-xs" style={{ color: 'rgba(255,255,255,0.5)', marginBottom: '14px' }}>
                  Associe chaque champ cible à une colonne du fichier. Prénom et Nom sont obligatoires.
                </p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {FIELDS.map(f => (
                    <div key={f.key}>
                      <label className="text-xs font-bold uppercase" style={{ color: 'rgba(255,255,255,0.5)', display: 'block', marginBottom: '4px', letterSpacing: '0.04em' }}>
                        {f.label}
                      </label>
                      <select
                        value={colMap[f.key] != null ? String(colMap[f.key]) : ''}
                        onChange={e => setMapping(f.key, e.target.value)}
                        className="text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        style={{
                          width: '100%', backgroundColor: 'rgba(255,255,255,0.85)',
                          color: '#222', borderRadius: '10px', border: 'none', height: '36px',
                        }}
                      >
                        <option value="">— (ignorer)</option>
                        {headers.map((h, i) => (
                          <option key={i} value={String(i)}>{h || `Colonne ${i + 1}`}</option>
                        ))}
                      </select>
                    </div>
                  ))}
                </div>
              </div>

              {/* Preview */}
              <div style={{ border: '1.5px solid rgba(255,255,255,0.15)', borderRadius: '16px', overflow: 'hidden', backgroundColor: 'rgba(255,255,255,0.85)' }}>
                <div className="flex items-center" style={{ padding: '8px 14px', borderBottom: '1px solid rgba(0,0,0,0.08)', fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', color: 'rgba(0,0,0,0.5)', letterSpacing: '0.04em' }}>
                  <div style={{ width: '32px' }} />
                  <div style={{ width: '110px' }}>Prénom</div>
                  <div style={{ width: '110px' }}>Nom</div>
                  <div style={{ width: '110px' }}>Tél.</div>
                  <div style={{ flex: 1 }}>Courriel</div>
                  <div style={{ width: '70px', textAlign: 'center' }}>Statut</div>
                </div>
                <div style={{ maxHeight: '420px', overflowY: 'auto' }}>
                  {rows.map((r, i) => {
                    const statusBg = r.status === 'ok' ? 'rgba(34,197,94,0.12)'
                      : r.status === 'skipped' ? 'rgba(245,158,11,0.12)'
                      : r.status === 'error' ? 'rgba(239,68,68,0.12)'
                      : 'transparent';
                    return (
                      <div key={i} className="flex items-center" style={{
                        padding: '8px 14px', borderBottom: '1px solid rgba(0,0,0,0.05)',
                        backgroundColor: i % 2 === 0 && r.status === 'pending' ? 'rgba(0,0,0,0.02)' : statusBg,
                        fontSize: '12px', color: 'rgba(0,0,0,0.8)',
                      }}>
                        <div style={{ width: '32px', color: 'rgba(0,0,0,0.4)' }}>{i + 1}</div>
                        <div style={{ width: '110px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.values.prenom}</div>
                        <div style={{ width: '110px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.values.nom}</div>
                        <div style={{ width: '110px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontFamily: 'monospace' }}>{r.values.tel}</div>
                        <div style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.values.courriel}</div>
                        <div style={{ width: '70px', textAlign: 'center' }}>
                          {r.status === 'ok' && <span title="Créé" style={{ color: '#166534' }}>✓</span>}
                          {r.status === 'skipped' && <span title={r.error}>—</span>}
                          {r.status === 'error' && <span title={r.error} style={{ color: '#b91c1c' }}>✗</span>}
                          {r.status === 'pending' && <span style={{ color: 'rgba(0,0,0,0.3)' }}>…</span>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center gap-4 text-xs" style={{ color: 'rgba(255,255,255,0.6)' }}>
                <span className="flex items-center gap-1"><CheckCircleIcon style={{ width: '14px', height: '14px', color: '#22c55e' }} />créé</span>
                <span className="flex items-center gap-1"><span style={{ color: '#f59e0b' }}>—</span> ignoré (doublon)</span>
                <span className="flex items-center gap-1"><ExclamationTriangleIcon style={{ width: '14px', height: '14px', color: '#ef4444' }} />erreur</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
