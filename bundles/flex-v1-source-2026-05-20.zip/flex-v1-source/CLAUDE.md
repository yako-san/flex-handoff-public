# Notes pour Claude — repo `flex-rev-app`

Conventions à respecter dans ce repo (override les defaults).

## Communication

- **Travailler en français.** L'utilisateur (yako-san, propriétaire de
  Yako Cyclo, Montréal) communique en français. Les commits, commentaires
  de code et messages utilisateur restent en français. Code identifiers
  et noms de fichiers en anglais comme d'habitude.
- **Pas de validation émotionnelle** (« t'as raison », « excellent »).
  Aller direct sur la rigueur du modèle métier.
- **Valider la cause avant la solution.** Confirmer la racine d'un bug
  avant de coder un fix. Pas d'action sur hypothèse non vérifiée.

## Workflow

- **Version bump auto.** Mention d'un n° de version dans un message
  utilisateur (ex. « v1.1.5 ») = bump auto `APP_VERSION` dans
  `components/layout/AppShell.tsx`.
- **Commit + push direct** après chaque série de modifs, sans demander
  (sauf si la permission Git est bloquée — alors commit seulement et
  attendre que l'utilisateur autorise le push).
- **Section 12 de l'aide** (`docs/tutoriels/12-changements-v2.md`) :
  changelog vivant. Mettre à jour à chaque release significative pour
  faciliter la sync vers le repo v2 (`flex`).

## Tests / Prod

- **JAMAIS toucher les sheets originaux pendant les tests.** Utiliser des
  copies DEV — voir `SHEETS_PIECES_DEV_ID` et la pièce sentinelle
  `_TEST_STOCK_` (P00549) dans le catalogue prod PIÈCES (avec endpoint
  `/api/admin/test-stock` pour vérifier le flux engagement AB/AC).
- **Drive timeouts** : les fichiers Drive timeout souvent — réessayer
  simplement plutôt que de débugger.

## Architecture spécifique

### Modèle stock v7.0.0 (`lib/sheets/reservation.ts`)
Invariant : `AB (stock physique) + AC (réservé)` doit rester constant
à toute mutation. Toute route qui modifie un BDT ou une vente doit :
```ts
const before = await snapshotStock();
// ... mutation ...
await safeRecomputeStockState(before, 'BDT' | 'VENTE' | 'ALL');
```

### Compteurs séquentiels (`lib/sheets/counter.ts`)
- `_PARAMÈTRES_!B2` = compteur ID vélo (`prochainID()`)
- `_PARAMÈTRES_!B3` = compteur facture vente (`prochainFactureNumero()`)
  — malgré le label A3 trompeur « Email — Pièces à commander ».
- Protégés v1.1.3+ par Mutex local + lock distribué Vercel KV.

### Pattern routes admin
```ts
const check = await requireAdmin();
if (!check.ok) {
  return NextResponse.json(
    { error: check.error, code: 'ADMIN_REQUIRED' },
    { status: check.status },  // 401 ou 403
  );
}
```
Le fail-safe `yako.cyclo@gmail.com` est toujours admin même si le sheet
des admin_emails est cassé.

### Pattern `_ensureTab()` + migration grille
Les onglets sont créés à la demande. Si le schéma évolue (nouvelles
colonnes), `_ensureTab()` étend la grille via `appendDimension` puis
réécrit le header. Voir `lib/sheets/depenses.ts` (cas v1.1.1) et
`lib/sheets/po.ts` (cas v1.1.3 — col P stockSyncedAt).

### Entités fiscales
- **Yako Cyclo** = travailleur autonome (TA) — entité fiscale active.
- **Cyclo Flex** = corp incorporée — n'est plus utilisée dans le système.

## Pas dans ce repo

- **`yako.ca`** : le site marketing public, ailleurs.
- **`flex`** : le repo v2 SaaS multi-tenant en cours (Postgres). On y
  porte les features post-v1.0.0 via la section 12 du tutoriel.

## Topbar mobile

Pas de sous-menu sur mobile. Logo = reload direct, aucun dropdown.

## Typage (convention v1.1.8+)

- **Session NextAuth** : `types/next-auth.d.ts` augmente `Session` et
  `JWT` avec `googleAccessToken` / `googleRefreshToken`. Plus besoin du
  cast `(session as any).googleAccessToken` — accède direct
  `session?.googleAccessToken`.
- **`catch (err: unknown)`** est la cible. Le helper
  `errMessage(err)` dans `lib/errors.ts` extrait un message safe. Les
  ~252 `catch (err: any)` existants seront migrés au fil des refactors —
  ne PAS rajouter de nouveau `: any` sur un catch.
- **Validation body** : utilise `parseBody(req, schema)` de
  `lib/validate.ts` au lieu de `await req.json() as Foo`.
