'use client';
import { useEffect, useMemo, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Link from 'next/link';
import Modal from '@/components/ui/Modal';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import VeloForm from '@/components/inventaire/VeloForm';
import { mutate as swrMutate } from 'swr';
import { useClients } from '@/hooks/useClients';
import { useInventaire } from '@/hooks/useInventaire';
import { useEmailTemplates } from '@/hooks/useEmailTemplates';
import { useArchives } from '@/hooks/useArchives';
import ArchiveDetailModal from '@/components/archives/ArchiveDetailModal';
import { toast } from '@/components/ui/Toast';
import { PlusIcon, ArrowTopRightOnSquareIcon, TrashIcon } from '@heroicons/react/24/outline';
import { STATUTS } from '@/lib/utils/statuts';
import { frDate } from '@/lib/utils/format';
import type { Client } from '@/types/client';

const schema = z.object({
  prenom    : z.string().min(1, 'Requis'),
  nom       : z.string().min(1, 'Requis'),
  tel       : z.string().optional(),
  // Indicatif pays E.164 — default '+1' (Canada/USA)
  indicatif : z.string().default('+1'),
  courriel  : z.string().email('Courriel invalide').optional().or(z.literal('')),
  commPref  : z.string(), // liste comma-separated : "Courriel,Texto"
  lead      : z.enum(['Cyclo Flex', 'yako.cyclo']),
  lang      : z.enum(['FR', 'EN']),
  notes     : z.string().optional(),
  // % de remise par défaut — 0 signifie "pas de remise"
  remise    : z.coerce.number().int().min(0).max(100).default(0),
  // Adresse postale (livraison/ramassage) — texte libre multi-ligne
  adressePostale: z.string().optional(),
  // v1.1.11+ : facturation employeur (rare — cas corporatif)
  entrepriseName   : z.string().optional(),
  entrepriseAdresse: z.string().optional(),
});

// Indicatifs pays proposés. Si pays absent → l'utilisateur tape +XX dans le tel
// (le helper telE164 respecte un + en début de raw).
const INDICATIFS = [
  { value: '+1',  label: '🇨🇦 +1' },
  { value: '+1',  label: '🇺🇸 +1' },
  { value: '+33', label: '🇫🇷 +33' },
  { value: '+32', label: '🇧🇪 +32' },
  { value: '+41', label: '🇨🇭 +41' },
  { value: '+44', label: '🇬🇧 +44' },
  { value: '+49', label: '🇩🇪 +49' },
  { value: '+34', label: '🇪🇸 +34' },
  { value: '+39', label: '🇮🇹 +39' },
] as const;

type FormData = z.infer<typeof schema>;

interface ClientFormProps {
  open: boolean;
  onClose: () => void;
  onCreated?: (nom: string) => void;
  /** Si fourni, le formulaire est en mode édition (pré-remplit + PATCH au submit) */
  editClient?: Client | null;
}

export default function ClientForm({ open, onClose, onCreated, editClient }: ClientFormProps) {
  const { creerClient, patchClient, grouped, removeClientBdc } = useClients();
  const { velos } = useInventaire();
  const { bdcs: archivedBdcs } = useArchives();
  const isEdit = !!editClient;

  // Version "live" du client : re-résolue depuis le cache SWR pour refléter
  // les modifs en cours (suppression BDT, update). Fallback sur le prop si
  // absent (ex. juste avant la fermeture du modal).
  const liveClient = useMemo<Client | null>(() => {
    if (!editClient) return null;
    const all = [
      ...(grouped?.recents ?? []),
      ...(grouped?.actifs  ?? []),
      ...(grouped?.autres  ?? []),
    ];
    return all.find(c => c._row === editClient._row) ?? editClient;
  }, [grouped, editClient]);

  // Liste unifiée des BDT du client (actifs INVENTAIRE + archivés) à partir
  // de liveClient.bdcIds (source de vérité enrichie côté serveur, toujours
  // à jour après une suppression).
  const clientBdts = useMemo(() => {
    if (!liveClient) return [];
    // Dédoublonne les bdcIds — la col I de CLIENTS peut contenir un même
    // ID plusieurs fois suite à un cycle archive/désarchive corrompu.
    const uniqueIds = [...new Set(liveClient.bdcIds.map(id => id.trim()).filter(Boolean))];
    return uniqueIds.map(id => {
      // ⚠ Priorité ARCHIVES > ACTIVE : si un BDT existe dans les deux
      // sources (data corrompue), on affiche son état terminal (archivé)
      // qui est la source de vérité métier. Sinon le pill montrerait
      // 'WIP vert' alors que le BDT est facturé/archivé/refusé.
      const arch = archivedBdcs.find(b => b.id === id);
      if (arch) {
        const [marque, modele, couleur, taille] = (arch.veloDesc || '')
          .split(',').map(s => s.trim());
        return {
          id,
          marque : marque  || '',
          modele : modele  || '',
          couleur: couleur || '',
          taille : taille  || '',
          status : arch.archiveStatus || 'ARCHIVÉ',
          dateIn : frDate(arch.dateIn),
          isActive: false,
          isGhost : false,
          _veloRow: null as number | null,
          _archiveRow: arch._bonRow,  // pour DELETE /api/archives
        };
      }
      const v = velos.find(vv => vv.id === id);
      if (v) {
        return {
          id,
          marque : v.marque,
          modele : v.modele,
          couleur: v.couleur,
          taille : v.taille,
          status : v.status,
          dateIn : frDate(v.date1),
          isActive: true,
          isGhost : false,
          _veloRow: v._row,
          _archiveRow: null as number | null,
        };
      }
      // Référence orpheline (ID dans CLIENTS col I mais ni actif ni archivé)
      return {
        id, marque: '', modele: '', couleur: '', taille: '',
        status: 'fantôme', dateIn: '', isActive: false, isGhost: true,
        _veloRow: null as number | null, _archiveRow: null as number | null,
      };
    });
  }, [liveClient, velos, archivedBdcs]);

  // Après création réussie, on garde le nom pour proposer d'enchaîner avec
  // la création d'un vélo via VeloForm (initialClient pré-rempli).
  const [createdNom, setCreatedNom] = useState<string | null>(null);
  const [showVeloForm, setShowVeloForm] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<{ id: string; isActive: boolean; isGhost?: boolean } | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [archiveDetail, setArchiveDetail] = useState<typeof archivedBdcs[number] | null>(null);

  async function doDeleteBdt() {
    if (!confirmDelete || !editClient) return;
    const id = confirmDelete.id;
    setDeleting(true);
    try {
      if (confirmDelete.isGhost) {
        // Référence orpheline : pas de BDT à supprimer, on retire juste
        // l'ID de la liste CLIENTS col I/J via removeClientBdc.
        await removeClientBdc(editClient._row, id);
        toast(`Référence fantôme ${id} retirée`);
      } else {
        const res = await fetch(`/api/bdc/${id}`, { method: 'DELETE' });
        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          throw new Error(err.error || 'Échec de la suppression');
        }
        toast(`BDT ${id} supprimé`);
      }
      await swrMutate(() => true, undefined, { revalidate: true });
      setConfirmDelete(null);
    } catch (err: any) {
      toast(err.message || 'Échec de la suppression', 'error');
    } finally {
      setDeleting(false);
    }
  }

  // Mécanicien par défaut pour les nouveaux clients : dérivé de l'email
  // de session. yako.cyclo@gmail.com → lead 'yako.cyclo', sinon fallback
  // 'Cyclo Flex' (catch-all atelier). Les valeurs du schema ne changent
  // pas : si l'email local n'est pas 'yako.cyclo', on reste sur Flex.
  const { data: session } = useSession();
  const defaultLead = useMemo<'Cyclo Flex' | 'yako.cyclo'>(() => {
    const email = session?.user?.email ?? '';
    const local = email.split('@')[0].toLowerCase();
    if (local === 'yako.cyclo' || local === 'yako') return 'yako.cyclo';
    return 'Cyclo Flex';
  }, [session?.user?.email]);

  // Préférences défaut éditables dans /parametres/atelier
  const { tpl } = useEmailTemplates();
  const defaultCommPref = tpl('client_default_commpref') || 'Courriel,Texto';
  const defaultLang     = (tpl('client_default_lang') === 'EN' ? 'EN' : 'FR') as 'FR' | 'EN';

  const { register, handleSubmit, reset, watch, setValue, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { commPref: defaultCommPref, lead: defaultLead, lang: defaultLang, indicatif: '+1' },
  });

  // Pré-remplit en mode édition à chaque ouverture / changement de client
  useEffect(() => {
    if (open && editClient) {
      reset({
        prenom   : editClient.prenom    ?? '',
        nom      : editClient.nom       ?? '',
        tel      : editClient.tel       ?? '',
        indicatif: editClient.indicatif ?? '+1',
        courriel : editClient.courriel  ?? '',
        commPref : (editClient.commPref as any) || defaultCommPref,
        lead     : (editClient.lead as any)     || defaultLead,
        lang     : (editClient.lang as any)     || defaultLang,
        notes    : editClient.notes ?? '',
        remise   : editClient.remise ?? 0,
        adressePostale   : editClient.adressePostale ?? '',
        entrepriseName   : editClient.entrepriseName ?? '',
        entrepriseAdresse: editClient.entrepriseAdresse ?? '',
      });
    } else if (open && !editClient) {
      reset({ prenom: '', nom: '', tel: '', indicatif: '+1', courriel: '', commPref: defaultCommPref, lead: defaultLead, lang: defaultLang, notes: '', remise: 0, adressePostale: '', entrepriseName: '', entrepriseAdresse: '' });
      setCreatedNom(null);
    }
  }, [open, editClient, reset, defaultLead, defaultCommPref, defaultLang]);

  async function onSubmit(data: FormData) {
    try {
      if (isEdit && editClient) {
        await patchClient(editClient._row, data as any);
        toast(`Client ${data.prenom} ${data.nom} mis à jour`);
        onClose();
      } else {
        const client = await creerClient(data as any);
        toast(`Client ${client.nomComplet} créé`);
        onCreated?.(client.nomComplet);
        // Au lieu de fermer tout de suite, on affiche un bouton "Nouveau
        // vélo pour ${nom}" qui ouvre VeloForm avec le client pré-rempli.
        setCreatedNom(client.nomComplet);
      }
    } catch (err: any) {
      toast(err.message, 'error');
    }
  }

  function handleFermer() {
    setCreatedNom(null);
    reset();
    onClose();
  }

  // Étape post-création : client créé, on propose d'enchaîner avec un vélo.
  if (createdNom && !isEdit) {
    return (
      <>
        <Modal open={open && !showVeloForm} onClose={handleFermer} title="Client créé" size="lg">
          <div className="space-y-4">
            <p className="text-sm" style={{ color: 'rgba(0,0,0,0.65)' }}>
              Le client <strong>{createdNom}</strong> a été créé avec succès.
            </p>
            <p className="text-sm" style={{ color: 'rgba(0,0,0,0.5)' }}>
              Souhaitez-vous ajouter un vélo pour ce client maintenant ?
            </p>
            <div className="flex justify-end pt-2">
              <button type="button" onClick={handleFermer} className="btn-primary">
                OK
              </button>
            </div>
          </div>
        </Modal>
        <VeloForm
          open={showVeloForm}
          initialClient={createdNom}
          onClose={() => { setShowVeloForm(false); handleFermer(); }}
          onCreated={() => { setShowVeloForm(false); handleFermer(); }}
        />
      </>
    );
  }

  return (
    <Modal open={open} onClose={onClose} title={isEdit ? 'Modifier client' : 'Nouveau client'} size="lg">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <h4 style={{ fontSize: '14px', fontWeight: 700, color: 'rgba(0,0,0,0.7)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Fiche contact
        </h4>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label-system">prénom *</label>
            <input {...register('prenom')} className="input-system" />
            {errors.prenom && <p className="text-xs text-red-500 mt-1">{errors.prenom.message}</p>}
          </div>
          <div>
            <label className="label-system">nom *</label>
            <input {...register('nom')} className="input-system" />
            {errors.nom && <p className="text-xs text-red-500 mt-1">{errors.nom.message}</p>}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label-system">téléphone</label>
            <div className="flex gap-2">
              <select {...register('indicatif')} className="input-system" style={{ width: '110px', flexShrink: 0 }}>
                {INDICATIFS.map(i => (
                  <option key={i.value} value={i.value}>{i.label}</option>
                ))}
              </select>
              <input {...register('tel')} type="tel" className="input-system" style={{ flex: 1, minWidth: 0 }} />
            </div>
          </div>
          <div>
            <label className="label-system">courriel</label>
            <input {...register('courriel')} type="email" className="input-system" />
            {errors.courriel && <p className="text-xs text-red-500 mt-1">{errors.courriel.message}</p>}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="label-system">communication</label>
            <CommPrefChecks
              value={watch('commPref') || ''}
              onChange={v => setValue('commPref', v, { shouldValidate: true, shouldDirty: true })}
            />
          </div>
          <div>
            <label className="label-system">lead</label>
            <select {...register('lead')} className="input-system">
              <option>Cyclo Flex</option>
              <option>yako.cyclo</option>
            </select>
          </div>
          <div>
            <label className="label-system">langue</label>
            <select {...register('lang')} className="input-system">
              <option value="FR">Français</option>
              <option value="EN">English</option>
            </select>
          </div>
        </div>

        <div>
          <label className="label-system">remise par défaut (appliquée sur les prochaines factures)</label>
          <select {...register('remise', { valueAsNumber: true })} className="input-system">
            <option value={0}>0 % (pas de remise)</option>
            <option value={10}>10 %</option>
            <option value={15}>15 %</option>
            <option value={25}>25 %</option>
            <option value={50}>50 %</option>
          </select>
        </div>

        <div>
          <label className="label-system">adresse postale</label>
          <textarea
            {...register('adressePostale')}
            rows={2}
            className="input-system"
            placeholder="Ex. 1234 rue Notre-Dame, Montréal, QC H4C 1H1"
          />
        </div>

        <div>
          <label className="label-system">notes</label>
          <textarea {...register('notes')} rows={2} className="input-system" />
        </div>

        {/* v1.1.11+ : facturation employeur — rare (cas corporatif). Replié
            par défaut pour ne pas encombrer le formulaire. Visible seulement
            au clic sur le <summary>. Si rempli → ajoute "À l'attention de :"
            sur le PDF facture sous le bloc client. */}
        <details style={{ borderTop: '1px solid rgba(0,0,0,0.08)', paddingTop: '10px' }}>
          <summary
            style={{
              cursor: 'pointer',
              fontSize: '12px',
              fontWeight: 600,
              color: 'rgba(0,0,0,0.55)',
              textTransform: 'uppercase',
              letterSpacing: '0.04em',
              padding: '4px 0',
            }}
          >
            Facturation employeur (optionnel)
          </summary>
          <div className="mt-3 space-y-3">
            <p style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)', lineHeight: 1.4 }}>
              À remplir uniquement si le service comptabilité d'une entreprise
              tierce demande à figurer sur la facture. Apparaîtra sur le PDF
              sous la mention « À l'attention de ».
            </p>
            <div>
              <label className="label-system">nom de l'employeur</label>
              <input
                {...register('entrepriseName')}
                className="input-system"
                placeholder="Ex. Société XYZ Inc."
              />
            </div>
            <div>
              <label className="label-system">adresse de l'employeur</label>
              <textarea
                {...register('entrepriseAdresse')}
                rows={2}
                className="input-system"
                placeholder="Ex. 456 boul. de l'Employeur, Montréal, QC, H2X 2X2"
              />
            </div>
          </div>
        </details>

      {/* Vélos + BDTs du client en mode édition */}
      {isEdit && editClient && (
        <div className="pt-6 mt-4" style={{ borderTop: '1px solid rgba(0,0,0,0.1)' }}>
          <div className="flex items-center justify-between mb-3">
            <h4 style={{ fontSize: '14px', fontWeight: 700, color: 'rgba(0,0,0,0.7)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              Vélos &amp; BDT ({clientBdts.length})
            </h4>
            <button
              type="button"
              onClick={() => setShowVeloForm(true)}
              className="flex items-center gap-1 text-xs font-bold"
              style={{
                height: '28px', padding: '0 10px', borderRadius: '14px',
                backgroundColor: 'rgba(255,240,86,0.6)',
                color: 'rgba(0,0,0,0.7)', border: 'none', cursor: 'pointer',
              }}
            >
              <PlusIcon style={{ width: '14px', height: '14px' }} />
              Nouveau vélo
            </button>
          </div>
          {clientBdts.length === 0 && (
            <p className="text-xs" style={{ color: 'rgba(0,0,0,0.4)' }}>
              Aucun vélo enregistré pour ce client.
            </p>
          )}
          <div className="flex flex-col" style={{ gap: '5px' }}>
            {clientBdts.map(b => {
              // Couleur simplifiée par catégorie (4 catégories) :
              //   - Fantôme           : gris très clair italique
              //   - Archivé REFUSÉ    : rouge
              //   - Archivé (LIVRÉ…)  : gris
              //   - Actif RV / REÇU   : jaune
              //   - Actif autre (WIP) : vert
              // Normalise le status : retire accents pour matcher REFUS / REÇU
              const raw = (b.status ?? '').toString();
              const norm = raw.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().trim();
              const st = (() => {
                if (b.isGhost)                            return { bg: 'rgba(0,0,0,0.08)', fg: 'rgba(0,0,0,0.45)' };
                if (!b.isActive && /REFUS/.test(norm))    return { bg: '#ffcdd2',          fg: '#b71c1c' };
                if (!b.isActive)                          return { bg: '#e0e0e0',          fg: 'rgba(0,0,0,0.55)' };
                if (norm === 'RV' || norm === 'RECU')     return { bg: '#fff056',          fg: '#000000' };
                return                                         { bg: '#88fa4e',          fg: '#000000' };
              })();
              const bg = st.bg;
              const fg = st.fg;
              // Affichage marque : si BDT actif en RV/REÇU et marque non
              // renseignée (vide / 'Sélection →') → 'RdV*' (tutoriel
              // workflow) jusqu'au passage en ÉVAL.
              const isPreEval = b.isActive && (norm === 'RV' || norm === 'RECU');
              const marqueDisp = (b.marque === '' || b.marque === 'Sélection →' || b.marque === '...')
                ? (isPreEval ? 'RdV*' : '')
                : b.marque;
              const desc = b.isGhost
                ? '(référence orpheline — BDT introuvable)'
                : ([marqueDisp, b.modele, b.couleur, b.taille].filter(Boolean).join(' · ') || '(sans description)');
              return (
                <div
                  key={b.id}
                  className="flex items-center"
                  style={{
                    padding: '2px 14px',
                    backgroundColor: bg,
                    color: fg,
                    borderRadius: '999px',
                    gap: '10px',
                    opacity: b.isGhost ? 0.7 : (b.isActive ? 1 : 0.85),
                    fontStyle: b.isGhost ? 'italic' : 'normal',
                  }}
                >
                  {(() => {
                    const inner = (
                      <>
                        <span
                          style={{
                            fontSize: '13px',
                            fontWeight: 700,
                            fontFamily: 'monospace',
                            minWidth: '50px',
                          }}
                        >
                          {b.id}
                        </span>
                        <span style={{ width: '90px', fontSize: '12px', fontFamily: 'monospace', opacity: 0.75 }}>
                          {b.dateIn || '—'}
                        </span>
                        <span style={{ flex: 1, fontSize: '13px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {desc}
                        </span>
                        <span
                          style={{
                            fontSize: '11px',
                            fontWeight: 700,
                            textTransform: 'uppercase',
                            letterSpacing: '0.04em',
                            opacity: 0.85,
                          }}
                        >
                          {b.status || '—'}
                        </span>
                        {!b.isGhost && (
                          <ArrowTopRightOnSquareIcon style={{ width: '14px', height: '14px', opacity: 0.6 }} />
                        )}
                      </>
                    );
                    if (b.isGhost) {
                      return (
                        <div
                          className="flex items-center"
                          style={{ gap: '10px', flex: '1 1 auto', minWidth: 0 }}
                        >
                          {inner}
                        </div>
                      );
                    }
                    if (!b.isActive) {
                      // BDT archivé → ouvre modal détail (pas de navigation)
                      return (
                        <button
                          type="button"
                          onClick={() => {
                            const arch = archivedBdcs.find(a => a.id === b.id);
                            if (arch) setArchiveDetail(arch);
                          }}
                          className="flex items-center transition-opacity hover:opacity-80"
                          style={{
                            background: 'none', border: 'none', padding: 0,
                            color: 'inherit', cursor: 'pointer',
                            gap: '10px', flex: '1 1 auto', minWidth: 0,
                            textAlign: 'left',
                          }}
                        >
                          {inner}
                        </button>
                      );
                    }
                    return (
                      <Link
                        href={`/inventaire/${b.id}`}
                        onClick={() => onClose()}
                        className="flex items-center transition-opacity hover:opacity-80"
                        style={{
                          textDecoration: 'none',
                          color: 'inherit',
                          gap: '10px',
                          flex: '1 1 auto',
                          minWidth: 0,
                        }}
                      >
                        {inner}
                      </Link>
                    );
                  })()}
                  <button
                    type="button"
                    onClick={() => setConfirmDelete({ id: b.id, isActive: b.isActive, isGhost: b.isGhost })}
                    title={b.isGhost ? `Retirer la référence orpheline ${b.id}` : `Supprimer définitivement ${b.id}`}
                    className="flex items-center justify-center transition-opacity hover:opacity-100"
                    style={{
                      width: '22px',
                      height: '22px',
                      border: 'none',
                      backgroundColor: 'transparent',
                      color: 'inherit',
                      opacity: 0.55,
                      cursor: 'pointer',
                      flexShrink: 0,
                      padding: 0,
                    }}
                  >
                    <TrashIcon style={{ width: '14px', height: '14px' }} />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

        {/* Annuler + Enregistrer en bas du modal */}
        <div className="flex justify-end gap-3 pt-2">
          <button type="button" onClick={onClose} className="btn-secondary">Annuler</button>
          <button type="submit" disabled={isSubmitting} className="btn-primary">
            {isSubmitting
              ? (isEdit ? 'Mise à jour…' : 'Création…')
              : (isEdit ? 'Enregistrer' : 'Créer le client')}
          </button>
        </div>
      </form>

      {/* VeloForm pour ajouter un vélo à ce client depuis le formulaire d'édition */}
      {isEdit && editClient && (
        <VeloForm
          open={showVeloForm}
          initialClient={editClient.nomComplet}
          onClose={() => setShowVeloForm(false)}
          onCreated={() => setShowVeloForm(false)}
        />
      )}

      {/* Détail BDT archivé (lecture seule) */}
      <ArchiveDetailModal
        open={archiveDetail !== null}
        bdc={archiveDetail}
        onClose={() => setArchiveDetail(null)}
      />

      {/* Confirmation suppression BDT */}
      <ConfirmDialog
        open={confirmDelete !== null}
        title={confirmDelete?.isGhost
          ? `Retirer la référence ${confirmDelete?.id ?? ''}`
          : `Supprimer le BDT ${confirmDelete?.id ?? ''} ?`}
        message={
          !confirmDelete
            ? ''
            : confirmDelete.isGhost
              ? `Cette référence pointe vers un BDT introuvable (ni dans INVENTAIRE ni dans ARCHIVES).\n\nElle sera retirée de la fiche ${editClient?.nomComplet ?? ''} (col I de CLIENTS). Aucun BDT n'est supprimé.`
              : `Suppression DÉFINITIVE :\n• Retiré de ${confirmDelete.isActive ? 'INVENTAIRE + lignes BDC' : 'ARCHIVES'}\n• Retiré de la fiche ${editClient?.nomComplet ?? ''}\n• Snapshot conservé dans _BDC_BACKUPS_`
        }
        confirmLabel={deleting ? '…' : (confirmDelete?.isGhost ? 'Retirer' : 'Supprimer')}
        cancelLabel="Annuler"
        danger={!confirmDelete?.isGhost}
        onConfirm={doDeleteBdt}
        onCancel={() => { if (!deleting) setConfirmDelete(null); }}
      />
    </Modal>
  );
}

// ─── Multi-choix pour commPref ─────────────────────────────────────
const COMM_OPTIONS = ['Texto', 'Courriel', 'Téléphone'] as const;

function CommPrefChecks({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const active = new Set(value.split(',').map(s => s.trim()).filter(Boolean));
  const toggle = (opt: string) => {
    const next = new Set(active);
    if (next.has(opt)) next.delete(opt);
    else next.add(opt);
    onChange([...next].join(','));
  };
  return (
    <div className="flex flex-col" style={{ gap: '4px', padding: '4px 0' }}>
      {COMM_OPTIONS.map(opt => {
        const checked = active.has(opt);
        return (
          <label key={opt} className="flex items-center cursor-pointer" style={{ gap: '8px' }}>
            <input
              type="checkbox"
              checked={checked}
              onChange={() => toggle(opt)}
              className="custom-checkbox"
            />
            <span style={{ fontSize: '13px', color: 'rgba(0,0,0,0.75)' }}>{opt}</span>
          </label>
        );
      })}
    </div>
  );
}
