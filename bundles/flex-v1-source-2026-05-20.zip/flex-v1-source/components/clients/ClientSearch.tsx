'use client';
import { useState, useMemo } from 'react';
import { useClients } from '@/hooks/useClients';
import type { Client } from '@/types/client';

interface ClientSearchProps {
  value: string;
  onChange: (nom: string) => void;
  onCreateNew?: () => void;
  placeholder?: string;
}

const SEPARATEURS = {
  recents : '── Derniers créés ──',
  actifs  : '── Actifs ──',
  autres  : '── Autres ──',
};

type Option =
  | { type: 'sep'; label: string }
  | { type: 'client'; client: Client };

export default function ClientSearch({ value, onChange, onCreateNew, placeholder = 'Sélection →' }: ClientSearchProps) {
  const { grouped, isLoading } = useClients();
  const [search, setSearch]    = useState('');
  const [open,   setOpen]      = useState(false);

  const options: Option[] = useMemo(() => {
    if (!grouped) return [];
    const q = search.toLowerCase();

    const filter = (clients: Client[]) =>
      clients.filter(c => !q || c.nomComplet.toLowerCase().includes(q));

    const result: Option[] = [];
    const recents = filter(grouped.recents);
    const actifs  = filter(grouped.actifs);
    const autres  = filter(grouped.autres);

    if (recents.length) {
      result.push({ type: 'sep', label: SEPARATEURS.recents });
      recents.forEach(c => result.push({ type: 'client', client: c }));
    }
    if (actifs.length) {
      result.push({ type: 'sep', label: SEPARATEURS.actifs });
      actifs.forEach(c => result.push({ type: 'client', client: c }));
    }
    if (autres.length) {
      result.push({ type: 'sep', label: SEPARATEURS.autres });
      autres.forEach(c => result.push({ type: 'client', client: c }));
    }
    return result;
  }, [grouped, search]);

  function select(nom: string) {
    onChange(nom);
    setSearch('');
    setOpen(false);
  }

  return (
    <div className="relative">
      <div
        className="flex items-center border rounded-lg px-3 py-2 cursor-pointer bg-white hover:border-blue-400"
        onClick={() => setOpen(v => !v)}
      >
        <span className={`flex-1 text-sm ${value ? 'text-gray-800' : 'text-gray-400'}`}>
          {value || placeholder}
        </span>
        <span className="text-gray-400 text-xs">▾</span>
      </div>

      {open && (
        <div className="absolute z-30 top-full mt-1 left-0 right-0 bg-white border rounded-xl shadow-xl max-h-72 flex flex-col">
          <div className="p-2 border-b">
            <input
              autoFocus
              type="search"
              placeholder="Rechercher…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              onClick={e => e.stopPropagation()}
              className="w-full text-sm px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="overflow-y-auto flex-1">
            {isLoading && <p className="p-3 text-sm text-gray-400">Chargement…</p>}
            {onCreateNew && (
              <button onClick={() => { onCreateNew(); setOpen(false); }}
                className="flex w-full items-center gap-2 px-4 py-2 text-sm text-blue-600 hover:bg-blue-50">
                ＋ Créer un client…
              </button>
            )}
            {options.map((opt, i) =>
              opt.type === 'sep'
                ? <p key={i} className="px-4 py-1 text-xs text-gray-400 bg-gray-50">{opt.label}</p>
                : (
                  <button key={i} onClick={() => select(opt.client.nomComplet)}
                    className={`flex w-full items-center px-4 py-2 text-sm hover:bg-blue-50 text-left ${opt.client.nomComplet === value ? 'font-semibold text-blue-600' : 'text-gray-700'}`}>
                    {opt.client.nomComplet}
                  </button>
                )
            )}
          </div>
        </div>
      )}
    </div>
  );
}
