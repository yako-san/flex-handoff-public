'use client';
/**
 * Affiche les préférences de communication d'un client sous forme
 * d'icônes (Courriel = ✉️, Texto = 💬, Téléphone = 📞).
 *
 * Le champ commPref est une chaîne CSV : "Courriel,Texto" ou
 * "Téléphone" etc.
 */
import { EnvelopeIcon, ChatBubbleLeftRightIcon, PhoneIcon } from '@heroicons/react/24/outline';

interface CommPrefIconsProps {
  /** Chaîne CSV des préférences (ex. "Courriel,Texto") */
  value     : string | undefined | null;
  /** Taille des icônes en px (défaut 16) */
  size      ?: number;
  /** Couleur des icônes (défaut gris foncé) */
  color     ?: string;
  /** Espacement entre icônes (défaut 6px) */
  gap       ?: number;
}

const ICONS = [
  { match: /courriel|email/i,       Icon: EnvelopeIcon,           label: 'Courriel'  },
  { match: /texto|sms/i,            Icon: ChatBubbleLeftRightIcon, label: 'Texto'     },
  { match: /t[ée]l[ée]phone|phone/i, Icon: PhoneIcon,              label: 'Téléphone' },
];

export default function CommPrefIcons({ value, size = 16, color = 'rgba(0,0,0,0.55)', gap = 6 }: CommPrefIconsProps) {
  const csv = (value ?? '').trim();
  if (!csv) {
    return <span style={{ color: 'rgba(0,0,0,0.25)' }}>—</span>;
  }
  const matched = ICONS.filter(({ match }) => match.test(csv));
  if (matched.length === 0) {
    return <span style={{ color: 'rgba(0,0,0,0.25)' }}>—</span>;
  }
  return (
    <span className="inline-flex items-center" style={{ gap: `${gap}px` }}>
      {matched.map(({ Icon, label }) => (
        <Icon
          key={label}
          title={label}
          style={{ width: `${size}px`, height: `${size}px`, color }}
        />
      ))}
    </span>
  );
}
