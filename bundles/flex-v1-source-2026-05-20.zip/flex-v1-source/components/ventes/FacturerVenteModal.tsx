'use client';
import { useState, useEffect } from 'react';
import Modal from '@/components/ui/Modal';
import { frPrix } from '@/lib/utils/format';
import type { Vente } from '@/types/vente';

export type ModePaiement = 'comptant' | 'interac' | 'cartes';

export interface FacturerVenteSubmit {
  noteClient   : string;
  lang         : 'FR' | 'EN';
  remisePce    : { type: 'pct' | 'fixed'; value: number };
  modePaiement : ModePaiement;
  generatePdf  : boolean;  // Walk-in : false par défaut. Autres : toujours true.
  /** v1.0.25+ : si true, statut journal = PAYÉ direct (au lieu d'ÉMIS) */
  payeMaintenant: boolean;
}

/** Taux TPS / TVQ Québec — appliqués TOUJOURS (LTA art. 165 + LTVQ art. 16). */
const TAUX_TPS = 0.05;
const TAUX_TVQ = 0.09975;
const round2 = (n: number) => Math.round(n * 100) / 100;

interface Props {
  open        : boolean;
  onClose     : () => void;
  vente       : Vente | null;
  /** Langue préférée du client (si connue) — pré-remplit le toggle FR/EN */
  clientLang? : 'FR' | 'EN';
  submitting  : boolean;
  onSubmit    : (v: FacturerVenteSubmit) => void | Promise<void>;
}

function computeMontantRemise(total: number, remise: { type: 'pct' | 'fixed'; value: number }): number {
  if (!remise || remise.value <= 0) return 0;
  if (remise.type === 'pct') return Math.round(total * remise.value) / 100;
  return Math.min(remise.value, total);
}

export default function FacturerVenteModal({
  open, onClose, vente, clientLang, submitting, onSubmit,
}: Props) {
  // Cas walk-in : UI simplifiée (pas de langue, pas de note client, mode
  // par défaut Interac, total en gros, bouton « Payé » à la place de
  // « Facturer »).
  const isWalkin = vente?.client === 'Walk-in';

  const [noteClient,    setNoteClient]    = useState('');
  const [lang,          setLang]          = useState<'FR' | 'EN'>(clientLang ?? 'FR');
  const [remiseType,    setRemiseType]    = useState<'pct' | 'fixed'>('pct');
  const [remiseVal,     setRemiseVal]     = useState<string>('');
  const [modePaiement,  setModePaiement]  = useState<ModePaiement>('comptant');
  // Walk-in : par défaut PAS de PDF (transaction comptabilisée seulement).
  // L'utilisateur peut activer le toggle pour générer un reçu PDF si demandé.
  const [generatePdf,   setGeneratePdf]   = useState<boolean>(true);
  // v1.0.25+ : « Payé maintenant » coché par défaut pour walk-in (paiement
  // immédiat sur place). Décoché pour ventes différées (client connu paie
  // plus tard). Détermine le statut initial du journal (PAYÉ vs ÉMIS).
  const [payeMaintenant, setPayeMaintenant] = useState<boolean>(true);

  // Reset à chaque ouverture
  useEffect(() => {
    if (open) {
      setNoteClient('');
      setLang(clientLang ?? 'FR');
      setRemiseType('pct');
      setRemiseVal('');
      setModePaiement(isWalkin ? 'interac' : 'comptant');
      setGeneratePdf(!isWalkin);  // Walk-in OFF par défaut, autres ON.
      setPayeMaintenant(isWalkin); // Walk-in = payé cash immédiat. Autres = à valider.
    }
  }, [open, clientLang, isWalkin]);

  const total         = vente?.total ?? 0;
  const remisePce     = { type: remiseType, value: parseFloat(remiseVal) || 0 };
  const montantRemise = computeMontantRemise(total, remisePce);
  const sousTotal     = Math.max(0, total - montantRemise);
  // Taxes Québec : toujours appliquées (peu importe le mode de paiement),
  // conformément à LTA art. 165 + LTVQ art. 16. Aligné avec le backend
  // factures.ts post-patch P0-2 (audit comptable 2026-04-28).
  const tps           = round2(sousTotal * TAUX_TPS);
  const tvq           = round2(sousTotal * TAUX_TVQ);
  const taxes         = round2(tps + tvq);
  const grandTotal    = round2(sousTotal + taxes);

  function handleSubmit() {
    onSubmit({ noteClient: noteClient.trim(), lang, remisePce, modePaiement, generatePdf, payeMaintenant });
  }

  if (!vente) return null;

  return (
    <Modal open={open} onClose={onClose} title="Facturer la vente" size="md">
      <div className="flex flex-col" style={{ gap: '16px' }}>

        {/* Rappel vente */}
        <div style={{
          backgroundColor: 'rgba(0,0,0,0.04)',
          borderRadius: '12px',
          padding: '12px 14px',
          fontSize: '13px',
          color: 'rgba(0,0,0,0.7)',
        }}>
          <div><strong>Client :</strong> {vente.client || '—'}</div>
          <div><strong>Date :</strong> {vente.date}</div>
          <div><strong>Items :</strong> {vente.items.length} · {frPrix(total)}</div>
        </div>

        {/* Langue (caché en mode walk-in) */}
        {!isWalkin && (
          <div>
            <label className="label-system">langue du courriel</label>
            <div className="flex items-center" style={{ gap: '6px' }}>
              {(['FR', 'EN'] as const).map(L => (
                <button
                  key={L}
                  type="button"
                  onClick={() => setLang(L)}
                  disabled={submitting}
                  className="flex items-center justify-center whitespace-nowrap"
                  style={{
                    height: '32px',
                    padding: '0 14px',
                    borderRadius: '32px',
                    fontSize: '13px',
                    fontWeight: 700,
                    border: 'none',
                    cursor: submitting ? 'not-allowed' : 'pointer',
                    backgroundColor: lang === L ? '#fff056' : 'rgba(0,0,0,0.08)',
                    color: lang === L ? '#000' : 'rgba(0,0,0,0.5)',
                  }}
                >
                  {L}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Mode de paiement */}
        <div>
          <label className="label-system">mode de paiement</label>
          <div className="flex items-center" style={{ gap: '6px' }}>
            {([
              { value: 'comptant', label: 'Comptant' },
              { value: 'interac',  label: 'Interac' },
              { value: 'cartes',   label: 'Carte' },
            ] as const).map(opt => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setModePaiement(opt.value)}
                disabled={submitting}
                className="flex items-center justify-center whitespace-nowrap"
                style={{
                  height: '32px',
                  padding: '0 14px',
                  borderRadius: '32px',
                  fontSize: '13px',
                  fontWeight: 700,
                  border: 'none',
                  cursor: submitting ? 'not-allowed' : 'pointer',
                  backgroundColor: modePaiement === opt.value ? '#fff056' : 'rgba(0,0,0,0.08)',
                  color: modePaiement === opt.value ? '#000' : 'rgba(0,0,0,0.5)',
                }}
              >
                {opt.label}
              </button>
            ))}
          </div>
          {/* v1.0.25+ : « Payé maintenant » — coché par défaut pour walk-in.
              Si coché, le journal écrit statut=PAYÉ direct au lieu d'ÉMIS,
              évite de devoir éditer le sheet manuellement plus tard. */}
          <label
            className="flex items-center gap-2 cursor-pointer"
            style={{ marginTop: '10px', userSelect: 'none' }}
            title="Coche si le client paye maintenant (statut PAYÉ direct au journal)"
          >
            <input
              type="checkbox"
              checked={payeMaintenant}
              onChange={e => setPayeMaintenant(e.target.checked)}
              disabled={submitting}
              className="custom-checkbox"
            />
            <span style={{ fontSize: '13px', fontWeight: 600, color: 'rgba(0,0,0,0.7)' }}>
              Payé maintenant
            </span>
            <span style={{ fontSize: '11px', color: 'rgba(0,0,0,0.45)' }}>
              (statut = PAYÉ au journal)
            </span>
          </label>
        </div>

        {/* Note client (caché en mode walk-in) */}
        {!isWalkin && (
          <div>
            <label className="label-system">note client (optionnelle)</label>
            <textarea
              value={noteClient}
              onChange={e => setNoteClient(e.target.value)}
              disabled={submitting}
              className="input-system"
              rows={3}
              placeholder="Message inclus dans le courriel de facture…"
              style={{ resize: 'vertical', minHeight: '70px' }}
            />
          </div>
        )}

        {/* Remise */}
        <div>
          <label className="label-system">remise (optionnelle)</label>
          <div className="flex items-center" style={{ gap: '8px' }}>
            <input
              type="number"
              min={0}
              max={remiseType === 'pct' ? 100 : undefined}
              step={remiseType === 'pct' ? 5 : 1}
              value={remiseVal}
              onChange={e => setRemiseVal(e.target.value)}
              disabled={submitting}
              className="input-system"
              placeholder="0"
              style={{ width: '110px', textAlign: 'right' }}
            />
            <button
              type="button"
              onClick={() => setRemiseType(t => t === 'pct' ? 'fixed' : 'pct')}
              disabled={submitting}
              className="flex items-center justify-center"
              style={{
                height: '32px',
                width: '40px',
                borderRadius: '32px',
                border: '1.5px solid rgba(0,0,0,0.3)',
                background: 'transparent',
                fontSize: '14px',
                fontWeight: 700,
                color: 'rgba(0,0,0,0.7)',
                cursor: submitting ? 'not-allowed' : 'pointer',
              }}
              title={remiseType === 'pct' ? 'Basculer en montant fixe ($)' : 'Basculer en pourcentage (%)'}
            >
              {remiseType === 'pct' ? '%' : '$'}
            </button>
            {montantRemise > 0 && (
              <span className="text-xs font-medium" style={{ color: '#dc2626' }}>
                − {frPrix(montantRemise)}
              </span>
            )}
          </div>
        </div>

        {/* Toggle PDF — Walk-in : OFF par défaut (vente comptabilisée
            sans reçu papier). ON si demandé. Label court qui ne overflow
            pas sur mobile. */}
        {isWalkin && (
          <div>
            <label className="label-system flex items-center" style={{ gap: '10px', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={generatePdf}
                onChange={e => setGeneratePdf(e.target.checked)}
                disabled={submitting}
                className="custom-checkbox"
              />
              <span>{generatePdf ? 'Avec reçu PDF' : 'Sans reçu PDF'}</span>
            </label>
          </div>
        )}

        {/* Aperçu totaux — TPS et TVQ ventilées, total en gros pour walk-in */}
        <div style={{
          backgroundColor: 'rgba(255,240,86,0.25)',
          borderRadius: '12px',
          padding: '12px 14px',
          fontSize: '13px',
        }}>
          <div className="flex justify-between" style={{ color: 'rgba(0,0,0,0.6)' }}>
            <span>Sous-total</span>
            <span>{frPrix(sousTotal)}</span>
          </div>
          {montantRemise > 0 && (
            <div className="flex justify-between" style={{ color: '#dc2626' }}>
              <span>Remise</span>
              <span>− {frPrix(montantRemise)}</span>
            </div>
          )}
          <div className="flex justify-between" style={{ color: 'rgba(0,0,0,0.6)' }}>
            <span>TPS (5 %)</span>
            <span>+ {frPrix(tps)}</span>
          </div>
          <div className="flex justify-between" style={{ color: 'rgba(0,0,0,0.6)' }}>
            <span>TVQ (9,975 %)</span>
            <span>+ {frPrix(tvq)}</span>
          </div>
          <div className="flex justify-between" style={{
            marginTop: '8px',
            paddingTop: '8px',
            borderTop: '1px solid rgba(0,0,0,0.15)',
            fontSize: isWalkin ? '24px' : '15px',
            fontWeight: 700,
            color: 'rgba(0,0,0,0.85)',
          }}>
            <span>Total</span>
            <span>{frPrix(grandTotal)}</span>
          </div>
        </div>

        {/* Actions — pas de bouton Annuler, le X du modal en haut sert. */}
        <div className="flex items-center gap-3" style={{ paddingTop: '8px' }}>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={submitting}
            className="btn-primary ml-auto"
          >
            {submitting ? '…' : (isWalkin ? 'Payé' : 'Facturer')}
          </button>
        </div>

      </div>
    </Modal>
  );
}
