'use client';
import React from 'react';
import HelpHint from '@/components/ui/HelpHint';

/**
 * PageHeader — En-tête de page avec titre, sous-titre et toolbar.
 *
 * Design system v5.4 :
 * - Titre 60pt jaune, thin Helvetica
 * - Sous-titre 20pt bold blanc 50%
 * - Bloc toolbar : hauteur 80pt, fond rgba(0,0,0,0.20), centré sur le titre
 * - Boutons sous-menu : 50pt de haut, texte 20pt
 *   - off : blanc 30%, hover : blanc 60%, actif : jaune
 * - Boutons (+) : 80pt rond jaune, + 42pt bold
 * - Bouton sync/utilitaire : 50pt outline jaune 2pt, icône 30pt
 * - Écarts entre éléments : 10pt
 * - Sans sous-menu : icônes dans le bloc foncé 80pt
 */

interface PageHeaderProps {
  /** Sous-titre en haut (ex: "commandes fournisseurs") */
  subtitle?: string;
  /** Titre principal (ex: "Réception") */
  title: string;
  /** Suffixe du titre en plus petit (ex: "/fournisseurs") */
  titleSuffix?: string;
  /** Contenu du toolbar (boutons, tabs, recherche) */
  children?: React.ReactNode;
  /** Slug du tutoriel d'aide associé (ex: "04-dashboard"). Si défini,
   *  un (?) en exposant apparaît à côté du titre, ouvre le popover HelpHint. */
  helpTopic?: string;
  /** Phrase d'aide affichée dans la bulle (1-2 phrases). */
  helpHint?: React.ReactNode;
  /** Titre de la bulle d'aide. Défaut : "Aide". */
  helpTitle?: string;
  /** Texte ajouté après le (?) HelpHint, dans la même ligne que le titre,
   *  en plus petit (utile pour ex. marque/modèle d'un BDT). */
  titleAfterHelp?: string;
}

export default function PageHeader({ subtitle, title, titleSuffix, children, helpTopic, helpHint, helpTitle = 'Aide', titleAfterHelp }: PageHeaderProps) {
  return (
    <div
      // -mx-0 md:-mx-5 : pas de marge négative sur mobile (sinon le
      // bouton + en bout de toolbar débordait du viewport et était
      // clippé). Sur desktop, on garde -20px pour étendre le fond gris.
      className="flex flex-col md:flex-row items-start md:items-center md:justify-between -mx-0 md:-mx-5"
      style={{
        paddingLeft  : 'clamp(20px, 4vw, 40px)',
        paddingRight : 'clamp(20px, 4vw, 40px)',
        paddingTop   : '20px',
        paddingBottom: '10px',
        marginBottom : 'clamp(20px, 4vw, 40px)',
        gap          : '14px',
        position     : 'sticky',
        top          : 0,
        zIndex       : 20,
        backgroundColor: '#757575',
      }}
    >
      {/* Sur-titre + titre */}
      <div className="flex flex-col items-start">
        {subtitle && (
          <p style={{ color: '#fff', fontSize: '13px', fontWeight: 700, marginBottom: '2px' }}>
            {subtitle}
          </p>
        )}
        <h1 style={{
          color: '#fff056',
          fontFamily: "'HelveticaNeue-Thin', 'Helvetica Neue Thin', 'Helvetica Neue', Helvetica, Arial, sans-serif",
          fontWeight: 300,
          fontSize: 'clamp(32px, 7vw, 50px)',
          lineHeight: 1,
          marginBottom: 0,
        }}>
          {title}
          {titleSuffix && <span style={{ fontSize: 'clamp(20px, 4.2vw, 30px)' }}> {titleSuffix}</span>}
          {helpTopic && (
            <span style={{ marginLeft: '12px' }}>
              <HelpHint
                topic={helpTopic}
                title={helpTitle}
                hint={helpHint ?? `Tutoriel : ${title}`}
                variant="outlined"
              />
            </span>
          )}
          {titleAfterHelp && (
            <span style={{ fontSize: 'clamp(20px, 4.2vw, 30px)', marginLeft: '12px', opacity: 0.85 }}>
              {titleAfterHelp}
            </span>
          )}
        </h1>
      </div>

      {/* Toolbar : aligné à droite sur desktop, pleine largeur sous titre sur mobile.
          v7.0.32+ : marginTop:30 sur desktop (md:mt-[30px]) pour descendre la
          barre de tabs sous le ParametresNav fixe (top:65, hauteur 32) sans
          déséquilibrer le bloc titre/subtitle qui reste au top. */}
      {children && (
        <div
          className="flex items-center flex-wrap w-full md:w-auto md:mt-[30px]"
          style={{ gap: '10px' }}
        >
          {children}
        </div>
      )}
    </div>
  );
}

// ── Sous-composants pour le toolbar ─────────────────────────────

/** Bloc foncé contenant les sous-menus (80pt de haut) */
export function ToolbarBlock({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center" style={{
      height: '50px',
      backgroundColor: 'rgba(0,0,0,0.20)',
      borderRadius: '50px',
      padding: '0 9px',
      gap: '10px',
    }}>
      {children}
    </div>
  );
}

/** Bouton (+) rond jaune 80pt */
export function AddButton({
  onClick,
  title = 'Ajouter',
  disabled = false,
}: { onClick?: () => void; title?: string; disabled?: boolean }) {
  return (
    <button
      type="button"
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      className="flex items-center justify-center transition-colors shrink-0"
      style={{
        width: '37px',
        height: '37px',
        borderRadius: '50%',
        backgroundColor: disabled ? 'rgba(255,255,255,0.2)' : '#fff056',
        color: disabled ? 'rgba(0,0,0,0.3)' : '#000',
        border: disabled ? '1.5px solid rgba(255,255,255,0.3)' : 'none',
        fontSize: '22px',
        fontWeight: 700,
        cursor: disabled ? 'not-allowed' : 'pointer',
        lineHeight: 1,
        opacity: disabled ? 0.5 : 1,
      }}
      title={disabled ? 'Action indisponible sur cet onglet' : title}
    >
      <span style={{ position: 'relative', top: '-2px' }}>+</span>
    </button>
  );
}

/** Bouton utilitaire outline jaune 50pt (sync, calendrier, etc.) */
export function UtilButton({ onClick, title, children }: { onClick: () => void; title?: string; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center justify-center transition-colors shrink-0"
      style={{
        width: '32px',
        height: '32px',
        borderRadius: '50%',
        backgroundColor: 'transparent',
        color: '#fff056',
        border: '2px solid #fff056',
        cursor: 'pointer',
      }}
      title={title}
    >
      <span style={{ width: '18px', height: '18px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {children}
      </span>
    </button>
  );
}

/** Barre de recherche dans le toolbar */
export function SearchInput({ value, onChange, placeholder = 'Rechercher…' }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <input
      type="search"
      placeholder={placeholder}
      value={value}
      onChange={e => onChange(e.target.value)}
      className="focus:outline-none focus:ring-2 focus:ring-yellow-400"
      style={{
        height: '32px',
        borderRadius: '32px',
        backgroundColor: 'rgba(255,255,255,0.7)',
        color: 'rgba(0,0,0,0.7)',
        border: 'none',
        width: '200px',
        fontSize: '13px',
        padding: '0 16px',
      }}
    />
  );
}
