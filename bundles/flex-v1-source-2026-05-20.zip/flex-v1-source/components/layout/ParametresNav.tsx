'use client';
import { useRouter, usePathname } from 'next/navigation';

const PAGES: { href: string; label: string }[] = [
  { href: '/parametres/emails',         label: 'Modèles de messages' },
  { href: '/parametres/equipe',         label: 'Équipe atelier' },
  { href: '/parametres/atelier',        label: 'Infos atelier' },
  { href: '/parametres/catalogue',      label: 'Catalogue vélo' },
  { href: '/parametres/scans',          label: 'Historique scans' },
  { href: '/parametres/sante',          label: 'Santé APIs Google' },
  { href: '/parametres/backup',         label: 'Backup / Export' },
  { href: '/parametres/import-clients', label: 'Import clients (CSV)' },
  { href: '/parametres/admin',          label: 'Admin — opérations destructives' },
];

/**
 * Sous-menu paramètres flottant — pattern visuel identique au ToolbarBlock
 * de la page Archives 2026 :
 *   - container : capsule noir 20% (background ToolbarBlock standard)
 *   - UtilButton (cercle outline jaune 32×32) pour le retour
 *   - PillToggle-like : capsule blanc 50% pour le choix de section
 */
export default function ParametresNav() {
  const pathname = usePathname();
  const router   = useRouter();

  if (pathname === '/parametres' || !pathname?.startsWith('/parametres')) return null;

  return (
    <div
      style={{
        // v7.0.32+ : top 65 — encore monté de 20 (vs 85). Capsule noire
        // externe retirée → c'est juste le pill jaune autonome.
        position: 'fixed',
        top: '65px',
        right: '60px',
        zIndex: 50,
      }}
    >
      {/* Pill jaune autonome — hauteur 38px (match exact .btn-primary
          "Sauvegarder" : font 0.9rem bold + py-2 ≈ 38px). */}
      <select
        value={pathname}
        onChange={e => {
          const href = e.target.value;
          if (href && href !== pathname) router.push(href);
        }}
        title="Aller à une autre section"
        className="focus:outline-none focus:ring-0"
        style={{
          height: '38px',
          padding: '0 36px 0 18px',
          borderRadius: '999px',
          backgroundColor: '#fff056',
          color: 'rgba(0,0,0,0.7)',
          border: 'none',
          outline: 'none',
          boxShadow: 'none',
          fontSize: '13px',
          fontWeight: 700,
          letterSpacing: '0.02em',
          cursor: 'pointer',
          appearance: 'none',
          WebkitAppearance: 'none',
          MozAppearance: 'none',
          backgroundImage:
            'url("data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'10\' height=\'6\' viewBox=\'0 0 10 6\'><path fill=\'rgba(0,0,0,0.7)\' d=\'M0 0l5 6 5-6z\'/></svg>")',
          backgroundRepeat: 'no-repeat',
          backgroundPosition: 'right 14px center',
        }}
      >
        {PAGES.map(p => (
          <option key={p.href} value={p.href} style={{ color: '#000', backgroundColor: '#fff' }}>
            {p.label}
          </option>
        ))}
      </select>
    </div>
  );
}
