'use client';
import { useEffect, useState } from 'react';
import { signOut } from 'next-auth/react';

type Status = 'ok' | 'expired' | 'error' | 'loading';
type Report = {
  sheets  : Status;
  drive   : Status;
  gmail   : Status;
  contacts: Status;
  details?: Record<string, string>;
};

const LABELS: Record<'sheets' | 'drive' | 'gmail' | 'contacts', string> = {
  sheets  : 'Sheets',
  drive   : 'Drive',
  gmail   : 'Gmail',
  contacts: 'Contacts',
};

function colorFor(s: Status): string {
  if (s === 'ok')      return '#22c55e'; // vert
  if (s === 'loading') return 'rgba(255,255,255,0.35)';
  if (s === 'expired') return '#ef4444'; // rouge
  return '#f59e0b';                      // orange (erreur technique)
}

/**
 * GoogleHealthPills — colonne verticale de pastilles de statut alignée
 * à droite, affichant l'état des APIs Google OAuth (Drive, Gmail, People).
 *
 * - Couleur : vert OK, rouge expiré, orange erreur technique
 * - Clic sur une pastille rouge → signOut pour reconnecter
 * - Hover tooltip avec détails
 * - Refresh toutes les 5 min
 */
export default function GoogleHealthPills() {
  const [report, setReport] = useState<Report>({
    sheets: 'loading', drive: 'loading', gmail: 'loading', contacts: 'loading',
  });

  async function fetchHealth() {
    try {
      const res = await fetch('/api/health/google');
      if (!res.ok) return;
      const data = await res.json();
      setReport({
        sheets  : data.sheets   ?? 'error',
        drive   : data.drive    ?? 'error',
        gmail   : data.gmail    ?? 'error',
        contacts: data.contacts ?? 'error',
        details : data.details,
      });
    } catch {
      setReport(prev => ({
        ...prev,
        sheets: 'error', drive: 'error', gmail: 'error', contacts: 'error',
      }));
    }
  }

  useEffect(() => {
    fetchHealth();
    const i = setInterval(fetchHealth, 5 * 60 * 1000); // 5 min
    return () => clearInterval(i);
  }, []);

  const services: ('sheets' | 'drive' | 'gmail' | 'contacts')[] = ['sheets', 'drive', 'gmail', 'contacts'];

  return (
    <div className="flex flex-col items-end" style={{ gap: '4px' }}>
      {services.map(svc => {
        const status = report[svc];
        const detail = report.details?.[svc];
        const isExpired = status === 'expired';
        const tooltip = `${LABELS[svc]} : ${status}${detail ? ` — ${detail}` : ''}${isExpired ? '\nClic = reconnecter' : ''}`;
        return (
          <button
            key={svc}
            type="button"
            onClick={() => { if (isExpired) signOut({ callbackUrl: '/login' }); }}
            title={tooltip}
            className="inline-flex items-center whitespace-nowrap transition-opacity hover:opacity-80"
            style={{
              padding    : '4px 14px',
              borderRadius: '999px',
              backgroundColor: 'rgba(0,0,0,0.25)',
              color      : '#fff',
              border     : 'none',
              cursor     : isExpired ? 'pointer' : 'default',
              fontSize   : '12px',
              fontWeight : 700,
              letterSpacing: '0.04em',
              textTransform: 'uppercase',
              gap        : '10px',
            }}
          >
            {LABELS[svc]}
            <span
              aria-hidden
              style={{
                width: '16px',
                height: '16px',
                borderRadius: '50%',
                backgroundColor: colorFor(status),
                display: 'inline-block',
                boxShadow: status === 'ok' ? '0 0 0 3px rgba(34,197,94,0.25)' : undefined,
              }}
            />
          </button>
        );
      })}
    </div>
  );
}
