'use client';
import { useEffect, useState } from 'react';
import { signOut } from 'next-auth/react';

/**
 * Bannière globale affichée quand le serveur retourne
 * `{ code: 'GOOGLE_AUTH_EXPIRED', reconnect: true }` sur n'importe
 * quelle route Google (Drive, Gmail, People).
 *
 * Monkey-patch `window.fetch` pour inspecter chaque réponse 401 avec le
 * flag `reconnect: true` — dès qu'on en voit une, on affiche la bannière
 * avec un CTA « Se reconnecter ».
 *
 * Monte ce composant dans AppShell pour couvrir toute l'app.
 */
export default function GoogleAuthBanner() {
  const [show, setShow]       = useState(false);
  const [message, setMessage] = useState('Session Google expirée');

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const originalFetch = window.fetch.bind(window);
    let cancelled = false;

    window.fetch = async (...args) => {
      const res = await originalFetch(...args);
      // N'inspecte que les 401 pour ne pas ralentir les responses OK
      if (!cancelled && res.status === 401) {
        // Clone pour ne pas consommer le body (l'appelant va le lire)
        try {
          const clone = res.clone();
          const ct    = clone.headers.get('content-type') ?? '';
          if (ct.includes('application/json')) {
            const body = await clone.json().catch(() => null);
            if (body?.reconnect === true || body?.code === 'GOOGLE_AUTH_EXPIRED') {
              setMessage(body.error || 'Session Google expirée — reconnecte-toi');
              setShow(true);
            }
          }
        } catch { /* ignore */ }
      }
      return res;
    };

    // Écoute un événement custom pour les cas où l'échec ne se traduit pas
    // par un 401 HTTP (ex. flag contactReconnect dans une réponse 201).
    function onExpired(e: Event) {
      const detail = (e as CustomEvent).detail ?? {};
      setMessage(detail.message || 'Session Google expirée — reconnecte-toi');
      setShow(true);
    }
    window.addEventListener('google-auth-expired', onExpired);

    return () => {
      cancelled = true;
      window.fetch = originalFetch;
      window.removeEventListener('google-auth-expired', onExpired);
    };
  }, []);

  if (!show) return null;

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 10000,
        backgroundColor: '#b91c1c',
        color: '#fff',
        padding: '12px 16px',
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.30)',
        fontSize: '13px',
        fontWeight: 600,
      }}
      role="alert"
    >
      <span style={{ fontSize: '18px' }}>⚠</span>
      <span style={{ flex: 1 }}>{message}</span>
      <button
        type="button"
        onClick={() => signOut({ callbackUrl: '/login' })}
        style={{
          padding: '6px 14px',
          borderRadius: '999px',
          backgroundColor: '#fff',
          color: '#b91c1c',
          border: 'none',
          fontSize: '12px',
          fontWeight: 700,
          textTransform: 'uppercase',
          letterSpacing: '0.04em',
          cursor: 'pointer',
        }}
      >
        Se reconnecter
      </button>
      <button
        type="button"
        onClick={() => setShow(false)}
        aria-label="Fermer"
        style={{
          width: '28px',
          height: '28px',
          borderRadius: '50%',
          backgroundColor: 'rgba(255,255,255,0.15)',
          color: '#fff',
          border: 'none',
          fontSize: '18px',
          fontWeight: 700,
          cursor: 'pointer',
          lineHeight: 1,
        }}
      >
        ×
      </button>
    </div>
  );
}
