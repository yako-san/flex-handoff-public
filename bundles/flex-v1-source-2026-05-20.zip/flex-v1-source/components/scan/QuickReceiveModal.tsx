'use client';
import { useEffect, useState, useMemo } from 'react';
import Modal from '@/components/ui/Modal';
import { toast } from '@/components/ui/Toast';
import { frPrix } from '@/lib/utils/format';
import type { Piece } from '@/types/catalogue';

/**
 * Modal de réception rapide ad-hoc — affichée après un scan SKU qui a
 * matché une pièce du catalogue. Demande la quantité reçue + fournisseur
 * + prix d'achat puis appelle `/api/po/adhoc-receive`.
 *
 * Pour un SKU non matché : flow différent côté parent (PieceForm).
 */

interface Props {
  open: boolean;
  onClose: () => void;
  /** Pièce matchée dans le catalogue (par SKU scanné). */
  piece: Piece | null;
  /** SKU scanné (au cas où piece est null mais on veut afficher le SKU). */
  scannedSku: string;
  /** Liste des fournisseurs connus (extraite du catalogue). */
  fournisseurs: string[];
  /** Callback après succès — parent peut refresh la liste pieces / toast. */
  onSuccess?: (result: { poNumber: string; piece: Piece | null }) => void;
}

export default function QuickReceiveModal({
  open,
  onClose,
  piece,
  scannedSku,
  fournisseurs,
  onSuccess,
}: Props) {
  const [qte,         setQte]         = useState(1);
  const [fournisseur, setFournisseur] = useState('');
  const [prixAchat,   setPrixAchat]   = useState(0);
  const [submitting,  setSubmitting]  = useState(false);

  // Pré-remplit avec les valeurs de la pièce matchée à chaque ouverture
  useEffect(() => {
    if (!open) return;
    setQte(1);
    setFournisseur(piece?.fournisseur ?? '');
    setPrixAchat(piece?.prixAchat ?? 0);
  }, [open, piece]);

  const fournisseursOptions = useMemo(
    () => [...new Set([
      ...(piece?.fournisseur ? [piece.fournisseur] : []),
      ...fournisseurs,
    ])].filter(Boolean).sort(),
    [piece, fournisseurs],
  );

  async function handleSubmit() {
    if (!piece) return;
    if (!fournisseur) { toast('Fournisseur requis', 'error'); return; }
    if (qte <= 0) { toast('Quantité doit être > 0', 'error'); return; }

    setSubmitting(true);
    try {
      const res = await fetch('/api/po/adhoc-receive', {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({
          pieceId    : piece.pieceId,
          sku        : piece.sku || scannedSku,
          nom        : piece.nom,
          qte,
          fournisseur,
          prixAchat,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erreur réception');

      toast(`+${qte} ${piece.nom} en stock (${data.poNumber})`, 'success');
      onSuccess?.({ poNumber: data.poNumber, piece });
      onClose();
    } catch (err: any) {
      toast(err.message || 'Erreur réception', 'error');
    } finally {
      setSubmitting(false);
    }
  }

  if (!piece) return null;

  return (
    <Modal open={open} onClose={onClose} title="Réception rapide" size="md">
      <div className="flex flex-col" style={{ gap: '16px' }}>
        {/* Pièce matchée */}
        <div
          style={{
            padding: '14px 16px',
            backgroundColor: 'rgba(255,240,86,0.25)',
            borderRadius: '16px',
          }}
        >
          <div style={{ fontSize: '11px', fontWeight: 600, color: 'rgba(0,0,0,0.5)', textTransform: 'lowercase', marginBottom: '4px' }}>
            pièce scannée
          </div>
          <div style={{ fontSize: '15px', fontWeight: 700, color: 'rgba(0,0,0,0.85)' }}>
            ⚙️ {piece.nom}
          </div>
          <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.55)', marginTop: '4px' }}>
            <span className="font-mono">{piece.sku || scannedSku}</span>
            {' · '}
            <span>stock actuel : <strong>{piece.stock}</strong></span>
          </div>
        </div>

        {/* Qté reçue */}
        <div>
          <label className="label-system">qté reçue</label>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setQte(q => Math.max(1, q - 1))}
              className="btn-secondary"
              style={{ width: '38px', height: '38px', padding: 0, justifyContent: 'center', fontSize: '18px' }}
              aria-label="Diminuer"
            >−</button>
            <input
              type="number"
              min={1}
              value={qte}
              onChange={e => setQte(Math.max(1, parseInt(e.target.value) || 1))}
              className="input-system text-center"
              style={{ width: '80px', fontSize: '18px', fontWeight: 700 }}
            />
            <button
              type="button"
              onClick={() => setQte(q => q + 1)}
              className="btn-secondary"
              style={{ width: '38px', height: '38px', padding: 0, justifyContent: 'center', fontSize: '18px' }}
              aria-label="Augmenter"
            >+</button>
          </div>
        </div>

        {/* Fournisseur */}
        <div>
          <label className="label-system">fournisseur</label>
          <select
            value={fournisseur}
            onChange={e => setFournisseur(e.target.value)}
            className="input-system"
          >
            <option value="">— sélectionner —</option>
            {fournisseursOptions.map(f => (
              <option key={f} value={f}>{f}</option>
            ))}
          </select>
        </div>

        {/* Prix achat */}
        <div>
          <label className="label-system">prix d'achat (unitaire)</label>
          <div className="flex items-center gap-2">
            <input
              type="number"
              min={0}
              step={0.01}
              value={prixAchat}
              onChange={e => setPrixAchat(Math.max(0, parseFloat(e.target.value) || 0))}
              className="input-system"
              style={{ width: '140px' }}
            />
            <span style={{ fontSize: '14px', color: 'rgba(0,0,0,0.5)' }}>$ / unité</span>
          </div>
          <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.4)', marginTop: '4px' }}>
            total réception : <strong>{frPrix(qte * prixAchat)}</strong>
          </div>
        </div>

        {/* Boutons */}
        <div className="flex justify-end gap-2" style={{ paddingTop: '8px', borderTop: '1px solid rgba(0,0,0,0.1)' }}>
          <button onClick={onClose} className="btn-secondary" disabled={submitting}>
            Annuler
          </button>
          <button onClick={handleSubmit} className="btn-primary" disabled={submitting || !fournisseur || qte <= 0}>
            {submitting ? 'Envoi…' : `Recevoir +${qte}`}
          </button>
        </div>
      </div>
    </Modal>
  );
}
