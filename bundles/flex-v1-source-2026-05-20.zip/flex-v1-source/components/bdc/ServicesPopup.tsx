'use client';
import React, { useState, useMemo, useEffect } from 'react';
import Modal from '@/components/ui/Modal';
import { useServices } from '@/hooks/useCatalogue';
import { useBDC } from '@/hooks/useBDC';
import { frPrix, normSearch } from '@/lib/utils/format';
import { toast } from '@/components/ui/Toast';
import { PlusIcon, ArrowRightIcon } from '@heroicons/react/24/outline';
import ServiceForm from '@/components/catalogue/ServiceForm';
import type { Service } from '@/types/catalogue';

interface ServicesPopupProps {
  bdcId: string;
  open: boolean;
  onClose: () => void;
  onOpenPieces?: () => void;
}

function svcLabel(nom: string): string {
  return nom;
}


export default function ServicesPopup({ bdcId, open, onClose, onOpenPieces }: ServicesPopupProps) {
  const { services, isLoading, addService, mutate: mutateServices } = useServices();
  const { bdc, addItems }       = useBDC(bdcId);

  // Pièces déjà dans ce BDC (miroir de ce que fait PiecesPopup pour les services)
  const bdcPieces = useMemo(() =>
    (bdc?.items ?? []).filter(it => it.piece),
    [bdc]
  );

  const [search,     setSearch]     = useState('');
  const [selectedCat, setSelectedCat] = useState('Toutes');
  const [selected,   setSelected]   = useState<Set<number>>(new Set());
  const [submitting, setSubmitting] = useState(false);

  // Reset sélection + recherche à chaque (ré)ouverture du popup — évite
  // que des cases cochées/filtres d'une session précédente persistent et
  // créent des ajouts fantômes au prochain submit.
  useEffect(() => {
    if (open) {
      setSelected(new Set());
      setSearch('');
      setSelectedCat('Toutes');
    }
  }, [open]);

  // Popup nouveau service (réutilise ServiceForm de la page Services)
  const [showServiceForm, setShowServiceForm] = useState(false);

  /** Vrai si la ligne du catalogue est une vraie entrée (pas un séparateur,
   *  pas un sous-item de forfait commençant par "-" ou "—") */
  function isCatalogRow(label: string | undefined): boolean {
    if (!label) return false;
    const t = label.trim();
    if (!t) return false;
    if (t === '--' || t === '-' || t === '—') return false;
    if (t.startsWith('- ') || t.startsWith('— ')) return false;
    return true;
  }

  // Catégories disponibles
  const categories = useMemo(() => {
    const cats = new Set(
      services
        .filter(s => isCatalogRow(s.label))
        .map(s => s.categorieAffichee || 'Autre')
    );
    return ['Toutes', ...Array.from(cats).sort()];
  }, [services]);

  /** Map forfait → liste des sous-tâches (pour tooltip mouse over).
   *  Détecte un forfait par "forfait" dans le label, et inclut les lignes suivantes
   *  qui commencent par — ou - jusqu'à la prochaine ligne sans préfixe. */
  const forfaitTasks = useMemo(() => {
    const m = new Map<string, string[]>();
    let currentForfait = '';
    for (const s of services) {
      const t = (s.label ?? '').trim();
      if (!t) continue;
      // Détection forfait header
      if (t.toLowerCase().includes('forfait') && !t.startsWith('—') && !t.startsWith('- ')) {
        currentForfait = t;
        if (!m.has(currentForfait)) m.set(currentForfait, []);
      } else if (currentForfait && (t.startsWith('—') || t.startsWith('- '))) {
        // Sous-item du forfait courant — nettoyer le préfixe
        const cleaned = t.replace(/^[—\-]\s*/, '').trim();
        if (cleaned) m.get(currentForfait)!.push(cleaned);
      } else if (currentForfait) {
        // Ligne sans préfixe → fin du forfait
        currentForfait = '';
      }
    }
    return m;
  }, [services]);

  // Services filtrés
  const filtered = useMemo(() =>
    services
      .filter(s => isCatalogRow(s.label))
      .filter(s => selectedCat === 'Toutes' || (s.categorieAffichee || 'Autre') === selectedCat)
      .filter(s => {
        if (!search) return true;
        const q = normSearch(search);
        return (
          normSearch(s.label).includes(q) ||
          normSearch(s.categorieAffichee).includes(q)
        );
      }),
    [services, search, selectedCat]
  );

  // Grouper par catégorie (uniquement si "Toutes")
  const groups = useMemo(() => {
    const map = new Map<string, Service[]>();
    filtered.forEach(s => {
      const cat = selectedCat === 'Toutes' ? (s.categorieAffichee || 'Autre') : selectedCat;
      if (!map.has(cat)) map.set(cat, []);
      map.get(cat)!.push(s);
    });
    return map;
  }, [filtered, selectedCat]);

  function toggle(row: number) {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(row) ? next.delete(row) : next.add(row);
      return next;
    });
  }

  async function handleSubmit() {
    const items = services
      .filter(s => selected.has(s._row))
      // Filet de sécurité : refuser les sous-items de forfait (commencent
      // par "- " ou "— ") et les séparateurs — ils ne doivent jamais être
      // insérés comme ITEM indépendant dans un BDT.
      .filter(s => isCatalogRow(s.label))
      .map(s => ({ serviceId: s.serviceId, nom: s.label, prix: s.prix }));
    if (!items.length) return;
    setSubmitting(true);
    try {
      await addItems('service', items);
      toast(`${items.length} service(s) ajouté(s)`);
      setSelected(new Set());
      onClose();
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  }


  return (
    <>
    <Modal open={open} onClose={onClose} title="Ajouter des services" size="lg" fullHeight>
      <div className="flex flex-col flex-1 min-h-0" style={{ gap: '12px' }}>

        {/* ── Header frozen : boutons + form + filtre/recherche ── */}
        <div className="flex flex-col shrink-0" style={{ gap: '12px' }}>

          {/* Boutons d'action */}
          <div className="flex gap-2">
            <button onClick={() => setShowServiceForm(true)} className="btn-primary">
              <PlusIcon className="h-4 w-4" /> Nouveau service
            </button>
            {onOpenPieces && (
              <button
                onClick={async () => {
                  // Si l'utilisateur a des services sélectionnés, les submit
                  // AVANT d'ouvrir le modal pièces — sinon la sélection est
                  // perdue (bug F : services disparaissent en ajoutant pièce).
                  if (selected.size > 0) {
                    await handleSubmit();  // gère aussi l'erreur + setSubmitting
                  }
                  onOpenPieces();
                }}
                disabled={submitting}
                className="btn-secondary ml-auto"
              >
                {submitting && selected.size > 0 ? 'Ajout…' : 'Ajouter des pièces'} <ArrowRightIcon className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Pièces déjà dans ce BDC */}
          {bdcPieces.length > 0 && (
            <div style={{ backgroundColor: 'rgba(0,0,0,0.04)', borderRadius: '16px', padding: '14px' }}>
              <p className="legende" style={{ color: 'rgba(0,0,0,0.5)', marginBottom: '8px' }}>
                Pièces dans ce BDC :
              </p>
              <ul className="space-y-0.5">
                {bdcPieces.map(it => (
                  <li key={it._row} className="flex items-center justify-between text-sm">
                    <span style={{ color: 'rgba(0,0,0,0.75)' }}>⚙️ : {it.piece!.nom}</span>
                    <span className="text-xs" style={{ color: 'rgba(0,0,0,0.5)' }}>
                      {it.piece!.qte} × {frPrix(it.piece!.prix)}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Filtre catégorie + recherche */}
          <div className="flex gap-2">
            <select
              value={selectedCat} onChange={e => setSelectedCat(e.target.value)}
              className="input-system shrink-0"
              style={{ width: '180px' }}
              title={selectedCat}
            >
              {categories.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            <input
              type="search" placeholder="Rechercher…" value={search}
              onChange={e => setSearch(e.target.value)}
              className="input-system flex-1 min-w-0"
            />
          </div>
        </div>

        {/* ── Liste (scrollable) ─────────────────────────── */}
        <div
          className="flex-1 min-h-0 overflow-y-auto"
          style={{ border: '1.5px solid rgba(0,0,0,0.15)', borderRadius: '16px' }}
        >
          {isLoading && (
            <p className="py-4 text-center text-sm" style={{ color: 'rgba(0,0,0,0.4)' }}>Chargement…</p>
          )}
          {!isLoading && filtered.length === 0 && (
            <p className="py-4 text-center text-sm" style={{ color: 'rgba(0,0,0,0.4)' }}>Aucun service trouvé.</p>
          )}
          {[...groups.entries()].map(([cat, svcs]) => (
            <div key={cat}>
              <p
                className="legende sticky top-0"
                style={{ padding: '6px 14px', color: 'rgba(0,0,0,0.45)', backgroundColor: 'rgba(0,0,0,0.04)' }}
              >
                {cat}
              </p>
              {svcs.map(s => {
                const tasks = forfaitTasks.get(s.label.trim()) || [];
                const isForfait = tasks.length > 0;
                return (
                  <label
                    key={s._row}
                    className="flex items-center gap-3 cursor-pointer transition-colors relative group"
                    style={{ padding: '10px 14px', borderTop: '1px solid rgba(0,0,0,0.06)' }}
                    onMouseEnter={e => (e.currentTarget.style.backgroundColor = 'rgba(255,240,86,0.18)')}
                    onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                  >
                    <input
                      type="checkbox" checked={selected.has(s._row)} onChange={() => toggle(s._row)}
                      className="custom-checkbox"
                    />
                    <span className="flex-1 text-sm flex items-center gap-2">
                      {svcLabel(s.label)}
                      {isForfait && (
                        <span style={{ fontSize: '10px', color: 'rgba(0,0,0,0.4)', fontStyle: 'italic' }}>
                          ({tasks.length} tâche{tasks.length > 1 ? 's' : ''})
                        </span>
                      )}
                    </span>
                    <span className="text-sm font-medium whitespace-nowrap" style={{ color: 'rgba(0,0,0,0.65)' }}>
                      {frPrix(s.prix)}
                    </span>
                    {/* Tooltip sous-tâches du forfait (au mouse over) */}
                    {isForfait && (
                      <div
                        className="absolute opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                        style={{
                          left: '40px',
                          top: '100%',
                          marginTop: '2px',
                          zIndex: 60,
                          backgroundColor: 'rgba(0,0,0,0.92)',
                          color: '#fff',
                          padding: '8px 12px',
                          borderRadius: '8px',
                          fontSize: '12px',
                          minWidth: '280px',
                          maxWidth: '500px',
                          boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
                        }}
                      >
                        <div style={{ fontWeight: 700, marginBottom: '4px', color: '#fff056' }}>Inclus dans le forfait :</div>
                        <ul style={{ paddingLeft: '16px', margin: 0, lineHeight: 1.5 }}>
                          {tasks.map((task, i) => (
                            <li key={i} style={{ listStyleType: 'disc' }}>{task}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </label>
                );
              })}
            </div>
          ))}
        </div>

        {/* ── Pied (frozen) ──────────────────────────────── */}
        <div className="flex items-center justify-between shrink-0" style={{ paddingTop: '12px', borderTop: '1px solid rgba(0,0,0,0.1)' }}>
          <p className="legende" style={{ color: 'rgba(0,0,0,0.5)' }}>{selected.size} sélectionné(s)</p>
          <div className="flex gap-2">
            <button onClick={onClose} className="btn-secondary">Annuler</button>
            <button onClick={handleSubmit} disabled={!selected.size || submitting} className="btn-primary">
              {submitting ? 'Ajout…' : 'Ajouter la sélection'}
            </button>
          </div>
        </div>
      </div>
    </Modal>

    <ServiceForm
      open={showServiceForm}
      onClose={() => setShowServiceForm(false)}
      categories={categories.filter(c => c !== 'Toutes')}
      onCreated={() => setShowServiceForm(false)}
    />
    </>
  );
}
