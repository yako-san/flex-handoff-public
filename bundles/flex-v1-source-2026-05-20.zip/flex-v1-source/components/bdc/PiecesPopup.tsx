'use client';
import React, { useState, useMemo, useEffect } from 'react';
import Modal from '@/components/ui/Modal';
import { usePieces } from '@/hooks/useCatalogue';
import { useBDC } from '@/hooks/useBDC';
import { frPrix, normSearch } from '@/lib/utils/format';
import { pceNomAvecStock } from '@/lib/utils/pieces';
import { toast } from '@/components/ui/Toast';
import { PlusIcon, ArrowLeftIcon } from '@heroicons/react/24/outline';
import PieceForm from '@/components/catalogue/PieceForm';
import type { Piece } from '@/types/catalogue';

interface PiecesPopupProps {
  bdcId: string;
  open: boolean;
  onClose: () => void;
  onOpenServices?: () => void;
}

interface SelectedPiece { piece: Piece; qte: number }

function pceLabel(nom: string): string {
  return '⚙️ : ' + nom;
}

function svcLabel(nom: string): string {
  return nom;
}

/** Noms à exclure du catalogue pièces */
function isExcluded(nom: string): boolean {
  if (!nom || nom.trim() === '') return true;
  const n = nom.trim().toLowerCase();
  if (n === 'nom item' || n === 'item') return true;
  if (nom.startsWith('FIN DE')) return true;
  if (nom.includes('FIN DE →')) return true;
  return false;
}

export default function PiecesPopup({ bdcId, open, onClose, onOpenServices }: PiecesPopupProps) {
  const { pieces, isLoading, addPiece } = usePieces();
  const { bdc, addItems }               = useBDC(bdcId);

  const [search,      setSearch]      = useState('');
  const [selectedCat, setSelectedCat] = useState('Toutes');
  const [selected,    setSelected]    = useState<Map<number, SelectedPiece>>(new Map());
  const [submitting,  setSubmitting]  = useState(false);

  // Popup nouvelle pièce (réutilise PieceForm de la page Pièces)
  const [showPieceForm, setShowPieceForm] = useState(false);

  // Draft persisté par BDT dans localStorage : permet de naviguer ailleurs
  // (ex. ouvrir un catalogue dans un autre onglet) et revenir sans perdre
  // les cases cochées. La draft expire après 2h pour éviter des fantômes
  // après un long délai.
  const DRAFT_KEY = `pieces-popup-draft-${bdcId}`;
  // v7.0.32+ : TTL réduit de 2h à 5min — la persistance n'est utile que pour
  // un reload accidentel de page pendant le picking, pas pour des sessions
  // séparées (où elle créait de la confusion : le user ouvrait le popup, voyait
  // des items déjà cochés d'une session précédente, cliquait pour "ajouter"
  // et décochait sans s'en rendre compte).
  const DRAFT_TTL_MS = 5 * 60 * 1000;

  // Load draft à l'ouverture
  useEffect(() => {
    if (!open) return;
    try {
      const raw = localStorage.getItem(DRAFT_KEY);
      if (raw) {
        const draft = JSON.parse(raw);
        const fresh = Date.now() - (draft?.timestamp ?? 0) < DRAFT_TTL_MS;
        if (fresh && Array.isArray(draft.selected)) {
          setSelected(new Map(draft.selected));
          setSearch(String(draft.search ?? ''));
          setSelectedCat(String(draft.selectedCat ?? 'Toutes'));
          return;
        }
        localStorage.removeItem(DRAFT_KEY);
      }
    } catch { /* ignore JSON / storage errors */ }
    // Pas de draft valide → reset propre
    setSelected(new Map());
    setSearch('');
    setSelectedCat('Toutes');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, bdcId]);

  // Save draft à chaque change (debounced via effect)
  useEffect(() => {
    if (!open) return;
    try {
      const draft = {
        timestamp   : Date.now(),
        selected    : [...selected.entries()],
        search,
        selectedCat,
      };
      localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
    } catch { /* storage full : ignore */ }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, selected, search, selectedCat, bdcId]);

  // Services déjà dans ce BDC
  const bdcServices = useMemo(() =>
    (bdc?.items ?? []).filter(it => it.service),
    [bdc]
  );

  // Catégories disponibles
  const categories = useMemo(() => {
    const cats = new Set(
      pieces
        .filter(p => !isExcluded(p.nom))
        .map(p => p.categorie || p.groupe || 'Autre')
    );
    return ['Toutes', ...Array.from(cats).sort()];
  }, [pieces]);

  // Fournisseurs disponibles
  const fournisseurs = useMemo(() =>
    [...new Set(
      pieces
        .filter(p => !isExcluded(p.nom))
        .map(p => p.fournisseur)
        .filter(f => !!f && f.toLowerCase() !== 'fournisseur'),
    )].sort(),
  [pieces]);

  // Pièces filtrées
  const filtered = useMemo(() =>
    pieces
      .filter(p => !isExcluded(p.nom))
      .filter(p => selectedCat === 'Toutes' || (p.categorie || p.groupe || 'Autre') === selectedCat)
      .filter(p => {
        if (!search) return true;
        const q = normSearch(search);
        return (
          normSearch(p.nom).includes(q) ||
          normSearch(p.groupe).includes(q) ||
          normSearch(p.categorie).includes(q)
        );
      }),
    [pieces, search, selectedCat]
  );

  // Grouper par catégorie
  const groups = useMemo(() => {
    const map = new Map<string, Piece[]>();
    filtered.forEach(p => {
      const cat = selectedCat === 'Toutes' ? (p.categorie || p.groupe || 'Autre') : selectedCat;
      if (!map.has(cat)) map.set(cat, []);
      map.get(cat)!.push(p);
    });
    return map;
  }, [filtered, selectedCat]);

  function toggle(piece: Piece) {
    setSelected(prev => {
      const next = new Map(prev);
      next.has(piece._row)
        ? next.delete(piece._row)
        : next.set(piece._row, { piece, qte: 1 });
      return next;
    });
  }

  function setQte(row: number, qte: number) {
    setSelected(prev => {
      const next  = new Map(prev);
      const entry = next.get(row);
      if (entry) next.set(row, { ...entry, qte: Math.max(1, qte) });
      return next;
    });
  }

  /** Vide la sélection en cours + le draft localStorage. Bouton visible
   *  dans le footer quand selected.size > 0. Évite la confusion d'un draft
   *  d'une session précédente qui pollue la nouvelle commande. */
  function handleClear() {
    setSelected(new Map());
    try { localStorage.removeItem(DRAFT_KEY); } catch { /* ignore */ }
  }

  async function handleSubmit() {
    const items = [...selected.values()].map(({ piece, qte }) => ({
      pieceId: piece.pieceId,   // v1.1.5+ : ID stable catalogue → col O BDC
      nom    : piece.nom,
      prix   : piece.prixBDC,
      qte,
    }));
    if (!items.length) return;
    setSubmitting(true);
    try {
      await addItems('piece', items);
      toast(`${items.length} pièce(s) ajoutée(s)`);
      setSelected(new Map());
      // Submit réussi → draft localStorage plus pertinente
      try { localStorage.removeItem(DRAFT_KEY); } catch { /* ignore */ }
      onClose();
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  }


  return (
    <>
    <Modal open={open} onClose={onClose} title="Ajouter des pièces" size="xl" fullHeight>
      <div className="flex flex-col flex-1 min-h-0" style={{ gap: '12px' }}>

        {/* ── Header frozen : boutons + form + services + filtre/recherche ── */}
        <div className="flex flex-col shrink-0" style={{ gap: '12px' }}>

          {/* Boutons d'action */}
          <div className="flex gap-2">
            {onOpenServices && (
              <button onClick={onOpenServices} className="btn-secondary">
                <ArrowLeftIcon className="h-4 w-4" /> Ajouter des services
              </button>
            )}
            <button onClick={() => setShowPieceForm(true)} className="btn-primary ml-auto">
              <PlusIcon className="h-4 w-4" /> Nouvelle pièce
            </button>
          </div>

          {/* Services dans ce BDC */}
          {bdcServices.length > 0 && (
            <div style={{ backgroundColor: 'rgba(0,0,0,0.04)', borderRadius: '16px', padding: '14px' }}>
              <p className="legende" style={{ color: 'rgba(0,0,0,0.5)', marginBottom: '8px' }}>
                Services dans ce BDC :
              </p>
              <ul className="space-y-0.5">
                {bdcServices.map(it => (
                  <li key={it._row} className="flex items-center justify-between text-sm">
                    <span style={{ color: 'rgba(0,0,0,0.75)' }}>{svcLabel(it.service!.nom)}</span>
                    <span className="text-xs" style={{ color: 'rgba(0,0,0,0.5)' }}>{frPrix(it.service!.prix)}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Filtre catégorie + recherche */}
          <div className="flex gap-2">
            <select
              value={selectedCat} onChange={e => setSelectedCat(e.target.value)}
              className="input-system shrink-0"
              style={{ width: '180px' }}
              title={selectedCat}
            >
              {categories.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            <input
              type="search" placeholder="Rechercher pièce, groupe, catégorie…" value={search}
              onChange={e => setSearch(e.target.value)}
              className="input-system flex-1 min-w-0"
            />
          </div>
        </div>

        {/* ── Liste (scrollable) ─────────────────────────── */}
        <div
          className="flex-1 min-h-0 overflow-y-auto"
          style={{ border: '1.5px solid rgba(0,0,0,0.15)', borderRadius: '16px' }}
        >
          {isLoading && (
            <p className="py-4 text-center text-sm" style={{ color: 'rgba(0,0,0,0.4)' }}>Chargement…</p>
          )}
          {!isLoading && filtered.length === 0 && (
            <p className="py-4 text-center text-sm" style={{ color: 'rgba(0,0,0,0.4)' }}>Aucune pièce trouvée.</p>
          )}
          {[...groups.entries()].map(([cat, grpPieces]) => (
            <div key={cat}>
              <p
                className="legende sticky top-0"
                style={{ padding: '6px 14px', color: 'rgba(0,0,0,0.45)', backgroundColor: 'rgba(0,0,0,0.04)' }}
              >
                {cat}
              </p>
              {grpPieces.map(p => {
                const isSelected = selected.has(p._row);
                const { label, stockInfo } = pceNomAvecStock(p.nom, p.stock);
                return (
                  <div
                    key={p._row}
                    className="flex items-center gap-3 transition-colors"
                    style={{
                      padding: '10px 14px',
                      borderTop: '1px solid rgba(0,0,0,0.06)',
                      backgroundColor: isSelected ? 'rgba(255,240,86,0.18)' : 'transparent',
                    }}
                  >
                    <input
                      type="checkbox" checked={isSelected} onChange={() => toggle(p)}
                      className="custom-checkbox"
                    />
                    <span className="flex-1 text-sm">
                      {pceLabel(label)}
                      <span className="ml-1 text-xs italic" style={{ color: 'rgba(0,0,0,0.4)' }}>{stockInfo}</span>
                    </span>
                    <span className="text-sm whitespace-nowrap" style={{ color: 'rgba(0,0,0,0.65)' }}>
                      {frPrix(p.prixBDC)}
                    </span>
                    {isSelected && (
                      <input
                        type="number" min={1} value={selected.get(p._row)!.qte}
                        onChange={e => setQte(p._row, parseInt(e.target.value) || 1)}
                        className="input-system text-center"
                        style={{ width: '64px', padding: '6px 8px' }}
                        onClick={e => e.stopPropagation()}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        {/* ── Pied ───────────────────────────────────────── */}
        <div className="flex items-center justify-between" style={{ paddingTop: '12px', borderTop: '1px solid rgba(0,0,0,0.1)' }}>
          <div className="flex items-center gap-3">
            <p className="legende" style={{ color: 'rgba(0,0,0,0.5)' }}>{selected.size} pièce(s) sélectionnée(s)</p>
            {selected.size > 0 && (
              <button
                onClick={handleClear}
                title="Vider la sélection en cours (et le brouillon)"
                style={{
                  fontSize: '12px',
                  fontWeight: 600,
                  color: 'rgba(0,0,0,0.5)',
                  background: 'none',
                  border: 'none',
                  textDecoration: 'underline',
                  cursor: 'pointer',
                  padding: 0,
                }}
              >
                Vider
              </button>
            )}
          </div>
          <div className="flex gap-2">
            <button onClick={onClose} className="btn-secondary">Annuler</button>
            <button onClick={handleSubmit} disabled={!selected.size || submitting} className="btn-primary">
              {submitting ? 'Ajout…' : 'Ajouter la sélection'}
            </button>
          </div>
        </div>
      </div>
    </Modal>

    <PieceForm
      open={showPieceForm}
      onClose={() => setShowPieceForm(false)}
      categories={categories.slice(1)}
      fournisseurs={fournisseurs}
      onCreated={() => setShowPieceForm(false)}
    />
    </>
  );
}
