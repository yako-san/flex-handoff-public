'use client';
import { useRef, useEffect } from 'react';
import CheckboxAction from './CheckboxAction';
import ArchiveChoiceDialog from './ArchiveChoiceDialog';
import HelpHint from '@/components/ui/HelpHint';
import { useBDC } from '@/hooks/useBDC';
import { useInventaire } from '@/hooks/useInventaire';
import { toast } from '@/components/ui/Toast';
import { frDate } from '@/lib/utils/format';
import { STATUTS, nextStatusOnAssign } from '@/lib/utils/statuts';
import { useEquipe } from '@/hooks/useEquipe';
import type { BDC } from '@/types/bdc';

export interface Remise { type: 'pct' | 'fixed'; value: number }

interface BDCHeaderProps {
  bdc: BDC;
  status?: string;
  noteClient?: string;
  noteClientFacture?: string;
  remiseSvc?: Remise;
  remisePce?: Remise;
  onArchived?: () => void;
  onApproved?: () => void;
}

/** Dropdown assignation d'une étape — style inline texte (pas de boîte) */
function EtapeSelect({
  label, value, onSave, disabled = false, helpTopic, helpTitle, helpHint,
}: {
  label: string;
  value: string;
  fg?: string;
  onSave: (v: string) => void;
  disabled?: boolean;
  helpTopic?: string;
  helpTitle?: string;
  helpHint?: React.ReactNode;
}) {
  const textColor  = 'rgba(0,0,0,0.5)';
  const { equipe } = useEquipe();
  return (
    <div>
      <p style={{ color: textColor, fontSize: '14px', fontWeight: 700, fontStyle: 'italic', marginBottom: '4px', display: 'flex', alignItems: 'center', gap: '4px' }}>
        {label}
        {helpTopic && (
          <HelpHint
            topic={helpTopic}
            title={helpTitle ?? label}
            hint={helpHint ?? `Tutoriel : ${label}`}
            size={13}
            />
        )}
      </p>
      {disabled ? (
        <div style={{ color: textColor, fontSize: '16px' }}>
          En attente
        </div>
      ) : (
        <select
          value={value}
          onChange={e => onSave(e.target.value)}
          className="bg-transparent border-0 p-0 cursor-pointer focus:outline-none focus:ring-0"
          style={{ color: textColor, fontSize: '16px', fontWeight: 400 }}
        >
          {equipe.map(opt => (
            <option key={opt} value={opt}>{opt || '—'}</option>
          ))}
        </select>
      )}
    </div>
  );
}

export default function BDCHeader({
  bdc, status = '', noteClient = '', noteClientFacture = '',
  remiseSvc, remisePce, onArchived, onApproved,
}: BDCHeaderProps) {
  const { patchBDC, setEvalStatus, resetEval, resetFacture, archiver, mutate: mutateBDC } = useBDC(bdc.id);
  const { patchVelo, velos, mutate: mutateInv }   = useInventaire();
  const velo                   = velos.find(v => v.id === bdc.id);

  // Choix capturé dans le popup ArchiveChoiceDialog avant l'appel à
  // onAction du CheckboxAction (qui lit cette ref).
  const archiveModeRef = useRef<'paye' | 'refuse' | null>(null);
  // v1.0.19+ : mode de paiement capturé en même temps que 'paye'.
  const paymentModeRef = useRef<'comptant' | 'interac' | 'cartes' | null>(null);

  const s  = STATUTS[status];
  const bg = s?.bg ?? '#f5f5f5';
  const fg = s?.fg ?? '#333333';

  async function saveEtape(field: 'eval' | 'meca' | 'ctrl', value: string) {
    const fields: any = { [field]: value };
    const nextStatus = nextStatusOnAssign(field, value, status);
    if (nextStatus) fields.status = nextStatus;
    // Désélection du ctrl. qlté (valeur vide '—') → retour au statut ON BENCH
    // si on était en CTRL QLTÉ. Permet de "reculer" d'une étape du workflow.
    if (field === 'ctrl' && !value && status === 'CTRL QLTÉ') {
      fields.status = 'ON BENCH';
    }
    await patchVelo(bdc.id, fields).catch(() => {});
  }

  /** Lance la création de la facture PDF + brouillon Gmail */
  async function doFacturer() {
    // Plus de pré-ouverture de fenêtre 'about:blank' (causait blank page
    // momentané, surtout sur iOS Safari où window.open peut écraser la
    // fenêtre courante). Toast en cours pour feedback, puis navigation
    // dans le même onglet une fois le draft prêt.
    toast('Génération de la facture…', 'info');

    const res = await fetch(`/api/bdc/${bdc.id}/facturer`, {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({
        noteClient: noteClientFacture || noteClient,
        remiseSvc: remiseSvc ?? { type: 'pct', value: 0 },
        remisePce: remisePce ?? { type: 'pct', value: 0 },
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error ?? 'Erreur facturation');
    }
    await Promise.all([mutateBDC(), mutateInv()]);
    toast(`Brouillon Gmail créé — ${data.message}`, 'success');
    if (data.draftUrl) {
      // Nouvel onglet (préserve la page BDT). Si le popup est bloqué par
      // le navigateur, l'utilisateur peut cliquer le lien dans le toast.
      window.open(data.draftUrl, '_blank', 'noopener,noreferrer');
    }
  }

  const services       = (bdc.items ?? []).filter(it => it.service);
  const allServicesDone = services.length > 0 && services.every(it => it.service!.fait);
  // Mécanique activée si l'évaluation est Approuvée OU Redux (Redux saute
  // l'approbation et démarre direct la séquence mécanique).
  const evalUnlocked   = bdc.checkOk || bdc.evalStatus === 'REDUX';
  const mecaDisabled   = !evalUnlocked;
  const ctrlDisabled   = !evalUnlocked || !allServicesDone;

  // Si le ctrl. qlté repasse en "En attente" (un service a été décoché
  // ou ajouté, rendant ctrlDisabled = true) alors que le statut était
  // CTRL QLTÉ, on recule automatiquement le BDT à ON BENCH pour
  // refléter que le travail n'est plus complet.
  useEffect(() => {
    if (ctrlDisabled && status === 'CTRL QLTÉ') {
      patchVelo(bdc.id, { status: 'ON BENCH' }).catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ctrlDisabled, status, bdc.id]);

  return (
    <div style={{ backgroundColor: bg, borderRadius: '30px', padding: '17px 24px 24px 24px' }}>

      {/* ── H2 — ID + Statut (pill) ── */}
      <div className="flex items-center gap-2">
        <span style={{ color: 'rgba(0,0,0,0.5)', fontSize: '30px', fontWeight: 400, lineHeight: 1 }}>
          {bdc.id}
        </span>
        {status && (
          <span
            className="inline-flex items-center whitespace-nowrap"
            style={{
              padding: '2px 10px',
              borderRadius: '999px',
              backgroundColor: 'rgba(0,0,0,0.15)',
              color: 'rgba(0,0,0,0.75)',
              fontSize: '11px',
              fontWeight: 700,
              letterSpacing: '0.04em',
              textTransform: 'uppercase',
            }}
          >
            {status}
          </span>
        )}
      </div>

      {/* ── Label "Bon de travail" ── */}
      <h4 style={{ color: 'rgba(0,0,0,0.4)', letterSpacing: '0.1em', margin: 0, marginTop: '20px', marginBottom: '4px', display: 'flex', alignItems: 'center', gap: '5px' }}>
        Bon de travail
        <HelpHint
          topic="05-workflow-bdt"
          title="Workflow : Bon de Travail"
          hint={(
            <>
              Le BDT a 4 cases d’avancement à cocher dans l’ordre :
              <ul style={{ margin: '6px 0', paddingLeft: '14px', listStyle: 'none' }}>
                <li>→ Évaluation envoyée</li>
                <li>→ Approuvée</li>
                <li>→ Bon de sortie</li>
                <li>→ Archiver</li>
              </ul>
              Chaque case déclenche une action (PDF, Gmail, statut, facture).
            </>
          )}
          size={13}
        />
      </h4>

      {/* ── H3 — Vélo desc ── */}
      <div style={{ color: 'rgba(0,0,0,0.5)', fontSize: '18px', fontWeight: 700, lineHeight: 1.1, marginBottom: '4px' }}>
        {velo
          ? [velo.marque, velo.modele, velo.couleur, velo.taille].filter(Boolean).join(', ')
          : bdc.veloDesc}
      </div>

      {/* ── Client ── */}
      <div style={{ color: 'rgba(0,0,0,0.5)', fontSize: '16px', fontWeight: 400, lineHeight: 1.1 }}>
        {bdc.clientNom}
      </div>

      {/* ── Dates ── */}
      <div className="grid grid-cols-2 gap-3" style={{ marginTop: '16px' }}>
        <div>
          <h4 style={{ color: 'rgba(0,0,0,0.4)', letterSpacing: '0.1em', margin: 0, marginBottom: '4px' }}>
            Date in
          </h4>
          <div style={{ color: 'rgba(0,0,0,0.5)', fontSize: '16px', fontWeight: 400, lineHeight: 1.1 }}>{frDate(bdc.dateIn) || '—'}</div>
        </div>
        <div>
          <h4 style={{ color: 'rgba(0,0,0,0.4)', letterSpacing: '0.1em', margin: 0, marginBottom: '4px' }}>
            Date out
          </h4>
          <div style={{ color: 'rgba(0,0,0,0.5)', fontSize: '16px', fontWeight: 400, lineHeight: 1.1 }}>
            {bdc.dateOut ? frDate(bdc.dateOut) : '—'}
          </div>
        </div>
      </div>

      {/* ── Séquence de travail ── */}
      <h4 style={{ color: 'rgba(0,0,0,0.4)', letterSpacing: '0.1em', margin: 0, marginTop: '20px', marginBottom: '8px' }}>
        Séquence de travail
      </h4>
      <div className="grid grid-cols-3 gap-2">
        <EtapeSelect
          label="évaluation"
          value={velo?.eval ?? ''}
          fg={fg}
          onSave={v => saveEtape('eval', v)}
          helpTopic="02-evaluer-velo"
          helpTitle="Évaluer un vélo"
          helpHint="Sélectionne le mécano qui fait l'évaluation. Le statut bascule en ÉVAL. Compose ensuite le devis (services + pièces) et envoie l'évaluation au client."
        />
        <EtapeSelect
          label="mécanique"
          value={velo?.meca ?? ''}
          fg={fg}
          onSave={v => saveEtape('meca', v)}
          disabled={mecaDisabled}
          helpTopic="03-reparer-velo"
          helpTitle="Réparer un vélo"
          helpHint="Sélectionne le mécano qui fait le travail. Le statut bascule en ON BENCH. À la fin, coche Bon de sortie pour générer la facture."
        />
        <EtapeSelect
          label="ctrl. qlté"
          value={velo?.ctrl ?? ''}
          fg={fg}
          onSave={v => saveEtape('ctrl', v)}
          disabled={ctrlDisabled}
        />
      </div>

      {/* ── Avancement ── */}
      <h4 style={{ color: 'rgba(0,0,0,0.4)', letterSpacing: '0.1em', margin: 0, marginTop: '20px', marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '5px' }}>
        Avancement
        <HelpHint
          topic="06-statut-bdt"
          title="Statut : Bon de Travail"
          hint="Légende des couleurs de statut : NOUVEAU (gris) → ÉVAL. (vert clair) → APPROUVÉ → ON BENCH (violet) → CTRL QLTÉ → FINI/FACTURÉ → LIVRÉ. Chaque clic case déclenche la transition."
          size={13}
        />
      </h4>

      {/* ── Actions (checkboxes) ── */}
      <div className="flex flex-col" style={{ gap: '4px' }}>
        {/* D — ÉVAL */}
        <CheckboxAction
          checked={bdc.checkEval}
          label="📤 Envoyer l'évaluation"
          checkedLabel="📤 Évaluation envoyée"
          confirmMessage="Générer l'évaluation PDF et créer un brouillon Gmail ?"
          uncheckConfirmMessage={`Régénérer l'évaluation du BDC ${bdc.id} ? Le PDF et le brouillon Gmail existants seront remplacés.`}
          onAction={async () => {
            // Plus de pré-ouverture de fenêtre — toast pour feedback,
            // navigation dans le même onglet vers le brouillon Gmail.
            toast('Génération de l\'évaluation…', 'info');
            const res = await fetch(`/api/bdc/${bdc.id}/evaluation`, {
              method : 'POST',
              headers: { 'Content-Type': 'application/json' },
              body   : JSON.stringify({
                noteClient,
                remiseSvc: remiseSvc ?? { type: 'pct', value: 0 },
                remisePce: remisePce ?? { type: 'pct', value: 0 },
              }),
            });
            const data = await res.json();
            if (!res.ok) {
              throw new Error(data.error ?? 'Erreur évaluation');
            }
            await Promise.all([mutateBDC(), mutateInv()]);
            toast(`Brouillon Gmail créé — ${data.message}`, 'success');
            if (data.draftUrl) {
              window.open(data.draftUrl, '_blank', 'noopener,noreferrer');
            }
          }}
          onUncheck={async () => {
            // Régénération : on clear le flag puis on relance la génération.
            toast('Régénération de l\'évaluation…', 'info');
            await resetEval();
            const res = await fetch(`/api/bdc/${bdc.id}/evaluation`, {
              method : 'POST',
              headers: { 'Content-Type': 'application/json' },
              body   : JSON.stringify({
                noteClient,
                remiseSvc: remiseSvc ?? { type: 'pct', value: 0 },
                remisePce: remisePce ?? { type: 'pct', value: 0 },
              }),
            });
            const data = await res.json();
            if (!res.ok) {
              throw new Error(data.error ?? 'Erreur évaluation');
            }
            await Promise.all([mutateBDC(), mutateInv()]);
            toast(`Évaluation régénérée — ${data.message}`, 'success');
            if (data.draftUrl) {
              window.open(data.draftUrl, '_blank', 'noopener,noreferrer');
            }
          }}
        />

        {/* E — Statut éval client : checkbox + label + 4 icônes mutex.
             👍🏻 Approuvée (vert) | ✂️ Redux→ON BENCH (orange) |
             ✋🏻 En attente (jaune) | 👎🏻 Refusée→archivage (rouge).
             Cliquer sur l'icône active la désélectionne (retour à ''). */}
        <EvalStatusButtons
          value={bdc.evalStatus ?? (bdc.checkOk ? 'APPROUVE' : '')}
          onChange={async (next) => {
            // Refusée → on archive directement (équivalent au choix
            // « Évaluation refusée » de la modale Archiver, mais accessible
            // depuis l'icône 👎🏻).
            if (next === 'REFUSE') {
              await setEvalStatus('REFUSE');
              await archiver(true);
              onArchived?.();
              return;
            }
            await setEvalStatus(next);
            await mutateInv();
            if (next === 'APPROUVE') onApproved?.();
          }}
        />

        {/* F — BDS → déclenche aussi la facturation automatiquement */}
        <CheckboxAction
          checked={bdc.checkBds}
          label="👌🏻 Bon de sortie"
          checkedLabel="🤙🏻 Facture envoyée"
          confirmMessage="Émettre le bon de sortie et générer la facture PDF ?"
          uncheckConfirmMessage={`Réinitialiser la facture du BDC ${bdc.id} ? Le statut repassera à ON BENCH (retour au travail).`}
          onAction={async () => {
            // 1. Marquer BDS dans le sheet
            await patchBDC('bon-de-sortie');
            // 2. Générer la facture + brouillon Gmail automatiquement
            await doFacturer();
          }}
          onUncheck={async () => {
            await resetFacture();
            await mutateInv();
          }}
        />

        {/* G — OUT : popup 2 choix Facture payée / Évaluation refusée
            Un BDT encore dans la séquence de travail (Inventaire actif)
            ne doit JAMAIS avoir Archiver coché — sinon le checkbox se
            bloque. On force donc checked=false, indépendamment de ce
            qui est dans le sheet (qui pourrait être stale après un
            cycle archive → désarchive → archive). */}
        <CheckboxAction
          checked={false}
          label="📥 Archiver"
          onAction={async () => {
            const mode    = archiveModeRef.current;
            const payMode = paymentModeRef.current;
            archiveModeRef.current = null;
            paymentModeRef.current = null;
            // Navigation immédiate vers /inventaire pour éviter le rendu
            // « Vélo introuvable » sur la page détail pendant que SWR
            // re-fetch /api/inventaire (le BDT vient d'en sortir).
            onArchived?.();
            try {
              // v1.0.19+ : si paiement, on marque la facture PAYÉ +
              // mode dans le journal AVANT archivage. Si l'API échoue,
              // on log mais on n'annule pas l'archivage (l'utilisateur
              // peut toujours rectifier le mode plus tard depuis la
              // fiche archivée via FactureStatusPanel).
              if (mode === 'paye' && payMode) {
                try {
                  await fetch('/api/factures/log-status', {
                    method : 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body   : JSON.stringify({
                      factureRef  : bdc.id,
                      docType     : 'facture',
                      statut      : 'PAYÉ',
                      modePaiement: payMode,
                    }),
                  });
                } catch (e: any) {
                  console.warn('[archiver] log-status failed:', e?.message);
                }
              }
              await archiver(mode === 'refuse');
              toast(`BDT ${bdc.id} archivé`);
            } catch (e: any) {
              toast(`Échec archivage : ${e?.message ?? 'erreur'}`, 'error');
            }
            // patchVelo({status:'LIVRÉ'}) retiré — inutile, le vélo n'est
            // plus dans INVENTAIRE après archiver(), l'appel renvoyait 404
            // et bloquait l'UI ~5 sec avant le redirect.
          }}
          customConfirm={({ open, onCancel, runAction }) => (
            <ArchiveChoiceDialog
              open={open}
              bdcId={bdc.id}
              onCancel={onCancel}
              onFacturePayee={(payMode) => {
                archiveModeRef.current = 'paye';
                paymentModeRef.current = payMode;
                runAction();
              }}
              onEvalRefusee={() => {
                archiveModeRef.current = 'refuse';
                paymentModeRef.current = null;
                runAction();
              }}
            />
          )}
        />
      </div>
    </div>
  );
}

// ─── EvalStatusButtons ──────────────────────────────────────────────
// Style identique à CheckboxAction (« Évaluation envoyée ») :
// checkbox + label « Évaluation : » + 4 icônes inline.
// Au repos (value === '') : toutes les icônes à 100%. Une fois un
// statut sélectionné : seule la sélectionnée à 100%, les autres à 50%.
const EVAL_OPTIONS: {
  value: 'APPROUVE' | 'REDUX' | 'ATTENTE' | 'REFUSE';
  icon : string;
  label: string;
}[] = [
  { value: 'APPROUVE', icon: '👍🏻', label: 'Approuvée'  },
  { value: 'REDUX',    icon: '✂️',  label: 'Redux'      },
  { value: 'ATTENTE',  icon: '✋🏻', label: 'Arrêt'      },
  { value: 'REFUSE',   icon: '👎🏻', label: 'Refusée'    },
];

function EvalStatusButtons({
  value, onChange,
}: {
  value: '' | 'APPROUVE' | 'REDUX' | 'ATTENTE' | 'REFUSE';
  onChange: (next: '' | 'APPROUVE' | 'REDUX' | 'ATTENTE' | 'REFUSE') => void | Promise<void>;
}) {
  const checked = value !== '';
  return (
    <label className="flex items-center gap-3 cursor-pointer select-none">
      <input
        type="checkbox"
        checked={checked}
        onChange={() => { if (checked) void onChange(''); }}
        className="custom-checkbox"
      />
      <span style={{ fontSize: '16px', fontWeight: 700, lineHeight: 1.2, color: 'rgba(0,0,0,0.5)' }}>
        Éval.
      </span>
      <div className="flex items-center" style={{ gap: '6px' }}>
        {EVAL_OPTIONS.map(opt => {
          const isActive = value === opt.value;
          // Si aucun statut choisi → 100%. Sinon : actif=100%, autres=50%.
          const opacity = !checked ? 1 : (isActive ? 1 : 0.5);
          return (
            <button
              key={opt.value}
              type="button"
              onClick={() => void onChange(isActive ? '' : opt.value)}
              title={opt.label}
              className="flex items-center transition-opacity"
              style={{
                backgroundColor: 'rgba(255,255,255,0.5)',
                border: 'none',
                cursor: 'pointer',
                padding: '4px 10px',
                height: '28px',
                borderRadius: '14px',
                gap: '5px',
                fontSize: '13px',
                fontWeight: 700,
                color: 'rgba(0,0,0,0.7)',
                opacity,
              }}
            >
              <span style={{ fontSize: '16px', lineHeight: 1 }}>{opt.icon}</span>
              {isActive && <span>{opt.label}</span>}
            </button>
          );
        })}
      </div>
    </label>
  );
}
