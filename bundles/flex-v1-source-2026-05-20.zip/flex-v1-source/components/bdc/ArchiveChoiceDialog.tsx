'use client';
import Modal from '@/components/ui/Modal';
import {
  BanknotesIcon,
  CreditCardIcon,
  DevicePhoneMobileIcon,
  NoSymbolIcon,
} from '@heroicons/react/24/outline';

type ModePaiement = 'comptant' | 'interac' | 'cartes';

interface ArchiveChoiceDialogProps {
  open: boolean;
  bdcId: string;
  /** v1.0.19+ : passe aussi le mode de paiement choisi par l'utilisateur. */
  onFacturePayee: (mode: ModePaiement) => void;
  onEvalRefusee : () => void;
  onCancel      : () => void;
}

const MODES: { value: ModePaiement; label: string; icon: typeof BanknotesIcon }[] = [
  { value: 'comptant', label: 'Comptant', icon: BanknotesIcon },
  { value: 'interac',  label: 'Interac',  icon: DevicePhoneMobileIcon },
  { value: 'cartes',   label: 'Cartes',   icon: CreditCardIcon },
];

/**
 * Popup d'archivage à 4 choix. Quand l'utilisateur active le checkbox
 * « Archiver » sur un BDT, on lui demande comment le client a payé :
 *  - Comptant / Interac / Cartes : flux normal — la facture est marquée
 *    PAYÉ + mode dans le journal ENCAISSE BDT, puis archivage.
 *  - Évaluation refusée : le client refuse les travaux, on archive sans
 *    facture et l'archive est marquée « ÉVAL. REFUSÉE ».
 *
 * v1.0.19+ : la sélection du mode est intégrée à l'archivage pour éviter
 * d'avoir à ouvrir la fiche post-archivage juste pour saisir le mode.
 */
export default function ArchiveChoiceDialog({
  open, bdcId, onFacturePayee, onEvalRefusee, onCancel,
}: ArchiveChoiceDialogProps) {
  return (
    <Modal open={open} onClose={onCancel} title={`Archiver BDC ${bdcId}`} size="md">
      <div className="space-y-4">
        <p className="text-sm" style={{ color: 'rgba(0,0,0,0.65)' }}>
          Le client a payé — comment ?
        </p>

        {/* Trois boutons mode de paiement = facture marquée PAYÉ + archivage en 1 clic. */}
        <div className="flex flex-col" style={{ gap: '10px' }}>
          {MODES.map(m => {
            const Icon = m.icon;
            return (
              <button
                key={m.value}
                type="button"
                onClick={() => onFacturePayee(m.value)}
                className="flex items-center gap-3 text-left transition-opacity hover:opacity-80"
                style={{
                  padding: '14px 18px',
                  borderRadius: '20px',
                  border: '2px solid #88fa4e',
                  backgroundColor: 'rgba(136, 250, 78, 0.12)',
                  color: 'rgba(0,0,0,0.8)',
                  cursor: 'pointer',
                }}
              >
                <Icon style={{ width: '26px', height: '26px', color: '#1f8f1f', flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: '15px', fontWeight: 700 }}>Payée — {m.label}</div>
                  <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.55)', marginTop: '2px' }}>
                    Marque la facture PAYÉ ({m.label.toLowerCase()}) et archive le BDT.
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Séparateur visuel léger */}
        <div style={{ height: '1px', backgroundColor: 'rgba(0,0,0,0.08)', margin: '4px 0' }} />

        <button
          type="button"
          onClick={onEvalRefusee}
          className="flex items-center gap-3 text-left w-full transition-opacity hover:opacity-80"
          style={{
            padding: '14px 18px',
            borderRadius: '20px',
            border: '2px solid #e53935',
            backgroundColor: 'rgba(229, 57, 53, 0.10)',
            color: 'rgba(0,0,0,0.8)',
            cursor: 'pointer',
          }}
        >
          <NoSymbolIcon style={{ width: '26px', height: '26px', color: '#b71c1c', flexShrink: 0 }} />
          <div>
            <div style={{ fontSize: '15px', fontWeight: 700 }}>Évaluation refusée</div>
            <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.55)', marginTop: '2px' }}>
              Le client refuse les travaux — archivage sans facture, trace conservée.
            </div>
          </div>
        </button>

        <div className="flex justify-end pt-1">
          <button type="button" onClick={onCancel} className="btn-secondary">
            Annuler
          </button>
        </div>
      </div>
    </Modal>
  );
}
