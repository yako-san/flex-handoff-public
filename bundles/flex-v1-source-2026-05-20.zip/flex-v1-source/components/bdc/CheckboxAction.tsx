'use client';
import { useState, type ReactNode } from 'react';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import { toast } from '@/components/ui/Toast';

interface CheckboxActionProps {
  checked: boolean;
  label: string;
  /** Label affiché quand la case est cochée (ex. "Facture envoyée") */
  checkedLabel?: string;
  confirmMessage?: string;
  /** Message de confirmation pour décocher */
  uncheckConfirmMessage?: string;
  danger?: boolean;
  disabled?: boolean;
  onAction: () => Promise<void>;
  /** Si fourni, la case peut être décochée pour réinitialiser */
  onUncheck?: () => Promise<void>;
  /** Rendu custom du dialog de confirmation. Si fourni, remplace ConfirmDialog
   *  standard lors du coche. Reçoit `open`, `onCancel` et `runAction` qui
   *  déclenche le onAction avec gestion pending/toast/erreur. */
  customConfirm?: (ctx: { open: boolean; onCancel: () => void; runAction: () => void }) => ReactNode;
}

/**
 * Checkbox avec confirmation avant action serveur + update optimiste.
 * Supporte le décocheage (onUncheck) pour les états réinitialisables.
 */
export default function CheckboxAction({
  checked, label, checkedLabel, confirmMessage, uncheckConfirmMessage,
  danger = false, disabled = false, onAction, onUncheck, customConfirm,
}: CheckboxActionProps) {
  const [pending, setPending]             = useState(false);
  const [showConfirm, setShowConfirm]     = useState(false);
  const [showUncheck, setShowUncheck]     = useState(false);

  const displayLabel = (checked && checkedLabel) ? checkedLabel : label;
  const canUncheck   = checked && !!onUncheck;

  // Extract leading icon (everything before first space) to render at 100% opacity
  const firstSpaceIdx = displayLabel.indexOf(' ');
  const icon = firstSpaceIdx > 0 ? displayLabel.slice(0, firstSpaceIdx) : '';
  const text = firstSpaceIdx > 0 ? displayLabel.slice(firstSpaceIdx + 1) : displayLabel;

  async function handleConfirm() {
    setShowConfirm(false);
    setPending(true);
    try {
      await onAction();
      toast(`${label} ✓`);
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setPending(false);
    }
  }

  async function handleUncheckConfirm() {
    setShowUncheck(false);
    setPending(true);
    try {
      await onUncheck!();
      toast(`${displayLabel} réinitialisé`);
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setPending(false);
    }
  }

  function handleClick() {
    if (pending) return;

    if (checked) {
      // Clic sur une case déjà cochée → décochage si onUncheck fourni
      if (!canUncheck) return;
      if (uncheckConfirmMessage) {
        setShowUncheck(true);
      } else {
        handleUncheckConfirm();
      }
    } else {
      // Clic pour cocher
      if (disabled) return;
      if (customConfirm || confirmMessage) {
        setShowConfirm(true);
      } else {
        handleConfirm();
      }
    }
  }

  const isEffectivelyDisabled = pending || (disabled && !canUncheck);

  return (
    <>
      <label className={`flex items-center gap-3 cursor-pointer select-none ${isEffectivelyDisabled ? 'opacity-40 cursor-not-allowed' : ''}`}>
        <input
          type="checkbox"
          checked={checked}
          onChange={handleClick}
          disabled={isEffectivelyDisabled}
          className="custom-checkbox"
        />
        <span style={{ fontSize: '16px', fontWeight: 700, lineHeight: 1.2 }}>
          {icon && <span style={{ opacity: 1 }}>{icon} </span>}
          <span style={{ color: danger ? '#dc2626' : 'rgba(0,0,0,0.5)' }}>{text}</span>
          {pending && <span style={{ color: 'rgba(0,0,0,0.5)' }} className="ml-1">…</span>}
          {canUncheck && !pending && (
            <span style={{ color: 'rgba(0,0,0,0.5)' }} className="ml-1 text-xs" title="Cliquez pour réinitialiser">↩</span>
          )}
        </span>
      </label>

      {customConfirm
        ? customConfirm({
            open      : showConfirm,
            onCancel  : () => setShowConfirm(false),
            runAction : handleConfirm,
          })
        : confirmMessage && (
            <ConfirmDialog
              open={showConfirm}
              title={label}
              message={confirmMessage}
              confirmLabel="Confirmer"
              danger={danger}
              onConfirm={handleConfirm}
              onCancel={() => setShowConfirm(false)}
            />
          )}

      {uncheckConfirmMessage && (
        <ConfirmDialog
          open={showUncheck}
          title={checkedLabel ?? label}
          message={uncheckConfirmMessage}
          confirmLabel="Réinitialiser"
          danger
          onConfirm={handleUncheckConfirm}
          onCancel={() => setShowUncheck(false)}
        />
      )}
    </>
  );
}
