'use client';
import { useEffect, useState } from 'react';
import { toast } from '@/components/ui/Toast';
import { CheckCircleIcon, BanknotesIcon, CreditCardIcon, DevicePhoneMobileIcon } from '@heroicons/react/24/outline';

/**
 * v1.0.15+ — Affiche et permet de modifier le statut + mode de paiement
 * d'une facture déjà émise (BDT facturé ou vente directe).
 *
 * Utilisé dans la fiche BDT FACTURÉ (`/inventaire/[id]`) et dans
 * `/catalogue/ventes` (vue post-facturation). Lit/écrit via
 * `/api/factures/log-status`.
 */

type Statut       = 'ÉMIS' | 'PAYÉ' | 'ANNULÉ';
type ModePaiement = 'comptant' | 'interac' | 'cartes';

interface Props {
  /** Référence de la facture : pour BDT = bdc.id (ex. "0042"), pour vente = factureNumero (ex. "V0012"). */
  factureRef: string;
  docType   : 'facture' | 'vente';
}

const MODES: { value: ModePaiement; label: string; icon: typeof BanknotesIcon }[] = [
  { value: 'comptant', label: 'Comptant', icon: BanknotesIcon },
  { value: 'interac',  label: 'Interac',  icon: DevicePhoneMobileIcon },
  { value: 'cartes',   label: 'Cartes',   icon: CreditCardIcon },
];

export default function FactureStatusPanel({ factureRef, docType }: Props) {
  const [loading, setLoading]           = useState(true);
  const [saving,  setSaving]            = useState<'statut' | 'mode' | null>(null);
  const [statut,  setStatut]            = useState<Statut>('ÉMIS');
  const [mode,    setMode]              = useState<ModePaiement>('comptant');
  const [factureDate, setFactureDate]   = useState('');

  async function refresh() {
    if (!factureRef) return;
    setLoading(true);
    try {
      const res  = await fetch(`/api/factures/log-status?ref=${encodeURIComponent(factureRef)}&type=${docType}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Erreur lecture statut');
      if (json.status) {
        setStatut((json.status.statut as Statut) || 'ÉMIS');
        setMode  ((json.status.modePaiement as ModePaiement) || 'comptant');
        setFactureDate(json.status.date || '');
      }
    } catch (err: any) {
      // Silencieux : facture peut-être pas encore au journal
      console.warn('[facture-status]', err?.message);
    } finally { setLoading(false); }
  }

  useEffect(() => { refresh(); /* eslint-disable-next-line */ }, [factureRef, docType]);

  async function patch(fields: { statut?: Statut; modePaiement?: ModePaiement }, scope: 'statut' | 'mode') {
    setSaving(scope);
    try {
      const res = await fetch('/api/factures/log-status', {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ factureRef, docType, ...fields }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Erreur mise à jour');
      if (fields.statut) setStatut(fields.statut);
      if (fields.modePaiement) setMode(fields.modePaiement);
      toast(scope === 'statut' ? `Facture marquée ${fields.statut}` : `Mode : ${fields.modePaiement}`, 'success');
    } catch (err: any) {
      toast(err.message, 'error');
    } finally { setSaving(null); }
  }

  if (!factureRef) return null;

  return (
    <div
      style={{
        padding: '14px 16px',
        backgroundColor: statut === 'PAYÉ' ? 'rgba(212,237,188,0.4)' : 'rgba(0,0,0,0.04)',
        borderRadius: '12px',
        marginTop: '12px',
      }}
    >
      <div className="flex items-center justify-between" style={{ marginBottom: '10px' }}>
        <div className="flex items-center gap-2">
          {statut === 'PAYÉ' && <CheckCircleIcon style={{ width: '20px', height: '20px', color: '#2e7d32' }} />}
          <span style={{ fontSize: '13px', fontWeight: 700, color: 'rgba(0,0,0,0.7)' }}>
            Facture {factureRef}
          </span>
          {factureDate && (
            <span style={{ fontSize: '11px', color: 'rgba(0,0,0,0.4)' }}>
              {factureDate}
            </span>
          )}
        </div>
        {loading && <span style={{ fontSize: '11px', color: 'rgba(0,0,0,0.4)' }}>chargement…</span>}
      </div>

      {/* Statut : pills toggle */}
      <div className="flex flex-wrap gap-2" style={{ marginBottom: '10px' }}>
        {(['ÉMIS', 'PAYÉ', 'ANNULÉ'] as Statut[]).map(s => {
          const active = s === statut;
          return (
            <button
              key={s}
              type="button"
              onClick={() => active ? null : patch({ statut: s }, 'statut')}
              disabled={saving === 'statut' || active}
              style={{
                height: '32px',
                padding: '0 14px',
                borderRadius: '32px',
                fontSize: '12px',
                fontWeight: 700,
                letterSpacing: '0.04em',
                border: 'none',
                cursor: active ? 'default' : 'pointer',
                backgroundColor: active
                  ? (s === 'PAYÉ' ? '#2e7d32' : s === 'ANNULÉ' ? '#d92020' : '#fff056')
                  : 'rgba(255,255,255,0.6)',
                color: active && (s === 'PAYÉ' || s === 'ANNULÉ') ? '#fff' : 'rgba(0,0,0,0.7)',
                opacity: saving === 'statut' && !active ? 0.4 : 1,
              }}
            >
              {s}
            </button>
          );
        })}
      </div>

      {/* Mode paiement : pills */}
      <div>
        <span className="legende" style={{ color: 'rgba(0,0,0,0.4)', display: 'block', marginBottom: '6px' }}>Mode de paiement</span>
        <div className="flex flex-wrap gap-2">
          {MODES.map(m => {
            const Icon = m.icon;
            const active = m.value === mode;
            return (
              <button
                key={m.value}
                type="button"
                onClick={() => active ? null : patch({ modePaiement: m.value }, 'mode')}
                disabled={saving === 'mode' || active}
                className="flex items-center gap-1"
                style={{
                  height: '32px',
                  padding: '0 12px',
                  borderRadius: '32px',
                  fontSize: '12px',
                  fontWeight: 700,
                  border: 'none',
                  cursor: active ? 'default' : 'pointer',
                  backgroundColor: active ? '#fff056' : 'rgba(255,255,255,0.6)',
                  color: 'rgba(0,0,0,0.7)',
                  opacity: saving === 'mode' && !active ? 0.4 : 1,
                }}
              >
                <Icon style={{ width: '14px', height: '14px' }} />
                {m.label}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
