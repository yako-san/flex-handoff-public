'use client';
import { useEffect, useState } from 'react';
import Modal from '@/components/ui/Modal';
import { frPrix } from '@/lib/utils/format';
import { computeTaxes } from '@/lib/finances/taxes';
import { BanknotesIcon, CreditCardIcon, DevicePhoneMobileIcon } from '@heroicons/react/24/outline';
import type { BDC } from '@/types/bdc';

type ModePaiement = 'comptant' | 'interac' | 'cartes';

interface AvanceObj {
  montant: number;
  mode?: ModePaiement;
  note?: string;
}

interface BDCTotauxProps {
  bdc: BDC;
  /** Montant de la remise sur services (en $) */
  remiseSvc?: number;
  /** Montant de la remise sur pièces (en $) */
  remisePce?: number;
  /** v1.0.15+ : avance versée par le client (acompte). Affichée en
   *  déduction du « reste à payer » sans toucher au total ni aux taxes. */
  avance?: AvanceObj;
  /** v1.0.17+ : callback de mise à jour de l'avance (modal au clic). */
  onAvanceChange?: (v: AvanceObj) => void;
  /** Total pièces affiché — calculé côté client. Fallback sur bdc.totalPieces. */
  totalPiecesAffiche?: number;
  /** Total services affiché — calculé côté client. Fallback sur bdc.totalServices.
   *  Utile quand le sheet TOT est désynchronisé. */
  totalServicesAffiche?: number;
}

const MODES: { value: ModePaiement; label: string; icon: typeof BanknotesIcon }[] = [
  { value: 'comptant', label: 'Comptant', icon: BanknotesIcon },
  { value: 'interac',  label: 'Interac',  icon: DevicePhoneMobileIcon },
  { value: 'cartes',   label: 'Cartes',   icon: CreditCardIcon },
];

function modeLabel(m?: ModePaiement): string {
  return MODES.find(x => x.value === m)?.label ?? '';
}

export default function BDCTotaux({
  bdc,
  remiseSvc = 0,
  remisePce = 0,
  avance,
  onAvanceChange,
  totalPiecesAffiche,
  totalServicesAffiche,
}: BDCTotauxProps) {
  const totalSvcBase = totalServicesAffiche ?? bdc.totalServices;
  const totalPceBase = totalPiecesAffiche   ?? bdc.totalPieces;
  const netSvc     = Math.max(0, totalSvcBase - remiseSvc);
  const netPce     = Math.max(0, totalPceBase - remisePce);
  const sousTotalHT = netSvc + netPce;
  // Total facture TTC = sous-total HT + TPS/TVQ Québec.
  const { grandTotal: totalTTC } = computeTaxes(sousTotalHT);

  const montantAv  = avance?.montant ?? 0;
  const hasAvance  = montantAv > 0;
  // Reste à payer = TTC - avance (l'avance est déduite après taxes,
  // pratique courante des acomptes au Québec).
  const reste      = Math.max(0, totalTTC - montantAv);

  const labelStyle: React.CSSProperties = {
    color: 'rgba(255,255,255,0.5)',
    fontSize: '14px',
    fontStyle: 'italic',
  };

  const linkStyle: React.CSSProperties = {
    color: 'rgba(255,255,255,0.7)',
    fontSize: '14px',
    fontStyle: 'italic',
    textDecoration: 'underline',
    background: 'transparent',
    border: 'none',
    padding: 0,
    cursor: 'pointer',
  };

  // ── Modal d'édition ──────────────────────────────────────────
  const [showModal, setShowModal] = useState(false);
  const [montantStr, setMontantStr] = useState('');
  const [mode,       setMode]       = useState<ModePaiement | ''>('');
  const [note,       setNote]       = useState('');

  // Réinitialise les champs à chaque ouverture du modal
  useEffect(() => {
    if (!showModal) return;
    setMontantStr(montantAv > 0 ? String(montantAv) : '');
    setMode(avance?.mode ?? '');
    setNote(avance?.note ?? '');
  }, [showModal, montantAv, avance?.mode, avance?.note]);

  function openModal() {
    if (!onAvanceChange) return; // mode lecture seule
    setShowModal(true);
  }

  function handleOk() {
    if (!onAvanceChange) return;
    const m = parseFloat(montantStr.replace(',', '.')) || 0;
    onAvanceChange({
      montant: m > 0 ? m : 0,
      mode  : (mode || undefined) as ModePaiement | undefined,
      note  : note.trim() || undefined,
    });
    setShowModal(false);
  }

  function handleClear() {
    if (!onAvanceChange) return;
    onAvanceChange({ montant: 0 });
    setShowModal(false);
  }

  return (
    <>
      <div
        className="flex items-center justify-between"
        style={{ backgroundColor: 'rgba(0,0,0,0.20)', borderRadius: '30px', height: '64px', padding: '0 24px' }}
      >
        {/* Détail à gauche : Services + Pièces = HT, puis lien « avance ? » ou résumé */}
        <span className="flex items-center gap-2 flex-wrap" style={{ minWidth: 0 }}>
          <span style={labelStyle}>
            Services : {frPrix(netSvc)} + Pièces {frPrix(netPce)} = {frPrix(sousTotalHT)} HT
          </span>
          {onAvanceChange && (
            hasAvance ? (
              <button
                type="button"
                onClick={openModal}
                style={linkStyle}
                title={avance?.note ? `Modifier l'avance — note : ${avance.note}` : "Modifier l'avance"}
              >
                avance : {frPrix(montantAv)}
                {avance?.mode ? ` · ${modeLabel(avance.mode)}` : ''}
              </button>
            ) : (
              <button type="button" onClick={openModal} style={linkStyle} title="Saisir une avance">
                avance ?
              </button>
            )
          )}
          {!onAvanceChange && hasAvance && (
            <span style={labelStyle}>
              · avance {frPrix(montantAv)}{avance?.mode ? ` (${modeLabel(avance.mode)})` : ''}
            </span>
          )}
        </span>

        {/* Total à droite — affiche le total facture TTC (taxes incluses) */}
        <div className="flex items-center gap-3">
          {hasAvance ? (
            <>
              <span style={labelStyle}>reste à payer</span>
              <span
                style={{
                  color: 'rgba(255,255,255,0.4)',
                  fontSize: '14px',
                  fontStyle: 'italic',
                  textDecoration: 'line-through',
                }}
                title="Total facture TTC avant déduction de l'acompte"
              >
                {frPrix(totalTTC)}
              </span>
              <span style={{
                color: '#fff056',
                fontSize: '30px',
                fontWeight: 700,
                lineHeight: 1,
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              }}>
                {frPrix(reste)}
              </span>
            </>
          ) : (
            <>
              <span style={labelStyle}>total facture</span>
              <span style={{
                color: '#fff056',
                fontSize: '30px',
                fontWeight: 700,
                lineHeight: 1,
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              }}>
                {frPrix(totalTTC)}
              </span>
            </>
          )}
        </div>
      </div>

      {/* ── Modal d'édition de l'avance ── */}
      <Modal
        open={showModal}
        onClose={() => setShowModal(false)}
        title="Avance versée"
        size="md"
      >
        <div className="flex flex-col" style={{ gap: '16px' }}>
          {/* Montant — text + inputMode decimal pour accepter "79,33" et "79.33" */}
          <div>
            <label className="label-system">Montant ($)</label>
            <input
              type="text"
              inputMode="decimal"
              autoFocus
              value={montantStr}
              onChange={e => {
                // Autorise chiffres, , et . — refuse le reste
                const v = e.target.value.replace(/[^\d.,]/g, '');
                setMontantStr(v);
              }}
              placeholder="0,00"
              className="input-system"
            />
          </div>

          {/* Mode de paiement */}
          <div>
            <label className="label-system">Mode de paiement</label>
            <div className="flex flex-wrap gap-2" style={{ marginTop: '4px' }}>
              {MODES.map(m => {
                const Icon = m.icon;
                const active = m.value === mode;
                return (
                  <button
                    key={m.value}
                    type="button"
                    onClick={() => setMode(active ? '' : m.value)}
                    className="flex items-center gap-1"
                    style={{
                      height: '34px',
                      padding: '0 14px',
                      borderRadius: '34px',
                      fontSize: '13px',
                      fontWeight: 700,
                      border: 'none',
                      cursor: 'pointer',
                      backgroundColor: active ? '#fff056' : 'rgba(0,0,0,0.06)',
                      color: 'rgba(0,0,0,0.7)',
                    }}
                  >
                    <Icon style={{ width: '14px', height: '14px' }} />
                    {m.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Note */}
          <div>
            <label className="label-system">Note</label>
            <textarea
              rows={3}
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="Détail facultatif (ex. acompte évaluation, n° de chèque…)"
              className="input-system"
              style={{ resize: 'vertical', minHeight: '60px' }}
            />
          </div>

          {/* Boutons */}
          <div className="flex items-center justify-between" style={{ paddingTop: '4px' }}>
            {hasAvance ? (
              <button
                type="button"
                onClick={handleClear}
                className="btn-secondary"
                style={{ padding: '8px 16px', fontSize: '13px' }}
                title="Effacer l'avance"
              >
                Effacer
              </button>
            ) : <span />}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="btn-secondary"
                style={{ padding: '8px 16px', fontSize: '13px' }}
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleOk}
                className="btn-primary"
                style={{ padding: '8px 18px', fontSize: '13px' }}
              >
                OK
              </button>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
}
