import { frPrix } from '@/lib/utils/format';
import { pceNomAvecStock } from '@/lib/utils/pieces';
import type { BDCItem } from '@/types/bdc';

import { CMD_STYLE } from '@/lib/utils/statuts';
const FLAG_COLORS: Record<string, { bg: string; color: string }> = Object.fromEntries(
  Object.entries(CMD_STYLE).map(([k, v]) => [k, { bg: v.bg, color: v.fg }])
);

/** Ajoute l'emoji 🧰 devant le nom de service, sauf forfaits/rencontres */
function svcLabel(nom: string): string {
  if (nom.startsWith('👌🏻 Forfait') || nom.startsWith('👋 Rencontre')) return nom;
  return '🧰 : ' + nom;
}

/** Ajoute l'emoji ⚙️ devant le nom de pièce */
function pceLabel(nom: string): string {
  return '⚙️ : ' + nom;
}

interface BDCItemRowProps {
  item: BDCItem;
}

export default function BDCItemRow({ item }: BDCItemRowProps) {
  const { service, piece } = item;

  return (
    <tr className="border-b last:border-0 hover:bg-gray-50 text-sm">
      {/* Services (colonnes K–N) */}
      <td className="px-3 py-1.5 text-gray-800">{service ? svcLabel(service.nom) : ''}</td>
      <td className="px-3 py-1.5 text-center">
        {service && (
          <span className={`text-xs px-1.5 py-0.5 rounded ${service.fait ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
            {service.fait ? 'FAIT' : '...'}
          </span>
        )}
      </td>
      <td className="px-3 py-1.5 text-right text-gray-600">
        {service ? frPrix(service.prix) : ''}
      </td>

      {/* Séparateur */}
      <td className="px-2" />

      {/* Pièces (colonnes P–V) */}
      <td className="px-3 py-1.5 text-gray-800">
        {piece && (() => {
          const { label, stockInfo } = pceNomAvecStock(piece.nom, 0);
          return (
            <>
              {pceLabel(label)}
              {stockInfo && (
                <span className="ml-1 text-xs text-gray-400 italic">{stockInfo}</span>
              )}
            </>
          );
        })()}
      </td>
      <td className="px-3 py-1.5 text-right text-gray-600">
        {piece ? frPrix(piece.prix) : ''}
      </td>
      <td className="px-3 py-1.5 text-center text-xs">
        {piece && (
          <span
            className="px-1.5 py-0.5 rounded font-bold"
            style={FLAG_COLORS[piece.cmd] ?? { bg: '#fff', color: '#000' }}
          >
            {piece.cmd}
          </span>
        )}
      </td>
      <td className="px-3 py-1.5 text-center text-gray-600">{piece?.qte ?? ''}</td>
      <td className="px-3 py-1.5 text-right text-gray-700 font-medium">
        {piece ? frPrix(piece.sousTotal) : ''}
      </td>
    </tr>
  );
}
