'use client';
import Link from 'next/link';
import { useArchives } from '@/hooks/useArchives';
import { useInventaire } from '@/hooks/useInventaire';
import { frPrix, frDate } from '@/lib/utils/format';
import { STATUTS } from '@/lib/utils/statuts';

/**
 * Historique des BDT passés pour un client donné.
 * Liste les BDT archivés (LIVRÉ / FACTURÉ / REFUSÉ) + les BDT actifs autres
 * que celui actuellement consulté. Tri par date (plus récent en tête).
 */
interface Props {
  /** Nom complet du client (filtre de matching). */
  client: string;
  /** BDT actuellement ouvert — exclu de la liste pour éviter le doublon. */
  currentBdtId?: string;
}

export default function VeloHistory({ client, currentBdtId }: Props) {
  const { bdcs: archives } = useArchives();
  const { velos }          = useInventaire();

  if (!client) return null;

  // BDT archivés du client
  const archived = archives
    .filter(b => b.clientNom === client && b.id !== currentBdtId)
    .map(b => ({
      id        : b.id,
      date      : b.dateOut || '',
      status    : b.archiveStatus || 'ARCHIVÉ',
      veloDesc  : b.veloDesc,
      total     : (b.totalServices || 0) + (b.totalPieces || 0),
      isArchived: true as const,
    }));

  // BDT actifs du client (hors courant) — aussi pertinents pour l'historique
  const active = velos
    .filter(v => v.client === client && v.id !== currentBdtId)
    .map(v => ({
      id        : v.id,
      date      : (v.date1 || '').split('\n')[0] || '',
      status    : v.status,
      veloDesc  : [v.marque, v.modele, v.couleur, v.taille].filter(Boolean).join(', '),
      total     : 0,
      isArchived: false as const,
    }));

  // Merge + tri par date descendante (plus récent en haut)
  const history = [...active, ...archived]
    .sort((a, b) => (b.date || '').localeCompare(a.date || ''));

  if (history.length === 0) return null;

  return (
    <div
      className="flex flex-col"
      style={{
        backgroundColor: 'rgba(255,255,255,0.5)',
        borderRadius: '20px',
        padding: '16px',
        gap: '4px',
      }}
    >
      <div className="flex items-center justify-between" style={{ marginBottom: '6px' }}>
        <h4 style={{ color: 'rgba(0,0,0,0.4)', letterSpacing: '0.1em', margin: 0, fontSize: '12px' }}>
          HISTORIQUE ({history.length})
        </h4>
      </div>
      {history.map(entry => {
        const st = STATUTS[entry.status];
        const pillBg = st?.bg ?? (entry.isArchived ? '#e0e0e0' : '#f5f5f5');
        const pillFg = st?.fg ?? 'rgba(0,0,0,0.6)';
        // Les BDT actifs sont cliquables ; les archivés renvoient vers /archives
        const href = entry.isArchived ? '/archives' : `/inventaire/${entry.id}`;
        return (
          <Link
            key={`${entry.isArchived ? 'arc' : 'act'}-${entry.id}`}
            href={href}
            className="flex items-center hover:bg-yellow-50 transition-colors"
            style={{
              padding: '6px 10px',
              borderRadius: '8px',
              textDecoration: 'none',
              color: 'inherit',
              gap: '8px',
            }}
          >
            <span style={{ fontFamily: 'monospace', fontWeight: 700, color: 'rgba(0,0,0,0.55)', fontSize: '12px', minWidth: '44px' }}>
              {entry.id}
            </span>
            <span
              style={{
                backgroundColor: pillBg,
                color: pillFg,
                padding: '2px 8px',
                borderRadius: '999px',
                fontSize: '10px',
                fontWeight: 700,
                whiteSpace: 'nowrap',
                minWidth: '70px',
                textAlign: 'center',
              }}
            >
              {entry.status}
            </span>
            <span style={{ flex: 1, fontSize: '12px', color: 'rgba(0,0,0,0.75)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {entry.veloDesc || '—'}
            </span>
            <span style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)', fontFamily: 'monospace', minWidth: '76px', textAlign: 'right' }}>
              {frDate(entry.date) || '—'}
            </span>
            {entry.total > 0 && (
              <span style={{ fontSize: '11px', fontWeight: 700, color: 'rgba(0,0,0,0.65)', minWidth: '60px', textAlign: 'right' }}>
                {frPrix(entry.total)}
              </span>
            )}
          </Link>
        );
      })}
    </div>
  );
}
