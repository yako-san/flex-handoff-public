/**
 * Réplique du RichText GAS "(Stock X)" en gris italic.
 * style identique à : newRichTextValue().setTextStyle(italic gris #9e9e9e)
 */
export default function StockBadge({ stock }: { stock: number }) {
  if (!stock) return null;
  return (
    <span className="ml-1 text-[11px] italic" style={{ color: '#9e9e9e' }}>
      (Stock {stock})
    </span>
  );
}
