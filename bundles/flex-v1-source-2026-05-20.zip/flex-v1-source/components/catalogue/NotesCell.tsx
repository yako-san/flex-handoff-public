'use client';
import { useEffect, useState } from 'react';

/**
 * Cellule de note libre liée à la col AC du sheet PIÈCES.
 * Commit au blur ou sur Enter. ESC pour annuler.
 */
export default function NotesCell({
  value,
  disabled = false,
  onSave,
}: {
  value: string;
  disabled?: boolean;
  onSave: (v: string) => void;
}) {
  const [local, setLocal] = useState(value ?? '');
  useEffect(() => { setLocal(value ?? ''); }, [value]);

  function commit() {
    const next = local.trim();
    if (next !== (value ?? '').trim()) onSave(next);
  }

  return (
    <input
      type="text"
      value={local}
      disabled={disabled}
      onChange={e => setLocal(e.target.value)}
      onBlur={commit}
      onKeyDown={e => {
        if (e.key === 'Enter') { (e.target as HTMLInputElement).blur(); }
        else if (e.key === 'Escape') { setLocal(value ?? ''); (e.target as HTMLInputElement).blur(); }
      }}
      placeholder="—"
      className="w-full text-xs focus:outline-none focus:ring-1 focus:ring-yellow-400 focus:bg-white"
      style={{
        height: '26px',
        border: 'none',
        outline: 'none',
        borderRadius: '4px',
        padding: '0 6px',
        backgroundColor: 'transparent',
        color: 'rgba(0,0,0,0.7)',
      }}
    />
  );
}
