'use client';
import { useEffect, useState } from 'react';
import Modal from '@/components/ui/Modal';
import { useServices } from '@/hooks/useCatalogue';
import { toast } from '@/components/ui/Toast';
import { ArrowPathIcon } from '@heroicons/react/24/outline';

/** Préfixes courants pour nommer un nouveau service */
const SERVICE_PREFIXES = [
  '',
  '🧰 Ajust. :',
  '🧰 Align. :',
  '🧰 Install. :',
  '🧰 Lav. :',
  '🧰 Lub. :',
  '🧰 Redress. :',
  '🧰 Remplac. :',
  '⛑️ Urgent. :',
];

interface ServiceFormProps {
  open: boolean;
  onClose: () => void;
  /** Liste des catégories existantes pour le dropdown. */
  categories: string[];
  /** Catégorie pré-remplie (utilisée quand on clique + sur un groupe). */
  initialCategorie?: string;
  onCreated?: () => void;
}

/**
 * Popup de création d'un service au catalogue À LA CARTE. Équivalent de
 * PieceForm pour les services. Le prix est calculé par la formule de la
 * sheet à partir de la durée (pas de champ prix manuel).
 */
export default function ServiceForm({
  open, onClose, categories, initialCategorie, onCreated,
}: ServiceFormProps) {
  const { addService, refreshServices } = useServices();

  const [prefix,    setPrefix]    = useState('');
  const [nom,       setNom]       = useState('');
  const [duree,     setDuree]     = useState('');
  const [categorie, setCategorie] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  async function handleRefreshCategories() {
    setRefreshing(true);
    try { await refreshServices(); toast('Catégories rafraîchies'); }
    catch (err: any) { toast(err.message, 'error'); }
    finally { setRefreshing(false); }
  }

  // Reset à chaque ouverture + pré-remplissage
  useEffect(() => {
    if (open) {
      setPrefix('');
      setNom('');
      setDuree('');
      setCategorie(initialCategorie ?? '');
    }
  }, [open, initialCategorie]);

  async function handleSubmit() {
    if (!nom.trim()) return;
    const fullLabel = prefix ? `${prefix} ${nom.trim()}` : nom.trim();
    setSubmitting(true);
    try {
      // Normalise la durée : "1" → "1:00", "1.5" → "1:30", "90 min" → "1:30".
      //   - nombre entier seul  → heures (N → N:00)
      //   - nombre décimal seul → heures + fraction (1.5 → 1:30)
      //   - "Nh[MM]" / "NN min" gardent le comportement parseDureeToMinutes du BDT
      //   - déjà au format "h:mm" → laissé tel quel
      function normaliseDuree(input: string): string {
        const s = input.trim();
        if (!s) return '1:00';
        if (/^\d+:\d{2}$/.test(s)) return s;                    // déjà h:mm
        if (/^\d+\s*min/i.test(s)) {                             // "90 min"
          const m = parseInt(s);
          return `${Math.floor(m/60)}:${String(m%60).padStart(2,'0')}`;
        }
        if (/^\d+\s*h(\s*\d+)?/i.test(s)) {                      // "2h30" / "2h"
          const [, h, m] = s.match(/^(\d+)\s*h\s*(\d+)?/i)!;
          return `${parseInt(h)}:${String(parseInt(m || '0')).padStart(2,'0')}`;
        }
        const num = parseFloat(s.replace(',', '.'));
        if (!isNaN(num)) {
          const h = Math.floor(num);
          const m = Math.round((num - h) * 60);
          return `${h}:${String(m).padStart(2,'0')}`;
        }
        return s;
      }
      const dureeFinal = normaliseDuree(duree);
      await addService(fullLabel, categorie, dureeFinal);
      toast('Service ajouté au catalogue');
      onCreated?.();
      onClose();
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  }

  const preview = prefix && nom ? `${prefix} ${nom}` : '';

  return (
    <Modal open={open} onClose={onClose} title="Nouveau service" size="lg">
      <div className="space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-1">
            <label className="label-system">préfixe</label>
            <select
              value={prefix}
              onChange={e => setPrefix(e.target.value)}
              className="input-system"
            >
              {SERVICE_PREFIXES.map(p => (
                <option key={p} value={p}>{p || '— sans préfixe —'}</option>
              ))}
            </select>
          </div>
          <div className="col-span-2">
            <label className="label-system">nom du service *</label>
            <input
              type="text" value={nom}
              onChange={e => setNom(e.target.value)}
              className="input-system"
              placeholder="ex. freins sur jante"
              autoFocus
            />
          </div>
        </div>

        {preview && (
          <p className="text-xs italic" style={{ color: 'rgba(0,0,0,0.5)' }}>
            Aperçu : {preview}
          </p>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label-system">durée</label>
            <input
              type="text" value={duree}
              onChange={e => setDuree(e.target.value)}
              className="input-system"
              placeholder="1:00"
            />
            <p className="text-xs italic mt-1" style={{ color: 'rgba(0,0,0,0.5)' }}>
              Format <code>h:mm</code> — défaut <code>1:00</code>. Le prix est
              calculé par la sheet à partir de la durée.
            </p>
          </div>
          <div>
            <label className="label-system">catégorie</label>
            <div className="flex items-center gap-2">
              <select
                value={categorie}
                onChange={e => setCategorie(e.target.value)}
                className="input-system flex-1"
              >
                <option value="">— Sélection —</option>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <button
                type="button"
                onClick={handleRefreshCategories}
                disabled={refreshing}
                title="Rafraîchir la liste des catégories (bypass cache)"
                className="flex items-center justify-center transition-colors"
                style={{
                  width: '40px', height: '40px', borderRadius: '50%',
                  backgroundColor: 'rgba(0,0,0,0.05)', border: '1.5px solid rgba(0,0,0,0.2)',
                  flexShrink: 0,
                }}
              >
                <ArrowPathIcon
                  className={refreshing ? 'animate-spin' : ''}
                  style={{ width: '18px', height: '18px', color: 'rgba(0,0,0,0.6)' }}
                />
              </button>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <button type="button" onClick={onClose} className="btn-secondary">
            Annuler
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!nom.trim() || submitting}
            className="btn-primary"
          >
            {submitting ? 'Ajout…' : 'Ajouter le service'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
