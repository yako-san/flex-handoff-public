'use client';
import React, { useState, useCallback, useMemo } from 'react';
import Modal from '@/components/ui/Modal';
import PromptDialog from '@/components/ui/PromptDialog';
import { toast } from '@/components/ui/Toast';
import { ArrowUpTrayIcon, CheckCircleIcon, ExclamationTriangleIcon, PencilSquareIcon } from '@heroicons/react/24/outline';
import { matchItems, type MatchedItem } from '@/lib/import/matchCatalogue';
import type { ParsedFile, ColumnMap } from '@/lib/import/parseFile';
import type { Piece } from '@/types/catalogue';
import { frPrix, normSearch } from '@/lib/utils/format';

interface ImportModalProps {
  open: boolean;
  onClose: () => void;
  pieces: Piece[];
  /** Liste des fournisseurs existants (optionnel, pour dropdown d'override). */
  fournisseurs?: string[];
  onImport: (items: { nom: string; sku: string; qteCommandee: number; prixAchat: number; pieceRow: number; pieceId: string }[], meta: Record<string, string>) => void;
}

type Step = 'upload' | 'mapping' | 'preview';

export default function ImportModal({ open, onClose, pieces, fournisseurs = [], onImport }: ImportModalProps) {
  const [step, setStep]       = useState<Step>('upload');
  const [parsed, setParsed]   = useState<ParsedFile | null>(null);
  const [colMap, setColMap]   = useState<ColumnMap | null>(null);
  const [matched, setMatched] = useState<MatchedItem[]>([]);
  const [loading, setLoading] = useState(false);
  // Index de la ligne en cours d'édition du match manuel
  const [editingIdx, setEditingIdx] = useState<number | null>(null);
  const [editSearch, setEditSearch] = useState('');
  // Variation saisie par ligne (ex. "60ml", "700-28").
  // Appendée au nom de la pièce lors de l'import.
  const [formats, setFormats] = useState<Record<number, string>>({});
  // Fournisseur choisi pour cet import (override de la détection auto)
  const [fournisseur, setFournisseur] = useState<string>('');

  // Prompts au style design-system (remplacent window.prompt natifs)
  const [promptNewFournOpen, setPromptNewFournOpen]   = useState(false);
  const [promptVariation, setPromptVariation]         = useState<{ idx: number; initial: string } | null>(null);

  /** Mémoire localStorage : rappelle le dernier choix de variation par SKU/desc. */
  const VARIATION_MEMORY_KEY = 'import-variation-memory';
  function loadMemory(): Record<string, string> {
    if (typeof window === 'undefined') return {};
    try { return JSON.parse(localStorage.getItem(VARIATION_MEMORY_KEY) || '{}'); }
    catch { return {}; }
  }
  function saveMemory(mem: Record<string, string>) {
    if (typeof window === 'undefined') return;
    try { localStorage.setItem(VARIATION_MEMORY_KEY, JSON.stringify(mem)); } catch {}
  }
  /** Clé stable pour un item matched (SKU en priorité, sinon description). */
  function memKey(m: MatchedItem): string {
    return (m.sku || m.description || '').toLowerCase().trim();
  }

  /** Applique le matched + initialise les formats (col fichier → mémoire → vide). */
  function applyMatched(items: MatchedItem[]) {
    const mem = loadMemory();
    const initFormats: Record<number, string> = {};
    items.forEach((it, i) => {
      const k = memKey(it);
      // Priorité : colonne Format du fichier > mémoire localStorage > vide
      const v = (it.format || '').trim() || (k && mem[k]) || '';
      if (v) initFormats[i] = v;
    });
    setMatched(items);
    setFormats(initFormats);
  }

  // Détection automatique des variations (volumes, tailles, dimensions…)
  // dans toutes les descriptions du fichier importé.
  const detectedVariations = useMemo(() => {
    const set = new Set<string>();
    const patterns: RegExp[] = [
      /\b\d+(?:[.,]\d+)?\s*(?:ml|oz|l|g|kg|mg|lb|lbs)\b/gi,     // volumes/poids
      /\b\d+\s*[x×-]\s*\d+(?:[.,]\d+)?(?:c?)\b/gi,              // tailles (700-28, 700x28)
      /\b\d+(?:[.,]\d+)?\s*(?:mm|cm|in|")\b/gi,                 // dimensions
      /\b(?:XS|S|M|L|XL|XXL|XXXL)\b/g,                          // tailles vêtements
      /\b\d{2,3}t\b/gi,                                          // dentures (ex. 32t)
    ];
    for (const m of matched) {
      // Valeur directe de la colonne Format/Variation du fichier (prioritaire)
      const f = (m.format || '').trim();
      if (f) set.add(f);
      // Extraction regex dans la description
      const desc = m.description || '';
      for (const re of patterns) {
        const matches = desc.match(re);
        if (matches) matches.forEach(s => set.add(s.trim()));
      }
    }
    // Ajouter aussi les valeurs courantes de formats (pour saisie custom)
    Object.values(formats).forEach(v => { const t = v?.trim(); if (t) set.add(t); });
    return [...set].sort();
  }, [matched, formats]);

  const reset = () => {
    setStep('upload');
    setParsed(null);
    setColMap(null);
    setMatched([]);
    setLoading(false);
    setEditingIdx(null);
    setEditSearch('');
    setFormats({});
    setFournisseur('');
  };

  // Assigne manuellement une pièce à une ligne
  const setMatchPiece = (idx: number, piece: Piece | null) => {
    setMatched(prev => prev.map((m, i) => i === idx
      ? { ...m, piece, matchType: piece ? 'nom' as const : 'none' as const }
      : m
    ));
    setEditingIdx(null);
    setEditSearch('');
  };

  /** Détecte si un texte contient plusieurs produits séparés par virgule.
   *  Deux patterns supportés :
   *    (a) "6 dry > Nom, 6 all cond > Nom, …"  (chaque partie a un ">")
   *    (b) "6 dry, 6 all cond., 6 wet, 6 e-bike"  (chaque partie débute par un nombre)
   *  Le cas (b) couvre les kits Mint'n Dry où la composition est dans la col SKU
   *  sans flèche (ex. STARTER KIT avec 4 variantes). */
  function detectMultiProducts(text: string): string[] | null {
    if (!text.includes(',')) return null;
    const parts = text.split(/\s*,\s*/).map(s => s.trim()).filter(Boolean);
    if (parts.length < 2) return null;
    const allHaveArrow   = parts.every(p => p.includes('>'));
    const allStartWithNum = parts.every(p => /^\d+\s+\S/.test(p));
    if (!allHaveArrow && !allStartWithNum) return null;
    return parts;
  }

  /** Éclate la ligne idx en N lignes (une par segment virgule). Regarde d'abord
   *  la description puis la col SKU (cas kit Mint'n Dry). La qté de chaque
   *  sous-ligne est le nombre préfixé dans le segment multiplié par la qté
   *  de la ligne parente — ex. 2 kits × "6 dry, 6 wet" → 12 dry + 12 wet. */
  const splitRow = (idx: number) => {
    const m = matched[idx];
    const parts =
      detectMultiProducts(m.description || '') ??
      detectMultiProducts(m.sku || '');
    if (!parts) return;

    // Répartition de la qté parente selon le contexte :
    //  Cas A — parentQty ≥ totalLeading : la qté parente est en UNITÉS totales
    //    (ex. "6 dry > X, 12 wet > Y" parentQty=18, totalLeading=18).
    //    → qty_part = parentQty × leadingNum / totalLeading
    //  Cas B — parentQty < totalLeading : la qté parente = nombre de KITS,
    //    chaque kit contient leadingNum de chaque variante (ex. STARTER KIT
    //    après normalisation MONTANT : parentQty=2 kits, totalLeading=24 items/kit).
    //    → qty_part = parentQty × leadingNum
    const allHaveLeadingNum = parts.every(p => /^\d+\s+\S/.test(p));
    const parentQty = m.qty || 1;
    const totalLeading = allHaveLeadingNum
      ? parts.reduce((s, p) => s + (parseInt(p.match(/^(\d+)\s+/)?.[1] ?? '0', 10) || 0), 0)
      : 0;
    const fallbackQtyPerPart = parentQty / parts.length;

    const subItems = parts.map(part => {
      const m2 = part.match(/^(\d+)\s+(.+)$/);
      const leadingNum = m2 ? parseInt(m2[1], 10) : null;
      let qty: number;
      if (allHaveLeadingNum && leadingNum !== null && totalLeading > 0) {
        qty = parentQty >= totalLeading
          ? parentQty * leadingNum / totalLeading  // cas A : unités totales
          : parentQty * leadingNum;                 // cas B : nombre de kits
        qty = Math.round(qty * 100) / 100;
      } else if (leadingNum !== null) {
        qty = leadingNum;
      } else {
        qty = fallbackQtyPerPart;
      }
      const rest = m2 ? m2[2] : part;
      // Texte après ">" = nom du produit (ex. "dry > LUBRIFIANT CÉRAMIQUE SEC")
      const afterArrow = rest.split('>').slice(1).join('>').trim();
      const description = afterArrow || rest;

      // Ré-match simple par nom
      const normDesc = description.toLowerCase().trim();
      const piece = pieces.find(p =>
        p.nom && p.nom.toLowerCase().trim() === normDesc
      ) || pieces.find(p =>
        p.nom && (p.nom.toLowerCase().includes(normDesc) || normDesc.includes(p.nom.toLowerCase()))
      ) || null;

      return {
        raw: m.raw,
        sku: '',
        description,
        qty,
        price: m.price, // prix unitaire identique — l'utilisateur ajustera
        format: '',
        barcode: m.barcode ?? '', // hérite du parent (le split ne duplique pas le barcode)
        piece,
        matchType: (piece ? 'nom' : 'none') as 'barcode' | 'sku' | 'nom' | 'none',
      };
    });

    setMatched(prev => {
      const before = prev.slice(0, idx);
      const after  = prev.slice(idx + 1);
      return [...before, ...subItems, ...after];
    });
    // Décale les formats des indices > idx
    setFormats(prev => {
      const out: Record<number, string> = {};
      for (const [k, v] of Object.entries(prev)) {
        const i = Number(k);
        if (i < idx) out[i] = v;
        else if (i > idx) out[i + parts.length - 1] = v;
      }
      return out;
    });
  };

  // Filtrage des pièces pour le dropdown de mapping manuel
  const filteredPiecesForEdit = useMemo(() => {
    if (editingIdx === null) return [];
    const q = normSearch(editSearch || matched[editingIdx]?.description || '');
    if (!q) return pieces.slice(0, 30);
    return pieces.filter(p => {
      if (!p.nom || p.nom === 'Nom ITEM' || p.nom.startsWith('FIN DE')) return false;
      return normSearch(p.nom).includes(q) || normSearch(p.sku).includes(q);
    }).slice(0, 30);
  }, [pieces, editingIdx, editSearch, matched]);

  const handleClose = () => { reset(); onClose(); };

  // ── Upload ─────────────────────────────────────────────────

  const handleFile = useCallback(async (file: File) => {
    setLoading(true);
    try {
      const form = new FormData();
      form.append('file', file);
      const res = await fetch('/api/po/import', { method: 'POST', body: form });
      if (!res.ok) throw new Error((await res.json()).error);
      const data: ParsedFile = await res.json();
      setParsed(data);
      setColMap(data.columnMap);
      // Auto-match
      const items = matchItems(data.rows, data.columnMap, pieces);
      applyMatched(items);
      setStep('preview');
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  }, [pieces]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  // ── Mapping change ─────────────────────────────────────────

  const updateMapping = (field: keyof Omit<ColumnMap, 'extra'>, idx: number | null) => {
    if (!parsed || !colMap) return;
    const newMap = { ...colMap, [field]: idx };
    setColMap(newMap);
    applyMatched(matchItems(parsed.rows, newMap, pieces));
  };

  // ── Import ─────────────────────────────────────────────────

  const handleImport = async () => {
    // Mémoriser les variations choisies pour les prochains imports
    const mem = loadMemory();
    matched.forEach((m, idx) => {
      const k = memKey(m);
      const v = (formats[idx] ?? '').trim();
      if (k && v) mem[k] = v;
    });
    saveMemory(mem);

    // ── Propagation du code-barre EAN/UPC détecté dans le fichier ──
    // Pour chaque item matché (piece ≠ null) avec un barcode détecté ET
    // qui diffère du codeBarre actuel de la pièce catalogue, on patche la
    // pièce pour enregistrer le code. Silencieux — les erreurs n'empêchent
    // pas la suite de l'import.
    const barcodePatches = matched
      .filter(m => m.piece && m.barcode && m.barcode !== (m.piece.codeBarre || ''))
      .map(m => ({ row: m.piece!._row, codeBarre: m.barcode }));
    if (barcodePatches.length > 0) {
      try {
        await Promise.all(
          barcodePatches.map(p =>
            fetch(`/api/catalogue/pieces/${p.row}`, {
              method : 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body   : JSON.stringify({ codeBarre: p.codeBarre }),
            })
          ),
        );
        toast(`${barcodePatches.length} code(s)-barre enregistré(s) au catalogue`);
      } catch (err: any) {
        console.warn('[import] propagation codeBarre partielle :', err?.message);
      }
    }

    const items = matched
      .map((m, idx) => ({ m, idx }))
      .filter(({ m }) => m.qty > 0) // ignorer qté 0
      .map(({ m, idx }) => {
        const baseNom = m.piece?.nom || m.description;
        const fmt     = (formats[idx] ?? '').trim();
        const nom     = fmt ? `${baseNom} ${fmt}` : baseNom;
        return {
          nom,
          sku          : m.piece?.sku || m.sku,
          qteCommandee : m.qty,
          prixAchat    : m.price || m.piece?.prixBase || m.piece?.prixAchat || 0,
          pieceRow     : m.piece?._row ?? -1,
          pieceId      : m.piece?.pieceId || '',
        };
      });
    const metaOut = { ...(parsed?.meta ?? {}) };
    if (fournisseur) metaOut.fournisseur = fournisseur;
    onImport(items, metaOut);
    handleClose();
  };

  // ── Render ─────────────────────────────────────────────────

  const matchedCount = matched.filter(m => m.piece).length;
  const unmatchedCount = matched.filter(m => !m.piece).length;

  return (
    <>
    <Modal open={open} onClose={handleClose} title="Import facture fournisseur" size="xl">
      {step === 'upload' && (
        <div
          onDragOver={e => e.preventDefault()}
          onDrop={handleDrop}
          className="flex flex-col items-center justify-center gap-4"
          style={{ padding: '40px', border: '2px dashed rgba(0,0,0,0.2)', borderRadius: '20px', backgroundColor: 'rgba(0,0,0,0.02)', cursor: 'pointer' }}
          onClick={() => document.getElementById('import-file-input')?.click()}
        >
          <ArrowUpTrayIcon style={{ width: '48px', height: '48px', color: 'rgba(0,0,0,0.3)' }} />
          <p style={{ color: 'rgba(0,0,0,0.5)', fontSize: '14px', fontWeight: 600 }}>
            {loading ? 'Chargement…' : 'Glisser un fichier .xlsx ou .csv ici, ou cliquer pour sélectionner'}
          </p>
          <input
            id="import-file-input"
            type="file"
            accept=".xlsx,.csv,.xls"
            style={{ display: 'none' }}
            onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
          />
        </div>
      )}

      {step === 'preview' && parsed && colMap && (
        <div>
          {/* Métadonnées */}
          {Object.keys(parsed.meta).length > 0 && (
            <div className="flex flex-wrap gap-3 mb-4" style={{ fontSize: '13px', color: 'rgba(0,0,0,0.5)' }}>
              {parsed.meta.invoiceNumber && <span>Facture : <strong>{parsed.meta.invoiceNumber}</strong></span>}
              {parsed.meta.orderNumber && <span>Commande : <strong>{parsed.meta.orderNumber}</strong></span>}
              {parsed.meta.date && <span>Date : <strong>{parsed.meta.date}</strong></span>}
            </div>
          )}

          {/* Mapping dropdowns + fournisseur */}
          <div className="flex gap-3 mb-4 flex-wrap">
            {(['sku', 'description', 'qty', 'price'] as const).map(field => (
              <div key={field}>
                <label className="label-system">{field === 'sku' ? 'SKU' : field === 'description' ? 'Description' : field === 'qty' ? 'Quantité' : 'Prix'}</label>
                <select
                  className="input-system"
                  value={colMap[field] ?? -1}
                  onChange={e => updateMapping(field, e.target.value === '-1' ? null : parseInt(e.target.value))}
                  style={{ minWidth: '140px' }}
                >
                  <option value={-1}>— non assigné —</option>
                  {parsed.headers.map((h, i) => (
                    <option key={i} value={i}>{h}</option>
                  ))}
                </select>
              </div>
            ))}
            {/* Fournisseur (override) */}
            <div>
              <label className="label-system">Fournisseur</label>
              <select
                className="input-system"
                value={fournisseurs.includes(fournisseur) ? fournisseur : (fournisseur ? '__custom__' : '')}
                onChange={e => {
                  const v = e.target.value;
                  if (v === '__new__') {
                    setPromptNewFournOpen(true);
                    return;
                  }
                  if (v === '__custom__') return;
                  setFournisseur(v);
                }}
                style={{ minWidth: '160px' }}
                title="Fournisseur du fichier importé — propagé au PO créé"
              >
                <option value="">— non assigné —</option>
                {fournisseur && !fournisseurs.includes(fournisseur) && (
                  <option value="__custom__">{fournisseur}</option>
                )}
                {fournisseurs.map(f => <option key={f} value={f}>{f}</option>)}
                <option value="__new__">＋ Nouveau fournisseur</option>
              </select>
            </div>
          </div>

          {/* Résumé */}
          <div className="flex gap-4 mb-3" style={{ fontSize: '13px' }}>
            <span style={{ color: '#2e7d32' }}>
              <CheckCircleIcon style={{ width: '14px', height: '14px', display: 'inline', verticalAlign: 'middle' }} /> {matchedCount} matchés
            </span>
            {unmatchedCount > 0 && (
              <span style={{ color: '#e65100' }}>
                <ExclamationTriangleIcon style={{ width: '14px', height: '14px', display: 'inline', verticalAlign: 'middle' }} /> {unmatchedCount} non matchés
              </span>
            )}
            <span style={{ color: 'rgba(0,0,0,0.4)' }}>{matched.length} items total</span>
          </div>

          {/* Table preview */}
          <div style={{ maxHeight: '400px', overflowY: 'auto', borderRadius: '12px', border: '1px solid rgba(0,0,0,0.1)' }}>
            {/* Header */}
            <div className="flex items-center" style={{ padding: '6px 12px', backgroundColor: 'rgba(0,0,0,0.06)', fontSize: '13px', fontWeight: 700, color: 'rgba(0,0,0,0.5)', position: 'sticky', top: 0 }}>
              <div style={{ width: '32px' }}></div>
              <div className="flex-1">Description</div>
              <div style={{ width: '110px', paddingLeft: '8px' }}>Variation</div>
              <div style={{ width: '100px' }}>SKU fichier</div>
              <div style={{ width: '50px', textAlign: 'center' }}>Qté</div>
              <div style={{ width: '70px', textAlign: 'right' }}>Prix</div>
              <div style={{ width: '180px', paddingLeft: '12px' }}>Match catalogue</div>
            </div>
            {matched.map((item, idx) => {
              // Masquer les lignes qui n'ont AUCUNE donnée utile :
              // description vide/dash ET pas de SKU ET pas de qty/price.
              // Si au moins un champ est présent, on garde la ligne.
              const desc = (item.description || '').trim();
              const descBlank = !desc || /^[\s\u2013\u2014\u2212-]+$/.test(desc);
              const hasSku    = !!item.sku;
              const hasValue  = item.qty > 0 || item.price > 0;
              if (descBlank && !hasSku && !hasValue) return null;
              return (
              <React.Fragment key={idx}>
                <div
                  className="flex items-center"
                  style={{
                    padding: '8px 12px',
                    fontSize: '13px',
                    borderBottom: editingIdx === idx ? 'none' : '1px solid rgba(0,0,0,0.05)',
                    backgroundColor: item.piece ? (item.matchType === 'sku' ? 'rgba(212,237,188,0.3)' : 'rgba(255,249,196,0.3)') : 'rgba(255,224,178,0.3)',
                  }}
                >
                  <div style={{
                    width: '32px',
                    color: item.piece ? '#2e7d32' : '#e65100',
                    fontSize: '10px',
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                  }}>
                    {item.piece ? '✓' : 'new'}
                  </div>
                  <div className="flex-1" style={{ fontWeight: 600, color: 'rgba(0,0,0,0.7)' }}>{item.description || '—'}</div>
                  <div style={{ width: '110px', paddingLeft: '8px' }}>
                    {(() => {
                      const val = formats[idx] ?? '';
                      const isCustom = val && !detectedVariations.includes(val);
                      return (
                        <select
                          value={isCustom ? '__custom__' : val}
                          onChange={e => {
                            const v = e.target.value;
                            if (v === '__custom__') {
                              setPromptVariation({ idx, initial: isCustom ? String(val) : '' });
                            } else {
                              setFormats(prev => ({ ...prev, [idx]: v }));
                            }
                          }}
                          className="focus:outline-none focus:ring-2 focus:ring-yellow-400"
                          style={{
                            width: '102px', height: '26px',
                            padding: '0 6px',
                            fontSize: '12px',
                            borderRadius: '6px',
                            border: '1px solid rgba(0,0,0,0.15)',
                            backgroundColor: '#fff',
                            cursor: 'pointer',
                          }}
                          title="Variation détectée dans le fichier — appendée au nom (ex. 60ml, 700-28)"
                        >
                          <option value="">— aucune —</option>
                          {isCustom && <option value="__custom__">{val}</option>}
                          {detectedVariations.map(v => (
                            <option key={v} value={v}>{v}</option>
                          ))}
                          <option value="__custom__">Autre…</option>
                        </select>
                      );
                    })()}
                  </div>
                  <div style={{ width: '100px', color: 'rgba(0,0,0,0.4)', fontFamily: 'monospace', fontSize: '12px' }}>{item.sku || '—'}</div>
                  <div style={{ width: '50px', textAlign: 'center', fontWeight: 700 }}>{item.qty}</div>
                  <div style={{ width: '70px', textAlign: 'right', color: 'rgba(0,0,0,0.5)' }}>{frPrix(item.price)}</div>
                  <div
                    onClick={() => { setEditingIdx(editingIdx === idx ? null : idx); setEditSearch(''); }}
                    className="flex items-center gap-1 cursor-pointer hover:bg-black/5"
                    style={{ width: '180px', padding: '4px 8px 4px 12px', fontSize: '12px', color: item.piece ? 'rgba(0,0,0,0.5)' : '#e65100', borderRadius: '6px' }}
                    title="Cliquer pour changer la pièce"
                  >
                    <span className="flex-1 truncate">
                      {item.piece ? item.piece.nom : 'Non trouvé — cliquer pour mapper'}
                    </span>
                    <PencilSquareIcon style={{ width: '12px', height: '12px', flexShrink: 0, opacity: 0.4 }} />
                  </div>
                  {/* Bouton Split si la description OU la col SKU contient plusieurs
                      produits (ex. Mint'n Dry : "6 dry > X, 6 all cond > Y, …"
                      ou "6 dry, 6 all cond., 6 wet, 6 e-bike" pour un kit) */}
                  {(detectMultiProducts(item.description || '') || detectMultiProducts(item.sku || '')) && (
                    <button
                      type="button"
                      onClick={() => splitRow(idx)}
                      title="Éclater cette ligne en plusieurs items (un par segment virgule)"
                      style={{
                        marginLeft: '4px', width: '26px', height: '26px',
                        borderRadius: '6px',
                        backgroundColor: 'rgba(255,240,86,0.5)',
                        color: 'rgba(0,0,0,0.7)',
                        border: '1px solid rgba(0,0,0,0.2)',
                        fontSize: '14px', fontWeight: 700,
                        cursor: 'pointer', padding: 0,
                      }}
                    >
                      ⎇
                    </button>
                  )}
                </div>
                {editingIdx === idx && (
                  <div style={{ padding: '8px 12px', backgroundColor: 'rgba(255,255,255,0.95)', borderBottom: '1px solid rgba(0,0,0,0.1)' }}>
                    <input
                      type="search"
                      autoFocus
                      placeholder="Rechercher une pièce dans le catalogue…"
                      value={editSearch}
                      onChange={e => setEditSearch(e.target.value)}
                      className="input-system mb-2"
                      style={{ width: '100%', maxWidth: '500px' }}
                    />
                    <div style={{ maxHeight: '200px', overflowY: 'auto', backgroundColor: '#fff', borderRadius: '8px', border: '1px solid rgba(0,0,0,0.1)' }}>
                      {item.piece && (
                        <button
                          type="button"
                          onClick={() => setMatchPiece(idx, null)}
                          className="w-full text-left px-3 py-2 text-xs hover:bg-red-50"
                          style={{ borderBottom: '1px solid rgba(0,0,0,0.06)', color: '#c62828' }}
                        >
                          ✗ Retirer le match (non importer cet item)
                        </button>
                      )}
                      {filteredPiecesForEdit.map(p => (
                        <button
                          key={p.pieceId || p._row}
                          type="button"
                          onClick={() => setMatchPiece(idx, p)}
                          className="w-full text-left px-3 py-2 text-xs hover:bg-yellow-50 flex justify-between items-center gap-2"
                          style={{ borderBottom: '1px solid rgba(0,0,0,0.06)' }}
                        >
                          <span className="flex-1 truncate">{p.nom}</span>
                          <span style={{ color: 'rgba(0,0,0,0.4)', fontFamily: 'monospace' }}>{p.sku || '—'}</span>
                          <span style={{ color: 'rgba(0,0,0,0.4)', minWidth: '70px', textAlign: 'right' }}>{frPrix(p.prixBase || p.prixAchat || 0)}</span>
                        </button>
                      ))}
                      {filteredPiecesForEdit.length === 0 && (
                        <div className="px-3 py-2 text-xs" style={{ color: 'rgba(0,0,0,0.4)' }}>Aucun résultat</div>
                      )}
                    </div>
                  </div>
                )}
              </React.Fragment>
              );
            })}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3 mt-4">
            <button type="button" onClick={reset} className="btn-secondary">Recommencer</button>
            <button
              type="button"
              onClick={handleImport}
              disabled={matched.length === 0}
              className="btn-primary ml-auto"
            >
              Importer {matched.filter(m => m.qty > 0).length} items
            </button>
          </div>
        </div>
      )}
    </Modal>

    {/* Prompts design-system (remplacent window.prompt natifs) */}
    <PromptDialog
      open={promptNewFournOpen}
      title="Nouveau fournisseur"
      message="Nom du nouveau fournisseur :"
      placeholder="ex. Norco Bicycles"
      confirmLabel="Ajouter"
      onConfirm={nom => {
        setPromptNewFournOpen(false);
        setFournisseur(nom);
      }}
      onCancel={() => setPromptNewFournOpen(false)}
    />

    <PromptDialog
      open={promptVariation !== null}
      title="Variation personnalisée"
      message="Nom de la variation :"
      defaultValue={promptVariation?.initial ?? ''}
      placeholder="ex. 60ml, 700-28, XL"
      confirmLabel="Appliquer"
      onConfirm={val => {
        if (promptVariation) {
          setFormats(prev => ({ ...prev, [promptVariation.idx]: val }));
        }
        setPromptVariation(null);
      }}
      onCancel={() => setPromptVariation(null)}
    />
    </>
  );
}
