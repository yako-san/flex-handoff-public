'use client';
import { useEffect, useState } from 'react';
import Modal from '@/components/ui/Modal';
import { usePieces } from '@/hooks/useCatalogue';
import { toast } from '@/components/ui/Toast';

interface PieceFormProps {
  open: boolean;
  onClose: () => void;
  /** Liste des catégories principales existantes pour le dropdown. */
  categories: string[];
  /** Catégorie pré-remplie (utilisée quand on clique + sur un groupe). */
  initialCategorie?: string;
  /** Fournisseur pré-rempli (utilisé quand on clique + sur un groupe fournisseur). */
  initialFournisseur?: string;
  /** Nom pré-rempli (ex. texte de recherche d'une pièce inexistante). */
  initialNom?: string;
  /** Code-barre pré-rempli (ex. depuis un scan d'une pièce inconnue). */
  initialCodeBarre?: string;
  /** Liste des fournisseurs existants pour le dropdown. */
  fournisseurs?: string[];
  onCreated?: (info?: { nom: string; fournisseur: string }) => void;
}

/**
 * Popup de création d'une pièce au catalogue. Remplace l'ancien formulaire
 * inline. Utilise le composant Modal partagé pour un style cohérent avec
 * ClientForm et VeloForm.
 */
export default function PieceForm({
  open, onClose, categories, initialCategorie, initialFournisseur, initialNom, initialCodeBarre, fournisseurs = [], onCreated,
}: PieceFormProps) {
  const { addPiece } = usePieces();

  const [marque,      setMarque]      = useState('');
  const [nom,         setNom]         = useState('');
  const [prix,        setPrix]        = useState('');
  const [qte,         setQte]         = useState('');
  const [categorie,   setCategorie]   = useState('');
  const [fournisseur, setFournisseur] = useState('');
  const [sku,         setSku]         = useState('');
  const [skuUrl,      setSkuUrl]      = useState('');
  const [codeBarre,   setCodeBarre]   = useState('');
  const [oos,         setOos]         = useState(false);
  const [cmdSpec,     setCmdSpec]     = useState(false);
  const [submitting,  setSubmitting]  = useState(false);

  // Reset à chaque ouverture + pré-remplissage + restore draft localStorage
  // Le draft est sauvegardé à chaque changement, permettant à l'utilisateur
  // de naviguer ailleurs et revenir sans perdre sa saisie.
  const DRAFT_KEY = 'pieceForm_draft_v1';
  useEffect(() => {
    if (!open) return;

    // Tente de restaurer un draft localStorage
    let draft: any = null;
    try {
      const raw = typeof window !== 'undefined' ? localStorage.getItem(DRAFT_KEY) : null;
      if (raw) draft = JSON.parse(raw);
    } catch { /* draft corrompu → ignore */ }

    setMarque(draft?.marque ?? '');
    setNom(draft?.nom ?? initialNom ?? '');
    setPrix(draft?.prix ?? '');
    setQte(draft?.qte ?? '1');
    let preSel = draft?.categorie ?? '';
    if (!preSel && initialCategorie) {
      if (categories.includes(initialCategorie)) {
        preSel = initialCategorie;
      } else {
        const prefix = initialCategorie.trim();
        const sub = categories.find(c => c.startsWith(prefix + ',') || c.startsWith(prefix + ' ,'));
        preSel = sub ?? prefix;
      }
    }
    setCategorie(preSel);
    setFournisseur(draft?.fournisseur ?? initialFournisseur ?? '');
    setSku(draft?.sku ?? '');
    setSkuUrl(draft?.skuUrl ?? '');
    setCodeBarre(draft?.codeBarre ?? initialCodeBarre ?? '');
    setOos(draft?.oos ?? false);
    setCmdSpec(draft?.cmdSpec ?? false);
  }, [open, initialCategorie, initialFournisseur, initialNom, initialCodeBarre, categories]);

  // Sauvegarde auto-draft à chaque changement (après init)
  useEffect(() => {
    if (!open) return;
    try {
      const draft = { marque, nom, prix, qte, categorie, fournisseur, sku, skuUrl, codeBarre, oos, cmdSpec };
      localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
    } catch { /* quota ou safari private — ignore */ }
  }, [open, marque, nom, prix, qte, categorie, fournisseur, sku, skuUrl, codeBarre, oos, cmdSpec]);

  async function handleSubmit() {
    if (!nom.trim()) return;
    const prixNum      = parseFloat(prix.replace(',', '.')) || 0;
    const qteNum       = parseInt(qte, 10) || 0;
    const finalCat     = cmdSpec ? 'Cmd. speciale' : categorie;
    const fullNom      = marque ? `${marque.trim()}, ${nom.trim()}` : nom.trim();
    setSubmitting(true);
    try {
      await addPiece({
        nom        : fullNom,
        categorie  : finalCat,
        qte        : qteNum,
        prix       : prixNum,
        fournisseur: fournisseur.trim(),
        sku        : sku.trim(),
        skuUrl     : skuUrl.trim(),
        codeBarre  : codeBarre.trim(),
        oos        : oos,
      });
      toast('Pièce ajoutée au catalogue');
      // Clear draft après submit réussi
      try { localStorage.removeItem(DRAFT_KEY); } catch { /* ignore */ }
      onCreated?.({ nom: fullNom, fournisseur: fournisseur.trim() });
      onClose();
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="Nouvelle pièce" size="lg">
      <div className="space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-1">
            <label className="label-system">marque</label>
            <input
              type="text" value={marque}
              onChange={e => setMarque(e.target.value)}
              className="input-system"
              placeholder="Shimano, Jagwire…"
            />
          </div>
          <div className="col-span-2">
            <label className="label-system">nom de la pièce *</label>
            <input
              type="text" value={nom}
              onChange={e => setNom(e.target.value)}
              className="input-system"
              placeholder="ex. Dura-Ace BR-R9200"
              autoFocus
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="label-system">prix d'achat</label>
            <input
              type="text" value={prix}
              onChange={e => setPrix(e.target.value)}
              className="input-system"
              placeholder="0,00"
            />
          </div>
          <div>
            <label className="label-system">quantité</label>
            <input
              type="number" min={0} value={qte}
              onChange={e => setQte(e.target.value)}
              className="input-system"
              placeholder="0"
            />
          </div>
          <div>
            <label className="label-system">fournisseur</label>
            <select
              value={fournisseur}
              onChange={e => setFournisseur(e.target.value)}
              className="input-system"
            >
              <option value="">—</option>
              {fournisseurs.map(f => <option key={f} value={f}>{f}</option>)}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label-system">SKU / référence</label>
            <input
              type="text" value={sku}
              onChange={e => setSku(e.target.value)}
              className="input-system font-mono"
              placeholder="ex. BR-R9200"
            />
          </div>
          <div>
            <label className="label-system">lien SKU (URL)</label>
            <input
              type="url" value={skuUrl}
              onChange={e => setSkuUrl(e.target.value)}
              className="input-system"
              placeholder="https://…"
            />
          </div>
        </div>

        <div>
          <label className="label-system">code-barre EAN / UPC (scan)</label>
          <input
            type="text" value={codeBarre}
            onChange={e => setCodeBarre(e.target.value)}
            className="input-system font-mono"
            placeholder="ex. 5411883041234 (scanné du produit)"
          />
        </div>

        <div className="flex items-center gap-5 flex-wrap">
          <label className="label-system flex items-center gap-2">
            <input
              type="checkbox" checked={cmdSpec}
              onChange={e => setCmdSpec(e.target.checked)}
              className="custom-checkbox"
            />
            <span>Commande spéciale</span>
          </label>
          <label className="label-system flex items-center gap-2">
            <input
              type="checkbox" checked={oos}
              onChange={e => setOos(e.target.checked)}
              className="custom-checkbox"
            />
            <span>OOS (out of stock — pièce discontinuée)</span>
          </label>
        </div>

        {!cmdSpec && (
          <div>
            <label className="label-system">catégorie</label>
            <select
              value={categorie}
              onChange={e => setCategorie(e.target.value)}
              className="input-system"
            >
              <option value="">— Sélection —</option>
              {categorie && !categories.includes(categorie) && (
                <option key={categorie} value={categorie}>{categorie}</option>
              )}
              {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        )}

        <div className="flex justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!nom.trim() || submitting}
            className="btn-primary"
          >
            {submitting ? 'Ajout…' : 'Ajouter'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
