'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import React, { useState, useRef, useEffect } from 'react';
import { ChevronDownIcon, ArrowPathIcon } from '@heroicons/react/24/outline';
import { mutate as swrMutate } from 'swr';
import { toast } from '@/components/ui/Toast';

/**
 * Barre d'onglets partagée entre les vues du catalogue pièces.
 *
 * Design system v5.4 :
 * - Boutons 50pt de haut, texte 20pt
 * - off : blanc 30%, hover : blanc 60%, actif : jaune #fff056
 * - Espacement 10pt entre boutons
 */
const TABS = [
  { href: '/catalogue/pieces',       label: 'catalogue' },
  { href: '/catalogue/fournisseurs', label: 'fournisseurs' },
  { href: '/catalogue/commande',     label: 'commandes' },
  { href: '/catalogue/reception',    label: 'réception' },
] as const;

export interface CatalogueAnchor { id: string; label: string }

export default function PiecesTabs({ anchors }: { anchors?: CatalogueAnchor[] }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  async function handleSync() {
    if (syncing) return;
    setSyncing(true);
    try {
      const res = await fetch('/api/sync?force=1', { method: 'POST' });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Erreur sync');
      // Revalide tous les endpoints SWR
      await swrMutate(() => true, undefined, { revalidate: true });
      toast('Données synchronisées');
    } catch (err: any) {
      toast(err?.message ?? 'Erreur de synchronisation', 'error');
    } finally {
      setSyncing(false);
    }
  }

  useEffect(() => {
    if (!open) return;
    function onClick(e: MouseEvent) {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, [open]);

  function scrollToAnchor(id: string) {
    setOpen(false);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  const syncBtn = (
    <button
      type="button"
      onClick={handleSync}
      disabled={syncing}
      title="Rafraîchir les données"
      className="flex items-center justify-center transition-colors shrink-0"
      style={{
        width: '28px',
        height: '28px',
        borderRadius: '50%',
        backgroundColor: 'transparent',
        color: '#fff056',
        border: '2px solid #fff056',
        cursor: syncing ? 'wait' : 'pointer',
        padding: 0,
      }}
    >
      <ArrowPathIcon
        className={syncing ? 'animate-spin' : ''}
        style={{ width: '14px', height: '14px', strokeWidth: 2.5 }}
      />
    </button>
  );

  return (
    <div className="flex items-center" style={{ gap: '10px' }}>
      {TABS.map(tab => {
        const active = pathname === tab.href || pathname.startsWith(tab.href + '/');
        const isCatalogue = tab.href === '/catalogue/pieces';
        const hasDropdown = isCatalogue && active && anchors && anchors.length > 0;

        const btnStyle = {
          padding: '0 14px',
          height: '32px',
          borderRadius: '32px',
          fontSize: '13px',
          fontWeight: 700 as const,
          letterSpacing: '0.02em',
          backgroundColor: active ? '#fff056' : 'rgba(255,255,255,0.3)',
          color: 'rgba(0,0,0,0.5)',
          border: 'none',
          cursor: 'pointer' as const,
          textDecoration: 'none' as const,
          transition: 'color 0.15s',
        };

        const offBg = 'rgba(255,255,255,0.3)';
        const hoverBg = 'rgba(255,255,255,0.6)';

        const withSync = (el: React.ReactNode) => (
          <React.Fragment key={tab.href}>
            {el}
            {active && syncBtn}
          </React.Fragment>
        );

        if (hasDropdown) {
          return withSync(
            <div className="relative" ref={ref}>
              <button
                onClick={() => setOpen(o => !o)}
                className="flex items-center whitespace-nowrap"
                style={btnStyle}
                onMouseEnter={e => { if (!active) e.currentTarget.style.backgroundColor = hoverBg; }}
                onMouseLeave={e => { if (!active) e.currentTarget.style.backgroundColor = offBg; }}
              >
                {tab.label}
                <ChevronDownIcon
                  style={{
                    width: '14px',
                    height: '14px',
                    marginLeft: '6px',
                    strokeWidth: 3,
                    transform: open ? 'rotate(180deg)' : 'none',
                    transition: 'transform 0.15s',
                  }}
                />
              </button>
              {open && (
                <div
                  className="absolute right-0 overflow-hidden"
                  style={{
                    top: 'calc(100% + 6px)',
                    minWidth: '220px',
                    backgroundColor: '#fff',
                    borderRadius: '20px',
                    boxShadow: '0 6px 24px rgba(0,0,0,0.25)',
                    zIndex: 50,
                    padding: '8px 0',
                  }}
                >
                  {anchors!.map(a => (
                    <button
                      key={a.id}
                      onClick={() => scrollToAnchor(a.id)}
                      className="w-full text-left transition-colors hover:bg-yellow-100"
                      style={{
                        padding: '10px 20px',
                        fontSize: '14px',
                        fontWeight: 600,
                        color: '#333',
                        background: 'transparent',
                        border: 'none',
                        cursor: 'pointer',
                      }}
                    >
                      {a.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        }

        return withSync(
          <Link
            href={tab.href}
            className="flex items-center whitespace-nowrap"
            style={btnStyle}
            onMouseEnter={e => { if (!active) e.currentTarget.style.backgroundColor = hoverBg; }}
            onMouseLeave={e => { if (!active) e.currentTarget.style.backgroundColor = offBg; }}
          >
            {tab.label}
          </Link>
        );
      })}
    </div>
  );
}
