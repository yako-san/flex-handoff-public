'use client';
import React, { useMemo, useState } from 'react';
import * as XLSX from 'xlsx';
import Modal from '@/components/ui/Modal';
import { toast } from '@/components/ui/Toast';
import { frPrix } from '@/lib/utils/format';
import { ArrowUpTrayIcon, CheckCircleIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';
import type { Piece } from '@/types/catalogue';

/** Row prête pour l'API — aligné sur BromptonImportRow côté backend. */
interface ParsedRow {
  nom             : string;
  sku             : string;
  categorieSuffix : string;
  prixBDC?        : number;
  prixAchat?      : number;
  notes?          : string;
  /** Statut calculé côté client : mise à jour d'une pièce existante ou nouvelle */
  _match          : 'update' | 'new' | 'skip';
  _matchedNom?    : string;
  _skipReason?    : string;
}

interface Props {
  open    : boolean;
  onClose : () => void;
  pieces  : Piece[];
  onDone  : () => void;
}

type Step = 'upload' | 'preview' | 'report';

const HEADER_ALIASES: Record<keyof Omit<ParsedRow, '_match' | '_matchedNom' | '_skipReason'>, string[]> = {
  nom            : ['nom d\'article', "nom d'article", "nom d article", 'nom', 'name'],
  sku            : ['code d\'article', "code d'article", 'code darticle', 'sku', 'code'],
  categorieSuffix: ['catégorie', 'categorie', 'category'],
  prixBDC        : ['prix', 'price'],
  prixAchat      : ['coût', 'cout', 'cost'],
  notes          : ['description', 'desc'],
};

function _norm(s: string): string {
  return String(s ?? '').trim().toLowerCase()
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ');
}
function _normSku(s: string): string {
  return String(s ?? '').trim().toLowerCase();
}

/** Cherche l'index de la colonne d'après ses alias (accent/case tolérant). */
function findColIdx(header: string[], aliases: string[]): number {
  const headerN = header.map(h => _norm(h));
  for (const a of aliases) {
    const k = _norm(a);
    const i = headerN.indexOf(k);
    if (i >= 0) return i;
  }
  return -1;
}

function parseXlsxToRows(buf: ArrayBuffer, pieces: Piece[]): { rows: ParsedRow[]; total: number } {
  const wb = XLSX.read(buf, { type: 'array' });
  const sheetName = wb.SheetNames[0];
  const ws = wb.Sheets[sheetName];
  const raw = XLSX.utils.sheet_to_json(ws, { header: 1, blankrows: false, defval: '' }) as unknown[][];
  if (!raw.length) return { rows: [], total: 0 };

  const header = raw[0].map(c => String(c ?? ''));
  const ixNom      = findColIdx(header, HEADER_ALIASES.nom);
  const ixSku      = findColIdx(header, HEADER_ALIASES.sku);
  const ixCat      = findColIdx(header, HEADER_ALIASES.categorieSuffix);
  const ixPrix     = findColIdx(header, HEADER_ALIASES.prixBDC);
  const ixCout     = findColIdx(header, HEADER_ALIASES.prixAchat);
  const ixDesc     = findColIdx(header, HEADER_ALIASES.notes);
  const ixFabriqu  = findColIdx(header, ['fabricant', 'manufacturer', 'brand', 'marque']);

  const bySku = new Map<string, Piece>();
  for (const p of pieces) { const k = _normSku(p.sku); if (k) bySku.set(k, p); }

  const out: ParsedRow[] = [];
  let total = 0;
  for (let i = 1; i < raw.length; i++) {
    const r = raw[i];
    const fabr = ixFabriqu >= 0 ? String(r[ixFabriqu] ?? '').trim() : '';
    // Filtre : seulement Fabricant = Brompton
    if (_norm(fabr) !== 'brompton') continue;
    total++;

    const nom = String(r[ixNom] ?? '').trim();
    const sku = String(r[ixSku] ?? '').trim();
    const cat = String(r[ixCat] ?? '').trim();
    const prix     = ixPrix  >= 0 ? parseFloat(String(r[ixPrix] ?? '').replace(',', '.')) : NaN;
    const achat    = ixCout  >= 0 ? parseFloat(String(r[ixCout] ?? '').replace(',', '.')) : NaN;
    const notes    = ixDesc  >= 0 ? String(r[ixDesc] ?? '').trim() : '';

    let match: ParsedRow['_match'] = 'new';
    let matchedNom: string | undefined;
    let skipReason: string | undefined;

    if (!sku)     { match = 'skip'; skipReason = 'SKU manquant'; }
    else if (!nom) { match = 'skip'; skipReason = 'Nom manquant'; }
    else {
      const hit = bySku.get(_normSku(sku));
      if (hit) { match = 'update'; matchedNom = hit.nom; }
    }

    out.push({
      nom,
      sku,
      categorieSuffix: cat,
      prixBDC        : Number.isFinite(prix)  ? prix  : undefined,
      prixAchat      : Number.isFinite(achat) ? achat : undefined,
      notes          : notes || undefined,
      _match         : match,
      _matchedNom    : matchedNom,
      _skipReason    : skipReason,
    });
  }
  return { rows: out, total };
}

export default function BromptonImportModal({ open, onClose, pieces, onDone }: Props) {
  const [step,       setStep]       = useState<Step>('upload');
  const [filename,   setFilename]   = useState<string>('');
  const [rows,       setRows]       = useState<ParsedRow[]>([]);
  const [totalBromp, setTotalBromp] = useState<number>(0);
  const [submitting, setSubmitting] = useState(false);
  const [report,     setReport]     = useState<any | null>(null);

  function reset() {
    setStep('upload');
    setFilename('');
    setRows([]);
    setTotalBromp(0);
    setSubmitting(false);
    setReport(null);
  }

  function close() {
    reset();
    onClose();
  }

  async function handleFile(file: File) {
    try {
      const buf = await file.arrayBuffer();
      const { rows, total } = parseXlsxToRows(buf, pieces);
      setFilename(file.name);
      setRows(rows);
      setTotalBromp(total);
      setStep('preview');
    } catch (err: any) {
      toast(`Erreur de lecture : ${err?.message ?? err}`, 'error');
    }
  }

  const { nAdd, nUpd, nSkip } = useMemo(() => {
    let nAdd = 0, nUpd = 0, nSkip = 0;
    for (const r of rows) {
      if (r._match === 'update') nUpd++;
      else if (r._match === 'new') nAdd++;
      else nSkip++;
    }
    return { nAdd, nUpd, nSkip };
  }, [rows]);

  async function submit() {
    const payload = rows
      .filter(r => r._match !== 'skip')
      .map(({ _match, _matchedNom, _skipReason, ...clean }) => clean);
    if (!payload.length) { toast('Aucune ligne à importer', 'error'); return; }
    setSubmitting(true);
    try {
      const res = await fetch('/api/catalogue/pieces/import-brompton', {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ rows: payload }),
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body?.error ?? 'Erreur import');
      setReport(body);
      setStep('report');
      onDone();
    } catch (err: any) {
      toast(err?.message ?? 'Erreur import', 'error');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal open={open} onClose={close} title="Importer catalogue Brompton" size="xl" fullHeight>
      <div className="flex flex-col" style={{ gap: '16px', minHeight: 0 }}>

        {step === 'upload' && (
          <div className="flex flex-col items-center justify-center text-center" style={{ padding: '40px 20px', gap: '14px' }}>
            <ArrowUpTrayIcon style={{ width: '48px', height: '48px', color: 'rgba(0,0,0,0.35)' }} />
            <div style={{ color: 'rgba(0,0,0,0.6)', fontSize: '15px', maxWidth: '520px' }}>
              Sélectionne le fichier <strong>xlsx</strong> / <strong>csv</strong> exporté depuis Square POS.
              Seules les lignes <strong>Fabricant = Brompton</strong> seront proposées à l'import.
            </div>
            <label
              className="btn-primary flex items-center gap-2 cursor-pointer"
              style={{ marginTop: '8px' }}
            >
              <ArrowUpTrayIcon style={{ width: '16px', height: '16px' }} />
              Choisir un fichier
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={e => {
                  const f = e.target.files?.[0];
                  if (f) handleFile(f);
                  e.target.value = '';
                }}
              />
            </label>
          </div>
        )}

        {step === 'preview' && (
          <>
            <div className="flex items-center gap-3" style={{ fontSize: '13px', color: 'rgba(0,0,0,0.65)' }}>
              <span><strong>{filename}</strong></span>
              <span>·</span>
              <span>{totalBromp} ligne{totalBromp > 1 ? 's' : ''} Brompton détectée{totalBromp > 1 ? 's' : ''}</span>
              <span className="ml-auto flex items-center gap-3">
                <span style={{ color: '#047857' }}>+{nAdd} nouveaux</span>
                <span style={{ color: '#1d4ed8' }}>↻{nUpd} MAJ</span>
                {nSkip > 0 && <span style={{ color: '#b45309' }}>⚠ {nSkip} ignorés</span>}
              </span>
            </div>

            <div className="flex-1 overflow-auto" style={{ border: '1px solid rgba(0,0,0,0.12)', borderRadius: '12px', minHeight: 0 }}>
              <table className="w-full text-sm">
                <thead className="list-header" style={{ position: 'sticky', top: 0, backgroundColor: '#f3f3f3' }}>
                  <tr>
                    <th className="px-3 py-2 text-left" style={{ width: '90px' }}>statut</th>
                    <th className="px-3 py-2 text-left">nom</th>
                    <th className="px-3 py-2 text-left" style={{ width: '120px' }}>SKU</th>
                    <th className="px-3 py-2 text-left" style={{ width: '180px' }}>catégorie</th>
                    <th className="px-3 py-2 text-right" style={{ width: '90px' }}>prix</th>
                    <th className="px-3 py-2 text-right" style={{ width: '90px' }}>coût</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r, i) => {
                    const bg = i % 2 === 0 ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.85)';
                    const statusColor = r._match === 'update' ? '#1d4ed8' : r._match === 'new' ? '#047857' : '#b45309';
                    const statusBg    = r._match === 'update' ? 'rgba(29,78,216,0.12)' : r._match === 'new' ? 'rgba(4,120,87,0.12)' : 'rgba(180,83,9,0.12)';
                    const statusLabel = r._match === 'update' ? 'MAJ' : r._match === 'new' ? 'Nouveau' : 'Ignoré';
                    return (
                      <tr key={i} style={{ backgroundColor: bg, borderBottom: '1px solid rgba(0,0,0,0.05)' }}>
                        <td className="px-3 py-2">
                          <span
                            className="inline-flex items-center whitespace-nowrap"
                            style={{
                              height: '22px', padding: '0 10px', borderRadius: '999px',
                              backgroundColor: statusBg, color: statusColor,
                              fontSize: '11px', fontWeight: 700, letterSpacing: '0.04em',
                            }}
                            title={r._skipReason || (r._matchedNom ? `Match : ${r._matchedNom}` : '')}
                          >
                            {statusLabel}
                          </span>
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap overflow-hidden text-ellipsis" title={r.nom}>{r.nom}</td>
                        <td className="px-3 py-2 font-mono text-xs">{r.sku || '—'}</td>
                        <td className="px-3 py-2 text-xs" style={{ color: 'rgba(0,0,0,0.6)' }}>
                          {r.categorieSuffix ? `9. Brompton, ${r.categorieSuffix}` : '9. Brompton'}
                        </td>
                        <td className="px-3 py-2 text-right">{r.prixBDC != null ? frPrix(r.prixBDC) : '—'}</td>
                        <td className="px-3 py-2 text-right">{r.prixAchat != null ? frPrix(r.prixAchat) : '—'}</td>
                      </tr>
                    );
                  })}
                  {rows.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-3 py-8 text-center" style={{ color: 'rgba(0,0,0,0.4)' }}>
                        Aucune ligne Brompton trouvée dans ce fichier.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="flex items-center gap-3">
              <button type="button" onClick={() => setStep('upload')} className="btn-secondary" disabled={submitting}>
                ← Changer de fichier
              </button>
              <button
                type="button"
                onClick={submit}
                disabled={submitting || (nAdd + nUpd) === 0}
                className="btn-primary ml-auto"
              >
                {submitting ? 'Import…' : `Importer (${nAdd + nUpd})`}
              </button>
            </div>
          </>
        )}

        {step === 'report' && report && (
          <div className="flex flex-col" style={{ gap: '14px' }}>
            <div className="flex items-center gap-3" style={{ color: '#047857' }}>
              <CheckCircleIcon style={{ width: '28px', height: '28px' }} />
              <span style={{ fontSize: '16px', fontWeight: 700 }}>Import terminé</span>
            </div>
            <div style={{ fontSize: '14px', color: 'rgba(0,0,0,0.7)' }}>
              <div><strong>{report.added?.length ?? 0}</strong> pièce{(report.added?.length ?? 0) > 1 ? 's' : ''} créée{(report.added?.length ?? 0) > 1 ? 's' : ''}</div>
              <div><strong>{report.updated?.length ?? 0}</strong> pièce{(report.updated?.length ?? 0) > 1 ? 's' : ''} mise{(report.updated?.length ?? 0) > 1 ? 's' : ''} à jour</div>
              {report.skipped?.length > 0 && (
                <div style={{ color: '#b45309' }}>
                  <strong>{report.skipped.length}</strong> ignorée{report.skipped.length > 1 ? 's' : ''}
                  <ul className="mt-2 ml-4 list-disc text-xs">
                    {report.skipped.map((s: any, i: number) => (
                      <li key={i}>{s.sku ? `${s.sku} · ` : ''}{s.nom} — {s.reason}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            <div className="flex items-center gap-3">
              <button type="button" onClick={reset} className="btn-secondary">Importer un autre fichier</button>
              <button type="button" onClick={close} className="btn-primary ml-auto">Fermer</button>
            </div>
          </div>
        )}

      </div>
    </Modal>
  );
}
