'use client';
import { useState, useCallback } from 'react';
import Modal from '@/components/ui/Modal';
import BarcodeScanner from '@/components/ui/BarcodeScanner';
import { usePieces } from '@/hooks/useCatalogue';
import { frPrix } from '@/lib/utils/format';
import { toast } from '@/components/ui/Toast';
import { PlusIcon, QrCodeIcon } from '@heroicons/react/24/outline';
import { logScan, updateLastScanAction } from '@/lib/utils/scanLog';
import type { Piece } from '@/types/catalogue';

interface Props {
  open: boolean;
  onClose: () => void;
}

/**
 * PriceLookupModal — scan rapide d'un code-barre/SKU pour voir le prix
 * de vente, le stock, et déclencher une commande en 1 clic.
 *
 * Flow :
 *   1. Ouvre le BarcodeScanner
 *   2. Scan → cherche par codeBarre puis SKU
 *   3. Affiche une card : nom, SKU, EAN, prix, stock, qté en commande
 *   4. Bouton « + à commander » → patchPiece({ flag:'$', qteACommander })
 *   5. « Nouveau scan » pour reset et recommencer
 *
 * N'ajoute rien à une vente — c'est un pur outil de consultation.
 */
export default function PriceLookupModal({ open, onClose }: Props) {
  const { pieces, patchPiece } = usePieces();
  const [found,       setFound]       = useState<Piece | null>(null);
  const [unknownCode, setUnknownCode] = useState('');
  const [cmdBusy,     setCmdBusy]     = useState(false);

  // Scanner est toujours actif tant que la modal est ouverte ET qu'aucun
  // résultat n'est affiché (sinon le user doit cliquer "Nouveau scan").
  const scannerOpen = open && !found && !unknownCode;

  const handleScan = useCallback((code: string) => {
    const norm = code.trim();
    const lc   = norm.toLowerCase();
    const byBarcode = pieces.find(p => (p.codeBarre || '').trim() === norm);
    if (byBarcode) {
      setFound(byBarcode);
      logScan({ code: norm, action: 'matched-barcode', pieceId: byBarcode.pieceId, pieceName: byBarcode.nom, note: 'price lookup' });
      return;
    }
    const bySku = pieces.find(p => (p.sku || '').trim().toLowerCase() === lc);
    if (bySku) {
      setFound(bySku);
      logScan({ code: norm, action: 'matched-sku', pieceId: bySku.pieceId, pieceName: bySku.nom, note: 'price lookup' });
      return;
    }
    setUnknownCode(norm);
    logScan({ code: norm, action: 'unknown', note: 'price lookup' });
  }, [pieces]);

  async function handleAddToOrder() {
    if (!found) return;
    setCmdBusy(true);
    try {
      const next = (found.qteACommander ?? 0) + 1;
      await patchPiece(found._row, { flag: '$', qteACommander: next });
      updateLastScanAction(found.codeBarre || found.sku || found.pieceId, {
        note: `Ajoutée à la commande (qté=${next})`,
      });
      toast(`${found.nom} — ajoutée à la commande (${next})`);
      // Rester sur la même card pour que l'utilisateur voie la mise à jour
      setFound(prev => prev ? { ...prev, flag: '$', qteACommander: next } : prev);
    } catch (err: any) {
      toast(err.message || 'Erreur commande', 'error');
    } finally {
      setCmdBusy(false);
    }
  }

  function resetForNext() {
    setFound(null);
    setUnknownCode('');
  }

  function handleClose() {
    setFound(null);
    setUnknownCode('');
    onClose();
  }

  return (
    <>
      {/* Scanner actif uniquement en phase scan */}
      <BarcodeScanner
        open={scannerOpen}
        onClose={handleClose}
        onScan={handleScan}
        lastMessage=""
      />

      {/* Modal résultat : affiché seulement après match ou inconnu */}
      <Modal open={open && (!!found || !!unknownCode)} onClose={handleClose} title="Recherche de prix" size="md">
        {found && (
          <div className="flex flex-col" style={{ gap: '14px' }}>
            <div style={{
              padding: '14px 16px',
              borderRadius: '16px',
              backgroundColor: 'rgba(255,240,86,0.15)',
              border: '1.5px solid rgba(0,0,0,0.1)',
            }}>
              <div style={{ fontSize: '18px', fontWeight: 700, color: 'rgba(0,0,0,0.85)', marginBottom: '4px' }}>
                {found.nom}
              </div>
              <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.5)', marginBottom: '10px' }}>
                {found.categorie || '—'} · {found.fournisseur || 'fournisseur ?'}
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <div style={{ fontSize: '10px', color: 'rgba(0,0,0,0.4)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Prix vente</div>
                  <div style={{ fontSize: '22px', fontWeight: 700, color: 'rgba(0,0,0,0.85)', lineHeight: 1 }}>{frPrix(found.prixBDC || found.prixBase)}</div>
                </div>
                <div>
                  <div style={{ fontSize: '10px', color: 'rgba(0,0,0,0.4)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Stock</div>
                  <div style={{ fontSize: '22px', fontWeight: 700, color: (found.stock ?? 0) > 0 ? '#166534' : '#b91c1c', lineHeight: 1 }}>{found.stock ?? 0}</div>
                </div>
                <div>
                  <div style={{ fontSize: '10px', color: 'rgba(0,0,0,0.4)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>En cmd</div>
                  <div style={{ fontSize: '22px', fontWeight: 700, color: 'rgba(0,0,0,0.85)', lineHeight: 1 }}>{found.qteACommander ?? 0}</div>
                </div>
              </div>
              <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)', marginTop: '10px', fontFamily: 'monospace' }}>
                SKU : {found.sku || '—'} · EAN : {found.codeBarre || '—'}
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button type="button" onClick={resetForNext} className="btn-secondary flex items-center gap-2">
                <QrCodeIcon style={{ width: '18px', height: '18px' }} />
                Nouveau scan
              </button>
              <button
                type="button"
                onClick={handleAddToOrder}
                disabled={cmdBusy}
                className="btn-primary flex items-center gap-2 ml-auto"
              >
                <PlusIcon style={{ width: '18px', height: '18px' }} />
                {cmdBusy ? '…' : 'À commander'}
              </button>
            </div>
          </div>
        )}

        {unknownCode && !found && (
          <div className="flex flex-col" style={{ gap: '14px' }}>
            <div style={{
              padding: '14px 16px',
              borderRadius: '16px',
              backgroundColor: 'rgba(239,68,68,0.10)',
              border: '1.5px solid rgba(239,68,68,0.30)',
            }}>
              <div style={{ fontSize: '14px', fontWeight: 700, color: '#b91c1c', marginBottom: '4px' }}>
                Code inconnu
              </div>
              <div style={{ fontFamily: 'monospace', fontSize: '14px', color: 'rgba(0,0,0,0.7)' }}>
                {unknownCode}
              </div>
              <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.5)', marginTop: '8px' }}>
                Ce code n'est ni un EAN connu ni un SKU du catalogue. Ajoute la pièce
                depuis la page Pièces si c'est un produit récurrent.
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <button type="button" onClick={resetForNext} className="btn-secondary flex items-center gap-2">
                <QrCodeIcon style={{ width: '18px', height: '18px' }} />
                Nouveau scan
              </button>
              <button type="button" onClick={handleClose} className="btn-primary">
                Fermer
              </button>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
}
