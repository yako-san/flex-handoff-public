'use client';
import { useMemo, useState } from 'react';
import { toast } from '@/components/ui/Toast';
import { LinkIcon } from '@heroicons/react/24/outline';
import { frPrix } from '@/lib/utils/format';
import type { PO } from '@/types/po';

/**
 * v1.0.14+ — Panneau qui affiche les PO ADHOC du même fournisseur que
 * `po` et propose de les fusionner dedans (regrouper les scans rapides
 * de la semaine dans la facture fournisseur quand elle arrive).
 *
 * Affiché uniquement si :
 *  - `po.status` ∈ {EN ATTENTE, PARTIEL} (modifiable)
 *  - Au moins 1 ADHOC-... même fournisseur en status RECU
 */
interface Props {
  po       : PO;
  pos      : PO[];
  mutatePOs: () => void;
}

export default function AdhocMergePanel({ po, pos, mutatePOs }: Props) {
  const [selected,   setSelected]   = useState<Set<string>>(new Set());
  const [submitting, setSubmitting] = useState(false);

  // Filtre les ADHOCs candidats : même fournisseur, RECU, dans le hook pos
  const candidates = useMemo(() => {
    if (po.status !== 'EN ATTENTE' && po.status !== 'PARTIEL') return [];
    return pos.filter(p =>
      p.poNumber.startsWith('ADHOC-')
      && p.fournisseur === po.fournisseur
      && p.status === 'RECU'
    ).sort((a, b) => a.dateReception && b.dateReception
      ? a.dateReception.localeCompare(b.dateReception)
      : 0);
  }, [po, pos]);

  if (candidates.length === 0) return null;

  function toggle(poNumber: string) {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(poNumber) ? next.delete(poNumber) : next.add(poNumber);
      return next;
    });
  }

  function selectAll() {
    setSelected(new Set(candidates.map(c => c.poNumber)));
  }

  async function handleMerge() {
    if (selected.size === 0) return;
    setSubmitting(true);
    try {
      const res = await fetch(`/api/po/${encodeURIComponent(po.poNumber)}/merge-adhoc`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ adhocPoNumbers: [...selected] }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erreur fusion');
      toast(
        `${data.merged} ADHOC fusionné${data.merged > 1 ? 's' : ''} dans ${po.poNumber} (${data.itemsAppended} items)`,
        'success',
      );
      setSelected(new Set());
      mutatePOs();
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      style={{
        padding: '14px 24px',
        backgroundColor: 'rgba(255,240,86,0.18)',
        borderTop: '1px solid rgba(0,0,0,0.08)',
      }}
    >
      <div className="flex items-center justify-between" style={{ marginBottom: '10px' }}>
        <div className="flex items-center gap-2">
          <LinkIcon style={{ width: '18px', height: '18px', color: 'rgba(0,0,0,0.55)' }} />
          <span style={{ fontSize: '13px', fontWeight: 700, color: 'rgba(0,0,0,0.7)' }}>
            Réceptions ad-hoc à fusionner ({candidates.length})
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={selectAll}
            disabled={submitting}
            style={{
              fontSize: '11px', fontWeight: 600, color: 'rgba(0,0,0,0.5)',
              background: 'none', border: 'none', textDecoration: 'underline',
              cursor: 'pointer', padding: 0,
            }}
          >
            Tout sélectionner
          </button>
          <button
            type="button"
            onClick={handleMerge}
            disabled={submitting || selected.size === 0}
            className="btn-primary"
            style={{ padding: '6px 14px', fontSize: '12px', height: '32px' }}
          >
            {submitting ? 'Fusion…' : `Fusionner (${selected.size})`}
          </button>
        </div>
      </div>

      <p style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)', marginBottom: '8px' }}>
        Items reçus en scan rapide cette semaine chez <strong>{po.fournisseur}</strong>.
        La fusion ajoute leurs items à ce PO et marque les ADHOC comme annulés (trace conservée).
      </p>

      <div className="flex flex-col" style={{ gap: '6px' }}>
        {candidates.map(adhoc => {
          const isSel  = selected.has(adhoc.poNumber);
          const total  = adhoc.items.reduce((s, it) => s + it.qteRecue * it.prixAchat, 0);
          const summary = adhoc.items
            .map(it => `${it.nom} ×${it.qteRecue}`)
            .join(' · ')
            .slice(0, 110);
          return (
            <label
              key={adhoc.poNumber}
              className="flex items-start gap-2 cursor-pointer"
              style={{
                padding: '8px 12px',
                backgroundColor: isSel ? 'rgba(255,240,86,0.4)' : 'rgba(255,255,255,0.6)',
                borderRadius: '8px',
              }}
            >
              <input
                type="checkbox"
                checked={isSel}
                onChange={() => toggle(adhoc.poNumber)}
                className="custom-checkbox shrink-0"
                style={{ marginTop: '2px' }}
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <span style={{ fontSize: '12px', fontWeight: 700, color: 'rgba(0,0,0,0.7)', fontFamily: 'monospace' }}>
                    {adhoc.poNumber}
                  </span>
                  <span style={{ fontSize: '12px', fontWeight: 700, color: 'rgba(0,0,0,0.65)' }}>
                    {frPrix(total)}
                  </span>
                </div>
                <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)', marginTop: '2px' }}>
                  {adhoc.dateReception ?? '—'} · {adhoc.items.length} item{adhoc.items.length > 1 ? 's' : ''}
                </div>
                <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.55)', marginTop: '2px', wordBreak: 'break-word' }}>
                  {summary}
                </div>
              </div>
            </label>
          );
        })}
      </div>
    </div>
  );
}
