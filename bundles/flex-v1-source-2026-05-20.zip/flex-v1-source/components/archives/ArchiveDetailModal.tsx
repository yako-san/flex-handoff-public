'use client';
/**
 * Modal de détail (lecture seule) d'un BDT archivé.
 *
 * Réutilisé dans /archives (clic sur ID) et dans /clients (clic sur pill
 * BDT archivé/refusé) — évite la navigation vers /inventaire/[id] qui
 * donne 'Vélo introuvable' pour les BDT archivés.
 *
 * Récupération prix arrondis : les prix unitaires des pièces archivées
 * peuvent être stockés arrondis (lecture FORMATTED_VALUE au moment du
 * snapshot). On lookup chaque pièce par nom dans le catalogue PIÈCES
 * actuel pour récupérer le prix d'origine (non arrondi). Fallback sur
 * le prix stocké si la pièce n'est plus au catalogue.
 */
import { useMemo } from 'react';
import Modal from '@/components/ui/Modal';
import { frDate, frPrix } from '@/lib/utils/format';
import { getArchiveStatutDisplay } from '@/lib/utils/statuts';
import { LockClosedIcon, XMarkIcon } from '@heroicons/react/24/outline';
import { usePieces } from '@/hooks/useCatalogue';
import type { BDC } from '@/types/bdc';

// v1.1.4 — Item 6 audit : statutColors local consolidé dans
// lib/utils/statuts.ts → getArchiveStatutDisplay (alias).
const statutColors = getArchiveStatutDisplay;

interface ArchiveDetailModalProps {
  open  : boolean;
  bdc   : BDC | null;
  onClose: () => void;
}

export default function ArchiveDetailModal({ open, bdc, onClose }: ArchiveDetailModalProps) {
  const { pieces: catalogPieces } = usePieces();
  // Map nom → prix catalogue actuel (pour rétablir les prix arrondis)
  const catalogPriceByName = useMemo(() => {
    const m = new Map<string, number>();
    for (const p of catalogPieces) {
      const key = (p.nom ?? '').trim().toLowerCase();
      if (!key) continue;
      const price = p.prixBDC || p.prixVente || p.prixBase || p.prixAchat || 0;
      if (price > 0 && !m.has(key)) m.set(key, price);
    }
    return m;
  }, [catalogPieces]);

  return (
    <Modal open={open && !!bdc} onClose={onClose} size="lg">
      {bdc && (() => {
        const b = bdc;
        const colors = statutColors(b.archiveStatus);
        const services = b.items.filter(it => it.service);
        // Pièces avec prix corrigé depuis catalogue (si dispo), sinon stocké
        const pieces = b.items
          .filter(it => it.piece)
          .map(it => {
            const stored = it.piece!.prix;
            const cataPrice = catalogPriceByName.get((it.piece!.nom ?? '').trim().toLowerCase());
            const prix = (cataPrice && cataPrice > 0) ? cataPrice : stored;
            const sousTotal = prix * (it.piece!.qte || 0);
            return { ...it, piece: { ...it.piece!, prix, sousTotal } };
          });
        // Recalcule total pièces depuis prix corrigés
        const totalPieces = pieces.reduce((s, it) => s + (it.piece!.sousTotal || 0), 0);
        const total = b.totalServices + totalPieces;

        return (
          <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {/* 1. ID + statut pill */}
            <div className="flex items-center gap-3">
              <span
                className="font-bold inline-flex items-center gap-2 flex-1"
                style={{
                  backgroundColor: colors.bg,
                  color: colors.fg,
                  padding: '6px 18px',
                  borderRadius: '20px',
                  fontSize: '18px',
                }}
              >
                {b.id}
                <span style={{ fontSize: '13px', fontWeight: 700, letterSpacing: '0.05em' }}>{colors.label}</span>
                <span className="ml-auto inline-flex items-center gap-2" style={{ flexShrink: 0 }}>
                  <span
                    className="inline-flex items-center justify-center"
                    style={{
                      width: '28px',
                      height: '28px',
                      borderRadius: '50%',
                      border: `2px solid ${colors.fg}`,
                    }}
                    title="Lecture seule"
                  >
                    <LockClosedIcon style={{ width: '14px', height: '14px' }} />
                  </span>
                  <button
                    onClick={onClose}
                    className="inline-flex items-center justify-center hover:opacity-70 transition-opacity"
                    style={{
                      width: '28px',
                      height: '28px',
                      borderRadius: '50%',
                      border: `2px solid ${colors.fg}`,
                      background: 'none',
                      color: colors.fg,
                      cursor: 'pointer',
                    }}
                    title="Fermer"
                  >
                    <XMarkIcon style={{ width: '14px', height: '14px' }} strokeWidth={3} />
                  </button>
                </span>
              </span>
            </div>

            {/* 2. Client + Vélo */}
            <div className="text-sm" style={{ color: 'rgba(0,0,0,0.6)' }}>
              <strong>Client :</strong> {b.clientNom} &nbsp;&nbsp; <strong>Vélo :</strong> {b.veloDesc}
            </div>

            {/* 3. Dates */}
            <div className="text-sm" style={{ color: 'rgba(0,0,0,0.6)' }}>
              <strong>Date in :</strong> {frDate(b.dateIn)}
              {b.dateOut && <> &nbsp;&nbsp; <strong>Date out :</strong> {frDate(b.dateOut)}</>}
            </div>

            {/* 4. Séquence de travail */}
            <div className="text-sm" style={{ color: 'rgba(0,0,0,0.6)' }}>
              <strong>Séquence de travail :</strong>{' '}
              {[
                { label: 'évaluation', name: b.evalMecano },
                { label: 'mécanique',  name: b.mecaMecano },
                { label: 'ctrl. qlté', name: b.ctrlMecano },
              ].map((e, i, arr) => {
                const isAttente = !e.name || e.name.toLowerCase().startsWith('attente');
                const icon = isAttente ? '–' : '✓';
                return (
                  <span key={e.label} style={{ color: 'rgba(0,0,0,0.5)' }}>
                    {icon} {e.label} : {e.name || 'En attente'}
                    {i < arr.length - 1 && <span style={{ margin: '0 8px', color: 'rgba(0,0,0,0.3)' }}>|</span>}
                  </span>
                );
              })}
            </div>

            {/* 5. Note interne */}
            {(() => {
              const note = b.noteInterne ?? '';
              if (!note) return null;
              const sepRegex = /^[─━\-=]{10,}\s*$/m;
              const m = note.match(sepRegex);
              let cleaned = note;
              if (m && m.index !== undefined) {
                cleaned = note.slice(m.index + m[0].length).trim();
              }
              if (!cleaned) return null;
              return (
                <div className="text-sm" style={{ color: 'rgba(0,0,0,0.5)', whiteSpace: 'pre-wrap' }}>
                  <strong style={{ color: 'rgba(0,0,0,0.6)' }}>Note interne</strong>
                  <div style={{ marginTop: '4px' }}>{cleaned}</div>
                </div>
              );
            })()}

            {/* Note vélo */}
            {b.noteVelo && (
              <p className="text-sm italic" style={{ color: 'rgba(0,0,0,0.5)' }}>
                Note vélo : {b.noteVelo}
              </p>
            )}

            {/* Services */}
            {services.length > 0 && (
              <div>
                <h3 className="text-sm font-bold uppercase" style={{ color: 'rgba(0,0,0,0.4)', marginBottom: '8px', paddingTop: '12px', borderTop: '1px solid rgba(0,0,0,0.5)' }}>Services</h3>
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ color: 'rgba(0,0,0,0.4)', fontStyle: 'italic', fontSize: '12px' }}>
                      <th className="text-left py-1 px-2">items</th>
                      <th className="text-right py-1 px-2 w-20">prix</th>
                    </tr>
                  </thead>
                  <tbody>
                    {services.map((it, i) => (
                      <tr key={i} style={{ backgroundColor: i % 2 === 0 ? 'rgba(0,0,0,0.03)' : 'transparent' }}>
                        <td className="py-1 px-2">{it.service!.nom}</td>
                        <td className="py-1 px-2 text-right">{frPrix(it.service!.prix)}</td>
                      </tr>
                    ))}
                    <tr style={{ fontWeight: 700 }}>
                      <td className="py-1 px-2">Total services</td>
                      <td className="py-1 px-2 text-right">{frPrix(b.totalServices)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}

            {/* Pièces */}
            {pieces.length > 0 && (
              <div>
                <h3 className="text-sm font-bold uppercase" style={{ color: 'rgba(0,0,0,0.4)', marginBottom: '8px', paddingTop: '12px', borderTop: '1px solid rgba(0,0,0,0.5)' }}>Pièces</h3>
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ color: 'rgba(0,0,0,0.4)', fontStyle: 'italic', fontSize: '12px' }}>
                      <th className="text-left py-1 px-2">items</th>
                      <th className="text-right py-1 px-2 w-20">prix</th>
                      <th className="text-center py-1 px-2 w-12">qté</th>
                      <th className="text-right py-1 px-2 w-24">s/total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pieces.map((it, i) => (
                      <tr key={i} style={{ backgroundColor: i % 2 === 0 ? 'rgba(0,0,0,0.03)' : 'transparent' }}>
                        <td className="py-1 px-2">{it.piece!.nom}</td>
                        <td className="py-1 px-2 text-right">{frPrix(it.piece!.prix)}</td>
                        <td className="py-1 px-2 text-center">{it.piece!.qte}</td>
                        <td className="py-1 px-2 text-right">{frPrix(it.piece!.sousTotal)}</td>
                      </tr>
                    ))}
                    <tr style={{ fontWeight: 700 }}>
                      <td className="py-1 px-2" colSpan={3}>Total pièces</td>
                      <td className="py-1 px-2 text-right">{frPrix(totalPieces)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}

            {/* Grand total */}
            <div className="flex justify-end" style={{ fontSize: '20px', fontWeight: 700 }}>
              Total : {frPrix(total)}
            </div>

            {services.length === 0 && pieces.length === 0 && (
              <p className="text-center text-sm" style={{ color: 'rgba(0,0,0,0.4)', padding: '20px' }}>
                Aucun détail disponible pour ce BDC.
              </p>
            )}
          </div>
        );
      })()}
    </Modal>
  );
}
