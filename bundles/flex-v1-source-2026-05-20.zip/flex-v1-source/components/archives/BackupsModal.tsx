'use client';
import useSWR from 'swr';
import Modal from '@/components/ui/Modal';
import LoadingSpinner from '@/components/ui/LoadingSpinner';

/**
 * Modal viewer des entrées _BDC_BACKUPS_.
 *
 * Read-only : affiche timestamp, action, bdcId, client, vélo, note.
 * Pour restaurer un snapshot → ouvrir le sheet INVENTAIRE onglet
 * `_BDC_BACKUPS_` directement (lignes append-only, JSON en col F/G).
 */

interface BackupEntry {
  _row: number;
  timestamp: string;
  action: string;
  bdcId: string;
  clientNom: string;
  veloDesc: string;
  note: string;
  hasBdcRows: boolean;
  hasInvRow: boolean;
}

import { jsonFetcher as fetcher } from '@/lib/swr';

const ACTION_COLORS: Record<string, { bg: string; fg: string; label: string }> = {
  'archive'            : { bg: '#e0e0e0', fg: '#333',     label: 'archivé' },
  'desarchive'         : { bg: '#d4edbc', fg: '#11734b',  label: 'désarchivé' },
  'archive-refuse'     : { bg: '#ffcdd2', fg: '#b71c1c',  label: 'refusé' },
  'pre-delete'         : { bg: '#ffcfc9', fg: '#b10202',  label: 'pre-delete' },
  'pre-delete-archive' : { bg: '#ffcfc9', fg: '#b10202',  label: 'pre-delete archive' },
  'manual'             : { bg: '#ffe0b2', fg: '#e65100',  label: 'manuel' },
};

export default function BackupsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { data, error, isLoading } = useSWR<BackupEntry[]>(
    open ? '/api/bdc-backups?limit=200' : null,
    fetcher,
  );

  return (
    <Modal open={open} onClose={onClose} title="Backups BDT" size="xl" fullHeight>
      <p className="text-sm" style={{ color: 'rgba(0,0,0,0.6)', marginBottom: '16px' }}>
        Snapshots automatiques avant chaque opération destructive.
        Les données brutes (JSON complet du BDC + ligne INVENTAIRE) sont
        dans l'onglet <code style={{ background: 'rgba(0,0,0,0.06)', padding: '1px 6px', borderRadius: '4px' }}>_BDC_BACKUPS_</code> du sheet Inventaire — ouvrir directement pour restaurer.
      </p>

      {isLoading && <LoadingSpinner className="py-10" />}
      {error && (
        <p style={{ color: '#b10202' }}>Erreur de chargement : {String(error?.message ?? error)}</p>
      )}

      {data && data.length === 0 && (
        <p className="text-center py-16" style={{ color: 'rgba(0,0,0,0.4)' }}>
          Aucun backup pour l'instant.
        </p>
      )}

      {data && data.length > 0 && (
        <div style={{ overflowX: 'auto' }}>
          <table className="w-full text-sm" style={{ borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(0,0,0,0.12)' }}>
                <Th>timestamp</Th>
                <Th>action</Th>
                <Th>id</Th>
                <Th>client</Th>
                <Th>vélo</Th>
                <Th>contenu</Th>
                <Th>note</Th>
              </tr>
            </thead>
            <tbody>
              {data.map((e, i) => {
                const bg = i % 2 === 0 ? 'rgba(0,0,0,0.02)' : 'transparent';
                const act = ACTION_COLORS[e.action] ?? { bg: '#f0f0f0', fg: '#555', label: e.action };
                return (
                  <tr key={e._row} style={{ backgroundColor: bg, borderBottom: '1px solid rgba(0,0,0,0.05)' }}>
                    <Td>
                      <span style={{ fontFamily: 'monospace', fontSize: '12px', color: 'rgba(0,0,0,0.65)' }}>
                        {e.timestamp}
                      </span>
                    </Td>
                    <Td>
                      <span style={{
                        backgroundColor: act.bg, color: act.fg,
                        fontSize: '11px', fontWeight: 700,
                        padding: '2px 10px', borderRadius: '999px',
                        whiteSpace: 'nowrap',
                      }}>{act.label}</span>
                    </Td>
                    <Td>
                      <span style={{ fontFamily: 'monospace', fontWeight: 700 }}>{e.bdcId}</span>
                    </Td>
                    <Td>{e.clientNom || '—'}</Td>
                    <Td>{e.veloDesc || '—'}</Td>
                    <Td>
                      <span style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)' }}>
                        {[e.hasBdcRows ? 'BDC' : '', e.hasInvRow ? 'INV' : ''].filter(Boolean).join(' + ') || '—'}
                      </span>
                    </Td>
                    <Td>
                      <span style={{ fontSize: '12px', color: 'rgba(0,0,0,0.5)' }}>{e.note || '—'}</span>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </Modal>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return (
    <th style={{
      padding: '8px 10px',
      textAlign: 'left',
      fontSize: '11px',
      fontWeight: 700,
      color: 'rgba(0,0,0,0.5)',
      letterSpacing: '0.04em',
      whiteSpace: 'nowrap',
    }}>{children}</th>
  );
}

function Td({ children }: { children: React.ReactNode }) {
  return (
    <td style={{ padding: '8px 10px', color: 'rgba(0,0,0,0.8)', verticalAlign: 'middle' }}>
      {children}
    </td>
  );
}
