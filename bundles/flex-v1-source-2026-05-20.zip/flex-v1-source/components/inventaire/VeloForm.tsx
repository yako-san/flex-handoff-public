'use client';
import { useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Modal from '@/components/ui/Modal';
import PromptDialog from '@/components/ui/PromptDialog';
import HelpHint from '@/components/ui/HelpHint';
import ClientForm from '@/components/clients/ClientForm';
import { useInventaire } from '@/hooks/useInventaire';
import { useClients } from '@/hooks/useClients';
import { useMarques } from '@/hooks/useCatalogue';
import { toast } from '@/components/ui/Toast';
import { ArrowPathIcon } from '@heroicons/react/24/outline';
import { useVeloTailles } from '@/hooks/useVeloTailles';

const ADD_MARQUE = '__add_marque__';
const ADD_CLIENT = '__add_client__';

const schema = z.object({
  client  : z.string().min(1, 'Requis'),
  marque  : z.string().min(1, 'Requis'),
  modele  : z.string().optional(),
  couleur : z.string().optional(),
  taille  : z.string().optional(),
  serie   : z.string().optional(),
});

type FormData = z.infer<typeof schema>;

interface VeloFormProps {
  open: boolean;
  onClose: () => void;
  onCreated?: (id: string) => void;
  /** Pré-remplit le champ client et le verrouille visuellement. */
  initialClient?: string;
}

export default function VeloForm({ open, onClose, onCreated, initialClient }: VeloFormProps) {
  const { velos, addVelo }                      = useInventaire();
  const { allNoms, mutate: mutateClients }      = useClients();
  const { marques, addMarque, refreshMarques }  = useMarques();
  const { tailles: veloTailles }                = useVeloTailles();

  const [showClientForm, setShowClientForm] = useState(false);
  const [refreshingMarques, setRefreshingMarques] = useState(false);
  const [promptMarqueOpen, setPromptMarqueOpen] = useState(false);

  // Enrichir les noms avec ceux de l'INVENTAIRE — trié par nom de famille
  const enrichedNoms = useMemo(() => {
    const set = new Set(allNoms);
    for (const v of velos) {
      if (v.client && v.client !== 'Sélection →') set.add(v.client);
    }
    const lastName = (full: string) => {
      const parts = full.trim().split(/\s+/);
      return parts.length > 1 ? parts[parts.length - 1] : full;
    };
    return [...set].sort((a, b) => {
      const cmp = lastName(a).localeCompare(lastName(b), 'fr');
      return cmp !== 0 ? cmp : a.localeCompare(b, 'fr');
    });
  }, [allNoms, velos]);

  // Enrichir les marques avec celles de l'INVENTAIRE
  const enrichedMarques = useMemo(() => {
    const set = new Set(marques.map(m => m.nom));
    for (const v of velos) {
      if (v.marque && v.marque !== 'Sélection →' && v.marque !== '...') set.add(v.marque);
    }
    return [...set].sort((a, b) => a.localeCompare(b, 'fr'));
  }, [marques, velos]);

  const { register, handleSubmit, reset, setValue, watch, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  // Pré-remplit le client à chaque ouverture si fourni par le parent.
  useEffect(() => {
    if (open) {
      reset({ client: initialClient ?? '', marque: '', modele: '', couleur: '', taille: '', serie: '' });
    }
  }, [open, initialClient, reset]);

  const currentClient = watch('client');
  const currentMarque = watch('marque');

  function handleClientChange(e: React.ChangeEvent<HTMLSelectElement>) {
    const v = e.target.value;
    if (v === ADD_CLIENT) {
      setShowClientForm(true);
      // Reset à la valeur précédente
      setValue('client', currentClient || '');
      return;
    }
    setValue('client', v, { shouldValidate: true });
  }

  async function handleMarqueChange(e: React.ChangeEvent<HTMLSelectElement>) {
    const v = e.target.value;
    if (v === ADD_MARQUE) {
      // Remet la valeur précédente en UI avant d'ouvrir le prompt
      setValue('marque', currentMarque || '');
      setPromptMarqueOpen(true);
      return;
    }
    setValue('marque', v, { shouldValidate: true });
  }

  async function submitNewMarque(nom: string) {
    setPromptMarqueOpen(false);
    try {
      await addMarque(nom);
      setValue('marque', nom, { shouldValidate: true });
      toast(`Marque « ${nom} » ajoutée`);
    } catch (err: any) {
      toast(err.message, 'error');
    }
  }

  async function handleRefreshMarques() {
    setRefreshingMarques(true);
    try {
      await refreshMarques();
      toast('Liste des marques rafraîchie');
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setRefreshingMarques(false);
    }
  }

  async function onSubmit(data: FormData) {
    try {
      const res = await addVelo(data);
      toast(`Vélo ${res.id} créé`);
      reset();
      onClose();
      onCreated?.(res.id);
    } catch (err: any) {
      toast(err.message, 'error');
    }
  }

  return (
    <>
      <Modal
        open={open}
        onClose={onClose}
        size="xl"
        title={
          <span style={{ display: 'inline-flex', alignItems: 'baseline', gap: '6px' }}>
            Nouveau Bon de Travail
            <HelpHint
              topic="01-recevoir-velo"
              title="Recevoir un vélo"
              hint="Crée un client (ou choisis-en un existant) + son vélo. Le BDT est ouvert automatiquement après création. Voir le tutoriel pour les étapes détaillées."
              size={18}
            />
          </span>
        }
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="label-system">client *</label>
            <select
              {...register('client')}
              onChange={handleClientChange}
              className="input-system"
            >
              <option value="">Sélection →</option>
              <option value={ADD_CLIENT}>＋ Ajouter un client</option>
              {enrichedNoms.map(n => <option key={n} value={n}>{n}</option>)}
            </select>
            {errors.client && <p className="text-xs text-red-500 mt-1">{errors.client.message}</p>}
          </div>

          <div>
            <label className="label-system">marque *</label>
            <div className="flex gap-2">
              <select
                {...register('marque')}
                onChange={handleMarqueChange}
                className="input-system flex-1"
              >
                <option value="">Sélection →</option>
                <option value={ADD_MARQUE}>＋ Ajouter une marque</option>
                <option value="Autre">Autre</option>
                {enrichedMarques.filter(m => m !== 'Autre').map(m => <option key={m} value={m}>{m}</option>)}
              </select>
              <button
                type="button"
                onClick={handleRefreshMarques}
                disabled={refreshingMarques}
                title="Rafraîchir la liste des marques (bypass cache)"
                className="flex items-center justify-center transition-colors"
                style={{
                  width: '40px', height: '40px', borderRadius: '50%',
                  backgroundColor: 'rgba(0,0,0,0.05)', border: '1.5px solid rgba(0,0,0,0.2)',
                  flexShrink: 0,
                }}
              >
                <ArrowPathIcon
                  className={refreshingMarques ? 'animate-spin' : ''}
                  style={{ width: '18px', height: '18px', color: 'rgba(0,0,0,0.6)' }}
                />
              </button>
            </div>
            {errors.marque && <p className="text-xs text-red-500 mt-1">{errors.marque.message}</p>}
          </div>

          <div className="grid grid-cols-2 gap-3">
            {(['modele','couleur','serie'] as const).map(field => (
              <div key={field}>
                <label className="label-system capitalize">{field === 'serie' ? '# série' : field}</label>
                <input {...register(field)} placeholder="..." className="input-system" />
              </div>
            ))}
            <div>
              <label className="label-system">Taille</label>
              <select {...register('taille')} className="input-system">
                {veloTailles.map(t => (
                  <option key={t} value={t}>{t || '—'}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary">Annuler</button>
            <button type="submit" disabled={isSubmitting} className="btn-primary">
              {isSubmitting ? 'Création…' : 'Créer le bon de travail'}
            </button>
          </div>
        </form>
      </Modal>

      <ClientForm
        open={showClientForm}
        onClose={() => setShowClientForm(false)}
        onCreated={nom => {
          mutateClients();
          setValue('client', nom, { shouldValidate: true });
        }}
      />

      <PromptDialog
        open={promptMarqueOpen}
        title="Nouvelle marque"
        message="Nom de la nouvelle marque :"
        placeholder="ex. Trek, Specialized, Giant"
        confirmLabel="Ajouter"
        onConfirm={submitNewMarque}
        onCancel={() => setPromptMarqueOpen(false)}
      />
    </>
  );
}
