'use client';
import { useEffect, useRef, useState } from 'react';
import { toast } from '@/components/ui/Toast';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import { ArrowUpTrayIcon, TrashIcon, PhotoIcon } from '@heroicons/react/24/outline';
import { compressImage } from '@/lib/utils/imageCompress';

interface Photo {
  id: string;
  name: string;
  webViewLink?: string;
  thumbnailLink?: string;
  mimeType: string;
  createdTime?: string;
}

interface VeloPhotosProps {
  /** BDC id (= velo id, équivalent). Utilisé pour la résolution Drive
   *  côté serveur via `/api/inventaire/[id]/photos`. */
  bdcId: string;
}

/**
 * v1.0.10+ — Bloc photos attachées à un VÉLO (BDT) — stockées dans
 * `<DRIVE_CLIENTS_FOLDER_ID>/<nomClient>/BDT-<bdcId>/`.
 *
 * Différent de `ClientPhotos` : ce composant cible les photos par-vélo
 * (pertinent pour archivage, état d'arrivée, suivi diagnostic). Les
 * photos d'un client précédent BDT restent dans `BDT-<oldBdcId>/`.
 *
 * Réutilise les routes DELETE et content du flow client (génériques par
 * fileId Drive), seules GET/POST list+upload sont dédiées au BDT.
 */
export default function VeloPhotos({ bdcId }: VeloPhotosProps) {
  const [photos,    setPhotos]    = useState<Photo[]>([]);
  const [loading,   setLoading]   = useState(false);
  const [uploading, setUploading] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Photo | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  async function refresh() {
    if (!bdcId) return;
    setLoading(true);
    try {
      const res  = await fetch(`/api/inventaire/${encodeURIComponent(bdcId)}/photos`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Erreur chargement photos');
      setPhotos(json.photos ?? []);
    } catch (err: any) { toast(err.message, 'error'); }
    finally { setLoading(false); }
  }

  useEffect(() => { refresh(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [bdcId]);

  async function handleFiles(files: FileList | null) {
    if (!files || !files.length || !bdcId) return;
    const MAX_BYTES = 4 * 1024 * 1024;
    setUploading(true);
    try {
      const tooBig: string[] = [];
      for (const original of Array.from(files)) {
        let file: File;
        try { file = await compressImage(original); } catch { file = original; }
        if (file.size > MAX_BYTES) {
          tooBig.push(`${original.name} (${(file.size / 1024 / 1024).toFixed(1)} MB après compression)`);
          continue;
        }
        const fd = new FormData();
        fd.append('file', file);
        const res = await fetch(`/api/inventaire/${encodeURIComponent(bdcId)}/photos`, {
          method: 'POST', body: fd,
        });
        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          throw new Error(err.error || `Upload échoué pour ${original.name}`);
        }
      }
      if (tooBig.length) {
        toast(`Trop volumineux même après compression : ${tooBig.join(', ')}`, 'error');
      }
      const uploaded = files.length - tooBig.length;
      if (uploaded > 0) {
        toast(`${uploaded} photo${uploaded > 1 ? 's' : ''} uploadée${uploaded > 1 ? 's' : ''}`);
      }
      await refresh();
    } catch (err: any) { toast(err.message, 'error'); }
    finally { setUploading(false); }
  }

  async function doDelete() {
    if (!deleteTarget) return;
    const p = deleteTarget;
    setDeleteTarget(null);
    try {
      // Route DELETE générique par fileId (réutilisée du flow client)
      const res = await fetch(`/api/clients/photos/${p.id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error((await res.json()).error || 'Erreur suppression');
      toast('Photo supprimée');
      await refresh();
    } catch (err: any) { toast(err.message, 'error'); }
  }

  if (!bdcId) return null;

  return (
    <div style={{ marginTop: '12px' }}>
      <div className="flex items-center justify-between" style={{ marginBottom: '8px' }}>
        <span className="legende" style={{ color: 'rgba(0,0,0,0.4)' }}>Photos du vélo</span>
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          className="flex items-center gap-1"
          style={{
            padding: '4px 10px',
            fontSize: '11px', fontWeight: 700,
            borderRadius: '999px',
            backgroundColor: 'rgba(0,0,0,0.08)',
            color: 'rgba(0,0,0,0.7)',
            border: 'none',
            cursor: uploading ? 'wait' : 'pointer',
          }}
        >
          <ArrowUpTrayIcon style={{ width: '12px', height: '12px' }} />
          {uploading ? 'Upload…' : 'Ajouter'}
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          multiple
          style={{ display: 'none' }}
          onChange={e => { handleFiles(e.target.files); e.target.value = ''; }}
        />
      </div>

      {loading && <p className="text-xs" style={{ color: 'rgba(0,0,0,0.4)' }}>Chargement…</p>}
      {!loading && photos.length === 0 && (
        <p className="text-xs" style={{ color: 'rgba(0,0,0,0.4)' }}>Aucune photo pour ce vélo.</p>
      )}
      {!loading && photos.length > 0 && (
        <div className="grid grid-cols-3 gap-2">
          {photos.map(p => (
            <div key={p.id} className="relative group" style={{
              aspectRatio: '1 / 1', borderRadius: '8px', overflow: 'hidden',
              backgroundColor: 'rgba(0,0,0,0.05)',
            }}>
              <a href={p.webViewLink} target="_blank" rel="noopener noreferrer"
                 title={p.name}
                 className="block w-full h-full">
                {p.mimeType?.startsWith('image/') ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={`/api/clients/photos/${p.id}/content`} alt={p.name}
                       loading="lazy"
                       style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : (
                  <div className="flex items-center justify-center w-full h-full" style={{ color: 'rgba(0,0,0,0.3)' }}>
                    <PhotoIcon style={{ width: '24px', height: '24px' }} />
                  </div>
                )}
              </a>
              <button
                type="button"
                onClick={() => setDeleteTarget(p)}
                className="absolute top-1 right-1 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                style={{
                  width: '22px', height: '22px', borderRadius: '50%',
                  backgroundColor: 'rgba(0,0,0,0.6)', color: '#fff', border: 'none',
                  cursor: 'pointer',
                }}
                title="Supprimer"
              >
                <TrashIcon style={{ width: '12px', height: '12px' }} />
              </button>
            </div>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={deleteTarget !== null}
        title="Supprimer la photo ?"
        message={deleteTarget ? `Supprimer « ${deleteTarget.name} » du dossier Drive du vélo ?` : ''}
        confirmLabel="Supprimer"
        danger
        onConfirm={doDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
