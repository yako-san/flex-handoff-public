import { getStatutStyle } from '@/lib/utils/statuts';

interface StatutBadgeProps {
  statut: string;
  className?: string;
}

/**
 * Badge statut avec couleurs hex exactes (identiques au GAS).
 * Style inline pour respecter les valeurs hex — pas de classes Tailwind dynamiques.
 */
export default function StatutBadge({ statut, className = '' }: StatutBadgeProps) {
  const style = getStatutStyle(statut);
  return (
    <span
      className={`inline-flex items-center justify-center px-2 py-0.5 rounded text-xs font-bold whitespace-nowrap ${className}`}
      style={style}
    >
      {statut}
    </span>
  );
}
