'use client';
import { useMemo } from 'react';
import Link from 'next/link';
import { frDate, frDateHeure } from '@/lib/utils/format';
import { STATUTS } from '@/lib/utils/statuts';
import { useClients } from '@/hooks/useClients';
import { useEmailTemplates } from '@/hooks/useEmailTemplates';
import { buildReminderUrl } from '@/lib/utils/reminderUrl';
import { ChatBubbleLeftRightIcon, EnvelopeIcon, PhoneIcon } from '@heroicons/react/24/outline';
import type { Velo } from '@/types/velo';

const READY_STATUSES = new Set(['FINI', 'FACTURER', 'FACTURÉ']);

/**
 * VeloCard — rendu mobile (iOS) d'une ligne inventaire.
 * Toute la carte est un Link vers le BDT détaillé. Les sélecteurs (client,
 * éval/méca/ctrl) ne sont plus édités ici : on passe par la page BDT.
 */
export default function VeloCard({ velo, isStaff = false }: { velo: Velo; isStaff?: boolean }) {
  const s  = STATUTS[velo.status] ?? { bg: '#f5f5f5', fg: '#333333' };
  const bg = isStaff ? 'rgba(255,255,255,0.5)' : s.bg;

  // Rappel comm pour les vélos prêts à ramasser
  const { grouped } = useClients();
  const { tpl }     = useEmailTemplates();
  const reminder = useMemo(() => {
    if (!READY_STATUSES.has(velo.status)) return null;
    const all = [
      ...(grouped?.recents ?? []),
      ...(grouped?.actifs  ?? []),
      ...(grouped?.autres  ?? []),
    ];
    const client   = all.find(c => `${c.prenom ?? ''} ${c.nom ?? ''}`.trim() === velo.client);
    const veloDesc = [velo.marque, velo.modele, velo.couleur, velo.taille].filter(Boolean).join(', ');
    return buildReminderUrl(client, velo.id, {
      smsTemplateFr: tpl('sms_rappel_fr'),
      smsTemplateEn: tpl('sms_rappel_en'),
      veloDesc,
    });
  }, [velo.status, velo.client, velo.id, velo.marque, velo.modele, velo.couleur, velo.taille, grouped, tpl]);
  const RemIcon = reminder?.kind === 'email' ? EnvelopeIcon
                : reminder?.kind === 'tel'   ? PhoneIcon
                : ChatBubbleLeftRightIcon;

  const labelStyle: React.CSSProperties = { fontSize: '11px', fontWeight: 700, color: 'rgba(0,0,0,0.4)', textTransform: 'uppercase', letterSpacing: '0.04em' };
  const valueStyle: React.CSSProperties = { fontSize: '13px', fontWeight: 400, color: 'rgba(0,0,0,0.7)' };

  return (
    <Link
      href={`/inventaire/${velo.id}`}
      className="block hover:opacity-90 transition-opacity"
      style={{ color: '#000', textDecoration: 'none' }}
    >
      <div
        style={{
          backgroundColor: bg,
          borderRadius: '18px',
          padding: '12px 14px',
          display: 'flex',
          flexDirection: 'column',
          gap: '6px',
        }}
      >
        {/* Ligne 1 : ID + statut (pill) */}
        <div className="flex items-center gap-2">
          <span style={{ fontSize: '14px', fontWeight: 700, lineHeight: 1 }}>{velo.id}</span>
          <span
            className="inline-flex items-center whitespace-nowrap"
            style={{
              padding: '2px 10px',
              borderRadius: '999px',
              backgroundColor: 'rgba(0,0,0,0.15)',
              color: 'rgba(0,0,0,0.75)',
              fontSize: '10px',
              fontWeight: 700,
              letterSpacing: '0.04em',
              textTransform: 'uppercase',
            }}
          >
            {velo.status}
          </span>
          {isStaff && (
            <span
              className="inline-flex items-center whitespace-nowrap"
              style={{
                padding: '2px 8px',
                borderRadius: '999px',
                backgroundColor: 'rgba(0,0,0,0.15)',
                color: 'rgba(0,0,0,0.65)',
                fontSize: '10px',
                fontWeight: 700,
                letterSpacing: '0.04em',
                textTransform: 'uppercase',
              }}
            >
              Staff
            </span>
          )}
          {reminder && (
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                window.location.href = reminder.url;
              }}
              title={`Envoyer rappel (${reminder.label})`}
              className="inline-flex items-center justify-center shrink-0 transition-colors hover:bg-black/10"
              style={{
                width: '24px',
                height: '24px',
                borderRadius: '50%',
                backgroundColor: 'rgba(0,0,0,0.08)',
                color: 'rgba(0,0,0,0.65)',
                border: 'none',
                cursor: 'pointer',
                padding: 0,
              }}
            >
              <RemIcon style={{ width: '12px', height: '12px' }} />
            </button>
          )}
        </div>

        {/* Ligne 2 : vélo (bold) */}
        <div style={{ ...valueStyle, fontWeight: 700 }}>
          {[velo.marque, velo.modele, velo.couleur, velo.taille].filter(Boolean).join(', ') || '—'}
        </div>

        {/* Ligne 3 : client (bold, sans label) */}
        {velo.client && (
          <div style={{ ...valueStyle, fontWeight: 700 }}>
            {velo.client}
          </div>
        )}

        {/* Ligne 4 : date reçu (+ heure si présente) */}
        <div className="flex items-center gap-2">
          <span style={labelStyle}>Reçu</span>
          <span style={{ ...valueStyle, whiteSpace: 'pre-line', lineHeight: 1.1 }}>{frDateHeure(velo.date1)}</span>
        </div>
      </div>
    </Link>
  );
}
