'use client';
import { useState, useMemo } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { frDate, frDateHeure } from '@/lib/utils/format';
import { STATUTS, STATUTS_ORDER, nextStatusOnAssign } from '@/lib/utils/statuts';
import { useInventaire } from '@/hooks/useInventaire';
import { useClients } from '@/hooks/useClients';
import ClientForm from '@/components/clients/ClientForm';
import { toast } from '@/components/ui/Toast';
import { useEquipe } from '@/hooks/useEquipe';
import type { Velo } from '@/types/velo';
import type { VeloColId } from './VeloTable';
import { buildReminderUrl } from '@/lib/utils/reminderUrl';
import { useEmailTemplates } from '@/hooks/useEmailTemplates';
import { ChatBubbleLeftRightIcon, EnvelopeIcon, PhoneIcon } from '@heroicons/react/24/outline';

const READY_STATUSES = new Set(['FINI', 'FACTURER', 'FACTURÉ']);

/**
 * Mapping statut → dernier index de colonne coloré (inclus).
 * Colonnes: 0=id, 1=velo, 2=client, 3=eval, 4=meca, 5=ctrl, 6=recu
 */
const STATUS_END_COL: Record<string, number> = {
  'REÇU':         0,
  'ÉVAL.':        3,
  'APPROUVÉ':     4,
  'ON BENCH':     4,
  'CTRL QLTÉ': 5,
  'FINI':         5,
  'FACTURER':     6,
  'FACTURÉ':      6,
  'LIVRÉ':        6,
};

export default function VeloRow({ velo, colOrder, isStaff = false }: { velo: Velo; colOrder: VeloColId[]; isStaff?: boolean }) {
  const router = useRouter();
  const { velos, patchVelo }                       = useInventaire();
  const { allNoms, grouped, mutate: mutateClients } = useClients();
  const { tpl }                                     = useEmailTemplates();
  const { equipe }                                  = useEquipe();

  // Rappel comm : affiché uniquement pour les statuts "prêts à ramasser"
  const reminder = useMemo(() => {
    if (!READY_STATUSES.has(velo.status)) return null;
    const all = [
      ...(grouped?.recents ?? []),
      ...(grouped?.actifs  ?? []),
      ...(grouped?.autres  ?? []),
    ];
    const client = all.find(c => `${c.prenom ?? ''} ${c.nom ?? ''}`.trim() === velo.client);
    const veloDesc = [velo.marque, velo.modele, velo.couleur, velo.taille].filter(Boolean).join(', ');
    return buildReminderUrl(client, velo.id, {
      smsTemplateFr: tpl('sms_rappel_fr'),
      smsTemplateEn: tpl('sms_rappel_en'),
      veloDesc,
    });
  }, [velo.status, velo.client, velo.id, velo.marque, velo.modele, velo.couleur, velo.taille, grouped, tpl]);
  const RemIcon = reminder?.kind === 'email' ? EnvelopeIcon
                : reminder?.kind === 'tel'   ? PhoneIcon
                : ChatBubbleLeftRightIcon;

  const enrichedNoms = useMemo(() => {
    const set = new Set(allNoms);
    for (const v of velos) {
      if (v.client && v.client !== 'Sélection →') set.add(v.client);
    }
    return [...set].sort((a, b) => a.localeCompare(b, 'fr'));
  }, [allNoms, velos]);

  const [showClientForm, setShowClientForm] = useState(false);
  const [saving,         setSaving]         = useState(false);

  const s  = STATUTS[velo.status] ?? { bg: '#f5f5f5', fg: '#333333' };
  // Vélos staff : fond uniforme blanc 50% (on ignore la couleur de statut)
  const bg = isStaff ? 'rgba(255,255,255,0.5)' : s.bg;

  const endCol = STATUS_END_COL[velo.status] ?? 0;

  async function patch(fields: Partial<Velo>) {
    if (saving) return;
    setSaving(true);
    try { await patchVelo(velo.id, fields as any); }
    catch (err: any) { toast(err.message, 'error'); }
    finally { setSaving(false); }
  }

  async function handleClientChange(e: React.ChangeEvent<HTMLSelectElement>) {
    const v = e.target.value;
    if (v === '__new__') { setShowClientForm(true); return; }
    if (v && v !== velo.client) patch({ client: v });
  }

  const cellText: React.CSSProperties = { color: 'rgba(0,0,0,0.5)', fontSize: '18px', fontWeight: 400 };

  /**
   * Indice minimum dans STATUTS_ORDER à partir duquel chaque colonne est
   * "débloquée" :
   *  - eval : dès REÇU (le vélo entre à l'atelier)
   *  - meca : à partir de APPROUVÉ (évaluation validée)
   *  - ctrl : à partir de ON BENCH (travail mécanique en cours)
   */
  const ETAPE_MIN_IDX: Record<'eval' | 'meca' | 'ctrl', number> = {
    eval: STATUTS_ORDER.indexOf('REÇU'),
    meca: STATUTS_ORDER.indexOf('APPROUVÉ'),
    ctrl: STATUTS_ORDER.indexOf('ON BENCH'),
  };

  function renderEtapeSelect(field: 'eval' | 'meca' | 'ctrl') {
    const value   = velo[field] ?? '';
    const curIdx  = STATUTS_ORDER.indexOf(velo.status as any);
    const unlocked = curIdx >= 0 && curIdx >= ETAPE_MIN_IDX[field];
    if (!unlocked) {
      return <span style={cellText}>{value || '—'}</span>;
    }
    return (
      <select
        value={value}
        onChange={async e => {
          const v = e.target.value;
          const nextStatus = nextStatusOnAssign(field, v, velo.status);
          const fields: Partial<Velo> = { [field]: v } as any;
          if (nextStatus) (fields as any).status = nextStatus;
          // v5.3.1 — sélectionner un mécanicien d'évaluation ouvre le BDT
          // v6.1.3 — on attend la fin du PATCH avant de naviguer pour
          // garantir que la nouvelle page voit le vélo (cache SWR à jour).
          await patch(fields);
          if (field === 'eval' && v) {
            router.push(`/inventaire/${velo.id}`);
          }
        }}
        disabled={saving}
        className="border-0 bg-transparent p-0 cursor-pointer focus:ring-0 focus:outline-none"
        style={cellText}
      >
        <option value="">Sélection →</option>
        {equipe.filter(o => o !== '').map(opt => (
          <option key={opt} value={opt}>{opt}</option>
        ))}
      </select>
    );
  }

  function renderCell(id: VeloColId) {
    switch (id) {
      case 'id':
        return (
          <Link
            href={`/inventaire/${velo.id}`}
            className="hover:opacity-75 transition-opacity flex items-baseline gap-1 w-full"
            style={{ color: '#000', textDecoration: 'none', cursor: 'pointer' }}
          >
            <span style={{ fontSize: '22px', fontWeight: 700, lineHeight: 1 }}>{velo.id}</span>
            <span
              className="inline-flex items-center whitespace-nowrap ml-2"
              style={{
                padding: '2px 10px',
                borderRadius: '999px',
                backgroundColor: 'rgba(0,0,0,0.15)',
                color: 'rgba(0,0,0,0.75)',
                fontSize: '11px',
                fontWeight: 700,
                letterSpacing: '0.04em',
                textTransform: 'uppercase',
              }}
            >
              {velo.status}
            </span>
            {reminder && (
              <a
                href={reminder.url}
                onClick={e => e.stopPropagation()}
                title={`Envoyer rappel (${reminder.label})`}
                className="inline-flex items-center justify-center shrink-0 ml-2 transition-colors hover:bg-black/10"
                style={{
                  width: '28px',
                  height: '28px',
                  borderRadius: '50%',
                  backgroundColor: 'rgba(0,0,0,0.08)',
                  color: 'rgba(0,0,0,0.65)',
                  textDecoration: 'none',
                  verticalAlign: 'middle',
                }}
              >
                <RemIcon style={{ width: '14px', height: '14px' }} />
              </a>
            )}
            {isStaff && (
              <span
                className="ml-2 inline-flex items-center whitespace-nowrap"
                style={{
                  padding: '2px 10px',
                  borderRadius: '999px',
                  backgroundColor: 'rgba(0,0,0,0.15)',
                  color: 'rgba(0,0,0,0.65)',
                  fontSize: '11px',
                  fontWeight: 700,
                  letterSpacing: '0.04em',
                  textTransform: 'uppercase',
                }}
              >
                Staff
              </span>
            )}
          </Link>
        );

      case 'client':
        return (
          <select
            value={enrichedNoms.includes(velo.client) ? velo.client : '__other__'}
            onChange={handleClientChange}
            disabled={saving}
            className="border-0 bg-transparent p-0 cursor-pointer focus:ring-0 focus:outline-none w-full"
            style={{ ...cellText, minWidth: '230px' }}
          >
            {!enrichedNoms.includes(velo.client) && velo.client && (
              <option value="__other__">{velo.client}</option>
            )}
            {enrichedNoms.map(n => <option key={n} value={n}>{n}</option>)}
            <option value="__new__">＋ Nouveau client</option>
          </select>
        );

      case 'velo':
        return (
          <span style={{ ...cellText, fontWeight: 700 }}>
            {[velo.marque, velo.modele, velo.couleur, velo.taille].filter(Boolean).join(', ')}
          </span>
        );

      case 'eval': return renderEtapeSelect('eval');
      case 'meca': return renderEtapeSelect('meca');
      case 'ctrl': return renderEtapeSelect('ctrl');
      case 'recu': {
        // Statut RV (rendez-vous à venir) → affiche date + heure (heure du RDV).
        // Tout autre statut (REÇU, ÉVAL. et au-delà) → masque l'heure : le
        // vélo est arrivé, l'heure du RDV n'est plus pertinente.
        const dateHeure = frDateHeure(velo.date1);
        const display = velo.status === 'RV' ? dateHeure : (dateHeure.split('\n')[0] || dateHeure);
        return <span style={{ ...cellText, whiteSpace: 'pre-line', lineHeight: 1.1 }}>{display}</span>;
      }
    }
  }

  return (
    <>
      <tr className="text-sm">
        {colOrder.map((id, i) => {
          const isColored = i <= endCol;
          const isFirst   = i === 0;
          const isLastColored = i === endCol;
          const isLastCol = i === colOrder.length - 1;

          return (
            <td key={id} className="px-3 py-2" style={{
              backgroundColor: isColored ? bg : 'transparent',
              borderRight: i < colOrder.length - 1 ? '1px solid rgba(255,255,255,0.25)' : 'none',
              borderRadius:
                isFirst && isLastColored ? '30px'
                : isFirst ? '30px 0 0 30px'
                : isLastColored && !isLastCol ? '0 30px 30px 0'
                : isLastCol && isColored ? '0 30px 30px 0'
                : '0',
            }}>
              {renderCell(id)}
            </td>
          );
        })}
      </tr>

      <ClientForm
        open={showClientForm}
        onClose={() => setShowClientForm(false)}
        onCreated={nom => { mutateClients(); patch({ client: nom }); }}
      />
    </>
  );
}
