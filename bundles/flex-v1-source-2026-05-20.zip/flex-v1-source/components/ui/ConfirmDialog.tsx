'use client';
import Modal from './Modal';

interface ConfirmDialogProps {
  open: boolean;
  title?: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
  /** Largeur du modal (mappe à Modal.size). Défaut 'sm'. */
  size?: 'sm' | 'md' | 'lg' | 'xl';
  onConfirm: () => void;
  onCancel: () => void;
}

export default function ConfirmDialog({
  open, title = 'Confirmer', message, confirmLabel = 'Confirmer',
  cancelLabel = 'Annuler', danger = false, size = 'sm', onConfirm, onCancel,
}: ConfirmDialogProps) {
  return (
    <Modal open={open} onClose={onCancel} title={title} size={size}>
      <p className="text-sm" style={{ color: 'rgba(0,0,0,0.7)', marginBottom: '24px', whiteSpace: 'pre-line' }}>{message}</p>
      <div className="flex justify-end gap-3">
        <button onClick={onCancel} className="btn-secondary">
          {cancelLabel}
        </button>
        <button onClick={onConfirm} className={danger ? 'btn-danger' : 'btn-primary'}>
          {confirmLabel}
        </button>
      </div>
    </Modal>
  );
}
