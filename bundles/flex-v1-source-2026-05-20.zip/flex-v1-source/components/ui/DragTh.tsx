import React from 'react';

/**
 * <th> draggable avec séparateur de colonne et indicateur visuel de survol.
 *
 * Utilisation :
 *   <DragTh {...dragProps(col.id)} isDragOver={dragOverId === col.id} className="px-4 py-2">
 *     {col.header}
 *   </DragTh>
 */
interface DragThProps extends React.ThHTMLAttributes<HTMLTableCellElement> {
  isDragOver?: boolean;
}

export default function DragTh({ isDragOver, className = '', children, ...props }: DragThProps) {
  return (
    <th
      className={[
        'select-none cursor-grab active:cursor-grabbing',
        'border-r border-gray-200 last:border-r-0',
        isDragOver ? 'bg-yellow-50 !border-l-2 !border-l-yellow-400' : '',
        className,
      ].join(' ')}
      {...props}
    >
      {children}
    </th>
  );
}
