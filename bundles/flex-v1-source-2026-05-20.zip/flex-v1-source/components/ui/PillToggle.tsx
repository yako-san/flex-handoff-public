'use client';
import React from 'react';

/**
 * Toggle "pills" — composant standard du design system FLEX-REV.
 *
 * Apparence : capsule blanche 50% qui contient des items, l'item actif
 * est mis en évidence par un fond jaune. Variante "dark" sur fond foncé.
 *
 *   ┌────────────────────────┐
 *   │ ( Actif ) ( Item 2 )   │
 *   └────────────────────────┘
 *
 * Utilisé sur :
 *   - Archives : Archivés / Refusés
 *   - Aide [slug] : Liste / Diapo
 *   - (à venir) toute page avec un choix exclusif entre 2-4 vues
 *
 * Usage :
 *   <PillToggle
 *     value={view}
 *     onChange={setView}
 *     options={[
 *       { value: 'a', label: 'Archivés (12)' },
 *       { value: 'b', label: 'Refusés (3)' },
 *     ]}
 *   />
 *
 * Pour des items uniquement icônes :
 *   <PillToggle
 *     value={mode}
 *     onChange={setMode}
 *     options={[
 *       { value: 'scroll', icon: <ChevronDownIcon ... />, ariaLabel: 'Liste' },
 *       { value: 'diapo',  icon: <ChevronRightIcon ... />, ariaLabel: 'Diapo' },
 *     ]}
 *   />
 */

export interface PillToggleOption<T extends string> {
  value: T;
  /** Libellé visible (peut être omis si on n'utilise que `icon`). */
  label?: React.ReactNode;
  /** Icône optionnelle, affichée à gauche du label (ou seule si pas de label). */
  icon?: React.ReactNode;
  /** Aria-label si l'item n'a pas de texte (icône seule). */
  ariaLabel?: string;
}

export interface PillToggleProps<T extends string> {
  value: T;
  onChange: (next: T) => void;
  options: ReadonlyArray<PillToggleOption<T>>;
  /** "light" (défaut) = container blanc 50%, "dark" = noir 20% (pour fond clair). */
  variant?: 'light' | 'dark';
  /** Hauteur totale (px). Défaut 32. */
  size?: number;
  /** className additionnel sur le container. */
  className?: string;
  style?: React.CSSProperties;
}

export default function PillToggle<T extends string>({
  value,
  onChange,
  options,
  variant = 'light',
  size = 32,
  className,
  style,
}: PillToggleProps<T>) {
  const containerBg = variant === 'dark'
    ? 'rgba(0,0,0,0.20)'
    : 'rgba(255,255,255,0.5)';
  const inactiveColor = variant === 'dark' ? '#fff056' : 'rgba(0,0,0,0.55)';
  const itemHeight = size - 6; // 3px de padding * 2

  return (
    <div
      className={`flex items-center ${className ?? ''}`}
      style={{
        backgroundColor: containerBg,
        borderRadius: '999px',
        padding: '3px',
        gap: '2px',
        height: `${size}px`,
        ...style,
      }}
      role="tablist"
    >
      {options.map(opt => {
        const active = value === opt.value;
        const hasIcon = !!opt.icon;
        const hasLabel = opt.label !== undefined && opt.label !== null && opt.label !== '';
        return (
          <button
            key={opt.value}
            type="button"
            role="tab"
            aria-selected={active}
            aria-label={opt.ariaLabel}
            onClick={() => { if (!active) onChange(opt.value); }}
            className="flex items-center justify-center"
            style={{
              padding: hasLabel ? '0 14px' : '0',
              minWidth: hasLabel ? undefined : `${itemHeight}px`,
              height: `${itemHeight}px`,
              borderRadius: '999px',
              backgroundColor: active ? '#fff056' : 'transparent',
              color: active ? '#000' : inactiveColor,
              fontSize: '12px',
              fontWeight: 700,
              border: 'none',
              cursor: active ? 'default' : 'pointer',
              transition: 'background-color 0.15s, color 0.15s',
              whiteSpace: 'nowrap',
              gap: hasIcon && hasLabel ? '6px' : 0,
            }}
          >
            {opt.icon}
            {hasLabel && <span>{opt.label}</span>}
          </button>
        );
      })}
    </div>
  );
}
