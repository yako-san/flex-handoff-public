'use client';
import { useEffect, useState } from 'react';
import Modal from './Modal';

interface PromptDialogProps {
  open: boolean;
  title?: string;
  message?: string;
  /** Valeur initiale de l'input (ex. pour édition). */
  defaultValue?: string;
  /** Placeholder de l'input. */
  placeholder?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  /** Valide que `value.trim()` est non vide avant d'activer le bouton. Défaut true. */
  requireNonEmpty?: boolean;
  onConfirm: (value: string) => void;
  onCancel: () => void;
}

/**
 * Remplaçant des `window.prompt()` natifs — même fonctionnalité mais au
 * style design-system (Modal size="sm" + input + Annuler/Confirmer).
 * Pendant de <ConfirmDialog /> pour les prompts texte.
 */
export default function PromptDialog({
  open,
  title = 'Valeur',
  message,
  defaultValue = '',
  placeholder,
  confirmLabel = 'Confirmer',
  cancelLabel = 'Annuler',
  requireNonEmpty = true,
  onConfirm,
  onCancel,
}: PromptDialogProps) {
  const [value, setValue] = useState(defaultValue);

  // Reset la valeur à chaque ouverture (ou changement de defaultValue)
  useEffect(() => {
    if (open) setValue(defaultValue);
  }, [open, defaultValue]);

  const canSubmit = requireNonEmpty ? value.trim().length > 0 : true;

  function handleSubmit(e?: React.FormEvent) {
    e?.preventDefault();
    if (!canSubmit) return;
    onConfirm(value.trim());
  }

  return (
    <Modal open={open} onClose={onCancel} title={title} size="sm">
      <form onSubmit={handleSubmit}>
        {message && (
          <p className="text-sm" style={{ color: 'rgba(0,0,0,0.7)', marginBottom: '16px', whiteSpace: 'pre-line' }}>
            {message}
          </p>
        )}
        <input
          type="text"
          autoFocus
          value={value}
          onChange={e => setValue(e.target.value)}
          placeholder={placeholder}
          className="input-system"
          style={{ marginBottom: '24px', width: '100%' }}
        />
        <div className="flex justify-end gap-3">
          <button type="button" onClick={onCancel} className="btn-secondary">
            {cancelLabel}
          </button>
          <button type="submit" disabled={!canSubmit} className="btn-primary">
            {confirmLabel}
          </button>
        </div>
      </form>
    </Modal>
  );
}
