/**
 * LoadingSpinner — roue de vélo qui tourne, couleur jaune de l'app (#fff056).
 * Thématique atelier vélo au lieu du spinner générique Tailwind.
 *
 * Props :
 *   - className : utility Tailwind pour le conteneur (ex. "py-20")
 *   - size : diamètre en px (défaut 40)
 */
export default function LoadingSpinner({
  className = '',
  size = 40,
}: { className?: string; size?: number }) {
  // Disque noir 50% qui contient la roue — padding 20% autour
  const disc = Math.round(size * 1.5);
  return (
    <div className={`flex flex-col items-center justify-center ${className}`} style={{ gap: '10px' }}>
      <div
        className="flex items-center justify-center"
        style={{
          width: `${disc}px`,
          height: `${disc}px`,
          borderRadius: '50%',
          backgroundColor: 'rgba(0,0,0,0.5)',
        }}
      >
        <svg
          className="animate-spin"
          width={size}
          height={size}
          viewBox="0 0 48 48"
          fill="none"
          aria-label="Chargement"
          role="img"
        >
          {/* Pneu — anneau extérieur épais */}
          <circle
            cx="24"
            cy="24"
            r="21"
            stroke="#fff056"
            strokeWidth="3"
            opacity="0.9"
          />
          {/* Jante — cercle intérieur fin */}
          <circle
            cx="24"
            cy="24"
            r="18"
            stroke="#fff056"
            strokeWidth="1"
            opacity="0.5"
          />
          {/* Rayons (8) — du moyeu à la jante */}
          {Array.from({ length: 8 }, (_, i) => {
            const angle = (i * Math.PI) / 4;
            const x = 24 + Math.cos(angle) * 18;
            const y = 24 + Math.sin(angle) * 18;
            return (
              <line
                key={i}
                x1="24"
                y1="24"
                x2={x}
                y2={y}
                stroke="#fff056"
                strokeWidth="1"
                opacity="0.7"
                strokeLinecap="round"
              />
            );
          })}
          {/* Moyeu — point central */}
          <circle cx="24" cy="24" r="3" fill="#fff056" />
        </svg>
      </div>
      <span
        style={{
          color: 'rgba(255,255,255,0.7)',
          fontSize: '13px',
          fontWeight: 600,
          letterSpacing: '0.08em',
          textTransform: 'uppercase',
        }}
      >
        spinning
      </span>
    </div>
  );
}
