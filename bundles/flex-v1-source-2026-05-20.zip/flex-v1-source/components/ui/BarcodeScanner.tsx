'use client';
import { useEffect, useRef, useState } from 'react';
import { BrowserMultiFormatReader, type IScannerControls } from '@zxing/browser';
import Modal from '@/components/ui/Modal';
import HelpHint from '@/components/ui/HelpHint';
import { BoltIcon, ArrowPathRoundedSquareIcon } from '@heroicons/react/24/outline';

interface Props {
  open: boolean;
  onClose: () => void;
  /** Appelé pour chaque scan réussi. Le parent gère le match catalogue. */
  onScan: (sku: string) => void;
  /** Optionnel : message à afficher après un scan (ex. « Ajouté : LUBE-DRY-60 »). */
  lastMessage?: string;
}

/**
 * Modal scanner de code-barres via la caméra (cross-browser iOS Safari OK).
 * Utilise @zxing/browser pour décoder EAN-13, UPC, Code128, QR, etc.
 *
 * Améliorations anti-flou :
 * - Stream HD 1920×1080 (fallback 1280×720) pour plus de détail
 * - focusMode 'continuous' si la caméra le supporte → autofocus permanent
 * - zoom minimal 2× si possible → force la caméra wide à focus plus court,
 *   essentiel sur iPhone où la caméra principale a un mini-focus trop long
 *   pour lire un EAN de près
 * - Tap sur la vidéo → applyConstraints focusMode 'single-shot' pour
 *   forcer un nouveau focus si jamais l'auto est perdu
 * - Bouton torch (flash) pour les conditions basse lumière
 */
export default function BarcodeScanner({ open, onClose, onScan, lastMessage }: Props) {
  const videoRef    = useRef<HTMLVideoElement>(null);
  const controlsRef = useRef<IScannerControls | null>(null);
  const trackRef    = useRef<MediaStreamTrack | null>(null);
  const streamRef   = useRef<MediaStream | null>(null);
  const lastCodeRef = useRef<{ code: string; time: number }>({ code: '', time: 0 });
  const [error, setError]                   = useState('');
  const [torchOn, setTorchOn]               = useState(false);
  const [torchAvailable, setTorchAvailable] = useState(false);
  // Sélection caméra (iPhone 15 Pro a main / ultra-wide / telephoto)
  const [cameras, setCameras]   = useState<MediaDeviceInfo[]>([]);
  const [camIndex, setCamIndex] = useState(0);

  useEffect(() => {
    if (!open) return;

    let cancelled = false;
    setError('');
    setTorchOn(false);
    setTorchAvailable(false);
    const reader = new BrowserMultiFormatReader();

    (async () => {
      try {
        // 1. Stream HD + focus continu demandé dès l'ouverture.
        //    Si une caméra est déjà sélectionnée (cameras[camIndex] populé),
        //    on cible son deviceId. Sinon fallback facingMode environment.
        const selected = cameras[camIndex];
        const videoConstraints: MediaTrackConstraints = selected
          ? {
              deviceId: { exact: selected.deviceId },
              width   : { ideal: 1920 },
              height  : { ideal: 1080 },
              frameRate: { ideal: 30 },
            }
          : {
              facingMode: { ideal: 'environment' },
              width     : { ideal: 1920 },
              height    : { ideal: 1080 },
              frameRate : { ideal: 30 },
            };
        const stream = await navigator.mediaDevices.getUserMedia({ video: videoConstraints });
        if (cancelled) { stream.getTracks().forEach(t => t.stop()); return; }

        // Populate la liste des caméras arrière une fois la permission accordée
        if (cameras.length === 0) {
          try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            const video   = devices.filter(d => d.kind === 'videoinput');
            // Préfère les caméras arrière (heuristique sur le label) — sur
            // iPhone 15 Pro on a : Back Camera, Back Ultra Wide Camera,
            // Back Telephoto Camera. Fallback : toutes les caméras.
            const back = video.filter(d => /back|rear|environment|arrière|ultra wide|telephoto/i.test(d.label));
            if (!cancelled) setCameras(back.length ? back : video);
          } catch { /* enumerateDevices peut échouer sans permission */ }
        }

        streamRef.current = stream;
        const [track] = stream.getVideoTracks();
        trackRef.current = track;

        // 2. Advanced constraints post-acquisition : focus continuous + zoom
        const caps: any = typeof track.getCapabilities === 'function' ? track.getCapabilities() : {};
        const advanced: any[] = [];
        if (Array.isArray(caps.focusMode) && caps.focusMode.includes('continuous')) {
          advanced.push({ focusMode: 'continuous' });
        }
        // Zoom modéré (2×) si dispo — aide à lire les petits codes EAN/UPC
        // de près et évite le flou de mise au point de la caméra wide iPhone
        if (caps.zoom && typeof caps.zoom === 'object') {
          const min = caps.zoom.min ?? 1;
          const max = caps.zoom.max ?? 1;
          const target = Math.min(2, max);
          if (target > min) advanced.push({ zoom: target });
        }
        if (advanced.length) {
          try { await track.applyConstraints({ advanced } as any); } catch { /* ignore */ }
        }
        setTorchAvailable(!!caps.torch);

        if (!videoRef.current) { stream.getTracks().forEach(t => t.stop()); return; }
        videoRef.current.srcObject = stream;
        // play() est déclenché par autoPlay + le user gesture du clic qui
        // a ouvert le modal — certains Safari bougonnent quand même.
        await videoRef.current.play().catch(() => {});

        // 3. Décode depuis l'élément vidéo (undefined deviceId → utilise srcObject existant)
        controlsRef.current = await reader.decodeFromVideoDevice(
          undefined,
          videoRef.current,
          (result) => {
            if (cancelled) return;
            if (result) {
              const code = result.getText().trim();
              const now = Date.now();
              if (code && (code !== lastCodeRef.current.code || now - lastCodeRef.current.time > 1500)) {
                lastCodeRef.current = { code, time: now };
                onScan(code);
              }
            }
          },
        );
      } catch (e: any) {
        setError(e?.message || 'Accès caméra refusé');
      }
    })();

    return () => {
      cancelled = true;
      controlsRef.current?.stop();
      controlsRef.current = null;
      if (trackRef.current) {
        try { trackRef.current.stop(); } catch {}
        trackRef.current = null;
      }
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => { try { t.stop(); } catch {} });
        streamRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, camIndex]);

  /** Tap sur la vidéo → force un refocus ponctuel (utile si l'auto-focus
   *  se fige ou quand on change de distance). */
  async function handleRefocus() {
    if (!trackRef.current) return;
    try {
      const caps: any = typeof trackRef.current.getCapabilities === 'function' ? trackRef.current.getCapabilities() : {};
      const advanced: any[] = [];
      if (Array.isArray(caps.focusMode)) {
        if (caps.focusMode.includes('single-shot')) advanced.push({ focusMode: 'single-shot' });
        else if (caps.focusMode.includes('continuous')) advanced.push({ focusMode: 'continuous' });
      }
      if (advanced.length) await trackRef.current.applyConstraints({ advanced } as any);
    } catch { /* ignore */ }
  }

  async function toggleTorch() {
    if (!trackRef.current || !torchAvailable) return;
    try {
      await trackRef.current.applyConstraints({ advanced: [{ torch: !torchOn }] } as any);
      setTorchOn(!torchOn);
    } catch { /* ignore */ }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={
        <span style={{ display: 'inline-flex', alignItems: 'baseline', gap: '4px' }}>
          Scanner SKU
          <span style={{ marginLeft: '6px' }}>
            <HelpHint
              topic="10-scanner-codebarre"
              title="Scanner code-barre"
              hint={(
                <>
                  <b>EAN/UPC → pièce identifiée en 2 sec.</b>
                  <br />1. Pointer le viseur sur le code-barre
                  <br />2. Bip ✓ = pièce reconnue → ajoutée
                  <br />3. Caméra reste ouverte, enchaîne plusieurs scans
                  <br /><br />
                  <b>Code inconnu</b> : popup avec 2 choix
                  <br />• Mapper à une pièce existante (associe l'EAN)
                  <br />• Créer une nouvelle pièce (EAN pré-rempli)
                  <br /><br />
                  <i>Astuces iPhone</i> : flash bouton 🔦, pinch pour zoom,
                  mode macro auto sur iPhone 13+. L'historique des 200 derniers
                  scans est dans Paramètres → Scans.
                </>
              )}
              size={18}
            />
          </span>
        </span>
      }
    >
      {error ? (
        <div
          style={{
            padding: '20px',
            borderRadius: '12px',
            backgroundColor: 'rgba(229,57,53,0.08)',
            color: '#b71c1c',
            fontSize: '13px',
          }}
        >
          ⚠ {error}
          <div style={{ marginTop: '8px', color: 'rgba(0,0,0,0.5)', fontSize: '12px' }}>
            Vérifie la permission caméra dans les réglages du navigateur.
          </div>
        </div>
      ) : (
        <div className="flex flex-col" style={{ gap: '12px' }}>
          <div
            onClick={handleRefocus}
            style={{
              width: '100%',
              maxHeight: '60vh',
              aspectRatio: '4 / 3',
              backgroundColor: '#000',
              borderRadius: '12px',
              overflow: 'hidden',
              position: 'relative',
              cursor: 'pointer',
            }}
            title="Toucher pour refocaliser"
          >
            <video
              ref={videoRef}
              playsInline
              muted
              autoPlay
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
            {/* Réticule visuel au centre */}
            <div
              style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                width: '70%',
                height: '120px',
                border: '3px solid rgba(255,240,86,0.9)',
                borderRadius: '16px',
                pointerEvents: 'none',
                boxShadow: '0 0 0 9999px rgba(0,0,0,0.25)',
              }}
            />
            {/* Bouton torch (bas-droit) si dispo */}
            {torchAvailable && (
              <button
                type="button"
                onClick={(e) => { e.stopPropagation(); toggleTorch(); }}
                title={torchOn ? 'Éteindre le flash' : 'Allumer le flash'}
                className="flex items-center justify-center transition-colors"
                style={{
                  position: 'absolute',
                  bottom: '12px',
                  right: '12px',
                  width: '44px',
                  height: '44px',
                  borderRadius: '50%',
                  backgroundColor: torchOn ? '#fff056' : 'rgba(0,0,0,0.5)',
                  color: torchOn ? '#000' : '#fff056',
                  border: 'none',
                  cursor: 'pointer',
                  padding: 0,
                }}
              >
                <BoltIcon style={{ width: '22px', height: '22px' }} />
              </button>
            )}
            {/* Bouton switch caméra (bas-gauche) si ≥ 2 caméras arrière
                disponibles. Sur iPhone 15 Pro : cycle main/ultra-wide/
                telephoto. Ultra-wide = focus macro 2 cm, idéal codes près. */}
            {cameras.length >= 2 && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setCamIndex(i => (i + 1) % cameras.length);
                }}
                title={`Caméra ${camIndex + 1}/${cameras.length} — ${cameras[camIndex]?.label || 'switch'}`}
                className="flex items-center justify-center transition-colors"
                style={{
                  position: 'absolute',
                  bottom: '12px',
                  left: '12px',
                  width: '44px',
                  height: '44px',
                  borderRadius: '50%',
                  backgroundColor: 'rgba(0,0,0,0.5)',
                  color: '#fff056',
                  border: 'none',
                  cursor: 'pointer',
                  padding: 0,
                }}
              >
                <ArrowPathRoundedSquareIcon style={{ width: '22px', height: '22px' }} />
              </button>
            )}
          </div>
          {lastMessage && (
            <div
              style={{
                padding: '10px 14px',
                borderRadius: '10px',
                backgroundColor: 'rgba(136,250,78,0.20)',
                color: '#2e7d32',
                fontSize: '13px',
                fontWeight: 600,
              }}
            >
              {lastMessage}
            </div>
          )}
          <p style={{ fontSize: '12px', color: 'rgba(0,0,0,0.5)', textAlign: 'center', marginBottom: 0 }}>
            Cadre le code dans le rectangle jaune. Touche l'image si c'est flou pour refaire la mise au point.
          </p>
        </div>
      )}
    </Modal>
  );
}
