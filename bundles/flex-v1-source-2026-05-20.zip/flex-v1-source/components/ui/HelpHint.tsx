'use client';
import React, { useState, useRef, useEffect, useLayoutEffect } from 'react';
import { createPortal } from 'react-dom';
import Link from 'next/link';
import { QuestionMarkCircleIcon, ArrowTopRightOnSquareIcon } from '@heroicons/react/24/solid';

/**
 * Si `hint` est un simple string, on découpe sur les points (". ") et on
 * affiche chaque phrase sur une ligne séparée pour faciliter la lecture
 * dans le popover (demandé par yako). Les hints JSX sont laissés tels
 * quels — l'auteur gère sa propre mise en page.
 */
function renderHint(hint: React.ReactNode): React.ReactNode {
  if (typeof hint !== 'string') return hint;
  const parts = hint.split(/(?<=\.)\s+/).filter(s => s.length > 0);
  return parts.map((s, i) => (
    <React.Fragment key={i}>
      {s}
      {i < parts.length - 1 && <br />}
    </React.Fragment>
  ));
}

/**
 * Petite icône (?) cliquable affichée à côté d'un mot/titre.
 * - Couleur par défaut : noir 50% (rgba(0,0,0,0.5))
 * - Aligné en haut du mot (vertical-align: top + offset)
 * - Popover rendu via portal sur document.body pour ne PAS être clippé
 *   par overflow:hidden des conteneurs parents.
 *
 * Usage :
 *   <HelpHint topic="05-workflow-bdt" hint="Coche la case quand le client dépose le vélo." />
 */

interface HelpHintProps {
  /** Slug du tutoriel ciblé (ex. "05-workflow-bdt"). */
  topic: string;
  /** 1-2 phrases (ou JSX) affichées dans la bulle. */
  hint: React.ReactNode;
  /** Titre court de la bulle. */
  title?: string;
  /** Taille de l'icône (px). */
  size?: number;
  /** Couleur de l'icône. Défaut : noir 50%. */
  color?: string;
  /** Style visuel : 'plain' = juste l'icône, 'outlined' = cercle outline
   *  jaune autour (utilisé pour les (?) sur titres de pages, cohérent
   *  avec les boutons sync/util du design system). */
  variant?: 'plain' | 'outlined';
}

export default function HelpHint({
  topic,
  hint,
  title = 'Astuce',
  size = 16,
  color,
  variant = 'plain',
}: HelpHintProps) {
  // 'plain' : icône noir 50% (inline labels, modals)
  // 'outlined' : icône JAUNE seule, plus grande, sans cercle (titres pages)
  const iconColor = color ?? (variant === 'outlined' ? '#fff056' : 'rgba(0,0,0,0.5)');
  const [open, setOpen] = useState(false);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const popoverRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);

  // Calcule la position du popover sous le bouton, en coordonnées viewport
  // (position: fixed dans le portal). Re-mesure sur scroll/resize.
  useLayoutEffect(() => {
    if (!open || !triggerRef.current) return;
    const recalc = () => {
      const rect = triggerRef.current!.getBoundingClientRect();
      const popoverWidth = 260;
      const screenW = window.innerWidth;
      // Centre par défaut, recadre si déborde
      let left = rect.left + rect.width / 2 - popoverWidth / 2;
      const margin = 8;
      if (left < margin) left = margin;
      if (left + popoverWidth > screenW - margin) left = screenW - popoverWidth - margin;
      setPos({ top: rect.bottom + 8, left });
    };
    recalc();
    window.addEventListener('scroll', recalc, true);
    window.addEventListener('resize', recalc);
    return () => {
      window.removeEventListener('scroll', recalc, true);
      window.removeEventListener('resize', recalc);
    };
  }, [open]);

  // Fermeture sur clic extérieur ou Escape
  useEffect(() => {
    if (!open) return;
    const onDocClick = (e: MouseEvent) => {
      const target = e.target as Node;
      if (triggerRef.current?.contains(target)) return;
      if (popoverRef.current?.contains(target)) return;
      setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDocClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDocClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  // SSR-safe : on ne rend le portal que côté client.
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        onClick={(e) => { e.preventDefault(); e.stopPropagation(); setOpen(o => !o); }}
        aria-label={`Aide : ${title}`}
        title={`Aide : ${title}`}
        style={{
          // 'outlined' = icône jaune un peu plus grande (28px) sans
          // outline ni cercle. 'plain' = icône à la `size` demandée.
          width: variant === 'outlined' ? '28px' : size,
          height: variant === 'outlined' ? '28px' : size,
          padding: 0,
          border: 'none',
          borderRadius: 0,
          background: 'transparent',
          color: iconColor,
          cursor: 'pointer',
          // Aligné en HAUT du mot/titre adjacent.
          verticalAlign: 'top',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          opacity: variant === 'outlined' ? 1 : 0.85,
          transition: 'opacity 0.15s, transform 0.15s',
        }}
        onMouseEnter={e => { e.currentTarget.style.opacity = '1'; e.currentTarget.style.transform = 'scale(1.05)'; }}
        onMouseLeave={e => {
          e.currentTarget.style.opacity = variant === 'outlined' ? '1' : '0.85';
          e.currentTarget.style.transform = 'scale(1)';
        }}
      >
        <QuestionMarkCircleIcon
          style={{
            width:  variant === 'outlined' ? '28px' : size,
            height: variant === 'outlined' ? '28px' : size,
          }}
        />
      </button>

      {mounted && open && pos && createPortal(
        <div
          ref={popoverRef}
          style={{
            position: 'fixed',
            top: pos.top,
            left: pos.left,
            zIndex: 9999,
            backgroundColor: '#fff',
            color: 'rgba(0,0,0,0.85)',
            borderRadius: '14px',
            padding: '14px 16px',
            boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
            width: '260px',
            fontSize: '13px',
            lineHeight: 1.45,
            textAlign: 'left',
            fontWeight: 400,
            // Empêche l'héritage de text-transform/letter-spacing depuis
            // les h2/h4 du design system globaux.
            textTransform: 'none',
            letterSpacing: 'normal',
            fontStyle: 'normal',
          }}
          role="tooltip"
          onClick={e => e.stopPropagation()}
        >
          <div style={{ fontWeight: 700, marginBottom: '6px', fontSize: '13px', color: 'rgba(0,0,0,0.85)' }}>
            {title}
          </div>
          <div style={{ marginBottom: '10px', color: 'rgba(0,0,0,0.7)' }}>
            {renderHint(hint)}
          </div>
          <Link
            href={`/aide/${topic}`}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '5px',
              fontSize: '12px',
              color: '#0066cc',
              textDecoration: 'none',
              fontWeight: 600,
            }}
            onClick={() => setOpen(false)}
          >
            Tutoriel complet
            <ArrowTopRightOnSquareIcon style={{ width: 12, height: 12 }} />
          </Link>
        </div>,
        document.body
      )}
    </>
  );
}
