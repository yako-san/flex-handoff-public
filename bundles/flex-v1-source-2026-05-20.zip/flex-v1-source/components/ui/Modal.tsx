'use client';
import { Dialog, DialogPanel, DialogTitle, Transition, TransitionChild } from '@headlessui/react';
import { Fragment } from 'react';
import { XMarkIcon } from '@heroicons/react/24/outline';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  /** Titre du modal. Accepte string OU JSX (ex: titre + <HelpHint/>). */
  title?: React.ReactNode;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  /** Force le panneau à la hauteur max disponible (pour popups longues listes) */
  fullHeight?: boolean;
  /** Override max-width (ex: "924px") — outrepasse `size` si fourni */
  maxWidth?: string;
  /** Bouton(s) custom affichés à gauche du X de fermeture dans l'en-tête. */
  headerAction?: React.ReactNode;
}

const sizeClass = { sm: 'max-w-sm', md: 'max-w-md', lg: 'max-w-2xl', xl: 'max-w-5xl' };

export default function Modal({ open, onClose, title, children, size = 'md', fullHeight = false, maxWidth, headerAction }: ModalProps) {
  return (
    <Transition appear show={open} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={onClose}>
        <TransitionChild as={Fragment}
          enter="ease-out duration-150" enterFrom="opacity-0" enterTo="opacity-100"
          leave="ease-in duration-100" leaveFrom="opacity-100" leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black/40" />
        </TransitionChild>

        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4">
            <TransitionChild as={Fragment}
              enter="ease-out duration-150" enterFrom="opacity-0 scale-95" enterTo="opacity-100 scale-100"
              leave="ease-in duration-100" leaveFrom="opacity-100 scale-100" leaveTo="opacity-0 scale-95"
            >
              <DialogPanel
                className={`relative w-full ${maxWidth ? '' : sizeClass[size]} bg-white overflow-hidden flex flex-col`}
                style={{
                  borderRadius: '24px',
                  boxShadow: '0 20px 60px rgba(0,0,0,0.35)',
                  maxHeight: 'calc(100vh - 40px)',
                  ...(maxWidth ? { maxWidth } : {}),
                  ...(fullHeight ? { height: 'calc(100vh - 40px)' } : {}),
                }}
              >
                {/* Bouton X de fermeture — toujours en haut à droite pad 10/10.
                    Sert aussi de bouton Annuler global (les modals internes
                    n'ont plus besoin d'un bouton « Annuler » dédié). */}
                <button
                  onClick={onClose}
                  className="absolute z-10 transition-colors"
                  style={{ top: 10, right: 10, padding: 10, color: 'rgba(0,0,0,0.4)' }}
                  onMouseEnter={e => (e.currentTarget.style.color = 'rgba(0,0,0,0.8)')}
                  onMouseLeave={e => (e.currentTarget.style.color = 'rgba(0,0,0,0.4)')}
                  aria-label="Fermer"
                >
                  <XMarkIcon className="h-5 w-5" />
                </button>
                {title && (
                  <div className="flex items-center justify-between shrink-0 px-4 pt-4 pb-2 sm:px-14 sm:pt-10 sm:pb-6">
                    <DialogTitle
                      as="div"
                      className="text-xl sm:text-3xl pr-10"
                      style={{
                        padding: 0,
                        margin: 0,
                        fontWeight: 400,
                        textTransform: 'none',
                        color: 'rgba(0,0,0,0.85)',
                      }}
                    >{title}</DialogTitle>
                    {headerAction && (
                      <div className="flex items-center mr-10" style={{ gap: '8px' }}>
                        {headerAction}
                      </div>
                    )}
                  </div>
                )}
                <div
                  className={`${fullHeight ? 'flex-1 overflow-hidden flex flex-col' : 'flex-1 overflow-y-auto overflow-x-hidden'} px-4 pt-2 pb-4 sm:px-14 sm:pt-4 sm:pb-12`}
                >
                  {children}
                </div>
              </DialogPanel>
            </TransitionChild>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
}
