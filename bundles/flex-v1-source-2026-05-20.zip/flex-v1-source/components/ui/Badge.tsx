import { type CSSProperties } from 'react';

interface BadgeProps {
  label: string;
  style?: CSSProperties;
  className?: string;
}

export default function Badge({ label, style, className = '' }: BadgeProps) {
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${className}`}
      style={style}
    >
      {label}
    </span>
  );
}
