'use client';
import { useState, useMemo, useRef, useEffect } from 'react';

/** Parse la catégorie (peut contenir plusieurs valeurs séparées par virgule) */
function parseCats(raw: string): string[] {
  return raw ? raw.split(',').map(s => s.trim()).filter(Boolean) : [];
}

/** Dropdown multi-select pour catégories */
export default function MultiSelectCat({
  value, options, disabled, onSave,
}: {
  value: string; options: string[]; disabled: boolean;
  onSave: (val: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const selected = useMemo(() => new Set(parseCats(value)), [value]);

  useEffect(() => {
    if (!open) return;
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [open]);

  function toggle(cat: string) {
    const next = new Set(selected);
    next.has(cat) ? next.delete(cat) : next.add(cat);
    onSave([...next].join(', '));
  }

  const display = selected.size > 0 ? [...selected].join(', ') : '—';

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => !disabled && setOpen(o => !o)}
        disabled={disabled}
        className="w-full text-left text-xs border rounded px-1 py-0.5 bg-white focus:outline-none focus:ring-1 focus:ring-yellow-400 text-gray-600 truncate"
        title={display}
      >
        {display}
      </button>
      {open && (
        <div className="absolute z-50 mt-1 left-0 w-56 max-h-48 overflow-y-auto bg-white border rounded-lg shadow-lg py-1">
          {options.map(cat => (
            <label key={cat} className="flex items-center gap-2 px-2 py-1 hover:bg-yellow-50 cursor-pointer text-xs">
              <input
                type="checkbox"
                checked={selected.has(cat)}
                onChange={() => toggle(cat)}
                className="h-3.5 w-3.5 rounded"
              />
              {cat}
            </label>
          ))}
        </div>
      )}
    </div>
  );
}
