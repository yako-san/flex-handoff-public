'use client';
import { useEffect, useState } from 'react';
import Modal from './Modal';
import { getScanLog, clearScanLog, scanLogToCsv, type ScanLogEntry } from '@/lib/utils/scanLog';
import { ArrowDownTrayIcon, TrashIcon } from '@heroicons/react/24/outline';

interface Props {
  open: boolean;
  onClose: () => void;
}

const ACTION_LABEL: Record<ScanLogEntry['action'], { label: string; color: string }> = {
  'matched-barcode'   : { label: 'Match EAN',      color: '#22c55e' },
  'matched-sku'       : { label: 'Match SKU',      color: '#3b82f6' },
  'mapped-existing'   : { label: 'Associé',        color: '#fff056' },
  'created-new'       : { label: 'Pièce créée',    color: '#a855f7' },
  'unknown-cancelled' : { label: 'Annulé',         color: 'rgba(0,0,0,0.3)' },
  'unknown'           : { label: 'Inconnu',        color: '#ef4444' },
};

/**
 * ScanLogModal — affiche les 200 derniers scans locaux (localStorage) pour
 * diagnostic / rattrapage manuel. Chaque ligne indique le timestamp, le
 * code scanné, l'action appliquée, et la pièce associée le cas échéant.
 *
 * Boutons : Exporter CSV (pour backup) + Effacer tout le log.
 */
export default function ScanLogModal({ open, onClose }: Props) {
  const [entries, setEntries] = useState<ScanLogEntry[]>([]);

  useEffect(() => {
    if (open) setEntries(getScanLog());
  }, [open]);

  function handleExport() {
    const csv  = scanLogToCsv();
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `scan-log-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  function handleClear() {
    if (!window.confirm('Effacer tout le log des scans ? Cette action est irréversible.')) return;
    clearScanLog();
    setEntries([]);
  }

  return (
    <Modal open={open} onClose={onClose} title={`Historique scans (${entries.length})`} size="lg">
      <div className="flex flex-col" style={{ gap: '12px' }}>
        <div className="flex items-center justify-between" style={{ gap: '10px' }}>
          <p style={{ fontSize: '12px', color: 'rgba(0,0,0,0.55)', margin: 0 }}>
            Log local (localStorage) des 200 derniers scans — pour rattrapage si
            une synchro sheet échoue.
          </p>
          <div className="flex items-center shrink-0" style={{ gap: '8px' }}>
            <button
              type="button"
              onClick={handleExport}
              disabled={!entries.length}
              title="Exporter en CSV"
              className="flex items-center gap-1 disabled:opacity-40"
              style={{
                padding: '6px 12px',
                borderRadius: '999px',
                backgroundColor: 'rgba(0,0,0,0.08)',
                color: 'rgba(0,0,0,0.7)',
                border: 'none',
                fontSize: '12px',
                fontWeight: 700,
                cursor: entries.length ? 'pointer' : 'not-allowed',
              }}
            >
              <ArrowDownTrayIcon style={{ width: '14px', height: '14px' }} />
              CSV
            </button>
            <button
              type="button"
              onClick={handleClear}
              disabled={!entries.length}
              title="Effacer le log"
              className="flex items-center gap-1 disabled:opacity-40"
              style={{
                padding: '6px 12px',
                borderRadius: '999px',
                backgroundColor: 'rgba(239,68,68,0.12)',
                color: '#b91c1c',
                border: 'none',
                fontSize: '12px',
                fontWeight: 700,
                cursor: entries.length ? 'pointer' : 'not-allowed',
              }}
            >
              <TrashIcon style={{ width: '14px', height: '14px' }} />
              Effacer
            </button>
          </div>
        </div>

        {entries.length === 0 ? (
          <p className="text-center py-6" style={{ color: 'rgba(0,0,0,0.4)', fontSize: '13px' }}>
            Aucun scan enregistré pour l'instant.
          </p>
        ) : (
          <div
            className="overflow-y-auto"
            style={{
              maxHeight: '420px',
              border: '1.5px solid rgba(0,0,0,0.15)',
              borderRadius: '12px',
            }}
          >
            {entries.map((e, i) => {
              const meta = ACTION_LABEL[e.action] ?? ACTION_LABEL['unknown'];
              const time = new Date(e.timestamp).toLocaleString('fr-CA', { hour12: false });
              return (
                <div
                  key={i}
                  className="flex items-start gap-3"
                  style={{
                    padding: '8px 14px',
                    borderBottom: '1px solid rgba(0,0,0,0.06)',
                    backgroundColor: i % 2 === 0 ? 'rgba(0,0,0,0.02)' : 'transparent',
                  }}
                >
                  <div className="shrink-0" style={{ fontSize: '11px', color: 'rgba(0,0,0,0.45)', minWidth: '130px' }}>
                    {time}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div style={{ fontFamily: 'monospace', fontSize: '13px', color: 'rgba(0,0,0,0.85)', wordBreak: 'break-all' }}>
                      {e.code}
                    </div>
                    {e.pieceName && (
                      <div style={{ fontSize: '12px', color: 'rgba(0,0,0,0.6)', marginTop: '2px' }}>
                        → {e.pieceName}{e.pieceId ? ` (${e.pieceId})` : ''}
                      </div>
                    )}
                    {e.note && (
                      <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.45)', fontStyle: 'italic', marginTop: '2px' }}>
                        {e.note}
                      </div>
                    )}
                  </div>
                  <span
                    className="shrink-0 inline-flex items-center whitespace-nowrap"
                    style={{
                      padding: '2px 8px',
                      borderRadius: '999px',
                      backgroundColor: meta.color,
                      color: meta.color === '#fff056' ? '#000' : '#fff',
                      fontSize: '10px',
                      fontWeight: 700,
                      letterSpacing: '0.04em',
                      textTransform: 'uppercase',
                    }}
                  >
                    {meta.label}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </Modal>
  );
}
