'use client';
import { useEffect, useState } from 'react';
import Modal from '@/components/ui/Modal';
import { toast } from '@/components/ui/Toast';
import { DEPENSE_CATEGORIES, DEPENSE_CATEGORIE_HINTS, CATEGORIE_DEDUCTIBLE_PCT, deductibleFactor } from '@/lib/depenses-categories';
import type { Depense, DepenseInput, ModePaiementDepense } from '@/types/depense';

interface Props {
  open    : boolean;
  onClose : () => void;
  /** Si fourni, mode édition. Sinon création. */
  depense?: Depense | null;
  onSave  : (input: DepenseInput) => Promise<void>;
  /** v1.0.29+ : top fournisseurs par fréquence — alimentent le datalist
   *  autocomplete pour saisie rapide (Babac, Uber, etc.). */
  suggestedFournisseurs?: string[];
}

const TAUX_TPS = 0.05;
const TAUX_TVQ = 0.09975;
const round2   = (n: number) => Math.round(n * 100) / 100;

/** Parse une saisie numérique acceptant virgule décimale (français). */
function parseDecimal(v: string): number {
  return parseFloat(v.replace(/\s/g, '').replace(',', '.')) || 0;
}

/** Formatte un nombre en chaîne fr-CA (virgule décimale). */
function fmtNum(n: number): string {
  return Number.isFinite(n) && n !== 0 ? String(n).replace('.', ',') : '';
}

export default function DepenseFormModal({ open, onClose, depense, onSave, suggestedFournisseurs = [] }: Props) {
  const isEdit = !!depense;

  const [date,         setDate]         = useState('');
  const [fournisseur,  setFournisseur]  = useState('');
  const [categorie,    setCategorie]    = useState<string>(DEPENSE_CATEGORIES[0]);
  const [description,  setDescription]  = useState('');
  const [htStr,        setHtStr]        = useState('');
  const [tpsStr,       setTpsStr]       = useState('');
  const [tvqStr,       setTvqStr]       = useState('');
  const [modePaiement, setModePaiement] = useState<ModePaiementDepense>('cartes');
  const [recuUrl,      setRecuUrl]      = useState('');
  const [notes,        setNotes]        = useState('');
  // v1.0.30+ : champs fiscaux additionnels
  const [numeroEntreprise, setNumeroEntreprise] = useState('');
  const [usagePctStr,      setUsagePctStr]      = useState('');  // vide = 100 %
  const [saving,       setSaving]       = useState(false);

  // Reset à chaque ouverture
  useEffect(() => {
    if (!open) return;
    if (depense) {
      setDate(depense.date);
      setFournisseur(depense.fournisseur);
      setCategorie(depense.categorie || DEPENSE_CATEGORIES[0]);
      setDescription(depense.description);
      setHtStr(fmtNum(depense.sousTotalHT));
      setTpsStr(fmtNum(depense.tps));
      setTvqStr(fmtNum(depense.tvq));
      setModePaiement(depense.modePaiement);
      setRecuUrl(depense.recuUrl ?? '');
      setNotes(depense.notes ?? '');
      setNumeroEntreprise(depense.numeroEntreprise ?? '');
      setUsagePctStr(depense.usagePct !== undefined && depense.usagePct !== 100 ? String(depense.usagePct) : '');
    } else {
      const today = new Date().toISOString().slice(0, 10);
      setDate(today);
      setFournisseur('');
      setCategorie(DEPENSE_CATEGORIES[0]);
      setDescription('');
      setHtStr('');
      setTpsStr('');
      setTvqStr('');
      setModePaiement('cartes');
      setRecuUrl('');
      setNotes('');
      setNumeroEntreprise('');
      setUsagePctStr('');
    }
  }, [open, depense]);

  // Calculs en direct
  const ht       = parseDecimal(htStr);
  const tps      = parseDecimal(tpsStr);
  const tvq      = parseDecimal(tvqStr);
  const totalTTC = round2(ht + tps + tvq);

  // Warning : taxes hors fourchette ~14,975 % du HT (cas TVH possible)
  const taxesExpected = round2(ht * (TAUX_TPS + TAUX_TVQ));
  const taxesActual   = round2(tps + tvq);
  const taxesDeviates = ht > 0 && Math.abs(taxesActual - taxesExpected) > 0.05;

  /** Auto-calcul TPS+TVQ depuis HT à la perte de focus du champ HT. */
  function autoFillTaxes() {
    if (ht <= 0) return;
    // Seulement si TPS et TVQ sont vides — ne pas écraser une saisie manuelle
    if (!tpsStr) setTpsStr(fmtNum(round2(ht * TAUX_TPS)));
    if (!tvqStr) setTvqStr(fmtNum(round2(ht * TAUX_TVQ)));
  }

  async function handleSave() {
    if (!date || !fournisseur || !categorie) {
      toast('Date, fournisseur et catégorie requis', 'error');
      return;
    }
    if (ht < 0 || tps < 0 || tvq < 0) {
      toast('Montants doivent être ≥ 0', 'error');
      return;
    }
    // v1.0.28+ : safety net — si HT > 0 et TPS/TVQ vides au moment du save
    // (user a oublié de tab-out du champ HT), auto-fill avant submit.
    // Évite les dépenses sauvegardées avec taxes à 0 par inattention.
    const finalTps = (!tpsStr && ht > 0) ? round2(ht * TAUX_TPS) : tps;
    const finalTvq = (!tvqStr && ht > 0) ? round2(ht * TAUX_TVQ) : tvq;
    // v1.0.30+ : parsing usagePct + validation borne
    let parsedUsage: number | undefined;
    if (usagePctStr.trim()) {
      const p = parseDecimal(usagePctStr);
      if (p <= 0 || p > 100) {
        toast('Usage % doit être entre 1 et 100', 'error');
        return;
      }
      // usagePct stocké seulement si différent de 100 (100 = default)
      if (p !== 100) parsedUsage = p;
    }
    setSaving(true);
    try {
      await onSave({
        date,
        fournisseur      : fournisseur.trim(),
        categorie,
        description      : description.trim(),
        sousTotalHT      : ht,
        tps              : finalTps,
        tvq              : finalTvq,
        modePaiement,
        recuUrl          : recuUrl.trim() || undefined,
        notes            : notes.trim() || undefined,
        numeroEntreprise : numeroEntreprise.trim() || undefined,
        usagePct         : parsedUsage,
      });
      toast(isEdit ? 'Dépense mise à jour' : `Dépense créée — ${totalTTC.toFixed(2)} $`, 'success');
      onClose();
    } catch (err: any) {
      toast(err?.message ?? 'Erreur', 'error');
    } finally {
      setSaving(false);
    }
  }

  const hint = DEPENSE_CATEGORIE_HINTS[categorie];

  return (
    <Modal open={open} onClose={onClose} title={isEdit ? `Modifier dépense ${depense?.id}` : 'Nouvelle dépense'} size="md">
      <div className="flex flex-col" style={{ gap: '14px' }}>

        {/* Date + fournisseur */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label-system">date</label>
            <input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              disabled={saving}
              className="input-system"
            />
          </div>
          <div>
            <label className="label-system">fournisseur</label>
            <input
              type="text"
              value={fournisseur}
              onChange={e => setFournisseur(e.target.value)}
              disabled={saving}
              placeholder="Babac, Uber, Costco…"
              className="input-system"
              list="depense-fournisseurs"
              autoComplete="off"
            />
            {/* v1.0.29+ : autocomplete depuis top 10 fournisseurs récents.
                Le user voit la liste au focus + filtre en tapant. Permet
                aussi tout nouveau nom (champ libre). */}
            {suggestedFournisseurs.length > 0 && (
              <datalist id="depense-fournisseurs">
                {suggestedFournisseurs.map(f => <option key={f} value={f} />)}
              </datalist>
            )}
          </div>
        </div>

        {/* v1.0.30+ : NE fournisseur (obligatoire au-delà de 30 $ HT pour
            réclamer CTI/CTP sans risque audit RQ). Champ optionnel sinon. */}
        <div>
          <label className="label-system">
            NE fournisseur (numéro d'entreprise / TPS / GST)
            {ht > 30 && <span style={{ color: '#dc2626', marginLeft: '6px' }} title="Obligatoire au-delà de 30 $ HT">⚠ requis</span>}
          </label>
          <input
            type="text"
            value={numeroEntreprise}
            onChange={e => setNumeroEntreprise(e.target.value)}
            disabled={saving}
            placeholder="ex. 123456789 RT0001"
            className="input-system"
          />
          <p style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)', marginTop: '4px', fontStyle: 'italic' }}>
            Tel qu'inscrit sur le reçu. Format libre.
          </p>
        </div>

        {/* Catégorie */}
        <div>
          <label className="label-system">catégorie</label>
          <select
            value={categorie}
            onChange={e => setCategorie(e.target.value)}
            disabled={saving}
            className="input-system"
          >
            {DEPENSE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          {hint && (
            <p style={{ fontSize: '11px', color: 'rgba(0,0,0,0.55)', marginTop: '4px', fontStyle: 'italic' }}>
              ⓘ {hint}
            </p>
          )}
        </div>

        {/* Description */}
        <div>
          <label className="label-system">description</label>
          <input
            type="text"
            value={description}
            onChange={e => setDescription(e.target.value)}
            disabled={saving}
            placeholder="« café meeting client », « pneus Canadian Tire », …"
            className="input-system"
          />
        </div>

        {/* HT / TPS / TVQ + Total */}
        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="label-system">sous-total HT</label>
            <input
              type="text"
              inputMode="decimal"
              value={htStr}
              onChange={e => setHtStr(e.target.value.replace(/[^\d.,]/g, ''))}
              onBlur={autoFillTaxes}
              disabled={saving}
              placeholder="0,00"
              className="input-system"
            />
          </div>
          <div>
            <label className="label-system">tps (5 %)</label>
            <input
              type="text"
              inputMode="decimal"
              value={tpsStr}
              onChange={e => setTpsStr(e.target.value.replace(/[^\d.,]/g, ''))}
              disabled={saving}
              placeholder="0,00"
              className="input-system"
            />
          </div>
          <div>
            <label className="label-system">tvq (9,975 %)</label>
            <input
              type="text"
              inputMode="decimal"
              value={tvqStr}
              onChange={e => setTvqStr(e.target.value.replace(/[^\d.,]/g, ''))}
              disabled={saving}
              placeholder="0,00"
              className="input-system"
            />
          </div>
        </div>

        {taxesDeviates && (
          <p style={{ fontSize: '12px', color: '#b45309', backgroundColor: '#fef3c7', padding: '8px 12px', borderRadius: '8px' }}>
            ⚠ Les taxes ne matchent pas les taux QC standard (~{taxesExpected.toFixed(2)} $ attendu). Reçu TVH ou hors-province ? OK si voulu.
          </p>
        )}

        {/* Total TTC affiché — payé brut */}
        <div style={{
          backgroundColor: 'rgba(0,0,0,0.05)',
          padding: '10px 14px',
          borderRadius: '12px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
          <span style={{ fontSize: '14px', color: 'rgba(0,0,0,0.6)', fontWeight: 600 }}>Total TTC</span>
          <span style={{ fontSize: '22px', fontWeight: 700, color: 'rgba(0,0,0,0.85)' }}>
            {totalTTC.toFixed(2).replace('.', ',')} $
          </span>
        </div>

        {/* v1.0.30+ : champ usagePct + calcul déductible effectif. Affiché
            seulement si pertinent (catégorie ≠ 100% OU usagePct < 100). */}
        {(() => {
          const catPct = CATEGORIE_DEDUCTIBLE_PCT[categorie] ?? 100;
          const usePct = usagePctStr ? parseDecimal(usagePctStr) : 100;
          const factor = deductibleFactor(categorie, usePct);
          const showDeductible = factor < 1 || catPct < 100;
          return (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <div>
                <label className="label-system">
                  usage business (%) — optionnel
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={usagePctStr}
                  onChange={e => setUsagePctStr(e.target.value.replace(/[^\d.,]/g, ''))}
                  disabled={saving}
                  placeholder="100"
                  className="input-system"
                  style={{ maxWidth: '120px' }}
                />
                <p style={{ fontSize: '11px', color: 'rgba(0,0,0,0.5)', marginTop: '4px', fontStyle: 'italic' }}>
                  Pour dépenses mixtes perso/business (téléphone, internet, loyer résidentiel, transport).
                  Vide = 100 %.
                </p>
              </div>

              {showDeductible && ht > 0 && (() => {
                // Effectifs avec safety net auto-fill (cohérent avec handleSave)
                const effTps = (!tpsStr && ht > 0) ? round2(ht * TAUX_TPS) : tps;
                const effTvq = (!tvqStr && ht > 0) ? round2(ht * TAUX_TVQ) : tvq;
                return (
                  <div style={{
                    backgroundColor: 'rgba(34,197,94,0.08)',
                    border: '1px solid rgba(34,197,94,0.25)',
                    padding: '10px 14px',
                    borderRadius: '12px',
                    fontSize: '12px',
                    color: 'rgba(0,0,0,0.75)',
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span>HT déductible ({(factor * 100).toFixed(0)} %)</span>
                      <strong>{(ht * factor).toFixed(2).replace('.', ',')} $</strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                      <span>CTI récupérable (TPS)</span>
                      <strong>{(effTps * factor).toFixed(2).replace('.', ',')} $</strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span>CTP récupérable (TVQ)</span>
                      <strong>{(effTvq * factor).toFixed(2).replace('.', ',')} $</strong>
                    </div>
                    {catPct < 100 && (
                      <p style={{ fontSize: '11px', marginTop: '6px', fontStyle: 'italic', color: 'rgba(0,0,0,0.55)' }}>
                        ⓘ Catégorie « {categorie} » : {catPct} % déductible (LTA art. 67.1).
                      </p>
                    )}
                  </div>
                );
              })()}
            </div>
          );
        })()}

        {/* Mode de paiement */}
        <div>
          <label className="label-system">mode de paiement</label>
          <div className="flex flex-wrap" style={{ gap: '6px' }}>
            {([
              { value: 'comptant', label: 'Comptant' },
              { value: 'interac',  label: 'Interac' },
              { value: 'cartes',   label: 'Carte' },
              { value: 'virement', label: 'Virement' },
            ] as const).map(opt => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setModePaiement(opt.value)}
                disabled={saving}
                className="flex items-center justify-center whitespace-nowrap"
                style={{
                  height: '32px',
                  padding: '0 14px',
                  borderRadius: '32px',
                  fontSize: '13px',
                  fontWeight: 700,
                  border: 'none',
                  cursor: saving ? 'not-allowed' : 'pointer',
                  backgroundColor: modePaiement === opt.value ? '#fff056' : 'rgba(0,0,0,0.08)',
                  color: modePaiement === opt.value ? '#000' : 'rgba(0,0,0,0.5)',
                }}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Reçu URL */}
        <div>
          <label className="label-system">URL du reçu (optionnel)</label>
          <input
            type="url"
            value={recuUrl}
            onChange={e => setRecuUrl(e.target.value)}
            disabled={saving}
            placeholder="https://drive.google.com/… ou autre"
            className="input-system"
          />
        </div>

        {/* Notes */}
        <div>
          <label className="label-system">notes (optionnel)</label>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            disabled={saving}
            className="input-system"
            rows={2}
            placeholder="Détail interne…"
            style={{ resize: 'vertical', minHeight: '60px' }}
          />
        </div>

        {/* Actions */}
        <div className="flex justify-end" style={{ gap: '10px', paddingTop: '6px' }}>
          <button type="button" onClick={onClose} disabled={saving} className="btn-secondary">
            Annuler
          </button>
          <button type="button" onClick={handleSave} disabled={saving} className="btn-primary">
            {saving ? 'Sauvegarde…' : (isEdit ? 'Mettre à jour' : 'Créer')}
          </button>
        </div>
      </div>
    </Modal>
  );
}
