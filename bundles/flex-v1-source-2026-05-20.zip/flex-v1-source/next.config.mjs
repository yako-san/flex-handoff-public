/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverComponentsExternalPackages: [
      "googleapis",
      "google-auth-library",
      "node-cache",
      "@sparticuz/chromium",
      "puppeteer-core",
    ],
  },
};

export default nextConfig;
