'use client';
import { useMemo } from 'react';
import { useEmailTemplates } from './useEmailTemplates';
import { VELO_TAILLES } from '@/lib/config';

/**
 * Tailles de vélo — lit depuis le sheet _EMAIL_TEMPLATES_ (clé velo_tailles,
 * JSON array). Fallback à la liste statique lib/config.ts.
 *
 * Retourne toujours une première entrée chaîne vide '' pour "— non renseigné".
 */
export function useVeloTailles() {
  const { tpl, mutate, isLoading } = useEmailTemplates();

  const tailles = useMemo<string[]>(() => {
    const raw = tpl('velo_tailles');
    try {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr) && arr.every(x => typeof x === 'string')) {
        return ['', ...arr];
      }
    } catch { /* ignore */ }
    return [...VELO_TAILLES];
  }, [tpl]);

  async function save(next: string[]) {
    const clean = next.filter(Boolean);
    const res = await fetch('/api/parametres/emails', {
      method : 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ velo_tailles: JSON.stringify(clean) }),
    });
    if (!res.ok) {
      let msg = `${res.status}`;
      try { const b = await res.json(); if (b?.error) msg = b.error; } catch {}
      throw new Error(msg);
    }
    await mutate();
  }

  return { tailles, save, isLoading };
}
