'use client';
import useSWR from 'swr';
import { jsonFetcher as fetcher } from '@/lib/swr';
import type { Piece, Service, Marque } from '@/types/catalogue';

// TTL long côté SWR (données peu fréquemment modifiées)
const SWR_OPTS = { revalidateOnFocus: false, dedupingInterval: 300_000 };

export function usePieces() {
  const { data, error, isLoading, mutate } = useSWR<{ pieces: Piece[] }>(
    '/api/catalogue/pieces', fetcher, SWR_OPTS
  );

  async function patchPiece(row: number, fields: { flag?: string; sku?: string; fournisseur?: string; categorie?: string; prixBDC?: number; qteACommander?: number; notes?: string; codeBarre?: string; oos?: boolean }) {
    // Mise à jour optimiste — convertit oos boolean → number (0/1) pour
    // matcher le type Piece (qui garde oos:number lu du sheet).
    const optimisticPatch: any = { ...fields };
    if (typeof fields.oos === 'boolean') optimisticPatch.oos = fields.oos ? 1 : 0;
    mutate(
      prev => prev ? {
        pieces: prev.pieces.map(p =>
          p._row === row ? { ...p, ...optimisticPatch } : p
        ),
      } : prev,
      { revalidate: false }
    );
    const res = await fetch(`/api/catalogue/pieces/${row}`, {
      method : 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(fields),
    });
    if (!res.ok) {
      await mutate();
      throw new Error((await res.json()).error);
    }
  }

  async function addPiece(input: {
    nom         : string;
    categorie   : string;
    qte?        : number;
    prix?       : number;
    fournisseur?: string;
    sku?        : string;
    skuUrl?     : string;
    codeBarre?  : string;
    oos?        : boolean;
  }) {
    const res = await fetch('/api/catalogue/pieces', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(input),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    await mutate();
  }

  return { pieces: data?.pieces ?? [], error, isLoading, patchPiece, addPiece, mutate };
}

export function useServices() {
  const { data, error, isLoading, mutate } = useSWR<{ services: Service[] }>(
    '/api/catalogue/services', fetcher, SWR_OPTS
  );

  async function patchService(row: number, fields: { categoriePrio?: string; label?: string; duree?: string }) {
    mutate(
      prev => prev ? {
        services: prev.services.map(s =>
          s._row === row ? {
            ...s, ...fields,
            categorieAffichee: (fields.categoriePrio ?? s.categoriePrio) || s.categorie,
          } : s
        ),
      } : prev,
      { revalidate: false }
    );
    const res = await fetch(`/api/catalogue/services/${row}`, {
      method : 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(fields),
    });
    if (!res.ok) {
      await mutate();
      throw new Error((await res.json()).error);
    }
    // Si la durée a changé, l'API retourne le prix recalculé par la
    // formule sheet (col E) — on l'écrit dans le state local pour refléter
    // la nouvelle valeur immédiatement (sans re-fetch complet).
    const payload = await res.json().catch(() => ({}));
    if (typeof payload?.prix === 'number') {
      const newPrix = payload.prix;
      mutate(
        prev => prev ? {
          services: prev.services.map(s =>
            s._row === row ? { ...s, prix: newPrix } : s
          ),
        } : prev,
        { revalidate: false }
      );
    }
  }

  /** Ajoute un service au catalogue À LA CARTE.
   *  Le prix est calculé par la formule de la sheet à partir de la durée.
   *  Retourne le prix calculé. */
  async function addNewService(label: string, categorie: string, duree: string = ''): Promise<{ prix: number; row: number }> {
    const res = await fetch('/api/catalogue/services', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ label, categorie, duree }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    const data = await res.json();
    await mutate();
    return { prix: data.prix ?? 0, row: data.row ?? 0 };
  }

  /** Force un fetch frais du catalogue services (bypass cache serveur). */
  async function refreshServices(): Promise<void> {
    const res   = await fetch('/api/catalogue/services?refresh=1');
    const fresh = await res.json();
    await mutate(fresh, { revalidate: false });
  }

  return { services: data?.services ?? [], error, isLoading, patchService, addService: addNewService, refreshServices, mutate };
}

export function useMarques() {
  const { data, error, isLoading, mutate } = useSWR<{ marques: Marque[] }>(
    '/api/catalogue/marques', fetcher, SWR_OPTS
  );

  async function addNewMarque(nom: string) {
    const res = await fetch('/api/catalogue/marques', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ nom }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    await mutate();
  }

  /** Force un refresh côté serveur (bypass cache 5 min) puis revalide SWR */
  async function refreshMarques() {
    const res = await fetch('/api/catalogue/marques?refresh=1');
    if (!res.ok) throw new Error('Erreur refresh marques');
    const fresh = await res.json();
    await mutate(fresh, { revalidate: false });
    return fresh.marques as Marque[];
  }

  return { marques: data?.marques ?? [], error, isLoading, addMarque: addNewMarque, mutate, refreshMarques };
}
