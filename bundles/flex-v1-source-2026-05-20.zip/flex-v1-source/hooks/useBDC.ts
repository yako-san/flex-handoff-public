'use client';
import useSWR, { mutate as swrMutate } from 'swr';
import { jsonFetcherStrict as fetcher } from '@/lib/swr';
import type { BDC, AddServiceInput, AddPieceInput, EvalStatus } from '@/types/bdc';

// SWR : un seul fetch initial, pas de revalidation au focus
// (toutes les mutations renvoient le BDC frais → on hydrate manuellement)
const SWR_OPTS = {
  revalidateOnFocus   : false,
  revalidateIfStale   : false,
  // Augmenté de 2s à 30s pour éviter cascade de fetch quand l'utilisateur
  // clique rapidement plusieurs checkboxes / ajoute des items en série
  // (cause majeure des erreurs 'Quota exceeded' Sheets API).
  dedupingInterval    : 30_000,
  keepPreviousData    : true,
  shouldRetryOnError  : false,
} as const;

/** Helper : parse la réponse d'une mutation et renvoie le BDC frais (ou throw). */
async function _readMutationResponse(res: Response): Promise<BDC> {
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body?.error ?? 'Requête échouée');
  return body as BDC;
}

export function useBDC(id: string) {
  const { data, error, isLoading, mutate } = useSWR<BDC>(
    id ? `/api/bdc/${id}` : null,
    fetcher,
    SWR_OPTS,
  );

  // ── Helpers mutation ───────────────────────────────────────────
  /** Applique une MAJ optimiste avant la mutation réseau. */
  function optimistic(patch: (prev: BDC) => BDC) {
    mutate(prev => (prev ? patch(prev) : prev), { revalidate: false });
  }

  /** Hydrate le SWR cache avec le BDC frais renvoyé par le serveur. */
  function commit(fresh: BDC) {
    mutate(fresh, { revalidate: false });
  }

  /** Rollback : revalidate depuis le serveur SANS clearer le cache.
   *  Avant : `mutate(undefined)` clearait `data` → la page BDT basculait
   *  en blank pendant le re-fetch. Maintenant on conserve la donnée
   *  optimiste/précédente le temps que le re-fetch arrive — moins de
   *  flash visuel quand une mutation rate (ex. quota Sheets). */
  async function rollback() {
    await mutate();
  }

  // ── Ajout items ───────────────────────────────────────────────
  async function addItems(type: 'service' | 'piece', items: AddServiceInput[] | AddPieceInput[]) {
    try {
      const res = await fetch(`/api/bdc/${id}/items`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ type, items }),
      });
      const fresh = await _readMutationResponse(res);
      commit(fresh);
      return fresh;
    } catch (e) {
      await rollback();
      throw e;
    }
  }

  // ── Actions globales BDC (approuver / bon-de-sortie / reset) ──
  async function patchBDC(action: 'approuver' | 'bon-de-sortie') {
    optimistic(prev => ({
      ...prev,
      checkOk : action === 'approuver'     ? true : prev.checkOk,
      checkBds: action === 'bon-de-sortie' ? true : prev.checkBds,
    }));
    try {
      const res = await fetch(`/api/bdc/${id}`, {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ action }),
      });
      const fresh = await _readMutationResponse(res);
      commit(fresh);
    } catch (e) { await rollback(); throw e; }
  }

  /** Set evalStatus côté client : '' | APPROUVE | REDUX | ATTENTE | REFUSE.
   *  Modifie aussi le statut INVENTAIRE associé côté serveur (ÉVAL./
   *  APPROUVÉ/EN ATTENTE selon la valeur). */
  async function setEvalStatusBDC(value: EvalStatus) {
    optimistic(prev => ({
      ...prev,
      evalStatus: value,
      checkOk   : value === 'APPROUVE',
    }));
    try {
      const res = await fetch(`/api/bdc/${id}`, {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ action: 'set-eval-status', evalStatus: value }),
      });
      const fresh = await _readMutationResponse(res);
      commit(fresh);
      // Invalider l'inventaire pour que le badge de statut se rafraîchisse.
      await swrMutate('/api/inventaire');
    } catch (e) { await rollback(); throw e; }
  }

  async function resetEval() {
    optimistic(prev => ({ ...prev, checkEval: false }));
    try {
      const res = await fetch(`/api/bdc/${id}`, {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ action: 'reset-eval' }),
      });
      const fresh = await _readMutationResponse(res);
      commit(fresh);
    } catch (e) { await rollback(); throw e; }
  }

  async function resetFacture() {
    optimistic(prev => ({ ...prev, checkBds: false }));
    try {
      const res = await fetch(`/api/bdc/${id}`, {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ action: 'reset-facture' }),
      });
      const fresh = await _readMutationResponse(res);
      commit(fresh);
    } catch (e) { await rollback(); throw e; }
  }

  async function archiver(refuse: boolean = false) {
    const res = await fetch(`/api/bdc/${id}/archiver`, {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ refuse }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    // Le BDC est passé de actif → archivé. Invalide tous les caches
    // qui en dépendent : BDC lui-même, INVENTAIRE (vélo retiré),
    // ARCHIVES (vélo ajouté), CLIENTS (dateOut éventuelle, bdcIds).
    await Promise.all([
      mutate(undefined, { revalidate: false }),
      swrMutate('/api/inventaire'),
      swrMutate('/api/archives'),
      swrMutate('/api/clients'),
    ]);
    return res.json();
  }

  // ── Patch prix/qté/durée (Services-Réhab / pièces) ────────────
  async function patchItemFields(
    row    : number,
    type   : 'service' | 'piece',
    fields : { nom?: string; prix?: number; qte?: number; sousTotal?: number; dureeOverride?: string; serviceId?: string },
  ) {
    // Optimiste : on met à jour localement + recalcule les totaux
    optimistic(prev => {
      const items = prev.items.map(it => {
        if (it._row !== row) return it;
        const next = { ...it };
        if (type === 'service' && next.service) {
          next.service = {
            ...next.service,
            serviceId: fields.serviceId ?? next.service.serviceId,
            nom      : fields.nom       ?? next.service.nom,
            prix     : fields.prix      ?? next.service.prix,
            status   : fields.dureeOverride ?? next.service.status,
          };
        } else if (type === 'piece' && next.piece) {
          const prix = fields.prix ?? next.piece.prix;
          const qte  = fields.qte  ?? next.piece.qte;
          next.piece = {
            ...next.piece,
            nom : fields.nom ?? next.piece.nom,
            prix, qte, sousTotal: prix * qte,
          };
        }
        return next;
      });
      const totalServices = items.reduce((s, i) => s + (i.service?.prix       ?? 0), 0);
      const totalPieces   = items.reduce((s, i) => s + (i.piece?.sousTotal    ?? 0), 0);
      return { ...prev, items, totalServices, totalPieces };
    });

    try {
      const res = await fetch(`/api/bdc/${id}/items`, {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ row, type, ...fields }),
      });
      const fresh = await _readMutationResponse(res);
      commit(fresh);
    } catch (e) { await rollback(); throw e; }
  }

  // ── Suppression d'un item ─────────────────────────────────────
  async function deleteItem(row: number) {
    // Optimiste : retrait local + recalcul totaux
    optimistic(prev => {
      const items        = prev.items.filter(it => it._row !== row);
      const totalServices = items.reduce((s, i) => s + (i.service?.prix    ?? 0), 0);
      const totalPieces   = items.reduce((s, i) => s + (i.piece?.sousTotal ?? 0), 0);
      return { ...prev, items, totalServices, totalPieces };
    });

    try {
      const res = await fetch(`/api/bdc/${id}/items`, {
        method : 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ row }),
      });
      const fresh = await _readMutationResponse(res);
      commit(fresh);
    } catch (e) { await rollback(); throw e; }
  }

  // ── Note d'un item (col W) ────────────────────────────────────
  async function patchItemNote(row: number, note: string) {
    optimistic(prev => ({
      ...prev,
      items: prev.items.map(it =>
        it._row === row && it.piece
          ? { ...it, piece: { ...it.piece, cmdNote: note } }
          : it,
      ),
    }));

    try {
      const res = await fetch(`/api/bdc/${id}/items`, {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ row, cmdNote: note }),
      });
      const fresh = await _readMutationResponse(res);
      commit(fresh);
    } catch (e) { await rollback(); throw e; }
  }

  // ── Remises services + pièces (col I du BON, JSON) ────────────
  async function patchRemises(
    remiseSvc: { type: 'pct' | 'fixed'; value: number } | undefined,
    remisePce: { type: 'pct' | 'fixed'; value: number } | undefined,
  ) {
    optimistic(prev => ({ ...prev, remiseSvc, remisePce }));
    try {
      const res = await fetch(`/api/bdc/${id}/remises`, {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ remiseSvc, remisePce }),
      });
      const fresh = await _readMutationResponse(res);
      commit(fresh);
    } catch (e) { await rollback(); throw e; }
  }

  // ── Avance / acompte (col I JSON, ligne BON) ─────────────────
  async function patchAvance(input: {
    montant: number;
    mode?: 'comptant' | 'interac' | 'cartes';
    note?: string;
  }) {
    const m = Number.isFinite(input.montant) && input.montant > 0 ? input.montant : 0;
    const next = m > 0 ? { montant: m, mode: input.mode, note: input.note } : undefined;
    optimistic(prev => ({ ...prev, avance: next }));
    try {
      const res = await fetch(`/api/bdc/${id}/avance`, {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ montant: m, mode: input.mode, note: input.note }),
      });
      const fresh = await _readMutationResponse(res);
      commit(fresh);
    } catch (e) { await rollback(); throw e; }
  }

  // ── Note client du BDC (col V éval / col W facture) ──────────
  async function patchNote(note: string, mode: 'eval' | 'facture' = 'eval') {
    optimistic(prev => ({
      ...prev,
      ...(mode === 'facture' ? { noteClientFacture: note } : { noteClient: note }),
    }));
    try {
      const res = await fetch(`/api/bdc/${id}/note`, {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ note, mode }),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      // Pas de retour de BDC frais ici — on garde l'optimiste.
    } catch (e) { await rollback(); throw e; }
  }

  // ── Patch fait / cmd ──────────────────────────────────────────
  async function patchItem(row: number, updates: { fait?: boolean; cmd?: string }) {
    optimistic(prev => ({
      ...prev,
      items: prev.items.map(it => {
        if (it._row !== row) return it;
        const next = { ...it };
        if (updates.fait !== undefined && next.service) next.service = { ...next.service, fait: updates.fait };
        if (updates.cmd  !== undefined && next.piece)   next.piece   = { ...next.piece, cmd: updates.cmd };
        return next;
      }),
    }));

    try {
      const res = await fetch(`/api/bdc/${id}/items`, {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ row, ...updates }),
      });
      const fresh = await _readMutationResponse(res);
      commit(fresh);
    } catch (e) { await rollback(); throw e; }
  }

  /**
   * v1.0.7+ — Patch des sous-items d'un forfait (cross-device).
   * Persiste l'array boolean en col J du sheet BDC + flag fait en col L.
   * Optimistic update sur item.service.subStates + item.service.fait.
   */
  async function patchForfaitSubs(row: number, subStates: boolean[], fait: boolean) {
    optimistic(prev => ({
      ...prev,
      items: prev.items.map(it => {
        if (it._row !== row || !it.service) return it;
        return { ...it, service: { ...it.service, subStates, fait } };
      }),
    }));
    try {
      const res = await fetch(`/api/bdc/${id}/items`, {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ row, subStates, fait }),
      });
      const fresh = await _readMutationResponse(res);
      commit(fresh);
    } catch (e) { await rollback(); throw e; }
  }

  return {
    bdc: data, error, isLoading,
    addItems, patchBDC, setEvalStatus: setEvalStatusBDC, resetEval, resetFacture, archiver,
    patchItem, patchItemFields, patchNote, patchRemises, patchAvance, deleteItem, patchItemNote,
    patchForfaitSubs,
    mutate,
  };
}
