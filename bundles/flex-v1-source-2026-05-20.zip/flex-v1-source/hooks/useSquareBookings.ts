'use client';
import useSWR from 'swr';
import { jsonFetcher as fetcher } from '@/lib/swr';
import type { SquareBooking } from '@/lib/square/bookings';

/**
 * Hook SWR pour les RDV Square.
 * Revalidation toutes les 5 min (focus + interval).
 *
 * Si l'env var SQUARE_ACCESS_TOKEN n'est pas configurée côté serveur,
 * l'API renvoie 503 avec `configMissing: true` — le hook expose ce
 * flag pour que l'UI puisse afficher un message de config.
 */
export function useSquareBookings(days = 30) {
  const { data, error, isLoading, mutate } = useSWR<{
    bookings     : SquareBooking[];
    error?       : string;
    configMissing?: boolean;
  }>(
    `/api/square/bookings?days=${days}`,
    fetcher,
    { revalidateOnFocus: true, refreshInterval: 5 * 60 * 1000 },
  );

  return {
    bookings     : data?.bookings ?? [],
    configMissing: data?.configMissing ?? false,
    squareError  : data?.error,
    error,
    isLoading,
    mutate,
  };
}
