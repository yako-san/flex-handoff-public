'use client';
import useSWR from 'swr';
import { useMemo } from 'react';
import { jsonFetcher as fetcher } from '@/lib/swr';
import type { Velo } from '@/types/velo';
import type { PatchVeloBody } from '@/types/api';

// Référence stable d'un tableau vide pour éviter de produire un nouveau
// tableau à chaque render quand les données ne sont pas encore arrivées.
const EMPTY_VELOS: Velo[] = [];

export function useInventaire() {
  // - keepPreviousData : empêche `data` de redevenir undefined pendant les
  //   revalidations (sinon page BDT en blank au clic checkbox d'avancement).
  // - revalidateOnFocus: false : pas de re-fetch sur retour d'onglet
  //   (évite cascade quand l'app reste ouverte longtemps).
  // - dedupingInterval 30s : si plusieurs composants demandent
  //   /api/inventaire dans une fenêtre 30s, un seul fetch est lancé.
  //   Réduit drastiquement les Quota exceeded sheets.googleapis.com.
  const { data, error, isLoading, mutate } = useSWR<Velo[]>('/api/inventaire', fetcher, {
    keepPreviousData   : true,
    revalidateOnFocus  : false,
    dedupingInterval   : 30_000,
  });

  async function addVelo(body: Partial<Velo> = {}) {
    const res = await fetch('/api/inventaire', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(body),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    await mutate();
    return res.json();
  }

  async function patchVelo(id: string, body: PatchVeloBody) {
    // Optimiste : met à jour localement avant la réponse serveur
    mutate(
      prev => prev?.map(v => v.id === id ? { ...v, ...body } : v),
      { revalidate: false }
    );
    const res = await fetch(`/api/inventaire/${id}`, {
      method : 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(body),
    });
    if (!res.ok) {
      await mutate(); // rollback
      throw new Error((await res.json()).error);
    }
    await mutate();
  }

  // Garantit toujours un Array : si l'API retourne un objet d'erreur (ex.
  // { error: "..." } sur 500), on retombe sur le tableau vide pour éviter
  // que velos.filter / .map plantent l'app.
  const velos = Array.isArray(data) ? data : EMPTY_VELOS;
  return { velos, error, isLoading, addVelo, patchVelo, mutate };
}
