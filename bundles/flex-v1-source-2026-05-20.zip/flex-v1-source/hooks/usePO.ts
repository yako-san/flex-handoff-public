'use client';
import useSWR from 'swr';
import { jsonFetcher as fetcher } from '@/lib/swr';
import type { PO } from '@/types/po';

const EMPTY: PO[] = [];

export function usePOs() {
  const { data, error, isLoading, mutate } = useSWR<PO[]>('/api/po', fetcher, {
    revalidateOnFocus: false,
  });

  const pos = Array.isArray(data) ? data : EMPTY;

  async function createPO(input: {
    poNumber: string;
    fournisseur: string;
    dateCommande: string;
    items: { nom: string; sku: string; qteCommandee: number; prixAchat: number; pieceRow: number; pieceId?: string; notes: string; categorie?: string }[];
  }) {
    const res = await fetch('/api/po', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(input),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    await mutate();
  }

  async function addLines(poNumber: string, items: { nom: string; sku: string; qteCommandee: number; prixAchat: number; pieceRow: number; pieceId?: string; notes: string; categorie?: string }[]) {
    const res = await fetch(`/api/po/${encodeURIComponent(poNumber)}`, {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ items }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    await mutate();
  }

  async function updateLine(poNumber: string, sheetRow: number, fields: { qteCommandee?: number; qteRecue?: number; recu?: boolean; notes?: string; categorie?: string }) {
    // Optimistic update — UI changes instantly
    const optimistic = pos.map(po => {
      if (po.poNumber !== poNumber) return po;
      const rowIdx = po._rows.indexOf(sheetRow);
      if (rowIdx === -1) return po;
      const newItems = [...po.items];
      newItems[rowIdx] = { ...newItems[rowIdx], ...fields };
      return { ...po, items: newItems };
    });

    mutate(optimistic, false); // update UI without revalidation

    const res = await fetch(`/api/po/${encodeURIComponent(poNumber)}`, {
      method : 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ sheetRow, ...fields }),
    });
    if (!res.ok) {
      await mutate(); // revert on error
      throw new Error((await res.json()).error);
    }
    const result = await res.json().catch(() => ({}));
    return result as { stockDelta?: number; createdPiece?: { nom: string; pieceId: string } };
  }

  async function deleteLine(poNumber: string, sheetRow: number) {
    const res = await fetch(`/api/po/${encodeURIComponent(poNumber)}`, {
      method : 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ sheetRow }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    await mutate();
  }

  async function reopenPO(poNumber: string) {
    const res = await fetch(`/api/po/${encodeURIComponent(poNumber)}`, {
      method : 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ action: 'reopen' }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    await mutate();
  }

  async function finalize(poNumber: string) {
    const res = await fetch(`/api/po/${encodeURIComponent(poNumber)}/finalize`, {
      method: 'POST',
    });
    if (!res.ok) throw new Error((await res.json()).error);
    const result = await res.json();
    await mutate();
    return result as { received: number; notReceived: number; stockUpdates: { nom: string; delta: number }[]; missing: { nom: string; sku: string; cmd: number; recu: number; manquant: number }[]; createdPieces: { nom: string; pieceId: string }[] };
  }

  return {
    pos,
    error,
    isLoading,
    createPO,
    addLines,
    updateLine,
    deleteLine,
    reopenPO,
    finalize,
    mutate,
  };
}
