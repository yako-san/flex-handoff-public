'use client';
import useSWR, { mutate as swrMutate } from 'swr';
import { jsonFetcher as fetcher } from '@/lib/swr';
import type { Vente } from '@/types/vente';

const EMPTY: Vente[] = [];

/**
 * Liste des ventes archivées (onglet `_VENTES_ARCHIVES_`).
 *
 * API symétrique de useArchives (BDC archivés) : un GET pour la liste, un
 * `desarchiver` pour ramener une vente dans `_VENTES_`, un `deleteArchive`
 * pour la suppression définitive (admin only côté API).
 */
export function useArchivedVentes() {
  const { data, error, isLoading, mutate } = useSWR<Vente[]>('/api/ventes/archives', fetcher, {
    revalidateOnFocus: false,
    keepPreviousData : true,
  });

  /** Désarchiver : remet la vente dans _VENTES_. */
  async function desarchiver(venteId: string) {
    const res = await fetch('/api/ventes/archives', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ venteId }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    mutate(
      (prev: Vente[] | undefined) => (prev ?? []).filter(v => v.venteId !== venteId),
      { revalidate: true },
    );
    swrMutate('/api/ventes').catch(() => {});
  }

  /** Suppression définitive (admin). */
  async function deleteArchive(venteId: string) {
    const res = await fetch('/api/ventes/archives', {
      method : 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ venteId }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    mutate(
      (prev: Vente[] | undefined) => (prev ?? []).filter(v => v.venteId !== venteId),
      { revalidate: true },
    );
  }

  return {
    ventes: Array.isArray(data) ? data : EMPTY,
    error,
    isLoading,
    desarchiver,
    deleteArchive,
    mutate,
  };
}
