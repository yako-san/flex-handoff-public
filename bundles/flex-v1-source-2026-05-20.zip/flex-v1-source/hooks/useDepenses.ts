'use client';
import useSWR from 'swr';
import { jsonFetcherStrict as fetcher } from '@/lib/swr';
import type { Depense, DepenseInput } from '@/types/depense';

/**
 * v1.0.26+ : hook CRUD pour les dépenses (admin only — la route serveur
 * retourne 403 si pas admin, le hook ne filtre pas côté client).
 *
 * v1.0.27+ : `includePOs` ajoute les PO finalisés/partiels compilés en
 * Depense virtuelle (read-only). Utile pour totaux trimestriels complets.
 */
export function useDepenses(opts: { includePOs?: boolean } = {}) {
  const url = opts.includePOs ? '/api/depenses?includePOs=1' : '/api/depenses';
  const { data, error, isLoading, mutate } = useSWR<{ depenses: Depense[]; posCompiles?: Depense[] }>(
    url,
    fetcher,
  );

  const depenses    = data?.depenses ?? [];
  const posCompiles = data?.posCompiles ?? [];

  async function createDepense(input: DepenseInput): Promise<Depense> {
    const res = await fetch('/api/depenses', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(input),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json?.error ?? `${res.status}`);
    await mutate();
    return json.depense;
  }

  async function updateDepense(id: string, patch: Partial<DepenseInput>): Promise<void> {
    const res = await fetch(`/api/depenses/${encodeURIComponent(id)}`, {
      method : 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(patch),
    });
    if (!res.ok) {
      const json = await res.json().catch(() => ({}));
      throw new Error(json?.error ?? `${res.status}`);
    }
    await mutate();
  }

  async function deleteDepense(id: string): Promise<void> {
    const res = await fetch(`/api/depenses/${encodeURIComponent(id)}`, { method: 'DELETE' });
    if (!res.ok) {
      const json = await res.json().catch(() => ({}));
      throw new Error(json?.error ?? `${res.status}`);
    }
    await mutate();
  }

  return {
    depenses,
    posCompiles,
    error,
    isLoading,
    createDepense,
    updateDepense,
    deleteDepense,
    mutate,
  };
}
