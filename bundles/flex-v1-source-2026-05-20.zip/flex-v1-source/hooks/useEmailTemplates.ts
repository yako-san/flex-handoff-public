'use client';
import useSWR from 'swr';
import { jsonFetcher as fetcher } from '@/lib/swr';
import { EMAIL_TEMPLATE_DEFAULTS as DEFAULTS } from '@/lib/emailTemplateDefaults';

/**
 * Hook SWR pour récupérer les templates (courriels + SMS rappel) depuis
 * /api/parametres/emails. Retourne un accès par clé avec fallback aux
 * valeurs par défaut (EMAIL_TEMPLATE_DEFAULTS).
 *
 * Usage :
 *   const { tpl } = useEmailTemplates();
 *   const smsFr = tpl('sms_rappel_fr');
 */
export function useEmailTemplates() {
  const { data, error, isLoading, mutate } = useSWR<Record<string, string>>(
    '/api/parametres/emails',
    fetcher,
    { revalidateOnFocus: false, dedupingInterval: 300_000 },
  );

  function tpl(key: string): string {
    return data?.[key] ?? DEFAULTS[key] ?? '';
  }

  return { tpl, templates: data ?? DEFAULTS, error, isLoading, mutate };
}
