'use client';
import useSWR from 'swr';
import { useMemo } from 'react';
import { jsonFetcher as fetcher } from '@/lib/swr';
import type { EquipeMember, EquipeMemberFormData } from '@/types/equipe';

/**
 * Équipe atelier — lit depuis l'onglet _EQUIPE_ via /api/parametres/equipe.
 *
 * Retourne :
 *  - members : EquipeMember[] (fiches complètes, courriel/tél/etc.)
 *  - equipe  : string[] (SURNOMS, pour les dropdowns BDT — courts et lisibles
 *              dans les colonnes étroites du tableau). Inclut une chaîne vide
 *              '' en tête = "non assigné". Filtré sur active === true.
 *              Fallback : prenom+nom si surnom vide, puis prenom seul.
 */
export function useEquipe() {
  const { data, error, isLoading, mutate } = useSWR<EquipeMember[]>(
    '/api/parametres/equipe',
    fetcher,
  );

  const members: EquipeMember[] = Array.isArray(data) ? data : [];

  const equipe = useMemo<string[]>(() => {
    const noms = members
      .filter(m => m.active)
      .map(m => m.surnom?.trim() || `${m.prenom} ${m.nom}`.trim() || m.prenom || '');
    return ['', ...noms.filter(Boolean)];
  }, [members]);

  async function createMember(body: EquipeMemberFormData): Promise<EquipeMember> {
    const res = await fetch('/api/parametres/equipe', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(body),
    });
    if (!res.ok) throw new Error((await res.json()).error || 'Erreur création');
    const created = await res.json();
    await mutate();
    return created;
  }

  async function updateMember(row: number, fields: Partial<EquipeMemberFormData>): Promise<void> {
    const res = await fetch('/api/parametres/equipe', {
      method : 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ row, fields }),
    });
    if (!res.ok) throw new Error((await res.json()).error || 'Erreur mise à jour');
    await mutate();
  }

  async function removeMember(row: number): Promise<void> {
    const res = await fetch('/api/parametres/equipe', {
      method : 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ row }),
    });
    if (!res.ok) throw new Error((await res.json()).error || 'Erreur suppression');
    await mutate();
  }

  return {
    members,
    equipe,           // compat dropdowns BDT (string[] avec '' en tête)
    isLoading,
    error,
    createMember,
    updateMember,
    removeMember,
    mutate,
    /** @deprecated — utilise createMember/updateMember/removeMember */
    save: async (_: string[]) => { /* noop pour compat ancien API */ },
  };
}
