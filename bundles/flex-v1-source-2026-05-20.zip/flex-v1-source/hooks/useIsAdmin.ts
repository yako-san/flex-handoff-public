'use client';
import { useMemo } from 'react';
import { useSession } from 'next-auth/react';
import { useEmailTemplates } from './useEmailTemplates';

/**
 * Hook de sécurité — retourne true si l'utilisateur courant est
 * admin, i.e. son email (session.user.email) figure dans la clé
 * `admin_emails` du sheet _EMAIL_TEMPLATES_ (JSON array), comparée
 * en casse insensible.
 *
 * Fallback fail-safe : `yako.cyclo@gmail.com` est TOUJOURS admin,
 * même si la liste sheet est vide / cassée — évite de se verrouiller
 * hors des Paramètres en cas de mauvaise config.
 *
 * Retourne aussi :
 *  - loading : true tant que session ou templates pas chargés
 *  - adminEmails : la liste effective (hors fallback) pour l'UI éditrice
 *  - save(emails) : met à jour la liste dans le sheet
 */
export function useIsAdmin() {
  const { data: session, status }            = useSession();
  const { tpl, mutate, isLoading: tplLoad }  = useEmailTemplates();

  const adminEmails = useMemo<string[]>(() => {
    const raw = tpl('admin_emails');
    try {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr) && arr.every(x => typeof x === 'string')) {
        return arr.map(s => s.trim().toLowerCase()).filter(Boolean);
      }
    } catch { /* ignore */ }
    return ['yako.cyclo@gmail.com'];
  }, [tpl]);

  const email   = (session?.user?.email ?? '').trim().toLowerCase();
  const isAdmin = email === 'yako.cyclo@gmail.com' || adminEmails.includes(email);
  const loading = status === 'loading' || tplLoad;

  async function save(emails: string[]) {
    const clean = emails.map(s => s.trim().toLowerCase()).filter(Boolean);
    // Toujours garantir yako.cyclo@gmail.com en fallback — on ne le force
    // pas dans la liste sheet (fail-safe côté hook), mais on log une alerte
    // si l'utilisateur essaie de retirer tout le monde.
    if (clean.length === 0) {
      throw new Error('Au moins un admin est requis (ou yako.cyclo@gmail.com reste admin par défaut).');
    }
    const res = await fetch('/api/parametres/emails', {
      method : 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ admin_emails: JSON.stringify(clean) }),
    });
    if (!res.ok) {
      let msg = `${res.status}`;
      try { const b = await res.json(); if (b?.error) msg = b.error; } catch {}
      throw new Error(msg);
    }
    await mutate();
  }

  return { isAdmin, loading, adminEmails, userEmail: email, save };
}
