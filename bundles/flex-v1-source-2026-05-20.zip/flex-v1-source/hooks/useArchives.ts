'use client';
import useSWR, { mutate as swrMutate } from 'swr';
import { jsonFetcher as fetcher } from '@/lib/swr';
import type { BDC } from '@/types/bdc';

// Référence stable d'un tableau vide pour éviter les re-renders en cascade.
const EMPTY_BDCS: BDC[] = [];

export function useArchives() {
  const { data, error, isLoading, mutate } = useSWR<BDC[]>('/api/archives', fetcher, {
    revalidateOnFocus: false,
  });

  async function desarchiver(bdcId: string, archiveRow: number) {
    const res = await fetch('/api/archives', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ bdcId, archiveRow }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    // Invalider tous les caches SWR affectés par le désarchivage :
    //  - /api/archives : la ligne y est retirée
    //  - /api/inventaire : une nouvelle ligne vélo y apparaît
    //  - /api/bdc/<id>  : le BDC devient accessible (détail page)
    //  - /api/clients   : dateOut du client peut-être effacée
    await Promise.all([
      mutate(),
      swrMutate('/api/inventaire'),
      swrMutate(`/api/bdc/${bdcId}`),
      swrMutate('/api/clients'),
    ]);
  }

  async function patchDate(archiveRow: number, field: string, value: string) {
    const res = await fetch('/api/archives', {
      method : 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ archiveRow, field, value }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    await mutate();
  }

  async function deleteArchive(bdcId: string, archiveRow: number) {
    const res = await fetch('/api/archives', {
      method : 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ bdcId, archiveRow }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    await mutate();
  }

  return { bdcs: Array.isArray(data) ? data : EMPTY_BDCS, error, isLoading, desarchiver, patchDate, deleteArchive, mutate };
}
