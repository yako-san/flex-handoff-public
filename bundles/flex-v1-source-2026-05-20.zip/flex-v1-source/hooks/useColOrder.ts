'use client';
import { useState, useRef, useCallback } from 'react';

export interface ColDef {
  id    : string;
  header: string;
  width ?: string;
  hCls ?: string;   // className sur <th>
  cCls ?: string;   // className sur <td>
}

/**
 * Gestion de l'ordre des colonnes avec persistance localStorage
 * et drag-and-drop natif HTML5.
 *
 * @param storageKey  Clé unique par tableau (ex. 'commandes', 'pieces')
 * @param defaultCols Colonnes par défaut dans l'ordre souhaité
 */
export function useColOrder<T extends ColDef>(
  storageKey  : string,
  defaultCols : T[],
) {
  const SK         = `col-order:${storageKey}`;
  const defaultIds = defaultCols.map(c => c.id);

  // Initialise depuis localStorage si valide, sinon ordre par défaut
  const [order, setOrder] = useState<string[]>(() => {
    if (typeof window === 'undefined') return defaultIds;
    try {
      const raw = localStorage.getItem(SK);
      if (raw) {
        const ids = JSON.parse(raw) as string[];
        if (ids.length === defaultIds.length && defaultIds.every(id => ids.includes(id))) {
          return ids;
        }
      }
    } catch {}
    return defaultIds;
  });

  const draggingRef              = useRef<string | null>(null);
  const [dragOverId, setDragOver] = useState<string | null>(null);

  const onDragStart = useCallback((id: string) => (e: React.DragEvent) => {
    draggingRef.current    = id;
    e.dataTransfer.effectAllowed = 'move';
  }, []);

  const onDragOver = useCallback((id: string) => (e: React.DragEvent) => {
    e.preventDefault();
    if (draggingRef.current && draggingRef.current !== id) setDragOver(id);
  }, []);

  const onDrop = useCallback((id: string) => (e: React.DragEvent) => {
    e.preventDefault();
    const from = draggingRef.current;
    if (!from || from === id) return;
    setOrder(prev => {
      const next    = [...prev];
      const fromIdx = next.indexOf(from);
      const toIdx   = next.indexOf(id);
      if (fromIdx === -1 || toIdx === -1) return prev;
      next.splice(fromIdx, 1);
      next.splice(toIdx, 0, from);
      try { localStorage.setItem(SK, JSON.stringify(next)); } catch {}
      return next;
    });
    setDragOver(null);
    draggingRef.current = null;
  }, [SK]);

  const onDragEnd = useCallback(() => {
    draggingRef.current = null;
    setDragOver(null);
  }, []);

  /** Props à étendre sur chaque <th> draggable */
  function dragProps(id: string) {
    return {
      draggable  : true as const,
      onDragStart: onDragStart(id),
      onDragOver : onDragOver(id),
      onDrop     : onDrop(id),
      onDragEnd,
    };
  }

  const orderedCols = order
    .map(id => defaultCols.find(c => c.id === id))
    .filter(Boolean) as T[];

  return { orderedCols, dragProps, dragOverId };
}
