'use client';
import { useEffect, useRef, useState } from 'react';
import { toast } from '@/components/ui/Toast';

/**
 * Détection des nouveaux RDV Square depuis la dernière visite.
 *
 * - Conserve dans localStorage (clé `square_seen_bookings_v1`) la liste
 *   des IDs déjà vus.
 * - À chaque changement de la liste `currentIds`, compare aux vus :
 *   si de nouveaux IDs apparaissent ET qu'on avait déjà une version
 *   précédente (pas au premier chargement à froid), affiche un toast
 *   et expose `newIds` pour décorer la UI.
 * - `markSeen(id?)` permet de marquer un RDV spécifique comme vu (ou
 *   tous si pas d'id). À appeler quand l'utilisateur clique sur + pour
 *   créer le BDT, ou sur un bouton « Tout vu ».
 */
const STORAGE_KEY = 'square_seen_bookings_v1';

function readSeen(): Set<string> {
  if (typeof window === 'undefined') return new Set();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return new Set();
    const arr = JSON.parse(raw);
    return new Set(Array.isArray(arr) ? arr : []);
  } catch {
    return new Set();
  }
}

function writeSeen(ids: Set<string>): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify([...ids]));
  } catch { /* quota / safari private → ignore */ }
}

export function useNewBookings(currentIds: string[]): {
  newIds      : Set<string>;
  markSeen    : (id?: string) => void;
  markAllSeen : () => void;
} {
  const [newIds, setNewIds] = useState<Set<string>>(() => new Set());
  const hadInitialLoad      = useRef<boolean>(false);
  const prevIdsRef          = useRef<string[]>([]);

  useEffect(() => {
    // Premier run : on considère que TOUS les RDV présents lors du 1er
    // chargement sont "nouveaux" → on affiche le badge mais PAS de toast
    // (pour ne pas spammer à chaque rafraîchissement de page).
    const seen = readSeen();
    const currentSet = new Set(currentIds);

    const fresh = new Set<string>();
    for (const id of currentSet) {
      if (!seen.has(id)) fresh.add(id);
    }

    // Toast uniquement si :
    //  - on a déjà eu un load précédent avec des données (pas le 1er render)
    //  - il y a des IDs qui n'étaient pas dans la version précédente
    if (hadInitialLoad.current) {
      const prevSet = new Set(prevIdsRef.current);
      const reallyNew = [...currentSet].filter(id => !prevSet.has(id) && !seen.has(id));
      if (reallyNew.length > 0) {
        toast(`${reallyNew.length} nouveau${reallyNew.length > 1 ? 'x' : ''} RDV Square !`);
      }
    } else if (currentIds.length > 0) {
      hadInitialLoad.current = true;
    }

    prevIdsRef.current = currentIds;
    setNewIds(fresh);
  }, [currentIds.join('|')]); // compare stable

  function markSeen(id?: string): void {
    const seen = readSeen();
    if (id) {
      seen.add(id);
      setNewIds(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    } else {
      for (const nid of newIds) seen.add(nid);
      setNewIds(new Set());
    }
    writeSeen(seen);
  }

  function markAllSeen(): void {
    markSeen();
  }

  return { newIds, markSeen, markAllSeen };
}
