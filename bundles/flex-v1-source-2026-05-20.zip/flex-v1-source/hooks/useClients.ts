'use client';
import useSWR from 'swr';
import { useMemo } from 'react';
import { toast } from '@/components/ui/Toast';
import type { ClientsGrouped, ClientFormData } from '@/types/client';

import { jsonFetcher as fetcher } from '@/lib/swr';

export function useClients() {
  // dedupingInterval 30s + revalidateOnFocus false : réduit les fetch
  // dupliqués (clients affichés sur plusieurs pages) et évite la
  // cascade au retour d'onglet — cause majeure de Quota exceeded.
  const { data, error, isLoading, mutate } = useSWR<ClientsGrouped>('/api/clients', fetcher, {
    revalidateOnFocus: false,
    dedupingInterval : 30_000,
    keepPreviousData : true,
  });

  async function patchLead(row: number, lead: string) {
    mutate(prev => {
      if (!prev) return prev;
      const patch = (arr: typeof prev.actifs) =>
        (arr ?? []).map(c => c._row === row ? { ...c, lead } : c);
      return { recents: patch(prev.recents), actifs: patch(prev.actifs), autres: patch(prev.autres) };
    }, { revalidate: false });

    const res = await fetch('/api/clients', {
      method : 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ row, lead }),
    });
    if (!res.ok) { await mutate(); throw new Error((await res.json()).error); }
  }

  async function creerClient(body: ClientFormData) {
    const res = await fetch('/api/clients', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(body),
    });
    const payload = await res.json();
    if (!res.ok) throw new Error(payload.error || 'Erreur création client');
    // Sync Contacts échouée : le client est bien créé en sheet, mais pas
    // dans les contacts Google. Déclenche la bannière globale si c'est un
    // problème de token (contactReconnect), sinon toast classique.
    if (payload.contactError) {
      if (payload.contactReconnect && typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('google-auth-expired', {
          detail: { message: payload.contactError },
        }));
      } else {
        toast(payload.contactError, 'error');
      }
    }

    // Optimiste : on ajoute immédiatement le nouveau client dans la liste
    // locale pour qu'il apparaisse dans les dropdowns sans attendre le
    // revalidate. Le new client va dans "recents" (clients récents).
    mutate(prev => {
      if (!prev) return prev;
      const already =
        (prev.recents ?? []).some(c => c._row === payload._row) ||
        (prev.actifs ?? []).some(c => c._row === payload._row) ||
        (prev.autres ?? []).some(c => c._row === payload._row);
      if (already) return prev;
      return {
        recents: [payload, ...(prev.recents ?? [])],
        actifs : prev.actifs ?? [],
        autres : prev.autres ?? [],
      };
    }, { revalidate: false });

    // Revalidation forcée fraîche (bypass cache serveur + dedupe SWR)
    // pour que les prochaines pages / hooks voient la vraie liste.
    await mutate(async () => {
      const r = await fetch('/api/clients?fresh=1');
      return r.json();
    });
    return payload;
  }

  /** PATCH plusieurs champs d'un client (prénom, nom, tél, courriel, comm, lead, notes). */
  async function patchClient(row: number, fields: Partial<ClientFormData>) {
    // Optimiste local
    mutate(prev => {
      if (!prev) return prev;
      const merge = (arr: typeof prev.actifs) =>
        (arr ?? []).map(c => {
          if (c._row !== row) return c;
          const updated: any = { ...c, ...fields };
          if (fields.prenom !== undefined || fields.nom !== undefined) {
            updated.nomComplet = `${updated.prenom ?? ''} ${updated.nom ?? ''}`.trim();
          }
          return updated;
        });
      return { recents: merge(prev.recents), actifs: merge(prev.actifs), autres: merge(prev.autres) };
    }, { revalidate: false });

    const res = await fetch('/api/clients', {
      method : 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ row, fields }),
    });
    if (!res.ok) {
      await mutate();
      throw new Error((await res.json()).error);
    }
    // Revalider depuis le serveur (cache invalidé)
    await mutate(async () => {
      const r = await fetch('/api/clients?fresh=1');
      return r.json();
    });
  }

  /** Retire un bdcId de la col I/J d'un client (ne supprime pas le BDC). */
  async function removeClientBdc(row: number, bdcId: string) {
    mutate(prev => {
      if (!prev) return prev;
      const filter = (arr: typeof prev.actifs) =>
        (arr ?? []).map(c => c._row === row ? { ...c, bdcIds: c.bdcIds.filter(id => id !== bdcId) } : c);
      return { recents: filter(prev.recents), actifs: filter(prev.actifs), autres: filter(prev.autres) };
    }, { revalidate: false });

    const res = await fetch('/api/clients', {
      method : 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ row, removeBdcId: bdcId }),
    });
    if (!res.ok) {
      await mutate();
      throw new Error((await res.json()).error);
    }
    await mutate(async () => {
      const r = await fetch('/api/clients?fresh=1');
      return r.json();
    });
  }

  async function removeClient(row: number) {
    // Optimiste : retire le client localement
    mutate(prev => {
      if (!prev) return prev;
      const filter = (arr: typeof prev.actifs) => (arr ?? []).filter(c => c._row !== row);
      return { recents: filter(prev.recents), actifs: filter(prev.actifs), autres: filter(prev.autres) };
    }, { revalidate: false });

    const res = await fetch('/api/clients', {
      method : 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ row }),
    });
    if (!res.ok) {
      await mutate();
      throw new Error((await res.json()).error);
    }
    // Revalider avec cache invalidé côté serveur
    await mutate(async () => {
      const r = await fetch('/api/clients?fresh=1');
      return r.json();
    });
  }

  async function refreshClients() {
    await mutate(async () => {
      const r = await fetch('/api/clients?fresh=1');
      return r.json();
    });
  }

  /** Liste plate de tous les noms (pour les selects), triée alphabétiquement
   *  par NOM DE FAMILLE puis prénom. Mémoïsée sur data pour stabilité référence. */
  const allNoms: string[] = useMemo(() => {
    const all = [
      ...(data?.recents ?? []),
      ...(data?.actifs  ?? []),
      ...(data?.autres  ?? []),
    ];
    // Dédupe par nomComplet
    const seen = new Set<string>();
    const unique = all.filter(c => {
      if (seen.has(c.nomComplet)) return false;
      seen.add(c.nomComplet);
      return true;
    });
    // Tri par nom de famille (puis prénom comme tiebreaker)
    unique.sort((a, b) => {
      const byNom = (a.nom || '').localeCompare(b.nom || '', 'fr');
      if (byNom !== 0) return byNom;
      return (a.prenom || '').localeCompare(b.prenom || '', 'fr');
    });
    return unique.map(c => c.nomComplet);
  }, [data]);

  return { grouped: data, allNoms, error, isLoading, creerClient, patchClient, patchLead, removeClient, removeClientBdc, refreshClients, mutate };
}

export function useVelosClient(nom: string | null) {
  return useSWR<string[]>(
    nom ? `/api/clients/${encodeURIComponent(nom)}/velos` : null,
    fetcher
  );
}
