# INDEX — flex-v1-source

> Bundle de transfert V1 → V2 préparé le **2026-05-20**.
> Source : `yako-san/flex-rev-app` (repo privé).
> Tag canonical : **`v1.0.0`** (commit `ef5e604`, livré le 2 mai 2026).
> HEAD au moment du zip : **`132184e`** (post-v1.0.22, post-clusters 1-4).

---

## 1. Version V1 figée

| Champ | Valeur |
|---|---|
| Repo | `yako-san/flex-rev-app` (privé) |
| Tag stable | `v1.0.0` — `ef5e604` (2 mai 2026) |
| HEAD bundle | `132184e` (docs sidebar spec, 2026-05-17) |
| Stack | Next.js 14.2.29 App Router + TypeScript strict, Google Sheets API v4, NextAuth v5 beta, Vercel KV (Upstash) |
| APP_VERSION | `v1.3.0-preview` (constante dans `components/layout/AppShell.tsx:25`) |

Pour replonger sur le code v1.0.0 exact, demander à yako-san le diff
`v1.0.0..132184e` — ou rejouer les patches livrés en clusters 1-4
documentés dans `docs/v2-handoff/CHANGES-CLUSTER-SESSION-2026-05-16.md`
(côté repo V1).

---

## 2. Vue d'ensemble — arborescence importante

```
app/                                           Next.js 14 App Router
├── (auth)/login/page.tsx                      Login NextAuth
├── inventaire/                                ⭐ section centrale atelier
│   ├── page.tsx                               Liste BDT (groupée NOUVEAU/WIP/FACTURÉ)
│   ├── [id]/page.tsx                          ⭐ DÉTAIL BDT (cible port immédiat)
│   └── new/                                   Création BDT
├── catalogue/
│   ├── pieces/page.tsx                        Catalogue pièces
│   ├── ventes/page.tsx                        Ventes directes (POS)
│   ├── commande/page.tsx                      Items à commander chez fournisseur
│   ├── reception/page.tsx                     POs en réception
│   └── services/page.tsx                      Catalogue services
├── clients/                                   Clients (liste alpha + modal édition)
├── archives/                                  BDT archivés
├── dashboard/                                 KPIs + sections
├── parametres/                                Settings (atelier, équipe, emails…)
├── menu/                                      Big menu mobile iOS-like
└── api/                                       Server routes
    ├── bdc/                                   ⭐ CRUD BDT
    │   ├── route.ts                           Liste BDT
    │   └── [id]/
    │       ├── route.ts                       GET/PATCH BDT individuel
    │       ├── items/route.ts                 ⭐ POST/DELETE items (cible port)
    │       ├── remises/route.ts               PATCH remises (% ou $)
    │       ├── avance/route.ts                PATCH avance (objet)
    │       ├── evaluation/route.ts            PATCH evalStatus + check
    │       ├── facturer/route.ts              Émettre facture PDF + Gmail draft
    │       ├── archiver/route.ts              Archive BDT (facturé ou refusé)
    │       └── …
    ├── ventes/                                CRUD ventes directes
    ├── catalogue/pieces/                      CRUD pièces catalogue
    ├── inventaire/                            CRUD vélos
    └── admin/                                 Routes admin-only (migration, etc.)

components/
├── bdc/                                       ⭐ Composants BDT
│   ├── BDCHeader.tsx                          Header sticky (numéro, client, statut)
│   ├── BDCPanel.tsx                           ⭐ Table items services + pièces
│   ├── BDCItemRow.tsx                         Une ligne d'item
│   ├── BDCTotaux.tsx                          Bloc total (Services + Pièces = HT - avance - TTC)
│   ├── PiecesPopup.tsx                        ⭐ Modal ajout pièces (cible port)
│   ├── ServicesPopup.tsx                      ⭐ Modal ajout services (cible port)
│   ├── ArchiveChoiceDialog.tsx                Dialog 4-boutons paiement+archive
│   ├── FactureStatusPanel.tsx                 Statut facture post-émission
│   ├── CheckboxAction.tsx                     Pattern customConfirm via modal
│   └── VeloHistory.tsx                        Historique BDT du vélo
├── inventaire/                                Table + cards vélos
│   ├── VeloTable.tsx                          Liste BDT groupée
│   ├── VeloRow.tsx                            Ligne BDT desktop
│   ├── VeloCard.tsx                           Card BDT mobile
│   └── StatutBadge.tsx                        Pill statut
├── layout/
│   ├── AppShell.tsx                           ⭐ Sidebar + topbar mobile
│   ├── PageHeader.tsx                         Bandeau gris sticky en haut de page
│   └── ParametresNav.tsx                      Sous-nav /parametres/*
├── ui/                                        Primitives génériques
│   ├── Modal.tsx                              ⭐ Wrapper Dialog HeadlessUI
│   ├── ConfirmDialog.tsx
│   ├── PillToggle.tsx                         Tabs pill (Éval/Facture, etc.)
│   ├── HelpHint.tsx                           Tooltip + Popover hint
│   ├── Toast.tsx                              Sonner-like top-right
│   ├── DragTh.tsx                             Header table draggable (col reorder)
│   ├── BarcodeScanner.tsx                     Caméra scan zxing
│   └── …
├── ventes/                                    Modals vente
├── clients/                                   Form + modal client
└── catalogue/                                 Forms pièces/services

lib/                                           Backend / helpers
├── sheets/                                    ⭐ Couche data Google Sheets
│   ├── client.ts                              Singleton googleapis + BDC_COL + TAB
│   ├── bdc.ts                                 ⭐ CRUD BDT (insertPieces, getBDC…)
│   ├── bdc-filters.ts                         Filtres items (forfait, etc.)
│   ├── catalogue.ts                           Pièces + services + marques
│   ├── ventes.ts                              CRUD ventes directes
│   ├── clients.ts                             CRUD clients
│   ├── reservation.ts                         ⭐ Modèle stock AB/AC (v7.0.0+)
│   ├── po.ts                                  CRUD POs fournisseurs
│   ├── inventaire.ts                          CRUD vélos
│   ├── factures.ts                            Génération facture (Google Doc + PDF + Gmail draft)
│   ├── emailTemplates.ts                      Templates emails (lus depuis sheet)
│   ├── counter.ts                             Compteurs séquentiels (n° BDT, facture)
│   └── …
├── finances/
│   └── taxes.ts                               ⭐ computeTaxes Québec (TPS 5%, TVQ 9.975%)
├── google/
│   ├── ownerToken.ts                          OAuth refresh token owner
│   ├── gmailDraft.ts                          Création brouillon Gmail
│   ├── calendar.ts                            Square bookings (Google Cal)
│   ├── drive.ts                               Upload Drive (PDF, photos)
│   └── withTokenRetry.ts                      Retry wrapper auth refresh
├── pdf/                                       Génération PDF
│   ├── templates/facture-html.ts              Template HTML facture
│   └── render-puppeteer.ts                    Puppeteer headless (Vercel + local)
├── auth.ts                                    NextAuth v5 config
├── auth/requireAdmin.ts                       Helper admin guard
├── cache.ts                                   Vercel KV + node-cache fallback
├── utils/
│   ├── format.ts                              frPrix, normSearch, dates
│   ├── pieces.ts                              ⭐ pceNomClean, stripIconPrefix, pieceKey
│   ├── statuts.ts                             ⭐ STATUTS, CMD_OPTIONS, transitions
│   ├── scanLog.ts                             Log des scans BR
│   └── …
└── export/v1.ts                               Schema export pour import V2

types/
├── bdc.ts                                     ⭐ BDC, BDCItem, BDCPieceItem, BDCServiceItem, AddPieceInput, AddServiceInput, AddItemsPayload
├── catalogue.ts                               Piece, Service, Marque
├── vente.ts                                   Vente, VenteItem
├── client.ts                                  Client
├── velo.ts                                    Velo, VeloStatus
├── po.ts                                      PO, POLineItem
├── archives.ts                                BDC archivé
└── …

hooks/                                         Hooks SWR par section
├── useBDC.ts                                  ⭐ BDT individuel (mutations)
├── useBDCs.ts                                 Liste BDT (avec filter)
├── useInventaire.ts                           Liste vélos
├── useCatalogue.ts                            ⭐ usePieces + useServices
├── useClients.ts
├── useVentes.ts                               Liste ventes + mutations
├── usePO.ts                                   POs
├── useColOrder.ts                             Réordonnable des colonnes
└── …

public/                                        Assets SVG seulement
├── logo-flex-rev-*.svg                        5 variantes du logo
├── logo-yako-cyclo.svg                        Logo facture
├── favicon-fv.svg
└── branding/

middleware.ts                                  Auth gate routes /api/* (NextAuth)
next.config.mjs                                serverComponentsExternalPackages
tailwind.config.ts                             Helvetica Neue, grays override
postcss.config.js
tsconfig.json                                  strict mode
package.json                                   Next 14.2 + deps
README.md                                      Doc projet
CLAUDE.md                                      Conventions repo
```

---

## 3. Flow « Ajout d'items dans la page BDT » — fichiers exacts

**Cible immédiate de port V2.** L'utilisateur ouvre `/inventaire/[bdcId]`,
clique sur un bouton « Ajouter pièces » (ou « Ajouter services »), un
modal s'ouvre avec une liste cochable groupée par catégorie, il
sélectionne ses items, ajuste les qtés, clique « Ajouter à la
sélection » → POST API → les lignes apparaissent dans la table BDT
(`BDCPanel`).

### Page et conteneur

| Fichier | Rôle |
|---|---|
| `app/inventaire/[id]/page.tsx` | Page server component qui charge le BDT, le client, et passe les props à `<BDCPanel>` |
| `components/bdc/BDCPanel.tsx` | Composant client qui rend la table services + pièces, gère l'ouverture des modals, dispatch les mutations via hook `useBDC` |

### Modals d'ajout

| Fichier | Rôle |
|---|---|
| `components/bdc/PiecesPopup.tsx` | **Modal pièces** : liste catalogue avec recherche+filtre catégorie, cases à cocher, qté éditable, persistance localStorage du draft pendant la session |
| `components/bdc/ServicesPopup.tsx` | **Modal services** : structure similaire pour les services du catalogue À LA CARTE |

### Composants enfants des modals

| Fichier | Rôle |
|---|---|
| `components/ui/Modal.tsx` | Wrapper générique basé sur `@headlessui/react Dialog` — radius 30px, backdrop blur, scroll lock |
| `components/ui/PillToggle.tsx` | Pills toggle si besoin (ex. SERVICES/PIÈCES dans le futur Modal unifié) |
| `components/ui/BarcodeScanner.tsx` | Scanner caméra zxing pour ajout par code-barre |

### API server

| Fichier | Rôle |
|---|---|
| `app/api/bdc/[id]/items/route.ts` | **POST `/api/bdc/[id]/items`** body `{ type: 'piece'\|'service', items: AddPieceInput[] \| AddServiceInput[] }` → appelle `insertPieces` ou `insertServices` puis `safeRecomputeStockState` |

### Couche data Sheets

| Fichier | Rôle |
|---|---|
| `lib/sheets/bdc.ts` | `insertPieces(bdcId, items)` (écrit lignes `BDC_TAG.ITEM` avec col O `PCE_ID` stable depuis cluster 1), `insertServices(bdcId, items)` (avec col I `SVC_ID`), `_safeInsertItemRows`, `_recalcTotaux` |
| `lib/sheets/reservation.ts` | `snapshotStock()` + `safeRecomputeStockState()` — invariant engagement AB/AC, recalcule reserved/engaged après chaque mutation |
| `lib/sheets/catalogue.ts` | `getPieces()`, `getServices()` — sources pour la recherche dans le modal |
| `lib/sheets/client.ts` | `BDC_COL` (mapping colonnes BDT), `TAB.BDC = 'BONS DE COMMANDES'`, `ROW.BDC_INS = 6` |

### Types

| Fichier | Types clés |
|---|---|
| `types/bdc.ts` | `BDCPieceItem`, `BDCServiceItem`, `BDCItem`, `AddPieceInput { pieceId?, nom, prix, qte, flag? }`, `AddServiceInput { serviceId?, nom, prix }`, `AddItemsPayload` |
| `types/catalogue.ts` | `Piece { pieceId, nom, prixBDC, prixVente, prixCost, stock, stockReserve, flag, sku, … }`, `Service { serviceId, label, prix, … }` |

### Hook côté client

| Fichier | Méthodes utilisées |
|---|---|
| `hooks/useBDC.ts` | `addItems(type, items)` → POST API + mutate SWR optimiste avec rollback en cas d'erreur |
| `hooks/useCatalogue.ts` | `usePieces()`, `useServices()` — caches SWR alimentant les modals |

### Helpers transversaux

| Fichier | Rôle |
|---|---|
| `lib/utils/pieces.ts` | `pieceKey()` (cluster 1), `pceNomClean()`, `stripIconPrefix()`, `normalizePieceName()` |
| `lib/utils/format.ts` | `frPrix(n)` (formatage `1 234,56 $`), `normSearch(s)` (search insensitive) |
| `lib/finances/taxes.ts` | `computeTaxes(sousTotal)` — QC 5%+9.975%, arrondi par taxe |

**Ordre de lecture recommandé pour le port** : page.tsx → BDCPanel.tsx
→ PiecesPopup.tsx → useBDC.ts addItems → app/api/bdc/[id]/items/route.ts
→ lib/sheets/bdc.ts insertPieces → types/bdc.ts.

---

## 4. Dépendances NPM clés du flow (mapping V2)

| V1 (dans le bundle) | Usage flow ajout items | Équivalent V2 (shadcn/Radix) |
|---|---|---|
| `@headlessui/react` v2.2 | Dialog (Modal.tsx), Transition | `@radix-ui/react-dialog` (shadcn `<Dialog>`) |
| `@heroicons/react` v2.2 | Icônes Trash/Plus/Check/… | `lucide-react` (déjà en V2) |
| `react-hook-form` v7.54 | Formulaires (PieceForm, ClientForm) | idem — déjà en V2 |
| `@hookform/resolvers` v3.10 | zod ↔ react-hook-form bridge | idem |
| `zod` v3.24 | Validation client + server | idem |
| `swr` v2.3 | Cache hooks (useBDC, useCatalogue) | `swr` ou `tanstack-query` — V2 peut garder SWR |
| `clsx` v2.1 | Concat conditional classnames | `clsx` ou `cn()` shadcn |
| `googleapis` v144 | API Sheets V1 backend | **NON applicable V2** — V2 utilise Prisma |
| `next-auth` v5 beta | Auth login | **Clerk en V2** — adapter session/userId |
| `@vercel/kv` v3 | Cache cross-lambda | V2 peut garder ou utiliser Postgres listen |
| `async-mutex` v0.5 | Mutex création BDT (anti double-clic) | utile à porter, lib disponible npm |

### Composants modal — patron à porter

`PiecesPopup` et `ServicesPopup` partagent une structure :

```
<Modal open onClose title="…" size="xl" fullHeight>
  <div className="flex flex-col flex-1 min-h-0" gap=12>
    /* Header frozen : recherche + filtres catégorie pills */
    <div shrink-0>...</div>
    /* Liste scrollable avec items cochables groupés par catégorie */
    <div flex-1 overflow-y-auto>
      {categories.map(cat => (
        <section key={cat}>
          <h3>{cat}</h3>
          {items.map(item => <CheckboxRow ... />)}
        </section>
      ))}
    </div>
    /* Footer frozen : compteur sélection + boutons Annuler/Ajouter */
    <div shrink-0>...</div>
  </div>
</Modal>
```

Le draft des sélections est persisté en `localStorage` (`pieces-popup-draft-${bdcId}`)
avec TTL 5 min — pattern utile à porter pour préserver l'état si l'user
navigue ailleurs et revient.

---

## 5. Invariants métier qui doivent survivre au port

Ces règles ne sont PAS toujours documentées dans le code — c'est la logique
mentale yako-san qui doit guider la session V2 :

### Remises

- **Stockées sur la ligne BON** (col I, format JSON) — pas par item
- Deux types de remise : `'pct'` (pourcentage 0-100) ou `'fixed'` (montant $ HT)
- Une remise pour les services, une pour les pièces (jamais les deux mélangées)
- Appliquées **avant** calcul taxes
- Persistées via `PATCH /api/bdc/[id]/remises` et `/api/ventes/[id]/facture`

### Taxes Québec

- TPS 5%, TVQ 9.975% — toujours calculées sur le sous-total HT
- Arrondi par taxe puis somme (cf `lib/finances/taxes.ts`) — pratique
  Revenu Québec (jamais arrondir le total directement)
- **Tous les prix stockés sont HT** — l'affichage TTC est calculé à la
  volée (cluster 3 item k a refondu le bloc Totaux BDT pour montrer
  les deux)
- Walk-in ventes : taxes incluses dans le prix affiché côté caisse,
  mais décomposées sur la facture

### Stock — modèle invariant engagement (v7.0.0+)

- **Col AB** = `stockPhysique` (sheet PIÈCES) — décrémenté SEULEMENT à
  la facturation (vente facturée ou BDT FACTURÉ)
- **Col AC** = `stockReserve` — recalculé en pur computed (pas un delta)
  à chaque mutation. Compte les BDT actifs dans `RESERVED_STATUSES` =
  `[APPROUVÉ, ON BENCH, CTRL QLTÉ, FINI, LIVRÉ]` + ventes brouillons
- Voir `lib/sheets/reservation.ts` pour le `_computeFromSource()`
- **`safeRecomputeStockState`** doit être appelé après TOUTE mutation
  qui touche BDT/Ventes/Inventaire — sinon AB/AC drift

### Statut d'évaluation BDT (evalStatus)

- Stocké col J de la ligne BON (séparé du `velo.status`)
- 5 valeurs : `''` (pas décidé), `'APPROUVE'`, `'REDUX'`, `'ATTENTE'`, `'REFUSE'`
- Backwards compat : si vide ET `checkOk=true` → APPROUVE
- Transitions auto : assigner un mécano à éval/méca/ctrl peut changer
  `velo.status` (cf `nextStatusOnAssign` dans `lib/utils/statuts.ts`)

### Prix 0 = « inclus » (cluster 4 item o)

- Un item de vente avec `prixUnit === 0` est considéré « inclus dans un
  forfait » (ex. chambre à air dans Urgence Flat à 30$ fixe)
- Le stock se décrémente quand même (qte > 0 suffit)
- Affichage : s/total montre `inclus` en italique grisé (`BDCPanel.tsx`
  + new vente modal + append vente modal)
- Pas de flag dédié — c'est juste `prixUnit === 0` qui déclenche le
  rendu

### Statut « payé » d'une vente (cluster 4 item m)

- Col P du sheet `_VENTES_` = `payeStatus` ('payé' ou vide)
- Distinct de `factureDate` (col J) = « facture émise »
- Une vente n'est archivable que si `payeStatus === 'payé'` ET `factureDate` présent
- Le bouton `<CheckCircleIcon>` toggle l'état dans l'UI

### Pièces : pieceId stable (cluster 1)

- Toute pièce du catalogue a un `pieceId` (col A PIÈCES, format
  `P00042`) — stable à travers les renames
- Les BDT écrivent maintenant `pieceId` en **col O** de BDT (sheet
  `BONS DE COMMANDES`)
- **Helper canonical** : `pieceKey({ pieceId?, nom })` dans
  `lib/utils/pieces.ts` — retourne `'id:P00042'` si pieceId, sinon
  `'nom:<normalisé>'`. Symétrique producer/consumer.
- Les consumers (stock reservation, PO matching, BDCPanel display) ont
  été refactorés pour utiliser cette clé en priorité (cluster 1 phase B)
- **V2 a déjà le bon modèle Prisma** (Bdc.items[].piece FK) — pas besoin
  de cette gymnastique, mais le **principe** reste : ne jamais matcher
  par nom seul.

### Services : même pattern, serviceId stable

- Col A SERVICES = `serviceId` (format `S00042`)
- Stocké col I de BDT (`SVC_ID`) depuis longtemps (avant cluster 1)
- Ventes : les services dans une vente ont leur `pieceId` (champ générique)
  rempli avec le `serviceId` (S-préfixé). Convention reconnue par
  `lib/sheets/ventes.ts:_adjustStock` qui skip les S-préfixés (pas de
  stock pour services).

### Couleur statuts vélo

- `lib/utils/statuts.ts:STATUTS` — palette fixe, sens métier strict
- Cluster 3 item h : `ÉVAL.` est passé de vert `#88fa4e` à jaune
  `#fff056` et a rejoint `RV`/`REÇU` dans le groupe NOUVEAU (en tête
  d'inventaire)
- **Ne PAS toucher** ces couleurs sans demander à yako-san — chaque
  couleur a une signification opérationnelle en atelier

---

## 6. Notes de sécurité

✅ **Vérifié au moment du zip** :

- Aucun fichier `.env*` inclus
- Aucun JSON de credentials (`client_secret_*.json`, `flex-rev-*.json`)
- Aucun token OAuth, refresh token, ou clé API hardcodés dans le code
  (vérifié par grep sur patterns Google `AIza`, `ya29.`, `1[A-Za-z0-9_-]{43,}`)
- Aucun SHEET_ID hardcodé — tous chargés depuis `process.env` via
  `SHEET_IDS` dans `lib/sheets/client.ts`

❌ **Fichiers exclus volontairement** (à demander à yako-san si besoin) :

- `.env.local` — contient `GOOGLE_CLIENT_ID`, `GOOGLE_PRIVATE_KEY`,
  `SHEETS_*_ID`, `NEXTAUTH_SECRET`, `OWNER_REFRESH_TOKEN`, `KV_REST_API_*`
- `.env.example` + `.env.local.example` — templates sans secrets, mais
  exclus par prudence (style suffit)
- `client_secret_*.googleusercontent.com.json` — credentials OAuth Google
- `flex-rev-*.json` — service account GCP
- `node_modules/`, `.next/`, `.git/`, `.vercel/`
- `docs/` (82 MB de screenshots) — V2 a déjà la copie dans
  `docs/v1-reference/`

---

## 7. Pour démarrer côté V2

1. Décompresser le zip → `flex-v1-source/`
2. Lire ce INDEX.md (déjà fait si tu lis ces lignes)
3. Pour le port du modal d'ajout d'items spécifiquement, lire dans l'ordre :
   - `app/inventaire/[id]/page.tsx`
   - `components/bdc/BDCPanel.tsx`
   - `components/bdc/PiecesPopup.tsx`
   - `components/bdc/ServicesPopup.tsx`
   - `hooks/useBDC.ts`
   - `app/api/bdc/[id]/items/route.ts`
   - `lib/sheets/bdc.ts` (juste les fonctions `insertPieces` et `insertServices`)
   - `types/bdc.ts`
4. Pour les conventions générales code/UI, lire `CLAUDE.md` + `README.md`
   à la racine du zip
5. Pour le contexte des changements récents post-`v1.0.0`, demander à
   yako-san le doc `CHANGES-CLUSTER-SESSION-2026-05-16.md` qui vit
   dans le repo V1 privé (ou le repo V2 public sous
   `docs/handoff/CHANGES-CLUSTER-SESSION-2026-05-16.md`)

---

**Préparé en autopilote** — yako-san fera le commit dans
`yako-san/flex-handoff-public` sous `bundles/flex-v1-source-2026-05-20.zip`,
OU drop direct dans le chat V2.
